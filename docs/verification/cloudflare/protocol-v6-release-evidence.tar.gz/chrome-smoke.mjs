import { createRequire } from 'node:module';
import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
const require = createRequire('/Users/duke/Dev/Personal/colonist-p2p/apps/web/package.json');
const { chromium, expect } = require('@playwright/test');
const output = '/private/tmp/hexfield-v6-live-smoke';
const contexts = [];
const pages = [];
const pageErrorNames = [];
const result = { scope: 'Production UI, two isolated Chrome profiles; setup and peer-accepted placement only', boardVisible: [], otherInitiallyWaiting: false, actingSettlementConfirmed: false, actingRoadConfirmed: false, otherBoardEnabledAfterActingRoad: false, pageErrorNames };
let profileRoot;
let deadline;
const run = async () => {
  profileRoot = await mkdtemp(join(tmpdir(), 'hexfield-live-release-'));
  for (const name of ['host', 'guest']) {
    const context = await chromium.launchPersistentContext(join(profileRoot, name), { channel: 'chrome', headless: true, viewport: { width: 1280, height: 900 }, locale: 'en-US' });
    contexts.push(context);
    const page = await context.newPage();
    page.setDefaultTimeout(10_000);
    page.on('pageerror', (error) => pageErrorNames.push(error.name));
    pages.push(page);
  }
  const [host, guest] = pages;
  result.stage = 'create';
  await host.goto('https://hexfield.steenbakkers.cc/#/online/create');
  await host.getByLabel('Room name').fill(`Releasecheck ${Date.now()}`);
  await host.getByLabel('Your player name').fill('Release host');
  await host.getByText('Advanced connection options', { exact: true }).click();
  await host.getByLabel('Invite friends with').selectOption('server');
  await host.getByLabel('Player count').selectOption('2');
  await host.getByRole('button', { name: 'Create room', exact: true }).click();
  const invite = host.getByRole('textbox', { name: /^Invitation link/ });
  await expect(invite).toBeVisible();
  result.stage = 'join';
  await guest.goto(await invite.inputValue());
  await guest.getByRole('button', { name: 'Take seat', exact: true }).first().click();
  await expect(guest.getByRole('button', { name: 'Ready up', exact: true })).toBeVisible();
  await host.getByRole('button', { name: 'Ready up', exact: true }).click();
  await guest.getByRole('button', { name: 'Ready up', exact: true }).click();
  await expect(host.getByRole('button', { name: 'Start game', exact: true })).toBeEnabled({ timeout: 20_000 });
  result.stage = 'start';
  await host.getByRole('button', { name: 'Start game', exact: true }).click();
  await Promise.all(pages.map((page) => expect(page).toHaveURL(/\/game\/[^/]+$/, { timeout: 60_000 })));
  const hostBoard = host.getByTestId('board-renderer');
  const guestBoard = guest.getByTestId('board-renderer');
  for (const page of pages) {
    await expect(page.getByTestId('board-renderer')).toBeVisible();
    await expect(page.getByTestId('board-renderer').locator('canvas')).toBeVisible();
    result.boardVisible.push(true);
  }
  await expect.poll(async () => Promise.all([hostBoard, guestBoard].map((board) => board.getAttribute('tabindex'))), { timeout: 20_000 }).toContain('0');
  const hostActs = (await hostBoard.getAttribute('tabindex')) === '0';
  const actor = hostActs ? host : guest;
  const actorBoard = hostActs ? hostBoard : guestBoard;
  const otherBoard = hostActs ? guestBoard : hostBoard;
  result.initialActor = hostActs ? 'host' : 'guest';
  await expect(otherBoard).toHaveAttribute('tabindex', '-1');
  result.otherInitiallyWaiting = true;
  for (const piece of ['settlement', 'road']) {
    result.stage = `acting-${piece}`;
    await expect(actorBoard).toHaveAttribute('tabindex', '0', { timeout: 20_000 });
    await actorBoard.focus();
    await actorBoard.press('Home');
    await actorBoard.press('Enter');
    const confirm = actor.getByRole('button', { name: `Confirm ${piece}`, exact: true });
    await expect(confirm).toBeVisible();
    await confirm.click();
    await expect(confirm).toHaveCount(0, { timeout: 20_000 });
    if (piece === 'settlement') result.actingSettlementConfirmed = true;
    else result.actingRoadConfirmed = true;
  }
  result.stage = 'peer-accepted-move';
  await expect(otherBoard).toHaveAttribute('tabindex', '0', { timeout: 20_000 });
  result.otherBoardEnabledAfterActingRoad = true;
  expect(pageErrorNames).toEqual([]);
};
await mkdir(output, { recursive: true });
try {
  await Promise.race([run(), new Promise((_, reject) => { deadline = setTimeout(() => reject(new Error('Release smoke exceeded 120 seconds')), 120_000); })]);
  result.result = 'PASS';
} catch (error) {
  result.result = 'FAIL';
  result.failureName = error.name;
  // Screenshots deliberately mask invitation/code text, including any lobby failure.
  await Promise.allSettled(pages.map((page, index) => page.screenshot({ path: join(output, `failure-${index}.png`), mask: [page.locator('textarea'), page.getByRole('textbox', { name: /^Invitation link/ })] })));
  process.exitCode = 1;
} finally {
  clearTimeout(deadline);
  await Promise.allSettled(contexts.map((context) => context.close()));
  if (profileRoot) await rm(profileRoot, { recursive: true, force: true });
  await writeFile(join(output, 'result.json'), JSON.stringify(result, null, 2) + '\n');
  process.stdout.write(JSON.stringify(result) + '\n');
}

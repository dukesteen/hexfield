# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mixed-engine-online.e2e.ts >> four mixed-engine contexts finish a manual-relay full-mesh game with matching audits
- Location: tests/mixed-engine-online.e2e.ts:1006:1

# Error details

```
Test timeout of 300000ms exceeded.
```
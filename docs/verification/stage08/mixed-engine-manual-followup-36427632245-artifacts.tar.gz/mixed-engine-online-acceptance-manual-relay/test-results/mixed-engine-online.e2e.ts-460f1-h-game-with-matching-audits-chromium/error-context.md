# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mixed-engine-online.e2e.ts >> four mixed-engine contexts finish a manual-relay full-mesh game with matching audits
- Location: tests/mixed-engine-online.e2e.ts:1053:1

# Error details

```
Error: Mixed-engine manual acceptance failed. Sanitized peer/lobby diagnostics: [{"engine":"chromium-a","route":"http://127.0.0.1:5310/#/game/JohAXIYDoh0GTWRvH-7biV","alerts":[],"diagnosticEvents":[{"atMs":7552,"source":"signal-description","from":"gq1I-DHT6jUZ","to":"O3fw_bZeejgB","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":2,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":457,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":14300,"source":"signal-description","from":"gq1I-DHT6jUZ","to":"KseFRmgDOZsu","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":4,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":435,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":28835,"source":"signal-description","from":"gq1I-DHT6jUZ","to":"aRHiBfQAkjaw","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":5,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":28889,"source":"signal-description","from":"gq1I-DHT6jUZ","to":"aRHiBfQAkjaw","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":6,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":457,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":3,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"host"},{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"O3fw_bZeejgB","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"KseFRmgDOZsu","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"aRHiBfQAkjaw","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":"playing","lobbyStatus":"starting","humanCount":4,"manual":{"phase":"connected","gatheringComplete":false,"hasCode":false},"closed":false,"game":{"head":{"hash":"fc9e15e23a8ccf326e3236ab87ad5e7ad1fc29b74ad8b402b1d85b8da54770b9","seq":144},"phase":"stealResult","turn":25,"activeSeat":3,"controlledSeats":[0],"pending":[{"kind":"random"},{"kind":"player","seat":3,"allowed":["CLAIM_VICTORY"]}],"resultPresent":false,"audit":"not-started"}},{"engine":"chromium-b","route":"http://127.0.0.1:5310/#/game/JohAXIYDoh0GTWRvH-7biV","alerts":[],"diagnosticEvents":[{"atMs":5209,"source":"manual-rtc","stage":"setRemoteDescription","outcome":"fulfilled"},{"atMs":5210,"source":"manual-rtc","stage":"setLocalDescription","outcome":"fulfilled"},{"atMs":5220,"source":"manual-open","stage":"complete"},{"atMs":5234,"source":"signal-description","from":"O3fw_bZeejgB","to":"gq1I-DHT6jUZ","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":13196,"source":"signal-description","from":"O3fw_bZeejgB","to":"KseFRmgDOZsu","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":2,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":435,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":29657,"source":"signal-description","from":"O3fw_bZeejgB","to":"aRHiBfQAkjaw","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":3,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"host"},{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"gq1I-DHT6jUZ","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"KseFRmgDOZsu","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"aRHiBfQAkjaw","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":"playing","lobbyStatus":"starting","humanCount":4,"manual":{"phase":"connected","gatheringComplete":true,"hasCode":false},"closed":false,"game":{"head":{"hash":"fc9e15e23a8ccf326e3236ab87ad5e7ad1fc29b74ad8b402b1d85b8da54770b9","seq":144},"phase":"stealResult","turn":25,"activeSeat":3,"controlledSeats":[1],"pending":[{"kind":"random"},{"kind":"player","seat":3,"allowed":["CLAIM_VICTORY"]}],"resultPresent":false,"audit":"not-started"}},{"engine":"firefox","route":"http://127.0.0.1:5310/#/game/JohAXIYDoh0GTWRvH-7biV","alerts":[],"diagnosticEvents":[{"atMs":5735,"source":"manual-rtc","stage":"setRemoteDescription","outcome":"fulfilled"},{"atMs":5736,"source":"manual-rtc","stage":"setLocalDescription","outcome":"fulfilled"},{"atMs":5792,"source":"manual-open","stage":"complete"},{"atMs":5852,"source":"signal-description","from":"KseFRmgDOZsu","to":"gq1I-DHT6jUZ","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":504,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":6106,"source":"signal-description","from":"KseFRmgDOZsu","to":"gq1I-DHT6jUZ","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":810,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":6944,"source":"signal-description","from":"KseFRmgDOZsu","to":"O3fw_bZeejgB","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":2,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":503,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":7210,"source":"signal-description","from":"KseFRmgDOZsu","to":"O3fw_bZeejgB","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":2,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":809,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":23847,"source":"signal-description","from":"KseFRmgDOZsu","to":"aRHiBfQAkjaw","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":504,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":3,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"gq1I-DHT6jUZ","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"O3fw_bZeejgB","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"aRHiBfQAkjaw","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":"playing","lobbyStatus":"starting","humanCount":4,"manual":{"phase":"connected","gatheringComplete":true,"hasCode":false},"closed":false,"game":{"head":{"hash":"fc9e15e23a8ccf326e3236ab87ad5e7ad1fc29b74ad8b402b1d85b8da54770b9","seq":144},"phase":"stealResult","turn":25,"activeSeat":3,"controlledSeats":[2],"pending":[{"kind":"random"},{"kind":"player","seat":3,"allowed":["CLAIM_VICTORY"]}],"resultPresent":false,"audit":"not-started"}},{"engine":"webkit","route":"http://127.0.0.1:5310/#/game/JohAXIYDoh0GTWRvH-7biV","alerts":[],"diagnosticEvents":[{"atMs":8821,"source":"manual-rtc","stage":"setRemoteDescription","outcome":"fulfilled"},{"atMs":8824,"source":"manual-rtc","stage":"setLocalDescription","outcome":"fulfilled"},{"atMs":12820,"source":"manual-open","stage":"complete"},{"atMs":12845,"source":"signal-description","from":"aRHiBfQAkjaw","to":"gq1I-DHT6jUZ","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":13486,"source":"signal-description","from":"aRHiBfQAkjaw","to":"gq1I-DHT6jUZ","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":719,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":16555,"source":"signal-description","from":"aRHiBfQAkjaw","to":"O3fw_bZeejgB","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":2,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":457,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":16709,"source":"signal-description","from":"aRHiBfQAkjaw","to":"KseFRmgDOZsu","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":3,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":435,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":3,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"gq1I-DHT6jUZ","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"O3fw_bZeejgB","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"KseFRmgDOZsu","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":"playing","lobbyStatus":"starting","humanCount":4,"manual":{"phase":"connected","gatheringComplete":false,"hasCode":false},"closed":false,"game":{"head":{"hash":"fc9e15e23a8ccf326e3236ab87ad5e7ad1fc29b74ad8b402b1d85b8da54770b9","seq":144},"phase":"stealResult","turn":25,"activeSeat":3,"controlledSeats":[3],"pending":[{"kind":"random"},{"kind":"player","seat":3,"allowed":["CLAIM_VICTORY"]}],"resultPresent":false,"audit":"not-started"}}]
```

# Test source

```ts
  927  |           peers = views.map((view) => ({
  928  |             head: view?.head ?? null,
  929  |             resultPresent: Boolean(view?.result),
  930  |             audit: view?.audit?.kind ?? null,
  931  |           }));
  932  |           if (views.every((view) => view?.result)) terminalAt ??= Date.now();
  933  |           onProgress(diagnostic());
  934  |           return views.every((view) => view?.result && view.audit?.kind === 'complete');
  935  |         },
  936  |         { timeout: 150_000, intervals: [100] },
  937  |       )
  938  |       .toBe(true);
  939  |   } catch (error) {
  940  |     throw new Error(`Mixed-engine play/audit driver: ${JSON.stringify(diagnostic())}`, {
  941  |       cause: error,
  942  |     });
  943  |   }
  944  |   const final = await Promise.all(pages.map((page) => inspectGame(page, gameId)));
  945  |   const head = final[0]?.head;
  946  |   const result = final[0]?.result;
  947  |   if (!head || !result) throw new Error('Missing audited terminal state');
  948  |   for (const view of final) {
  949  |     expect(view?.head).toEqual(head);
  950  |     expect(view?.result).toEqual(result);
  951  |     expect(view?.audit).toMatchObject({ kind: 'complete', report: { ok: true, complete: true } });
  952  |     expect(view?.peerCount).toBe(3);
  953  |   }
  954  |   return { ...diagnostic(), terminalSeq: head.seq, modeAuditCount: final.length };
  955  | }
  956  | 
  957  | async function runMode(playwright: Playwright, mode: 'signaling' | 'manual') {
  958  |   const opened = await launchFourEngines(playwright);
  959  |   const [host, second, third, fourth] = opened.pages;
  960  |   if (!host || !second || !third || !fourth) throw new Error('Missing mixed-engine page');
  961  |   const errors: EngineName[] = [];
  962  |   for (const [index, page] of opened.pages.entries()) {
  963  |     const engine = engineNames[index];
  964  |     if (!engine) throw new Error('Missing browser engine label');
  965  |     page.on('pageerror', () => errors.push(engine));
  966  |   }
  967  |   const started = Date.now();
  968  |   let phase = 'lobby';
  969  |   let readingProgress = false;
  970  |   let finishProgress: FinishProgress | null = null;
  971  |   const emitProgress = (peers?: unknown) => {
  972  |     process.stdout.write(
  973  |       `${JSON.stringify({ mode, phase, elapsedMs: Date.now() - started, finish: finishProgress, peers })}\n`,
  974  |     );
  975  |   };
  976  |   const setPhase = (next: string) => {
  977  |     phase = next;
  978  |     emitProgress();
  979  |   };
  980  |   emitProgress();
  981  |   // A runner-level timeout can interrupt the catch block itself. Retain public
  982  |   // progress during the run, without private hands, SDP, candidates or keys.
  983  |   const progress = setInterval(() => {
  984  |     if (readingProgress) return;
  985  |     readingProgress = true;
  986  |     void Promise.all(
  987  |       opened.pages.map(async (page, index) => ({
  988  |         engine: engineNames[index],
  989  |         ...(await readRoom(page, true).catch(() => ({ unavailable: true }))),
  990  |       })),
  991  |     )
  992  |       .then((peers) => {
  993  |         emitProgress(peers);
  994  |         return undefined;
  995  |       })
  996  |       .finally(() => {
  997  |         readingProgress = false;
  998  |       });
  999  |   }, 10_000);
  1000 |   try {
  1001 |     const fixture = await startFourPlayerRoom(opened.pages, mode);
  1002 |     const lobbyElapsedMs = Date.now() - started;
  1003 |     setPhase('setup');
  1004 |     const setupStarted = Date.now();
  1005 |     await certifyPostSetupMove(opened.pages, fixture.gameId);
  1006 |     const setupElapsedMs = Date.now() - setupStarted;
  1007 |     setPhase('play-and-audit');
  1008 |     const completion = await finishAndAudit(opened.pages, fixture.gameId, (snapshot) => {
  1009 |       finishProgress = snapshot;
  1010 |       if (
  1011 |         snapshot.peers.length === opened.pages.length &&
  1012 |         snapshot.peers.every((peer) => peer.resultPresent) &&
  1013 |         phase !== 'audit'
  1014 |       )
  1015 |         setPhase('audit');
  1016 |     });
  1017 |     setPhase('complete');
  1018 |     expect(errors).toEqual([]);
  1019 |     return { mode, browserSet: engineNames, lobbyElapsedMs, setupElapsedMs, ...completion };
  1020 |   } catch (error) {
  1021 |     const diagnostics = await Promise.all(
  1022 |       opened.pages.map(async (page, index) => ({
  1023 |         engine: engineNames[index],
  1024 |         ...(await readRoom(page, true).catch(() => null)),
  1025 |       })),
  1026 |     );
> 1027 |     throw new Error(
       |           ^ Error: Mixed-engine manual acceptance failed. Sanitized peer/lobby diagnostics: [{"engine":"chromium-a","route":"http://127.0.0.1:5310/#/game/JohAXIYDoh0GTWRvH-7biV","alerts":[],"diagnosticEvents":[{"atMs":7552,"source":"signal-description","from":"gq1I-DHT6jUZ","to":"O3fw_bZeejgB","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":2,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":457,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":14300,"source":"signal-description","from":"gq1I-DHT6jUZ","to":"KseFRmgDOZsu","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":4,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":435,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":28835,"source":"signal-description","from":"gq1I-DHT6jUZ","to":"aRHiBfQAkjaw","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":5,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":28889,"source":"signal-description","from":"gq1I-DHT6jUZ","to":"aRHiBfQAkjaw","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":6,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":457,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":3,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"host"},{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"O3fw_bZeejgB","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"KseFRmgDOZsu","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"aRHiBfQAkjaw","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":"playing","lobbyStatus":"starting","humanCount":4,"manual":{"phase":"connected","gatheringComplete":false,"hasCode":false},"closed":false,"game":{"head":{"hash":"fc9e15e23a8ccf326e3236ab87ad5e7ad1fc29b74ad8b402b1d85b8da54770b9","seq":144},"phase":"stealResult","turn":25,"activeSeat":3,"controlledSeats":[0],"pending":[{"kind":"random"},{"kind":"player","seat":3,"allowed":["CLAIM_VICTORY"]}],"resultPresent":false,"audit":"not-started"}},{"engine":"chromium-b","route":"http://127.0.0.1:5310/#/game/JohAXIYDoh0GTWRvH-7biV","alerts":[],"diagnosticEvents":[{"atMs":5209,"source":"manual-rtc","stage":"setRemoteDescription","outcome":"fulfilled"},{"atMs":5210,"source":"manual-rtc","stage":"setLocalDescription","outcome":"fulfilled"},{"atMs":5220,"source":"manual-open","stage":"complete"},{"atMs":5234,"source":"signal-description","from":"O3fw_bZeejgB","to":"gq1I-DHT6jUZ","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":13196,"source":"signal-description","from":"O3fw_bZeejgB","to":"KseFRmgDOZsu","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":2,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":435,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":29657,"source":"signal-description","from":"O3fw_bZeejgB","to":"aRHiBfQAkjaw","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":3,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"host"},{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"gq1I-DHT6jUZ","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"KseFRmgDOZsu","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"aRHiBfQAkjaw","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":"playing","lobbyStatus":"starting","humanCount":4,"manual":{"phase":"connected","gatheringComplete":true,"hasCode":false},"closed":false,"game":{"head":{"hash":"fc9e15e23a8ccf326e3236ab87ad5e7ad1fc29b74ad8b402b1d85b8da54770b9","seq":144},"phase":"stealResult","turn":25,"activeSeat":3,"controlledSeats":[1],"pending":[{"kind":"random"},{"kind":"player","seat":3,"allowed":["CLAIM_VICTORY"]}],"resultPresent":false,"audit":"not-started"}},{"engine":"firefox","route":"http://127.0.0.1:5310/#/game/JohAXIYDoh0GTWRvH-7biV","alerts":[],"diagnosticEvents":[{"atMs":5735,"source":"manual-rtc","stage":"setRemoteDescription","outcome":"fulfilled"},{"atMs":5736,"source":"manual-rtc","stage":"setLocalDescription","outcome":"fulfilled"},{"atMs":5792,"source":"manual-open","stage":"complete"},{"atMs":5852,"source":"signal-description","from":"KseFRmgDOZsu","to":"gq1I-DHT6jUZ","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":504,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":6106,"source":"signal-description","from":"KseFRmgDOZsu","to":"gq1I-DHT6jUZ","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":810,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":6944,"source":"signal-description","from":"KseFRmgDOZsu","to":"O3fw_bZeejgB","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":2,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":503,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":7210,"source":"signal-description","from":"KseFRmgDOZsu","to":"O3fw_bZeejgB","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":2,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":809,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":23847,"source":"signal-description","from":"KseFRmgDOZsu","to":"aRHiBfQAkjaw","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":504,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":3,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"gq1I-DHT6jUZ","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"O3fw_bZeejgB","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"aRHiBfQAkjaw","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":"playing","lobbyStatus":"starting","humanCount":4,"manual":{"phase":"connected","gatheringComplete":true,"hasCode":false},"closed":false,"game":{"head":{"hash":"fc9e15e23a8ccf326e3236ab87ad5e7ad1fc29b74ad8b402b1d85b8da54770b9","seq":144},"phase":"stealResult","turn":25,"activeSeat":3,"controlledSeats":[2],"pending":[{"kind":"random"},{"kind":"player","seat":3,"allowed":["CLAIM_VICTORY"]}],"resultPresent":false,"audit":"not-started"}},{"engine":"webkit","route":"http://127.0.0.1:5310/#/game/JohAXIYDoh0GTWRvH-7biV","alerts":[],"diagnosticEvents":[{"atMs":8821,"source":"manual-rtc","stage":"setRemoteDescription","outcome":"fulfilled"},{"atMs":8824,"source":"manual-rtc","stage":"setLocalDescription","outcome":"fulfilled"},{"atMs":12820,"source":"manual-open","stage":"complete"},{"atMs":12845,"source":"signal-description","from":"aRHiBfQAkjaw","to":"gq1I-DHT6jUZ","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":13486,"source":"signal-description","from":"aRHiBfQAkjaw","to":"gq1I-DHT6jUZ","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":719,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":16555,"source":"signal-description","from":"aRHiBfQAkjaw","to":"O3fw_bZeejgB","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":2,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":457,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":16709,"source":"signal-description","from":"aRHiBfQAkjaw","to":"KseFRmgDOZsu","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":3,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":435,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":3,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"gq1I-DHT6jUZ","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"O3fw_bZeejgB","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"KseFRmgDOZsu","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":"playing","lobbyStatus":"starting","humanCount":4,"manual":{"phase":"connected","gatheringComplete":false,"hasCode":false},"closed":false,"game":{"head":{"hash":"fc9e15e23a8ccf326e3236ab87ad5e7ad1fc29b74ad8b402b1d85b8da54770b9","seq":144},"phase":"stealResult","turn":25,"activeSeat":3,"controlledSeats":[3],"pending":[{"kind":"random"},{"kind":"player","seat":3,"allowed":["CLAIM_VICTORY"]}],"resultPresent":false,"audit":"not-started"}}]
  1028 |       `Mixed-engine ${mode} acceptance failed. Sanitized peer/lobby diagnostics: ${JSON.stringify(diagnostics)}`,
  1029 |       { cause: error },
  1030 |     );
  1031 |   } finally {
  1032 |     clearInterval(progress);
  1033 |     await Promise.allSettled(opened.contexts.map((context) => context.close()));
  1034 |     await Promise.allSettled(opened.browsers.map((browser) => browser.close()));
  1035 |   }
  1036 | }
  1037 | 
  1038 | test('four mixed-engine contexts finish a signaling full-mesh game with matching audits', async ({
  1039 |   playwright,
  1040 | }, testInfo) => {
  1041 |   test.skip(
  1042 |     process.env.CP2P_MIXED_ENGINE_MODE !== 'signaling',
  1043 |     'The workflow runs one connection mode per job',
  1044 |   );
  1045 |   test.setTimeout(240_000);
  1046 |   const result = await runMode(playwright, 'signaling');
  1047 |   await testInfo.attach('mixed-engine-summary', {
  1048 |     body: JSON.stringify(result, null, 2),
  1049 |     contentType: 'application/json',
  1050 |   });
  1051 | });
  1052 | 
  1053 | test('four mixed-engine contexts finish a manual-relay full-mesh game with matching audits', async ({
  1054 |   playwright,
  1055 | }, testInfo) => {
  1056 |   test.skip(
  1057 |     process.env.CP2P_MIXED_ENGINE_MODE !== 'manual-relay',
  1058 |     'The workflow runs one connection mode per job',
  1059 |   );
  1060 |   test.setTimeout(300_000);
  1061 |   const result = await runMode(playwright, 'manual');
  1062 |   await testInfo.attach('mixed-engine-summary', {
  1063 |     body: JSON.stringify(result, null, 2),
  1064 |     contentType: 'application/json',
  1065 |   });
  1066 | });
  1067 | 
```
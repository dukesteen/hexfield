Read-only review. Do not use tools. User chose Claude Opus 5.5 at medium effort.
We need one trustworthy, short four-engine integration game, real rules/proofs/audits. Production v6 is now deployed after passing signaling four-engine complete game + clean audits, all9 realcrypto scenarios, persistence/recovery, and live 2ChromeUI smoke. Manual fullmesh works, but wholegame CI deadline varies. User says stop wasteful long/repeated tests and prioritize a usable release. We will not rerun unchanged tests until lucky.
Evidence:
- Prior current-source manual run: setup finished ~152s, all4 terminal/audits verifying by290s, outer300s expired; complete audit unobserved.
- We fixed bot config identity reset in test-only structured-clone views, retaining stable owned config. Production untouched.
- Latest 836fb11 requests real reduced motion with 4 renderers. At ~110s entered play. 150s finish predicate timeout (NOT overall300 timeout). Last all4 certified head seq144 samehash, no terminal/audits not-started, no refusals. Census81 acceptedcommands:END_TURN24,ROLL_DICE24,BUILD_ROAD2,OFFER_TRADE3,RESPOND_TRADE9,MOVE_ROBBER5,STEAL5,MARITIME_TRADE1,DISCARD7,CANCEL_TRADE1. No BUILD_CITY/SETTLEMENT. Legal/proof checks pass, progressing but random bot not winning quickly.
- Setup botrng isfixed perplayer, but live verified board/dice entropy remains genuinely random. Stable config alone does not make whole game deterministic.
- Numeric150/240/300limits are harness bounds, not docs08/09 product timing targets. User approved bounded test counts, not silent timeout inflation.
- We noticed once terminal, currentdriver needlessly fetches fullprivate/state/legal8timesperpoll while4auditsrun. A thin public-only audit reader is obvious cleanup but cannot fix latest nonterminal timeout.
Question: recommend smallest principled one-time driver correction rather than more retries/optimization theater. Should we use a legal goal-directed test-only policy to immediately build VP, do only useful maritime trades, avoid player offers (covered elsewhere), and use production RandomBot for interrupt choices? Or restructure explicit play/audit time budgets, or both? Give concrete minimal algorithm using existing legal command enumeration, ownhand only, no force dice/resources/results/replay shortcuts, no lower3VPtarget, no disabledproofs/renderers/audit assertions. Discuss setup selection resource diversity/citygoal and starvation. Explain what is actually evidenced vs inferred. Need bounded meaningful targeted unit regression for policy, then oneCI manualrun; do not demand huge repeats. Flag any coverage weakened and exactbounds proposal only if justified. Limit response~1500words.


FILE apps/web/tests/mixed-engine-online.e2e.ts
/* eslint-disable no-await-in-loop -- Membership and game commands depend on prior certified state. */
import { expect, test } from '@playwright/test';
import type { Browser, BrowserContext, Page, PlaywrightWorkerArgs } from '@playwright/test';
import { RandomBot, createBotRng } from '@cp2p/bots';
import { chooseBotPending } from '@cp2p/protocol';
import type { CommandShape, Seat } from '@cp2p/engine';
import { stableBotConfig } from './helpers/stable-bot-config.js';

test.skip(
  process.env.CP2P_MIXED_ENGINE_ACCEPTANCE !== '1',
  'Manual mixed-engine acceptance runs only from its opt-in workflow',
);

const signalingUrl = 'ws://127.0.0.1:8909';
const appBaseUrl = `http://127.0.0.1:${process.env.PLAYWRIGHT_TEST_PORT ?? '5187'}`;
const engineNames = ['chromium-a', 'chromium-b', 'firefox', 'webkit'] as const;
type EngineName = (typeof engineNames)[number];
type Playwright = PlaywrightWorkerArgs['playwright'];
const registryPaths = new WeakMap<Page, string>();
const diagnosticKey = '__cp2pMixedEngineDiagnostics';

interface OpenedBrowserSet {
  readonly browsers: readonly Browser[];
  readonly contexts: readonly BrowserContext[];
  readonly pages: readonly Page[];
}

async function launchFourEngines(playwright: Playwright): Promise<OpenedBrowserSet> {
  const browsers: Browser[] = [];
  const contexts: BrowserContext[] = [];
  try {
    const chromium = await playwright.chromium.launch({ headless: true });
    browsers.push(chromium);
    const firefox = await playwright.firefox.launch({ headless: true });
    browsers.push(firefox);
    const webkit = await playwright.webkit.launch({ headless: true });
    browsers.push(webkit);
    const contextOptions = {
      baseURL: appBaseUrl,
      reducedMotion: 'reduce',
      viewport: { width: 1280, height: 900 },
    } as const;
    const first = await chromium.newContext(contextOptions);
    contexts.push(first);
    const second = await chromium.newContext(contextOptions);
    contexts.push(second);
    const third = await firefox.newContext(contextOptions);
    contexts.push(third);
    const fourth = await webkit.newContext(contextOptions);
    contexts.push(fourth);
    await Promise.all(
      contexts.map(async (context) => {
        context.setDefaultTimeout(15_000);
        context.setDefaultNavigationTimeout(30_000);
        await context.addInitScript(() => performance.setResourceTimingBufferSize(5_000));
      }),
    );
    return {
      browsers,
      contexts,
      pages: await Promise.all(contexts.map((context) => context.newPage())),
    };
  } catch (error) {
    await Promise.allSettled(contexts.map((context) => context.close()));
    await Promise.allSettled(browsers.map((browser) => browser.close()));
    throw error;
  }
}

async function roomModulePath(page: Page): Promise<string> {
  const cached = registryPaths.get(page);
  if (cached) return cached;
  const path = await page.evaluate(() =>
    performance
      .getEntriesByType('resource')
      .map((entry) => entry.name)
      .find((name) => new URL(name).pathname.endsWith('/room-registry.ts')),
  );
  if (!path) throw new Error('The loaded app room registry is unavailable');
  const url = new URL(path);
  const loadedPath = url.pathname + url.search;
  registryPaths.set(page, loadedPath);
  return loadedPath;
}

async function installFailureDiagnostics(page: Page): Promise<void> {
  const modules = () =>
    page.evaluate(() => {
      const resources = performance
        .getEntriesByType('resource')
        .map((entry) => entry.name)
        .map((name) => ({ name, path: new URL(name).pathname }));
      return {
        room: resources.find(({ path }) => /\/online-room\.(?:ts|js)$/.test(path))?.name ?? null,
        peerLink: resources.find(({ path }) => /\/peer-link\.(?:ts|js)$/.test(path))?.name ?? null,
        codec: resources.find(({ path }) => /\/canonical\.(?:ts|js)$/.test(path))?.name ?? null,
        envelope:
          resources.find(({ path }) => /\/signaling-envelope\.(?:ts|js)$/.test(path))?.name ?? null,
      };
    });
  try {
    await expect
      .poll(
        async () => {
          const paths = await modules();
          return Boolean(paths.room && paths.peerLink);
        },
        { timeout: 10_000 },
      )
      .toBe(true);
  } catch {
    const filenames = await page.evaluate(() =>
      performance
        .getEntriesByType('resource')
        .map((entry) => new URL(entry.name).pathname.split('/').at(-1) ?? '')
        .filter(Boolean)
        .toSorted()
        .slice(-50),
    );
    throw new Error(
      `Mixed-engine diagnostics could not find the loaded room and peer modules after UI readiness; loaded module filenames: ${filenames.join(', ') || 'none'}`,
    );
  }
  const paths = await modules();
  if (!paths.room || !paths.peerLink)
    throw new Error('Mixed-engine diagnostic modules disappeared after they were loaded');
  await page.evaluate(
    async ({ roomPath, peerLinkPath, codecPath, envelopePath, key }) => {
      const record = (event: Record<string, unknown>) => {
        const current = Reflect.get(window, key);
        const events: Record<string, unknown>[] = Array.isArray(current) ? current : [];
        if (events.length >= 64) events.shift();
        events.push({ atMs: Math.round(performance.now()), ...event });
        Reflect.set(window, key, events);
      };
      let manualOpenStage: string | null = null;
      // oxlint-disable-next-line unicorn/consistent-function-scoping -- This helper is serialized into the browser realm.
      const errorName = (error: unknown): string => {
        const name = error instanceof Error ? error.name : '';
        return [
          'Error',
          'TypeError',
          'RangeError',
          'ReferenceError',
          'SyntaxError',
          'AbortError',
          'DataError',
          'EncodingError',
          'InvalidAccessError',
          'InvalidStateError',
          'NetworkError',
          'NotReadableError',
          'NotSupportedError',
          'OperationError',
          'SecurityError',
          'TimeoutError',
        ].includes(name)
          ? name
          : 'OtherError';
      };
      // oxlint-disable-next-line unicorn/consistent-function-scoping -- This helper is serialized into the browser realm.
      const errorCode = (error: unknown) => {
        const code =
          typeof error === 'object' && error !== null ? Reflect.get(error, 'code') : undefined;
        return typeof code === 'number' && Number.isSafeInteger(code) ? code : null;
      };
      // oxlint-disable-next-line unicorn/consistent-function-scoping -- The browser-evaluated callback must be self-contained.
      const safeError = async (error: unknown) => {
        const name = errorName(error);
        const domCode = errorCode(error);
        const message = error instanceof Error ? error.message : '';
        const knownReasons: readonly [RegExp, string][] = [
          [/Invalid signaling envelope body/i, 'invalid-signaling-envelope'],
          [/Peer is outside the active mesh roster/i, 'peer-outside-active-roster'],
          [/No signaling route to peer/i, 'no-signaling-route'],
          [/Signaling adapter is closed/i, 'signaling-adapter-closed'],
          [/Signaling send timed out/i, 'signaling-send-timeout'],
          [/Signaling send waiters are full/i, 'signaling-waiters-full'],
          [/Signaling send buffer is full/i, 'signaling-send-buffer-full'],
          [/Manual offer is outside the room roster/i, 'manual-offer-outside-roster'],
          [/Manual answer does not bind this invitation/i, 'manual-answer-binding'],
          [/Manual invitation was already used/i, 'manual-invitation-already-used'],
          [/Failed to set remote (?:offer|answer) sdp/i, 'remote-description-rejected'],
          [/setRemoteDescription/i, 'remote-description-rejected'],
          [/Canonical encoding accepts integers only/i, 'canonical-non-integer'],
          [/Canonical objects must contain enumerable data properties/i, 'canonical-accessor'],
          [/Canonical objects must be plain records/i, 'canonical-non-record'],
          [/Canonical arrays cannot have holes/i, 'canonical-sparse-array'],
          [/Canonical objects cannot contain symbol keys/i, 'canonical-symbol-key'],
          [/Canonical encoding does not accept cyclic values/i, 'canonical-cycle'],
          [/Unsupported canonical value/i, 'canonical-unsupported-value'],
          [/Canonical arrays must contain plain data elements/i, 'canonical-array-accessor'],
        ];
        const known = knownReasons.find(([pattern]) => pattern.test(message));
        if (known)
          return {
            name,
            ...(domCode === null ? {} : { domCode }),
            message: known[1],
          };
        const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(message));
        return {
          name,
          ...(domCode === null ? {} : { domCode }),
          message: 'unclassified',
          fingerprint: [...new Uint8Array(digest)]
            .map((byte) => byte.toString(16).padStart(2, '0'))
            .join('')
            .slice(0, 16),
        };
      };
      // oxlint-disable-next-line unicorn/consistent-function-scoping -- Keep module URL resolution in the browser-evaluated callback.
      const moduleSpecifier = (path: string) => {
        const url = new URL(path);
        return url.pathname + url.search;
      };
      // oxlint-disable typescript/no-unsafe-type-assertion -- These imports resolve the app modules already loaded by this page.
      const { OnlineRoom } = (await import(
        /* @vite-ignore */ moduleSpecifier(roomPath)
      )) as typeof import('../src/session/online-room.js');
      const { PeerLink } = (await import(
        /* @vite-ignore */ moduleSpecifier(peerLinkPath)
      )) as typeof import('@cp2p/p2p');
      const codec = codecPath
        ? ((await import(
            /* @vite-ignore */ moduleSpecifier(codecPath)
          )) as typeof import('@cp2p/codec'))
        : null;
      const envelope = envelopePath
        ? ((await import(
            /* @vite-ignore */ moduleSpecifier(envelopePath)
          )) as typeof import('../../../packages/p2p/src/signaling-envelope.js'))
        : null;
      const canonicalEncode = codec?.canonicalEncode ?? null;
      const validSignalEnvelopeBody = envelope?.validSignalEnvelopeBody ?? null;

      const originalOpen = Reflect.get(OnlineRoom, 'open');
      if (typeof originalOpen !== 'function')
        throw new Error('OnlineRoom open method is unavailable to the test observer');
      OnlineRoom.open = async function (...args) {
        const request = args[0];
        const manualJoin =
          typeof request === 'object' &&
          request !== null &&
          Reflect.get(request, 'kind') === 'manual-join';
        if (manualJoin) manualOpenStage = 'decode-offer';
        try {
          const result = await Reflect.apply(originalOpen, this, args);
          if (manualJoin) record({ source: 'manual-open', stage: 'complete' });
          return result;
        } catch (error) {
          record({
            source: manualJoin ? 'manual-open' : 'room-open',
            ...(manualJoin ? { stage: manualOpenStage } : {}),
            error: await safeError(error),
          });
          throw error;
        } finally {
          if (manualJoin) manualOpenStage = null;
        }
      };

      const rtcPrototype = Reflect.get(RTCPeerConnection, 'prototype');
      for (const method of ['setRemoteDescription', 'setLocalDescription'] as const) {
        const original = Reflect.get(rtcPrototype, method);
        if (typeof original !== 'function') continue;
        Reflect.set(rtcPrototype, method, function (this: unknown, ...args: unknown[]) {
          if (manualOpenStage === null) return Reflect.apply(original, this, args);
          manualOpenStage =
            method === 'setRemoteDescription' ? 'set-remote-description' : 'set-local-description';
          try {
            return Promise.resolve(Reflect.apply(original, this, args)).then(
              (value: unknown) => {
                manualOpenStage =
                  method === 'setRemoteDescription'
                    ? 'remote-description-set'
                    : 'local-description-set';
                record({ source: 'manual-rtc', stage: method, outcome: 'fulfilled' });
                return value;
              },
              async (error: unknown) => {
                record({
                  source: 'manual-rtc',
                  stage: method,
                  outcome: 'rejected',
                  error: await safeError(error),
                });
                throw error;
              },
            );
          } catch (error) {
            void safeError(error)
              .then((safe) =>
                record({ source: 'manual-rtc', stage: method, outcome: 'threw', error: safe }),
              )
              .catch(() =>
                record({
                  source: 'manual-rtc',
                  stage: method,
                  outcome: 'threw',
                  error: { name: 'OtherError', message: 'diagnostic-capture-failed' },
                }),
              );
            throw error;
          }
        });
      }

      const prototype = Reflect.get(PeerLink, 'prototype');
      const originalSendSignal = Reflect.get(prototype, 'sendSignal');
      if (typeof originalSendSignal !== 'function')
        throw new Error('PeerLink signal method is unavailable to the test observer');
      Reflect.set(prototype, 'sendSignal', function (this: unknown, blob: unknown) {
        const options =
          typeof this === 'object' && this !== null ? Reflect.get(this, 'options') : null;
        if (typeof options !== 'object' || options === null)
          return Reflect.apply(originalSendSignal, this, [blob]);
        const originalSignal = Reflect.get(options, 'signal');
        if (typeof originalSignal !== 'function')
          return Reflect.apply(originalSendSignal, this, [blob]);
        const wrappedSignal = function (this: unknown, ...signalArgs: unknown[]) {
          // oxlint-disable-next-line unicorn/consistent-function-scoping -- The nested callback is serialized into the browser realm.
          const get = (value: unknown, property: string): unknown =>
            typeof value === 'object' && value !== null ? Reflect.get(value, property) : undefined;
          const description = get(blob, 'description');
          const candidate = get(blob, 'candidate');
          const sdp = get(description, 'sdp');
          const candidateText = get(candidate, 'candidate');
          // oxlint-disable-next-line unicorn/consistent-function-scoping -- This helper runs in the browser callback.
          const safeKeys = (value: unknown, allowed: readonly string[]) =>
            typeof value === 'object' && value !== null
              ? Object.keys(value)
                  .map((property) => (allowed.includes(property) ? property : 'other'))
                  .toSorted()
              : [];
          // oxlint-disable-next-line unicorn/consistent-function-scoping -- This helper runs in the browser callback.
          const safeInteger = (value: unknown) =>
            typeof value === 'number' && Number.isSafeInteger(value) ? value : null;
          let canonicalFailure: string | null = null;
          if (typeof canonicalEncode === 'function') {
            try {
              canonicalEncode(blob);
            } catch (error) {
              const message = error instanceof Error ? error.message : '';
              const reasons: readonly [RegExp, string][] = [
                [/integers only/i, 'canonical-non-integer'],
                [/plain records/i, 'canonical-non-record'],
                [/symbol keys/i, 'canonical-symbol-key'],
                [/cyclic values/i, 'canonical-cycle'],
                [/unsupported canonical value/i, 'canonical-unsupported-value'],
                [/enumerable data properties/i, 'canonical-accessor'],
                [/plain data elements/i, 'canonical-array-accessor'],
                [/holes/i, 'canonical-sparse-array'],
              ];
              canonicalFailure =
                reasons.find(([pattern]) => pattern.test(message))?.[1] ?? 'canonical-other';
            }
          }
          const scope = get(options, 'scope');
          const from = get(options, 'self');
          const to = get(options, 'peer');
          let blobValidWithSyntheticEnvelope: boolean | null = null;
          if (typeof validSignalEnvelopeBody === 'function') {
            try {
              blobValidWithSyntheticEnvelope = validSignalEnvelopeBody({
                version: 2,
                scope,
                from,
                to,
                attemptId: 'AQEBAQEBAQEBAQEBAQEBAQ',
                sessionId: 'AwMDAwMDAwMDAwMDAwMDAw',
                attemptSeq: 1,
                blob,
              });
            } catch {
              blobValidWithSyntheticEnvelope = false;
            }
          }
          const metadata = {
            kind: get(blob, 'kind') ?? null,
            blobKeys: safeKeys(blob, [
              'kind',
              'generation',
              'revision',
              'description',
              'candidate',
              'inReplyTo',
            ]),
            generation: safeInteger(get(blob, 'generation')),
            revision: safeInteger(get(blob, 'revision')),
            inReplyTo: safeInteger(get(blob, 'inReplyTo')),
            descriptionType: get(description, 'type') ?? null,
            descriptionKeys: safeKeys(description, ['type', 'sdp']),
            sdpLength: typeof sdp === 'string' ? sdp.length : null,
            candidateLength: typeof candidateText === 'string' ? candidateText.length : null,
            candidateKeys: safeKeys(candidate, [
              'candidate',
              'sdpMid',
              'sdpMLineIndex',
              'usernameFragment',
            ]),
            canonicalFailure,
            blobValidWithSyntheticEnvelope,
          };
          try {
            if (get(blob, 'kind') === 'description')
              record({
                source: 'signal-description',
                from: typeof from === 'string' ? from.slice(0, 12) : null,
                to: typeof to === 'string' ? to.slice(0, 12) : null,
                ...metadata,
              });
            const sent = Reflect.apply(originalSignal, this, signalArgs);
            return Promise.resolve(sent).catch(async (error: unknown) => {
              record({
                source: 'signal-callback',
                stage: 'rejected',
                ...metadata,
                error: await safeError(error),
              });
              throw error;
            });
          } catch (error) {
            void safeError(error)
              .then((safe) => {
                record({ source: 'signal-callback', stage: 'threw', ...metadata, error: safe });
                return undefined;
              })
              .catch(() => {
                record({
                  source: 'signal-callback',
                  stage: 'threw',
                  ...metadata,
                  error: { name: 'OtherError', message: 'diagnostic-capture-failed' },
                });
                return undefined;
              });
            throw error;
          }
        };
        Reflect.set(options, 'signal', wrappedSignal);
        try {
          return Reflect.apply(originalSendSignal, this, [blob]);
        } finally {
          if (Reflect.get(options, 'signal') === wrappedSignal)
            Reflect.set(options, 'signal', originalSignal);
        }
      });
    },
    {
      roomPath: paths.room,
      peerLinkPath: paths.peerLink,
      codecPath: paths.codec,
      envelopePath: paths.envelope,
      key: diagnosticKey,
    },
  );
}

async function readRoom(page: Page, includePeerStats = false) {
  const path = await roomModulePath(page);
  return page.evaluate(
    async ({ modulePath, includePeerStats: readPeerStats }) => {
      // oxlint-disable typescript/no-unsafe-type-assertion -- Import the registry module actually loaded by this browser context.
      const { getOnlineRoom, getOnlineGameRoom } = (await import(
        /* @vite-ignore */ modulePath
      )) as typeof import('../src/features/online/room-registry.js');
      // oxlint-enable typescript/no-unsafe-type-assertion
      const diagnosticEvents = Reflect.get(window, '__cp2pMixedEngineDiagnostics');
      const route = location.hash.split('?')[0] ?? '';
      const pageEvidence = {
        route: `${location.origin}${location.pathname}${route}`,
        alerts: [...document.querySelectorAll('[role="alert"]')]
          .map((element) => element.textContent?.trim() ?? '')
          .filter(Boolean)
          .slice(0, 4),
        diagnosticEvents: Array.isArray(diagnosticEvents) ? diagnosticEvents : [],
      };
      const lobbyId = route.match(/\/lobby\/([^/]+)/)?.[1];
      const gameId = route.match(/\/game\/([^/]+)/)?.[1];
      const room = gameId ? getOnlineGameRoom(gameId) : getOnlineRoom(lobbyId ?? '');
      if (!room) return { ...pageEvidence, roomOpen: false, humanCount: 0, peerCount: 0 };
      const snapshot = room.getSnapshot();
      const session = room.getGame()?.session;
      const peerStats = readPeerStats ? await room.getPeerStats?.().catch(() => []) : [];
      // Address-free state for unfinished links is absent from authenticated
      // peer stats. Read it only in diagnostics; never change transport state.
      const transport = readPeerStats ? Reflect.get(room, 'transport') : null;
      const unfinishedLinks = ['links', 'pendingLinks'].flatMap((slot) => {
        const links = transport ? Reflect.get(transport, slot) : null;
        if (!(links instanceof Map)) return [];
        return [...links].map(([peer, item]) => {
          const link = Reflect.get(item, 'link');
          const pc = Reflect.get(link, 'pc');
          return {
            peer: typeof peer === 'string' ? peer.slice(0, 12) : null,
            slot,
            authenticated: Reflect.get(link, 'isAuthenticated'),
            connection: Reflect.get(pc, 'connectionState'),
            ice: Reflect.get(pc, 'iceConnectionState'),
            signaling: Reflect.get(pc, 'signalingState'),
            localRevision: Reflect.get(link, 'localRevision'),
            remoteRevision: Reflect.get(link, 'remoteRevision'),
            queuedDescriptions: Reflect.get(link, 'pendingDescriptions'),
          };
        });
      });
      return {
        ...pageEvidence,
        roomOpen: true,
        peerCount: snapshot.peers.length,
        connectionError: snapshot.connectionError,
        diagnostic: snapshot.diagnostic,
        signalingState: snapshot.signaling.state,
        peerStates:
          peerStats?.map(({ state, route: peerRoute }) => ({ state, route: peerRoute })) ?? [],
        unfinishedLinks,
        startup: snapshot.startup?.phase ?? null,
        lobbyStatus: snapshot.lobby?.status ?? null,
        humanCount: snapshot.lobby?.seats.filter((seat) => seat.kind === 'human').length ?? 0,
        manual: {
          phase: snapshot.manual.phase,
          gatheringComplete: snapshot.manual.gatheringComplete,
          hasCode: snapshot.manual.code !== null,
        },
        closed: snapshot.closed,
        game: session
          ? {
              head: session.getFairness?.()?.head ?? null,
              phase: session.getState().turn.phase.at(-1)?.id ?? null,
              turn: session.getState().turn.number,
              activeSeat: session.getState().turn.activeSeat,
              controlledSeats: session.controllableSeats(),
              pending: session
                .getPending()
                .map((item) =>
                  item.kind === 'player'
                    ? { kind: item.kind, seat: item.seat, allowed: item.allowed }
                    : { kind: item.kind },
                ),
              resultPresent: Boolean(session.getState().result),
              audit: session.getAudit?.().kind ?? null,
            }
          : null,
      };
    },
    { modulePath: path, includePeerStats },
  );
}

async function navigateToInviteWithinDocument(page: Page, invitation: string): Promise<void> {
  const target = new URL(invitation);
  const current = await page.evaluate(() => ({
    origin: location.origin,
    pathname: location.pathname,
  }));
  if (target.origin !== current.origin || target.pathname !== current.pathname)
    throw new Error('Invitation URL would leave the current app document');
  await page.evaluate((hash) => {
    location.hash = hash;
  }, target.hash);
}

async function getManualInvitation(page: Page, peer?: string): Promise<string> {
  const path = await roomModulePath(page);
  const result = await page.evaluate(
    async ({ modulePath, target }) => {
      // oxlint-disable typescript/no-unsafe-type-assertion -- This is the running room registry, used only to drive the genuine public room method.
      const { getOnlineRoom } = (await import(
        /* @vite-ignore */ modulePath
      )) as typeof import('../src/features/online/room-registry.js');
      // oxlint-enable typescript/no-unsafe-type-assertion
      const roomId = new URL(location.href).hash.match(/\/lobby\/([^/?]+)/)?.[1];
      const room = roomId ? getOnlineRoom(roomId) : null;
      if (!room) throw new Error('The host lobby is not open');
      if (!room.startManualInvitation) throw new Error('Manual invitation is unavailable');
      const created = await room.startManualInvitation(target ?? undefined);
      if (!created.ok) throw new Error(`Manual offer failed: ${created.error.code}`);
      return created.value;
    },
    { modulePath: path, target: peer ?? null },
  );
  const final = await manualOfferState(page);
  if (
    !final ||
    !final.code ||
    final.code !== result.code ||
    typeof final.gatheringComplete !== 'boolean'
  )
    throw new Error('Manual room snapshot did not retain the gathered offer');
  return final.code;
}

async function manualOfferState(page: Page) {
  const path = await roomModulePath(page);
  return page.evaluate(async (modulePath) => {
    // oxlint-disable typescript/no-unsafe-type-assertion -- Read public bootstrap progress from the current room only.
    const { getOnlineRoom } = (await import(
      /* @vite-ignore */ modulePath
    )) as typeof import('../src/features/online/room-registry.js');
    // oxlint-enable typescript/no-unsafe-type-assertion
    const roomId = new URL(location.href).hash.match(/\/lobby\/([^/?]+)/)?.[1];
    const room = roomId ? getOnlineRoom(roomId) : null;
    return room?.getSnapshot().manual ?? null;
  }, path);
}

async function acceptManualAnswer(inviter: Page, code: string): Promise<void> {
  const path = await roomModulePath(inviter);
  const result = await inviter.evaluate(
    async ({ modulePath, answer }) => {
      // oxlint-disable typescript/no-unsafe-type-assertion -- Call the app's public manual-answer API on its active room.
      const { getOnlineRoom } = (await import(
        /* @vite-ignore */ modulePath
      )) as typeof import('../src/features/online/room-registry.js');
      // oxlint-enable typescript/no-unsafe-type-assertion
      const roomId = new URL(location.href).hash.match(/\/lobby\/([^/?]+)/)?.[1];
      const room = roomId ? getOnlineRoom(roomId) : null;
      if (!room) throw new Error('The inviter lobby is not open');
      if (!room.acceptManualAnswer) throw new Error('Manual answer is unavailable');
      const accepted = await room.acceptManualAnswer(answer);
      return accepted.ok ? null : accepted.error.code;
    },
    { modulePath: path, answer: code },
  );
  if (result) throw new Error(`Manual answer rejected: ${result}`);
}

async function startFourPlayerRoom(pages: readonly Page[], mode: 'signaling' | 'manual') {
  const [host, ...guests] = pages;
  if (!host || guests.length !== 3) throw new Error('Expected four isolated browser pages');
  const gameName = mode === 'signaling' ? 'Mixed signaling acceptance' : 'Mixed manual acceptance';
  await host.goto('/#/online/create');
  await expect(host.getByLabel('Room name', { exact: true })).toBeVisible();
  await installFailureDiagnostics(host);
  await host.getByLabel('Room name', { exact: true }).fill(gameName);
  await host.getByLabel('Your player name', { exact: true }).fill('Player 1');
  await host.getByText('Advanced connection options', { exact: true }).click();
  await host.getByLabel('Player count').selectOption('4');
  await host.getByLabel('Victory points to win', { exact: true }).fill('3');
  await host
    .getByLabel('Invite friends with')
    .selectOption(mode === 'signaling' ? 'server' : 'manual');
  if (mode === 'signaling')
    await host.getByLabel('Custom room server', { exact: true }).fill(signalingUrl);
  await host.getByRole('button', { name: 'Create room', exact: true }).click();
  await expect(host.getByRole('heading', { name: gameName })).toBeVisible();

  if (mode === 'signaling') {
    const invite = await host.getByRole('textbox', { name: /^Invitation link/ }).inputValue();
    for (const guest of guests) {
      await guest.goto('/#/join');
      await expect(guest.getByLabel('Invitation link or code', { exact: true })).toBeVisible();
      await installFailureDiagnostics(guest);
      await navigateToInviteWithinDocument(guest, invite);
      await expect(guest.getByRole('heading', { name: gameName })).toBeVisible({ timeout: 45_000 });
      await guest.getByRole('button', { name: 'Take seat', exact: true }).first().click();
    }
  } else {
    for (const guest of guests) {
      await guest.goto('/#/join');
      await expect(guest.getByLabel('Invitation link or code', { exact: true })).toBeVisible();
      await installFailureDiagnostics(guest);
      const invite = await getManualInvitation(host);
      await guest.getByLabel('Invitation link or code', { exact: true }).fill(invite);
      await guest.getByRole('button', { name: 'Join room', exact: true }).click();
      await expect(guest).toHaveURL(/\/lobby\/[^/]+$/, { timeout: 45_000 });
      await expect
        .poll(async () => {
          const state = await manualOfferState(guest);
          return typeof state?.code === 'string' && typeof state.gatheringComplete === 'boolean';
        })
        .toBe(true);
      const answer = (await manualOfferState(guest))?.code;
      if (!answer) throw new Error('A joined guest did not produce its manual answer');
      await acceptManualAnswer(host, answer);
      await expect(guest.getByRole('heading', { name: gameName })).toBeVisible({ timeout: 45_000 });
      await guest.getByRole('button', { name: 'Take seat', exact: true }).first().click();
      await expect
        .poll(async () => {
          const state = await readRoom(host);
          return state.roomOpen ? state.humanCount : 0;
        })
        .toBeGreaterThan(1);
    }
  }

  await expect
    .poll(
      async () =>
        Promise.all(
          pages.map(async (page) => {
            const state = await readRoom(page);
            return state.roomOpen ? state.peerCount : 0;
          }),
        ),
      // Allow the production 30s attempt, 250ms retry and 10s HELLO window.
      // The overall test and subsequent play/audit limits stay unchanged.
      { timeout: 45_000, intervals: [100] },
    )
    .toEqual([3, 3, 3, 3]);
  await Promise.all(pages.map((page) => page.getByRole('button', { name: 'Ready up' }).click()));
  await expect(host.getByRole('button', { name: 'Start game', exact: true })).toBeEnabled({
    timeout: 45_000,
  });
  await host.getByRole('button', { name: 'Start game', exact: true }).click();
  await Promise.all(
    pages.map((page) => expect(page).toHaveURL(/\/game\/[^/]+$/, { timeout: 90_000 })),
  );
  const gameId = new URL(host.url()).hash.match(/\/game\/([^/?]+)/)?.[1];
  if (!gameId) throw new Error('Game URL did not include an id');
  return { gameId, gameName };
}

async function inspectGame(page: Page, gameId: string) {
  const modulePath = await roomModulePath(page);
  const view = await page.evaluate(
    async ({ path, id }) => {
      // oxlint-disable typescript/no-unsafe-type-assertion -- Read the session from the app-loaded production registry.
      const { getOnlineGameRoom } = (await import(
        /* @vite-ignore */ path
      )) as typeof import('../src/features/online/room-registry.js');
      // oxlint-enable typescript/no-unsafe-type-assertion
      const room = getOnlineGameRoom(id);
      const session = room?.getGame()?.session;
      if (!room || !session) return null;
      const seat = session.controllableSeats()[0];
      const legal = seat === undefined ? undefined : session.getLegalCommands(seat);
      return {
        head: session.getFairness?.()?.head ?? null,
        phase: session.getState().turn.phase.at(-1)?.id ?? null,
        result: session.getState().result ?? null,
        seat,
        pending: session.getPending(),
        state: session.getState(),
        privateState: seat === undefined ? null : session.getPrivate(seat),
        legal,
        audit: session.getAudit?.() ?? null,
        peerCount: room.getSnapshot().peers.length,
      };
    },
    { path: modulePath, id: gameId },
  );
  return view
    ? {
        ...view,
        pending: chooseBotPending(
          view.state,
          view.pending,
          new Set(view.seat === undefined ? [] : [view.seat]),
        ),
      }
    : null;
}

async function submit(page: Page, gameId: string, seat: Seat, command: CommandShape, seq: number) {
  const modulePath = await roomModulePath(page);
  return page.evaluate(
    async ({ path, id, actingSeat, action, revision }) => {
      // oxlint-disable typescript/no-unsafe-type-assertion -- Submit a legal action through the actual online session.
      const { getOnlineGameRoom } = (await import(
        /* @vite-ignore */ path
      )) as typeof import('../src/features/online/room-registry.js');
      // oxlint-enable typescript/no-unsafe-type-assertion
      const session = getOnlineGameRoom(id)?.getGame()?.session;
      if (!session) throw new Error('The online session is unavailable');
      const result = await session.submit(actingSeat, action, { expectedRevision: revision });
      return result.ok ? null : result.error.code;
    },
    { path: modulePath, id: gameId, actingSeat: seat, action: command, revision: seq },
  );
}

async function certifyPostSetupMove(pages: readonly Page[], gameId: string): Promise<void> {
  const ready = async () => Promise.all(pages.map((page) => inspectGame(page, gameId)));
  const setupBots = pages.map((_, index) => ({
    bot: new RandomBot(),
    state: stableBotConfig(),
    rng: createBotRng(new Uint8Array(32).fill(index + 101)),
  }));
  await expect
    .poll(
      async () => {
        const views = await ready();
        // Setup ends in preRoll. This driver submits the first roll below;
        // waiting for main here would wait for a command it never sends.
        if (views.every((item) => item?.phase === 'preRoll')) return true;
        const index = views.findIndex(
          (item) => item?.phase === 'setup' && item.pending?.kind === 'player' && item.legal,
        );
        if (index < 0) return false;
        const view = views[index];
        const actor = setupBots[index];
        const page = pages[index];
        if (
          view?.seat === undefined ||
          !view.pending ||
          !view.privateState ||
          !view.legal ||
          !view.head ||
          !actor ||
          !page
        )
          return false;
        const command = actor.bot.decide(
          { state: actor.state(view.state), priv: view.privateState, seat: view.seat },
          view.pending,
          actor.rng,
        );
        const refused = await submit(page, gameId, view.seat, command, view.head.seq);
        if (refused && refused !== 'stale-head' && refused !== 'stale-revision')
          throw new Error(`A legal setup placement was rejected: ${refused}`);
        return false;
      },
      {
        timeout: 120_000,
        intervals: [100],
      },
    )
    .toBe(true);
  const views = await ready();
  const before = views[0]?.head;
  if (!before) throw new Error('No certified head after setup');
  let accepted = false;
  for (const [index, view] of views.entries()) {
    if (!view?.pending || view.seat === undefined || !view.legal) continue;
    const command = view.legal.commands.find((item) => item.type !== 'END_TURN');
    if (!command) continue;
    const page = pages[index];
    if (!page) throw new Error('Post-setup actor page disappeared');
    const refused = await submit(page, gameId, view.seat, command, before.seq);
    if (refused) throw new Error(`Post-setup move rejected: ${refused}`);
    accepted = true;
    break;
  }
  if (!accepted) throw new Error('No non-END_TURN main-phase move was available');
  await expect
    .poll(
      async () => {
        const heads = (await ready()).map((item) => item?.head);
        const seq = heads[0]?.seq;
        return seq !== undefined && seq > before.seq && heads.every((head) => head?.seq === seq);
      },
      { timeout: 45_000 },
    )
    .toBe(true);
  const after = await ready();
  const afterHead = after[0]?.head;
  if (!afterHead || afterHead.seq <= before.seq)
    throw new Error('Post-setup action did not advance the head');
  expect(after.map((item) => item?.head)).toEqual([afterHead, afterHead, afterHead, afterHead]);
}

interface FinishProgress {
  readonly commands: number;
  readonly accepted: Readonly<Record<string, number>>;
  readonly refusedCommands: Readonly<Record<string, number>>;
  readonly playElapsedMs: number;
  readonly auditElapsedMs: number;
  readonly peers: readonly {
    readonly head: { readonly seq: number; readonly hash: string } | null;
    readonly resultPresent: boolean;
    readonly audit: string | null;
  }[];
}

async function finishAndAudit(
  pages: readonly Page[],
  gameId: string,
  onProgress: (progress: FinishProgress) => void,
) {
  const bots = pages.map((_, index) => ({
    bot: new RandomBot(),
    state: stableBotConfig(),
    rng: createBotRng(new Uint8Array(32).fill(index + 31)),
  }));
  let commands = 0;
  const started = Date.now();
  let terminalAt: number | undefined;
  const accepted: Record<string, number> = {};
  const refusedCommands: Record<string, number> = {};
  let peers: FinishProgress['peers'] = [];
  const diagnostic = (): FinishProgress => ({
    commands,
    accepted: { ...accepted },
    refusedCommands: { ...refusedCommands },
    peers,
    playElapsedMs: (terminalAt ?? Date.now()) - started,
    auditElapsedMs: terminalAt === undefined ? 0 : Date.now() - terminalAt,
  });
  onProgress(diagnostic());
  try {
    await expect
      .poll(
        async () => {
          for (const [index, page] of pages.entries()) {
            const view = await inspectGame(page, gameId);
            if (
              !view ||
              view.result ||
              view.seat === undefined ||
              view.pending?.kind !== 'player' ||
              !view.privateState ||
              !view.legal ||
              !view.head
            )
              continue;
            const actor = bots[index];
            if (!actor) throw new Error('Missing deterministic browser bot');
            const command = actor.bot.decide(
              { state: actor.state(view.state), priv: view.privateState, seat: view.seat },
              view.pending,
              actor.rng,
            );
            const refused = await submit(page, gameId, view.seat, command, view.head.seq);
            if (refused) refusedCommands[refused] = (refusedCommands[refused] ?? 0) + 1;
            if (refused && refused !== 'stale-head' && refused !== 'stale-revision')
              throw new Error(`A legal browser move was rejected: ${refused}`);
            if (!refused) {
              commands += 1;
              accepted[command.type] = (accepted[command.type] ?? 0) + 1;
            }
            onProgress(diagnostic());
            if (commands > 300) throw new Error('The bounded mixed-engine game exceeded 300 moves');
          }
          const views = await Promise.all(pages.map((page) => inspectGame(page, gameId)));
          peers = views.map((view) => ({
            head: view?.head ?? null,
            resultPresent: Boolean(view?.result),
            audit: view?.audit?.kind ?? null,
          }));
          if (views.every((view) => view?.result)) terminalAt ??= Date.now();
          onProgress(diagnostic());
          return views.every((view) => view?.result && view.audit?.kind === 'complete');
        },
        { timeout: 150_000, intervals: [100] },
      )
      .toBe(true);
  } catch (error) {
    throw new Error(`Mixed-engine play/audit driver: ${JSON.stringify(diagnostic())}`, {
      cause: error,
    });
  }
  const final = await Promise.all(pages.map((page) => inspectGame(page, gameId)));
  const head = final[0]?.head;
  const result = final[0]?.result;
  if (!head || !result) throw new Error('Missing audited terminal state');
  for (const view of final) {
    expect(view?.head).toEqual(head);
    expect(view?.result).toEqual(result);
    expect(view?.audit).toMatchObject({ kind: 'complete', report: { ok: true, complete: true } });
    expect(view?.peerCount).toBe(3);
  }
  return { ...diagnostic(), terminalSeq: head.seq, modeAuditCount: final.length };
}

async function runMode(playwright: Playwright, mode: 'signaling' | 'manual') {
  const opened = await launchFourEngines(playwright);
  const [host, second, third, fourth] = opened.pages;
  if (!host || !second || !third || !fourth) throw new Error('Missing mixed-engine page');
  const errors: EngineName[] = [];
  for (const [index, page] of opened.pages.entries()) {
    const engine = engineNames[index];
    if (!engine) throw new Error('Missing browser engine label');
    page.on('pageerror', () => errors.push(engine));
  }
  const started = Date.now();
  let phase = 'lobby';
  let readingProgress = false;
  let finishProgress: FinishProgress | null = null;
  const emitProgress = (peers?: unknown) => {
    process.stdout.write(
      `${JSON.stringify({ mode, phase, elapsedMs: Date.now() - started, finish: finishProgress, peers })}\n`,
    );
  };
  const setPhase = (next: string) => {
    phase = next;
    emitProgress();
  };
  emitProgress();
  // A runner-level timeout can interrupt the catch block itself. Retain public
  // progress during the run, without private hands, SDP, candidates or keys.
  const progress = setInterval(() => {
    if (readingProgress) return;
    readingProgress = true;
    void Promise.all(
      opened.pages.map(async (page, index) => ({
        engine: engineNames[index],
        ...(await readRoom(page, true).catch(() => ({ unavailable: true }))),
      })),
    )
      .then((peers) => {
        emitProgress(peers);
        return undefined;
      })
      .finally(() => {
        readingProgress = false;
      });
  }, 10_000);
  try {
    const fixture = await startFourPlayerRoom(opened.pages, mode);
    const lobbyElapsedMs = Date.now() - started;
    setPhase('setup');
    const setupStarted = Date.now();
    await certifyPostSetupMove(opened.pages, fixture.gameId);
    const setupElapsedMs = Date.now() - setupStarted;
    setPhase('play-and-audit');
    const completion = await finishAndAudit(opened.pages, fixture.gameId, (snapshot) => {
      finishProgress = snapshot;
      if (
        snapshot.peers.length === opened.pages.length &&
        snapshot.peers.every((peer) => peer.resultPresent) &&
        phase !== 'audit'
      )
        setPhase('audit');
    });
    setPhase('complete');
    expect(errors).toEqual([]);
    return { mode, browserSet: engineNames, lobbyElapsedMs, setupElapsedMs, ...completion };
  } catch (error) {
    const diagnostics = await Promise.all(
      opened.pages.map(async (page, index) => ({
        engine: engineNames[index],
        ...(await readRoom(page, true).catch(() => null)),
      })),
    );
    throw new Error(
      `Mixed-engine ${mode} acceptance failed. Sanitized peer/lobby diagnostics: ${JSON.stringify(diagnostics)}`,
      { cause: error },
    );
  } finally {
    clearInterval(progress);
    await Promise.allSettled(opened.contexts.map((context) => context.close()));
    await Promise.allSettled(opened.browsers.map((browser) => browser.close()));
  }
}

test('four mixed-engine contexts finish a signaling full-mesh game with matching audits', async ({
  playwright,
}, testInfo) => {
  test.skip(
    process.env.CP2P_MIXED_ENGINE_MODE !== 'signaling',
    'The workflow runs one connection mode per job',
  );
  test.setTimeout(240_000);
  const result = await runMode(playwright, 'signaling');
  await testInfo.attach('mixed-engine-summary', {
    body: JSON.stringify(result, null, 2),
    contentType: 'application/json',
  });
});

test('four mixed-engine contexts finish a manual-relay full-mesh game with matching audits', async ({
  playwright,
}, testInfo) => {
  test.skip(
    process.env.CP2P_MIXED_ENGINE_MODE !== 'manual-relay',
    'The workflow runs one connection mode per job',
  );
  test.setTimeout(300_000);
  const result = await runMode(playwright, 'manual');
  await testInfo.attach('mixed-engine-summary', {
    body: JSON.stringify(result, null, 2),
    contentType: 'application/json',
  });
});


FILE apps/web/tests/helpers/stable-bot-config.ts
import { deepStrictEqual } from 'node:assert';
import type { GameState } from '@cp2p/engine';

/** Browser observations are structured clones; RandomBot tracks a game by config identity. */
export function stableBotConfig(): (state: GameState) => GameState {
  let config: GameState['config'] | undefined;
  return (state) => {
    if (config === undefined) config = structuredClone(state.config);
    else deepStrictEqual(state.config, config, 'Browser bot game config changed');
    return { ...state, config };
  };
}


FILE packages/bots/src/random-bot.ts
import { createBaseEngine, enumerateCommands } from '@cp2p/engine';
import type { CommandShape, Engine, Pending, TradeOffer } from '@cp2p/engine';
import type { Resource, ResourceCounts } from '@cp2p/engine';
import { RESOURCES } from '@cp2p/engine';
import { createRng } from '@cp2p/engine/rng';
import { buildBoardGraph } from '@cp2p/engine/geometry';
import type { BoardGraph } from '@cp2p/engine/geometry';
import type { Bot, BotRng, BotView } from './types.js';

/** The seed belongs to this bot and game, never to the public rules engine. */
export function createBotRng(seed: Uint8Array): BotRng {
  return createRng(seed);
}

const CITY_COST = { brick: 0, lumber: 0, wool: 0, grain: 2, ore: 3 };
const SETTLEMENT_COST = { brick: 1, lumber: 1, wool: 1, grain: 1, ore: 0 };
const ROAD_COST = { brick: 1, lumber: 1, wool: 0, grain: 0, ore: 0 };
const DEV_COST = { brick: 0, lumber: 0, wool: 1, grain: 1, ore: 1 };
const graphs = new WeakMap<BotView['state']['board']['hexes'], BoardGraph>();

function boardGraph(view: BotView): BoardGraph {
  const hexes = view.state.board.hexes;
  let graph = graphs.get(hexes);
  if (!graph) {
    graph = buildBoardGraph(hexes);
    graphs.set(hexes, graph);
  }
  return graph;
}

function openSites(view: BotView, graph: BoardGraph): Set<string> {
  const buildings = new Set(view.state.board.buildings.map((piece) => piece.vertex));
  return new Set(
    graph.vertexIds.filter((vertex) => {
      const index = graph.vertexIndex[vertex];
      return (
        index !== undefined &&
        !buildings.has(vertex) &&
        !(graph.vertexNeighbors[index] ?? []).some((neighbor) => buildings.has(neighbor))
      );
    }),
  );
}

function connectedSite(view: BotView, graph: BoardGraph, sites: ReadonlySet<string>): boolean {
  const roads = new Set(
    view.state.board.roads.filter((road) => road.seat === view.seat).map((road) => road.edge),
  );
  return [...sites].some((vertex) => {
    const index = graph.vertexIndex[vertex];
    return index !== undefined && (graph.vertexEdges[index] ?? []).some((edge) => roads.has(edge));
  });
}

function productiveSettlements(
  commands: readonly CommandShape[],
  view: BotView,
  graph: BoardGraph,
): CommandShape[] {
  const settlements = commands.filter(
    (command) =>
      (command.type === 'PLACE_SETTLEMENT' || command.type === 'BUILD_SETTLEMENT') &&
      typeof command.vertex === 'string',
  );
  if (settlements.length < 2) return [...commands];
  const tokens = new Map(view.state.board.hexes.map((hex) => [hex.id, hex.token]));
  const score = (command: CommandShape): number => {
    const index = graph.vertexIndex[String(command.vertex)];
    if (index === undefined) return 0;
    return (graph.vertexHexes[index] ?? []).reduce((total, hex) => {
      const token = tokens.get(hex);
      return total + (token === null || token === undefined ? 0 : 6 - Math.abs(7 - token));
    }, 0);
  };
  const best = Math.max(...settlements.map(score));
  return commands.filter((command) => !settlements.includes(command) || score(command) >= best - 2);
}

function targetCost(view: BotView, hasSettlementSite: boolean): ResourceCounts | null {
  const seat = view.state.seats.find((holder) => holder.seat === view.seat);
  if (!seat) throw new Error('Bot seat is absent from the game');
  const canUpgrade =
    (seat.piecesLeft.city ?? 0) > 0 &&
    view.state.board.buildings.some(
      (building) => building.seat === view.seat && building.kind === 'settlement',
    );
  if (hasSettlementSite && (seat.piecesLeft.settlement ?? 0) > 0) {
    if (canUpgrade) {
      const missing = (cost: ResourceCounts): number =>
        RESOURCES.reduce(
          (total, resource) =>
            total + Math.max(0, cost[resource] - (view.priv.hand[resource] ?? 0)),
          0,
        );
      if (missing(CITY_COST) <= missing(SETTLEMENT_COST)) return CITY_COST;
    }
    return SETTLEMENT_COST;
  }
  if (canUpgrade) return CITY_COST;
  return (seat.piecesLeft.settlement ?? 0) > 0 && (seat.piecesLeft.road ?? 0) > 0
    ? ROAD_COST
    : null;
}

function canSpendWithoutBreakingGoal(
  hand: Readonly<Record<string, number>>,
  spent: ResourceCounts,
  goal: ResourceCounts | null,
): boolean {
  return (
    !goal ||
    RESOURCES.every(
      (resource) =>
        spent[resource] === 0 || (hand[resource] ?? 0) - spent[resource] >= goal[resource],
    )
  );
}

function goalResource(view: BotView, cost: ResourceCounts | null): Resource | null {
  if (!cost) return null;
  const priority: readonly Resource[] =
    cost === CITY_COST
      ? ['ore', 'grain']
      : cost === ROAD_COST
        ? ['brick', 'lumber']
        : ['brick', 'lumber', 'wool', 'grain'];
  return priority.find((resource) => (view.priv.hand[resource] ?? 0) < cost[resource]) ?? null;
}

function oneResourceField(value: unknown): { resource: Resource; count: number } | null {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return null;
  const keys = Object.keys(value);
  if (keys.length !== 1) return null;
  const resource = keys[0];
  if (resource === undefined) return null;
  const count = Reflect.get(value, resource);
  if (typeof count !== 'number') return null;
  switch (resource) {
    case 'brick':
    case 'lumber':
    case 'wool':
    case 'grain':
    case 'ore':
      return { resource, count };
    default:
      return null;
  }
}

function usefulTrade(
  command: CommandShape,
  view: BotView,
  cost: ResourceCounts | null,
  goal: Resource | null,
): boolean {
  if (!goal) return false;
  const received = oneResourceField(command.type === 'MARITIME_TRADE' ? command.get : command.want);
  const given = oneResourceField(command.give);
  return (
    received?.resource === goal &&
    !!given &&
    (view.priv.hand[given.resource] ?? 0) - given.count >= (cost?.[given.resource] ?? 0)
  );
}

function commandWeight(type: string, offersThisTurn: number, totalOffers: number): number {
  if (type === 'BUILD_SETTLEMENT') return 30;
  if (type === 'BUILD_CITY') return 30;
  if (type === 'BUILD_ROAD') return 12;
  if (type === 'BUY_DEV_CARD' || type === 'PLAY_DEV_CARD') return 8;
  if (type === 'OFFER_TRADE' || type === 'PROPOSE_TRADE')
    return offersThisTurn >= 1 || totalOffers >= 8 ? 0 : 1;
  if (type === 'MARITIME_TRADE') return 2;
  if (type === 'END_TURN') return offersThisTurn >= 1 ? 8 : 4;
  return 5;
}

function weightedChoice(
  commands: readonly CommandShape[],
  offersThisTurn: number,
  totalOffers: number,
  rng: BotRng,
): CommandShape {
  const groups = new Map<string, CommandShape[]>();
  for (const command of commands) {
    const group = groups.get(command.type) ?? [];
    group.push(command);
    groups.set(command.type, group);
  }
  const total = [...groups.keys()].reduce(
    (sum, type) => sum + commandWeight(type, offersThisTurn, totalOffers),
    0,
  );
  if (total <= 0) {
    const fallback = commands[rng.int(commands.length)];
    if (!fallback) throw new Error('No legal command');
    return fallback;
  }
  let index = rng.int(total);
  for (const [type, group] of groups) {
    index -= commandWeight(type, offersThisTurn, totalOffers);
    if (index < 0) {
      const chosen = group[rng.int(group.length)];
      if (chosen) return chosen;
    }
  }
  throw new Error('Bot RNG returned an out-of-range choice');
}

/** Small, reproducible policy for simulation and offline play. */
export class RandomBot implements Bot {
  readonly id = 'random';
  private gameConfig: BotView['state']['config'] | null = null;
  private turnNumber = -1;
  private offersThisTurn = 0;
  private totalOffers = 0;

  constructor(private readonly engine: Engine = createBaseEngine()) {}

  respondToTrade(_view: BotView, _offer: TradeOffer, rng: BotRng): boolean {
    return rng.int(10) < 3;
  }

  decide(view: BotView, pending: Pending, rng: BotRng): CommandShape {
    if (view.priv.seat !== view.seat || pending.kind !== 'player' || pending.seat !== view.seat)
      throw new Error('Bot decision requires its own player pending');
    if (this.gameConfig !== view.state.config) {
      this.gameConfig = view.state.config;
      this.turnNumber = -1;
      this.totalOffers = 0;
    }
    if (this.turnNumber !== view.state.turn.number) {
      this.turnNumber = view.state.turn.number;
      this.offersThisTurn = 0;
    }
    if (view.state.turn.phase.at(-1)?.id === 'preRoll') {
      const legal = this.engine.getLegalCommands(view.state, view.seat, view.priv);
      const sole = legal.templates.length === 0 ? legal.commands[0] : undefined;
      if (legal.commands.length === 1 && sole && pending.allowed.includes(sole.type)) return sole;
    }
    const graph = boardGraph(view);
    const sites = openSites(view, graph);
    const hasSettlementSite = connectedSite(view, graph, sites);
    const cost = targetCost(view, hasSettlementSite);
    const goal = goalResource(view, cost);
    const withinPending = (command: CommandShape): boolean =>
      pending.allowed.includes(command.type);
    const policyFilter = (command: CommandShape): boolean => {
      if (!withinPending(command)) return false;
      if (command.type === 'BUILD_ROAD' && hasSettlementSite) return false;
      if (
        command.type === 'BUILD_SETTLEMENT' &&
        cost === CITY_COST &&
        !canSpendWithoutBreakingGoal(view.priv.hand, SETTLEMENT_COST, CITY_COST)
      )
        return false;
      if (
        command.type === 'OFFER_TRADE' ||
        command.type === 'PROPOSE_TRADE' ||
        command.type === 'MARITIME_TRADE'
      ) {
        if (commandWeight(command.type, this.offersThisTurn, this.totalOffers) === 0) return false;
        return usefulTrade(command, view, cost, goal);
      }
      if (
        command.type === 'BUY_DEV_CARD' &&
        !canSpendWithoutBreakingGoal(view.priv.hand, DEV_COST, cost)
      )
        return false;
      return true;
    };
    const options = { sampleIndex: (maxExclusive: number) => rng.int(maxExclusive) };
    const preferred = enumerateCommands(this.engine, view.state, view.seat, view.priv, {
      ...options,
      candidateFilter: policyFilter,
    });
    const commands = preferred.length
      ? preferred
      : enumerateCommands(this.engine, view.state, view.seat, view.priv, {
          ...options,
          candidateFilter: withinPending,
        });
    if (commands.length === 0) throw new Error(`No legal command for seat ${view.seat}`);
    const responses = commands.filter((command) => command.type === 'RESPOND_TRADE');
    if (responses.length) {
      const accept = rng.int(10) < 3;
      const matching =
        responses.find((command) => command.accept === accept) ??
        responses.find((command) => command.accept === false);
      if (matching) return matching;
    }
    const roadExtenders = commands.filter((command) => {
      if (command.type !== 'BUILD_ROAD' || typeof command.edge !== 'string') return false;
      const index = graph.edgeIndex[command.edge];
      return (
        index !== undefined && (graph.edgeVertices[index] ?? []).some((vertex) => sites.has(vertex))
      );
    });
    const focused = roadExtenders.length
      ? commands.filter(
          (command) => command.type !== 'BUILD_ROAD' || roadExtenders.includes(command),
        )
      : commands;
    const discards = focused.filter((command) => command.type === 'DISCARD');
    if (discards.length > 1 && cost) {
      const lostGoal = (command: CommandShape): number => {
        const cards = command.cards;
        if (typeof cards !== 'object' || cards === null || Array.isArray(cards)) return Infinity;
        return RESOURCES.reduce((total, resource) => {
          const discarded = Reflect.get(cards, resource);
          return (
            total +
            Math.max(
              0,
              cost[resource] -
                (view.priv.hand[resource] ?? 0) +
                (typeof discarded === 'number' ? discarded : 0),
            )
          );
        }, 0);
      };
      const least = Math.min(...discards.map(lostGoal));
      const safest = discards.filter((command) => lostGoal(command) === least);
      const selected = safest[rng.int(safest.length)];
      if (!selected) throw new Error('No discard choice');
      return selected;
    }
    const selected = weightedChoice(
      productiveSettlements(focused, view, graph),
      this.offersThisTurn,
      this.totalOffers,
      rng,
    );
    if (selected.type === 'OFFER_TRADE' || selected.type === 'PROPOSE_TRADE') {
      this.offersThisTurn++;
      this.totalOffers++;
    }
    return selected;
  }
}


FILE packages/bots/src/types.ts
import type {
  CommandShape,
  GameState,
  Pending,
  PrivateState,
  Seat,
  TradeOffer,
} from '@cp2p/engine';

/** Only the owner's secret state is available to a bot. */
export interface BotView {
  state: GameState;
  priv: PrivateState;
  seat: Seat;
}

/** Independent per-game, per-seat random stream. */
export interface BotRng {
  int(maxExclusive: number): number;
}

export interface Bot {
  id: string;
  decide(view: BotView, pending: Pending, rng: BotRng): CommandShape;
  respondToTrade?(view: BotView, offer: TradeOffer, rng: BotRng): boolean;
}


FILE docs/08-webrtc-networking.md
# 08 — WebRTC Networking & Signaling

## Goal

Implement `@cp2p/p2p`:

- a real `Transport` (from stage 06) over a **full mesh of WebRTC DataChannels**,
- pluggable **signaling adapters**: manual codes/QR (zero server), a tiny WebSocket signaling service, and in-mesh relay for mesh completion,
- configurable STUN/TURN,
- connection diagnostics.

Plus `apps/signaling`, the optional signaling service.

## Prerequisites

Stage 06 is complete. This stage can be built in parallel with stage 07.

## 1. Peer connections

- One `RTCPeerConnection` per remote peer. N ≤ 6 → at most 15 connections per game (5 per peer).
- Use the **perfect negotiation** pattern (the MDN reference implementation):
  - the "polite" peer is the one with the lexicographically smaller `PeerId`,
  - handle glare and ICE restarts,
  - use trickle ICE when the signaling channel supports it.
- DataChannels (negotiated, pre-agreed ids, so no extra signaling round):
  - `game` (id 0): `ordered: true`, reliable. All protocol messages.
  - `bulk` (id 1): `ordered: true`, reliable. Snapshots and sync batches, so they don't head-of-line-block game traffic.
- **Framing & chunking**: messages > 16 KiB are split into chunks: `[msgId u32][index u16][count u16][payload]`. Reassemble with a 30 s timeout and a 1 MiB cap. Respect `bufferedAmount`: pause sending above 1 MiB, resume on `bufferedamountlow` (threshold 256 KiB).
- **Peer authentication**: after the channel opens, both sides exchange `HELLO` signed with their Ed25519 identity key, _including a hash of the DTLS fingerprints of both sides_ (from the local/remote SDP). This binds the identity to this DTLS session and stops a malicious signaling server from man-in-the-middling. If the fingerprint binding fails, close the connection and show a security warning.
- Liveness: `PING` every 2 s. Mark the peer down after 3 missed pongs, or on `connectionState` = `failed`/`closed`. On `disconnected`, wait 5 s, then try an ICE restart. On `failed`, rebuild the connection via any available signaling path.

## 2. Signaling adapters

```ts
interface SignalingAdapter {
  kind: 'manual' | 'server' | 'mesh-relay';
  // deliver an opaque signaling blob to a specific peer (or a room)
  send(to: PeerId | 'room', blob: SignalBlob): Promise<void>;
  onSignal(cb: (from: PeerId, blob: SignalBlob) => void): Unsubscribe;
  close(): void;
}
```

### 2.1 Manual (copy/paste + QR) — zero infrastructure

- Only between the **inviter** and each **joiner**. Remaining mesh links are built via mesh relay (§2.3).
- Uses non-trickle ICE: wait for `icegatheringstate == complete` (with a 4 s cap), then encode.
- **Offer code**: `{ v:1, from: PeerId, sdp: minimised SDP, lobby: { name, inviterName }, sig }`.
  - Minimise the SDP: keep only lines needed for data channels (`v, o, s, t, a=group, m=application, c, a=ice-ufrag, a=ice-pwd, a=fingerprint, a=setup, a=mid, a=sctp-port, a=max-message-size, a=candidate`), and drop redundant candidates (keep host, srflx, relay; max 4).
  - Then canonical JSON → deflate-raw → base64url → prefix `HX1.`. Target < 700 chars so it fits a QR code (version ≤ 25, error correction M).
- Flow:
  1. The inviter shows the offer as a QR code, a copyable text code and a share button (Web Share API).
  2. The joiner scans or pastes it and gets an **answer code** shown the same way.
  3. The inviter scans or pastes the answer. The connection is established.
- The offer is single-use per joiner. The inviter UI shows a "next invite" button that creates a fresh `RTCPeerConnection` and offer for each additional joiner.
- Scanning: the `BarcodeDetector` API where available, else `jsQR` on camera frames (`getUserMedia`). Pasting must always work.

### 2.2 Signaling server (optional, best UX)

- `apps/signaling`: a room-based relay of opaque blobs. It **never** parses game data.
  - `wss://host/room/<roomId>`
  - Messages: `join { peerId, sig }`, `signal { to, blob }`, `peers [...]`, `leave`.
  - Room ids: 10 random base32 characters (≈ 50 bits), plus a URL-friendly invite `https://app/#/join/<roomId>`.
  - Limits: 8 peers per room, 64 KiB per message, 30 messages/s per connection, room TTL 24 h after the last activity.
  - Stateless apart from room membership. No logs of blob contents.
- Two deployment targets, from the same core logic:
  - **Cloudflare Worker + Durable Object** (one DO per room, WebSocket hibernation API),
  - **Node** (`ws` library) for self-hosting, with a Dockerfile.
- The client uses trickle ICE over the server.
- The app setting "Signaling server URL" defaults to the project's deployed instance (configurable at build time and by the user). Empty = manual only.

### 2.3 Mesh relay

- Once a peer is connected to _any_ mesh member, it can signal every other member **through the existing DataChannels**: `RELAY_SIGNAL { to, from, blob }`, forwarded by the connected member.
- Rules: relayed blobs are signed by the originator. The forwarder can't read them usefully (SDP isn't secret, but the signature prevents tampering).
- This means that in manual mode, the inviter only exchanges codes with each joiner once, and the full mesh builds itself.
- Also used for reconnections mid-game when the signaling server is unavailable.

### 2.4 Future adapter (optional; don't implement now)

- Public decentralised signaling (Nostr relays or BitTorrent tracker WebSocket signaling, as in the `trystero` library). Leave the interface ready. Record the idea in DECISIONS.md.

## 3. ICE servers

- Defaults: a list of public STUN servers (configurable). **No default TURN.**
- The settings UI accepts TURN URLs plus credentials (static), or a "TURN credentials endpoint" URL returning short-lived credentials (for users who deploy coturn or a managed TURN service). Fetch it with a TanStack Query `useTurnCredentials` query (`staleTime` = credential TTL − 60 s) and validate the response with a Valibot schema.
- Write `docs/ops/turn.md` explaining how to deploy coturn, with a sample config.
- ICE transport policy option: `all` (default) or `relay` (privacy mode: hides your IP from other players; requires TURN).

## 4. Transport implementation

`WebRtcTransport implements Transport`:

- Maintains the peer table `{ peerId → { pc, channels, state, rtt, lastSeen } }`.
- `send`/`broadcast` only to authenticated peers.
- Emits `onPeerChange` on authentication and on loss.
- Exposes `stats()`: RTT, bytes, candidate pair types (host/srflx/relay) for diagnostics.

## 5. Diagnostics UI

A "Connection" panel in lobby and game:

- per-peer status, RTT, and route type (direct LAN / direct NAT / relayed),
- a "test connectivity" button that gathers local candidates and reports whether srflx/relay candidates were obtained (detecting "STUN blocked" / "no TURN configured"). Model it as a TanStack Query mutation; signaling-server reachability is a `useSignalingHealth` query,
- clear guidance text when a connection fails: suggest TURN, or the same network, or a hotspot.

## 6. Testing

- **Unit**: SDP minimiser round-trip (a minimised SDP still negotiates); code encode/decode; chunking/reassembly with random sizes; the backpressure logic, with a fake channel.
- **Node integration**: use `node-datachannel` (libdatachannel bindings) or `werift` as the `RTCPeerConnection` implementation in Node to run 4-peer mesh tests with the in-process signaling server. The transport must accept an injected RTC implementation.
- **Playwright multi-browser**: launch 4 browser contexts (Chromium ×2, Firefox, WebKit), using the local signaling server, and play a short scripted game (bots control all seats) to completion. Also run the manual-code flow by passing codes between contexts through the test harness.
- **Fault injection**: close a browser context mid-game and reopen it (full reconnection is stage 10; here assert only that the transport detects the loss and rebuilds when the peer returns).

## Steps

1. `PeerLink` (single connection, perfect negotiation, channels, chunking, backpressure, auth handshake with fingerprint binding).
2. `WebRtcTransport` (mesh management).
3. Signaling server core + Node host + tests; then the Cloudflare DO host.
4. Server adapter.
5. Manual adapter: SDP minimisation, codes, QR generate/scan UI components.
6. Mesh relay adapter.
7. ICE settings, diagnostics panel, TURN docs.
8. Node integration tests + Playwright multi-browser test.

## Acceptance criteria

- [x] 4 browsers (including Firefox and WebKit) form a full mesh via the signaling server and via manual codes plus mesh relay. Verified in [run 36408263093](verification/stage08/mixed-engine-manual-2026-09-28.md) at `95a1f63`; manual relay also finished with four audits, while signaling hit its unchanged 240-second game limit.
- [ ] Offer codes fit a QR code and scan successfully on a phone camera (manual test, recorded in STATUS.md).
- [x] The identity binding rejects a tampered signaling path (unit test with a MITM fake signaling adapter swapping fingerprints).
- [x] A 1 MiB message transfers correctly with backpressure.
- [x] The signaling server never logs or inspects blobs (code review checklist item plus a test asserting blobs are forwarded verbatim).

The [networking acceptance audit](verification/stage08/current-acceptance-audit.md)
records the source review and passing focused checks for these three items.


FILE docs/09-lobby-and-game-setup.md
# 09 — Lobby & Game Setup (first end-to-end P2P game)

## Goal

Users can create a game, invite friends (link, code or QR), configure rules, fill seats with humans or bots, and start. Starting runs a **genesis ceremony** that produces the signed genesis entry with all cryptographic commitments. After this stage, real people on different networks can play a full base game P2P.

## Prerequisites

Stages 05, 07 and 08 are complete.

## 1. Lobby model

The lobby is a small replicated document owned by the **lobby host** (the creator; after a host disconnect, the lowest remaining peer). Unlike the game log, lobby edits are host-authoritative and simple: the host broadcasts `LOBBY_STATE { version, ... }`, and other peers send requests.

```ts
interface LobbyState {
  version: number;
  lobbyId: string; // = signaling room id or random id in manual mode
  hostPeer: PeerId;
  name: string;
  seats: Array<{
    seat: Seat;
    kind: 'open' | 'human' | 'bot';
    peer?: PeerId;
    name?: string;
    colour: ColourId;
    ready: boolean;
    botLevel?: BotLevel;
    botHost?: PeerId;
  }>;
  spectators: PeerId[];
  config: GameConfigDraft; // modules + options + map choice + timers
  status: 'open' | 'starting' | 'started';
}
```

Messages: `LOBBY_STATE`, `LOBBY_REQ { kind: 'takeSeat' | 'leaveSeat' | 'setName' | 'setColour' | 'setReady' | 'spectate' }`, `LOBBY_CONFIG { patch }` (host only), `LOBBY_KICK` (host only), `LOBBY_START` (host only, needs all humans ready).

Rules:

- Any config change resets every `ready` flag.
- Colours must be unique.
- 2–4 seats for base; 5–6 once the `five-six` module exists.
- Bot seats are hosted by the lobby host by default. The host can reassign a bot's host to another peer.

## 2. Screens

1. **Home**: Play online (create / join), Play local (stage 05), Settings, How to play, Rules variants reference.
2. **Create game**: name, then choose the connection method:
   - "Invite link" (signaling server): shows a link, a copy button and a QR code.
   - "Offline codes" (manual): shows the offer QR/code per joiner, with the answer-code input.
3. **Join**: route `join/$roomId` (`#/join/<room>`) auto-joins via the server; or paste/scan a code at `#/join`. Routes added in this stage: `online/create`, `join/index`, `join/$roomId`, `lobby/$lobbyId`, `game/$gameId` (the P2P game screen; `useBlocker` guard on leave).
4. **Lobby**:
   - seat list with status, colour picker, ready toggle;
   - config panel (editable only by the host, read-only for others): player count, map layout, modules, all options (from each module's `optionsSchema`, rendered generically), VP target, timers, seed ("random" or a fixed hex for replaying a board);
   - chat;
   - connection diagnostics;
   - "Add bot" / "Open seat" / "Kick".
5. **Starting**: a progress view of the ceremony steps (§3) with per-peer check marks and timeouts.
6. Then the game screen (stage 05 UI with a `P2PSession`).

## 3. Genesis ceremony

Run when the host presses Start (all humans ready, all connected in a full mesh). Every step is signed. Before local genesis consent, a step timeout (20 s) aborts the ceremony and returns to the lobby with an error. Retire that ceremony and use fresh secrets on retry. Once a client durably promises and signs an exact genesis digest, timeout cannot revoke the signature. It stays in a recoverable waiting state until that genesis is assembled or an agreed disposition resolves it.

1. **Freeze**: the host broadcasts `CEREMONY_BEGIN { lobbyVersion, protocolVersion, engineVersion, config, seats, ceremonyNonce }`. Every peer checks it equals its lobby view and replies with a signed `FREEZE_ACK`.
2. **Secrets**: each human seat (and each bot host, for each of its bots) generates `masterSecret`s. For each one it computes and publishes a `SeatCommitments` package:
   - `masterPub` and the encryption key `E` (stage 07 §1),
   - `beaconTip` (hash-chain tip, stage 07 §2),
   - `seedCommit = H("seed" ‖ seedShare)`, where `seedShare = HKDF(master, "genesis-seed")`,
   - deck lock public keys for the decks the config needs (or a compact commitment from which they're derivable; see stage 07 §3),
   - Feldman coefficient commitments and `escrowShareHashes[]` (stage 07 §7).
3. **Escrow**, only when the game starts with at least four humans: send sealed Shamir shares via `PRIVATE`. Each recipient verifies its share against the Feldman commitments, then replies with a signed `SHARE_ACK { dealerSeat, H(share) }`. A bad share aborts the ceremony (stage 07 §7).
4. **Seed reveal**: after every `seedCommit` is collected, each seat reveals `seedShare`. Then `genesisSeed = SHA-256("cp2p/genesis" ‖ seedShares in seat order)`. (The config may specify a fixed seed; then the commit-reveal is skipped and the seed is used as-is. Mark such games "fixed board".)
5. **Deck setup**: before genesis consent, collect every ordered shuffle and lock pass for every configured deck. The canonical catalogue and all seat keys, including bots, come from the frozen manifest. The deck `ceremonyId` binds the protocol/engine versions, config, ordered seats and fresh 32-byte ceremony nonce. It excludes the later seed and transcript commitments to avoid a hash cycle. Persist each local pass before sending it. Every human must obtain and verify the complete transcript and final locked deck; missing or invalid passes abort the ceremony.
6. **Genesis draft**: every peer builds the identical `Genesis` body:
   `{ protocolVersion, engineVersion, config, seats(with game keys, identity bindings, names, colours, kinds, botHosts), genesisSeed, ceremonyNonce, security: 'verified', commitments(including deck definitions, ordered signed-pass hashes, final locked-deck hashes, share acknowledgements and sealed shares), createdAt(host clock, informational) }`.
   Hash the body and derive the routing `gameId` exactly as defined in stage 06. Each human uses `prepareGenesisConsent` to verify the complete deck transcript and durably reserve one final genesis digest for this ceremony and seat before returning its signature. A retry returns the same consent; a redraft that changes the digest must begin a fresh ceremony. The body excludes its derived identifier and consent signatures. A fixed board still needs a fresh agreed ceremony nonce. Retain the exact public transcript blobs for setup completion after a restart; a hash list alone cannot prove availability or valid setup.
   The ceremony coordinator first records an irreversible `consenting` phase for that digest in the same device-global registry that orders aborts. From then on, local abort is refused. Later authenticated share disclosures are retained across restart for agreed handling; they do not erase the consent or silently allow normal gameplay. A valid signed genesis can complete local storage while its disclosure disposition remains pending. This boundary avoids a client retiring keys whose genesis signature peers can still use.
7. **Start and certify decks**: seq 0 is genesis with all human signatures. The term 1 sequencer certifies the already-fixed passes individually as state-preserving `crypto/deck-pass` entries, each within the 256 KiB message cap including its proposal/certificate envelope. Certified proposer-exclusion controls may intervene without resetting the deck cursor. The first engine pending, `startSeat`, stays frozen at its genesis anchor. No human reveals a beacon link and no gameplay entry is accepted until every committed deck pass has been verified and certified.

Version compatibility: in `HELLO` and in step 1, peers compare `protocolVersion` (must be equal) and `engineVersion` (must be equal). Otherwise the joining peer sees "Your app version differs from the host's. Please reload (the host is on vX)." The service worker update flow (stage 18) must make "reload to update" reliable.

## 4. Seat keys & bots

- A human gets a fresh voting/command key for each game, bound to the authenticated device identity during the ceremony. Persist that key together with the game's consensus safety records before signing genesis. Keep it independent of escrowed game secrets.
- A bot seat gets its own Ed25519 key generated by the bot host. The bot host signs bot commands with the bot key. The genesis records `botHost` so peers know which peer relays them.
- Bot move timing: add a humanlike delay (configurable 0.5–2 s) so bots don't act instantly.

## 5. Turn timers in P2P

- Timer config lives in genesis. The **sequencer** tracks deadlines using the entry times it observes. When a deadline passes, the sequencer appends a `system` `TIMEOUT` entry whose evidence is `{ pendingSince: seq, deadlineMs }`.
- That evidence is outside the engine input. The input itself contains only `kind`, `type`, `seat`, and `phase`.
- Peers accept it if their own local clock agrees (with ±3 s tolerance) that the deadline has passed since they applied `pendingSince`. If they disagree, they reject it, and the sequencer retries later. Don't use absolute timestamps across devices; use each peer's own monotonic time since it applied the referenced entry.
- The UI timer ring uses local time since the referenced entry.
- Timeout auto-actions that need the timed-out seat's private data (e.g. discard) are computed by that seat's client if it's online (it submits the command itself when its own local timer expires). If it's offline, the action waits until takeover (stage 10).

## 6. Chat & emotes

- `CHAT` messages are broadcast, signed and rate-limited (5 per 10 s), max 300 chars. They're not in the game log (not hashed), but are stored locally.
- A small set of quick emotes/reactions.
- Mute per player.

## Steps

1. Lobby state machine + messages + host handover (unit tests on memnet).
2. Screens: home, create, join, lobby (with generic option rendering from `optionsSchema`).
3. Ceremony implementation + memnet tests (including every abort path).
4. Wire the `P2PSession` start from genesis. Game screen in P2P mode (own seat only; other hands hidden; waiting indicators showing who the game waits for, from `getPending`).
5. Timers in P2P.
6. Chat.
7. Playwright: 3 browser contexts + 1 bot; create via link, join, configure, start, and play to the end with bots controlling all human seats through the `__cp2p` hook. Assert all contexts see the same winner and the audit passes.
8. Manual test on real devices across networks (home Wi-Fi + mobile hotspot). Record the results in STATUS.md.

## Acceptance criteria

- [ ] Create → invite → join → start → finish → audit ✓ works over the signaling server and over manual codes.
- [x] Mixed humans and bots work, and a guest peer can host a bot. The [hosted-bot terminal trace](verification/stage09/hosted-bot-v6-acceptance.md) verifies the full two-human/two-bot game and both audits; the [guest-hosted command trace](verification/stage09/guest-bot-consent-races-2026-09-28.md) certifies a bot command signed by a bot hosted on the other human peer and strictly replays it on both peers.
- [x] A version mismatch is detected with a clear message. The [signed-version UI check](verification/stage09/lobby-ceremony-ui-bridge.md) rejects incompatible protocol and engine versions and displays the host version without a start action.
- [x] Pre-consent ceremony abort and timeout paths retire the attempt and return a retired state to the lobby. The [timeout/disclosure integration checks](verification/stage09/ceremony-timeout-disclosure-check-2026-09-28.md) cover missing phases and UI restoration; the [cross-coordinator consent races](verification/stage09/guest-bot-consent-races-2026-09-28.md) prove durable retirement-first and consent-first outcomes.
- [x] A post-consent timeout preserves the signed promise and restores to a recoverable waiting state. The timeout/disclosure integration check retains the exact consent across restore and completes only when the missing signed packet arrives.
- [x] An authenticated post-consent disclosure preserves the promise and restores a recoverable halted/waiting state. The [timeout/disclosure integration checks](verification/stage09/ceremony-timeout-disclosure-check-2026-09-28.md) exercise the real coordinator and rendered UI; the [opening fence](verification/stage09/disclosure-opening-fence-2026-09-28.md) verifies retained authenticated evidence blocks opening after restore. This criterion does not require normal gameplay to resume after disclosure.
- [x] Turn timers work, and a disagreeing peer cannot be forced into an early timeout. The [signed timer traces](verification/stage10/timer-acceptance.md) cover early `preRoll` and trade timeout refusal at verified replicas; the [owner-private discard trace](verification/stage09/private-discard-timer-2026-09-28.md) proves no pre-expiry command and the owner's signed discard at local expiry.


FILE docs/verification/p2p-acceptance-policy.md
# Bounded M-C and M-D acceptance

The user authorized reducing redundant game counts. Stages 07 and 10 use the
following deterministic coverage requirements instead of hundreds of repetitions
of each scenario. This changes sample counts, not the required failure cases,
security guarantees, performance targets or browser coverage. No unchecked gate
becomes complete through this policy change.

## Stage 07

Run one reproducible game for each of the nine Stage 06 scenarios with the real
cryptographic participants and verified genesis. The existing stub-randomness
simulation remains useful separate coverage; it cannot satisfy these checks.

| Scenario                        | Required observation                                                                                                                                                        |
| ------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Clean four-peer network         | Complete play and independent final audits with matching certified histories.                                                                                               |
| Delayed and duplicated messages | Actually deliver duplicates and 50–400 ms latency; certify the same history and finish.                                                                                     |
| Sequencer crash and restart     | Crash mid-turn, keep durable safety records, return after 20 seconds, and finish without conflicting votes.                                                                 |
| Two-against-two partition       | Neither partition commits during the 30-second split. Heal and finish from the same prefix.                                                                                 |
| Three-against-one partition     | The quorum commits when required inputs are available. A missing private input must wait. Heal, catch up and finish.                                                        |
| Invalid proposer                | Reject the signed invalid command, certify the attributable finding and proposer exclusion, then finish with three honest voters and legal commands from the excluded seat. |
| Censoring proposer              | Observe an actually censored command, replace the proposer and commit that command, then finish.                                                                            |
| Corrupted local state           | Exercise verified repair from certified history and finish without rolling back any committed entry.                                                                        |
| Two simultaneous restarts       | Restore both peers from durable records, fetch missing certified entries, and finish on the same history.                                                                   |

Record protocol version, source revision, seed, actual injected fault, certified
head and relevant safety assertions. The faulty client in the invalid-proposer
case is not required to maintain an honest history. Expected misconduct findings
in that case are distinct from false findings in honest games.

Require three honest terminal compositions: human-only, humans with hosted bots,
and survivors with a recovered bot. Each must finish on the current protocol,
have no false `CHEAT_PROOF`, and obtain a complete successful independent audit
from every surviving human. At least one uses the server-backed browser path.
The same game can satisfy a scenario and a composition when it proves both.

Keep one focused signed adversarial case for every row of the Stage 07 cheat
table. Assert the stated detection time and outcome, including the private
recovery-void policy. Primitive rejection alone does not prove admission or
certification behavior. Keep the fast 100,000-round dice distribution test.

## Stage 10

Exercise every named chaos addition at least once with deterministic faults and
the current protocol. A trace may cover multiple rows only when it records the
required observation for each.

| Case                         | Required observation                                                                                                                                                                                                           |
| ---------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Periodic restart             | In a four-human game, restart a peer with storage intact at each reached approximately 50-entry boundary, rotating the peer. Restore the exact certified prefix and safety state before voting.                                |
| Permanent departure          | Depart mid-game with four humans, certify old-quorum authorization, reconstruct private state, activate the bot, finish and independently audit every survivor.                                                                |
| Everyone leaves              | Close all peers mid-game, reopen them in a fixed non-seat order, restore the same prefix, certify a new move, finish and audit.                                                                                                |
| Sequencer loss during unlock | Interrupt before persistence, after persistence but before send, and after peer acceptance but before local commit. Never send an unpersisted vote or replace a durable contribution; retry the same operation after recovery. |
| Return after takeover        | Rebuild the returning human's private state, certify fresh keys, keep old keys retired and continue. Exercise another takeover where the signed quorum permits it; otherwise assert pause.                                     |

Compare reconstructed private state with an independent omniscient engine at
every certified sequence of the representative lifecycle game. Add focused
fixtures for draw, steal, transfer, recovery and return if that game does not
exercise their private-state changes. Public-state or final-score agreement
cannot replace exact private-state equality.

Retain focused checks for every signing/persistence interruption boundary,
transaction abort, lost acknowledgement, writer contention, stale import,
migration, withholding shares and two-/three-human quorum loss. Retain native
browser refresh, takeover, save transfer, encryption, history and snapshot
checks. The measured three-second resume target remains unchanged.

## Execution

Use bounded runs with explicit time and move limits. A timeout is a failure to
investigate, not a reason to silently increase the limit. Store public results
and source provenance; keep private game material out of reports. Run local
native browser checks in Chrome. Run the required Firefox/WebKit combinations
on CI to avoid the user's local browser crash popups.

The existing Stage 06 CI policy is unchanged. The new real-crypto and lifecycle
fixtures must be named and mapped to these rows before claiming acceptance.

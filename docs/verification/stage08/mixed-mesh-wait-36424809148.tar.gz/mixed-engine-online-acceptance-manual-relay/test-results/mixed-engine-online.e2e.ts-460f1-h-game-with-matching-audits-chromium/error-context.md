# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mixed-engine-online.e2e.ts >> four mixed-engine contexts finish a manual-relay full-mesh game with matching audits
- Location: tests/mixed-engine-online.e2e.ts:1002:1

# Error details

```
Error: Mixed-engine manual acceptance failed. Sanitized peer/lobby diagnostics: [{"engine":"chromium-a","route":"http://127.0.0.1:5310/#/lobby/a47kmdh5g5","alerts":[],"diagnosticEvents":[{"atMs":6839,"source":"signal-description","from":"57kqYxfEIftM","to":"q30hmoYErQSA","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":12866,"source":"signal-description","from":"57kqYxfEIftM","to":"9mylgSOvVRoz","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":2,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":25233,"source":"signal-description","from":"57kqYxfEIftM","to":"rPZsFAfDGbgO","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":457,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":3,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"host"},{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"q30hmoYErQSA","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"9mylgSOvVRoz","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"rPZsFAfDGbgO","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":null,"lobbyStatus":"open","humanCount":4,"manual":{"phase":"connected","gatheringComplete":false,"hasCode":false},"closed":false,"game":null},{"engine":"chromium-b","route":"http://127.0.0.1:5310/#/lobby/a47kmdh5g5","alerts":[],"diagnosticEvents":[{"atMs":4845,"source":"manual-rtc","stage":"setRemoteDescription","outcome":"fulfilled"},{"atMs":4846,"source":"manual-rtc","stage":"setLocalDescription","outcome":"fulfilled"},{"atMs":4856,"source":"manual-open","stage":"complete"},{"atMs":4865,"source":"signal-description","from":"q30hmoYErQSA","to":"57kqYxfEIftM","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":5040,"source":"signal-description","from":"q30hmoYErQSA","to":"57kqYxfEIftM","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":2,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":457,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":25012,"source":"signal-description","from":"q30hmoYErQSA","to":"rPZsFAfDGbgO","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":2,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"host"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"57kqYxfEIftM","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"rPZsFAfDGbgO","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":null,"lobbyStatus":"open","humanCount":4,"manual":{"phase":"connected","gatheringComplete":true,"hasCode":false},"closed":false,"game":null},{"engine":"firefox","route":"http://127.0.0.1:5310/#/lobby/a47kmdh5g5","alerts":[],"diagnosticEvents":[{"atMs":5422,"source":"manual-rtc","stage":"setRemoteDescription","outcome":"fulfilled"},{"atMs":5442,"source":"manual-rtc","stage":"setLocalDescription","outcome":"fulfilled"},{"atMs":5481,"source":"manual-open","stage":"complete"},{"atMs":5538,"source":"signal-description","from":"9mylgSOvVRoz","to":"57kqYxfEIftM","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":504,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":5648,"source":"signal-description","from":"9mylgSOvVRoz","to":"57kqYxfEIftM","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":2,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":547,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":5822,"source":"signal-description","from":"9mylgSOvVRoz","to":"q30hmoYErQSA","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":504,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":6232,"source":"signal-description","from":"9mylgSOvVRoz","to":"q30hmoYErQSA","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":810,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":6736,"source":"signal-description","from":"9mylgSOvVRoz","to":"q30hmoYErQSA","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":810,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":7738,"source":"signal-description","from":"9mylgSOvVRoz","to":"q30hmoYErQSA","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":810,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":9742,"source":"signal-description","from":"9mylgSOvVRoz","to":"q30hmoYErQSA","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":810,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":19649,"source":"signal-description","from":"9mylgSOvVRoz","to":"rPZsFAfDGbgO","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":4,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":504,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":2,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"57kqYxfEIftM","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"q30hmoYErQSA","slot":"links","authenticated":false,"connection":"new","ice":"new","signaling":"have-local-offer","localRevision":1,"remoteRevision":-1,"queuedDescriptions":0},{"peer":"rPZsFAfDGbgO","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":null,"lobbyStatus":"open","humanCount":4,"manual":{"phase":"connected","gatheringComplete":true,"hasCode":false},"closed":false,"game":null},{"engine":"webkit","route":"http://127.0.0.1:5310/#/lobby/a47kmdh5g5","alerts":[],"diagnosticEvents":[{"atMs":7068,"source":"manual-rtc","stage":"setRemoteDescription","outcome":"fulfilled"},{"atMs":7069,"source":"manual-rtc","stage":"setLocalDescription","outcome":"fulfilled"},{"atMs":11076,"source":"manual-open","stage":"complete"},{"atMs":11091,"source":"signal-description","from":"rPZsFAfDGbgO","to":"57kqYxfEIftM","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":11502,"source":"signal-description","from":"rPZsFAfDGbgO","to":"57kqYxfEIftM","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":720,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":11571,"source":"signal-description","from":"rPZsFAfDGbgO","to":"57kqYxfEIftM","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":2,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":457,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":13182,"source":"signal-description","from":"rPZsFAfDGbgO","to":"q30hmoYErQSA","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":3,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":457,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":13250,"source":"signal-description","from":"rPZsFAfDGbgO","to":"9mylgSOvVRoz","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":4,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":435,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":3,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"57kqYxfEIftM","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"q30hmoYErQSA","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"9mylgSOvVRoz","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":null,"lobbyStatus":"open","humanCount":4,"manual":{"phase":"connected","gatheringComplete":false,"hasCode":false},"closed":false,"game":null}]
```

# Test source

```ts
  876  |               view.pending?.kind !== 'player' ||
  877  |               !view.privateState ||
  878  |               !view.legal ||
  879  |               !view.head
  880  |             )
  881  |               continue;
  882  |             const actor = bots[index];
  883  |             if (!actor) throw new Error('Missing deterministic browser bot');
  884  |             const command = actor.bot.decide(
  885  |               { state: actor.state(view.state), priv: view.privateState, seat: view.seat },
  886  |               view.pending,
  887  |               actor.rng,
  888  |             );
  889  |             const refused = await submit(page, gameId, view.seat, command, view.head.seq);
  890  |             if (refused) refusedCommands[refused] = (refusedCommands[refused] ?? 0) + 1;
  891  |             if (refused && refused !== 'stale-head' && refused !== 'stale-revision')
  892  |               throw new Error(`A legal browser move was rejected: ${refused}`);
  893  |             if (!refused) {
  894  |               commands += 1;
  895  |               accepted[command.type] = (accepted[command.type] ?? 0) + 1;
  896  |             }
  897  |             if (commands > 300) throw new Error('The bounded mixed-engine game exceeded 300 moves');
  898  |           }
  899  |           const views = await Promise.all(pages.map((page) => inspectGame(page, gameId)));
  900  |           if (views.every((view) => view?.result)) terminalAt ??= Date.now();
  901  |           return views.every((view) => view?.result && view.audit?.kind === 'complete');
  902  |         },
  903  |         { timeout: 150_000, intervals: [100] },
  904  |       )
  905  |       .toBe(true);
  906  |   } catch (error) {
  907  |     throw new Error(`Mixed-engine play/audit driver: ${JSON.stringify(diagnostic())}`, {
  908  |       cause: error,
  909  |     });
  910  |   }
  911  |   const final = await Promise.all(pages.map((page) => inspectGame(page, gameId)));
  912  |   const head = final[0]?.head;
  913  |   const result = final[0]?.result;
  914  |   if (!head || !result) throw new Error('Missing audited terminal state');
  915  |   for (const view of final) {
  916  |     expect(view?.head).toEqual(head);
  917  |     expect(view?.result).toEqual(result);
  918  |     expect(view?.audit).toMatchObject({ kind: 'complete', report: { ok: true, complete: true } });
  919  |     expect(view?.peerCount).toBe(3);
  920  |   }
  921  |   return { ...diagnostic(), terminalSeq: head.seq, modeAuditCount: final.length };
  922  | }
  923  | 
  924  | async function runMode(playwright: Playwright, mode: 'signaling' | 'manual') {
  925  |   const opened = await launchFourEngines(playwright);
  926  |   const [host, second, third, fourth] = opened.pages;
  927  |   if (!host || !second || !third || !fourth) throw new Error('Missing mixed-engine page');
  928  |   const errors: EngineName[] = [];
  929  |   for (const [index, page] of opened.pages.entries()) {
  930  |     const engine = engineNames[index];
  931  |     if (!engine) throw new Error('Missing browser engine label');
  932  |     page.on('pageerror', () => errors.push(engine));
  933  |   }
  934  |   const started = Date.now();
  935  |   let phase = 'lobby';
  936  |   let readingProgress = false;
  937  |   // A runner-level timeout can interrupt the catch block itself. Retain public
  938  |   // progress during the run, without private hands, SDP, candidates or keys.
  939  |   const progress = setInterval(() => {
  940  |     if (readingProgress) return;
  941  |     readingProgress = true;
  942  |     void Promise.all(
  943  |       opened.pages.map(async (page, index) => ({
  944  |         engine: engineNames[index],
  945  |         ...(await readRoom(page, true).catch(() => ({ unavailable: true }))),
  946  |       })),
  947  |     )
  948  |       .then((peers) => {
  949  |         process.stdout.write(
  950  |           `${JSON.stringify({ mode, phase, elapsedMs: Date.now() - started, peers })}\n`,
  951  |         );
  952  |         return undefined;
  953  |       })
  954  |       .finally(() => {
  955  |         readingProgress = false;
  956  |       });
  957  |   }, 10_000);
  958  |   try {
  959  |     const fixture = await startFourPlayerRoom(opened.pages, mode);
  960  |     const lobbyElapsedMs = Date.now() - started;
  961  |     phase = 'setup';
  962  |     const setupStarted = Date.now();
  963  |     await certifyPostSetupMove(opened.pages, fixture.gameId);
  964  |     const setupElapsedMs = Date.now() - setupStarted;
  965  |     phase = 'play-and-audit';
  966  |     const completion = await finishAndAudit(opened.pages, fixture.gameId);
  967  |     expect(errors).toEqual([]);
  968  |     return { mode, browserSet: engineNames, lobbyElapsedMs, setupElapsedMs, ...completion };
  969  |   } catch (error) {
  970  |     const diagnostics = await Promise.all(
  971  |       opened.pages.map(async (page, index) => ({
  972  |         engine: engineNames[index],
  973  |         ...(await readRoom(page, true).catch(() => null)),
  974  |       })),
  975  |     );
> 976  |     throw new Error(
       |           ^ Error: Mixed-engine manual acceptance failed. Sanitized peer/lobby diagnostics: [{"engine":"chromium-a","route":"http://127.0.0.1:5310/#/lobby/a47kmdh5g5","alerts":[],"diagnosticEvents":[{"atMs":6839,"source":"signal-description","from":"57kqYxfEIftM","to":"q30hmoYErQSA","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":12866,"source":"signal-description","from":"57kqYxfEIftM","to":"9mylgSOvVRoz","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":2,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":25233,"source":"signal-description","from":"57kqYxfEIftM","to":"rPZsFAfDGbgO","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":457,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":3,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"host"},{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"q30hmoYErQSA","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"9mylgSOvVRoz","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"rPZsFAfDGbgO","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":null,"lobbyStatus":"open","humanCount":4,"manual":{"phase":"connected","gatheringComplete":false,"hasCode":false},"closed":false,"game":null},{"engine":"chromium-b","route":"http://127.0.0.1:5310/#/lobby/a47kmdh5g5","alerts":[],"diagnosticEvents":[{"atMs":4845,"source":"manual-rtc","stage":"setRemoteDescription","outcome":"fulfilled"},{"atMs":4846,"source":"manual-rtc","stage":"setLocalDescription","outcome":"fulfilled"},{"atMs":4856,"source":"manual-open","stage":"complete"},{"atMs":4865,"source":"signal-description","from":"q30hmoYErQSA","to":"57kqYxfEIftM","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":5040,"source":"signal-description","from":"q30hmoYErQSA","to":"57kqYxfEIftM","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":2,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":457,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":25012,"source":"signal-description","from":"q30hmoYErQSA","to":"rPZsFAfDGbgO","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":2,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"host"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"57kqYxfEIftM","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"rPZsFAfDGbgO","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":null,"lobbyStatus":"open","humanCount":4,"manual":{"phase":"connected","gatheringComplete":true,"hasCode":false},"closed":false,"game":null},{"engine":"firefox","route":"http://127.0.0.1:5310/#/lobby/a47kmdh5g5","alerts":[],"diagnosticEvents":[{"atMs":5422,"source":"manual-rtc","stage":"setRemoteDescription","outcome":"fulfilled"},{"atMs":5442,"source":"manual-rtc","stage":"setLocalDescription","outcome":"fulfilled"},{"atMs":5481,"source":"manual-open","stage":"complete"},{"atMs":5538,"source":"signal-description","from":"9mylgSOvVRoz","to":"57kqYxfEIftM","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":504,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":5648,"source":"signal-description","from":"9mylgSOvVRoz","to":"57kqYxfEIftM","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":2,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":547,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":5822,"source":"signal-description","from":"9mylgSOvVRoz","to":"q30hmoYErQSA","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":504,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":6232,"source":"signal-description","from":"9mylgSOvVRoz","to":"q30hmoYErQSA","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":810,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":6736,"source":"signal-description","from":"9mylgSOvVRoz","to":"q30hmoYErQSA","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":810,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":7738,"source":"signal-description","from":"9mylgSOvVRoz","to":"q30hmoYErQSA","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":810,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":9742,"source":"signal-description","from":"9mylgSOvVRoz","to":"q30hmoYErQSA","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":3,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":810,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":19649,"source":"signal-description","from":"9mylgSOvVRoz","to":"rPZsFAfDGbgO","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":4,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":504,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":2,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"57kqYxfEIftM","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"q30hmoYErQSA","slot":"links","authenticated":false,"connection":"new","ice":"new","signaling":"have-local-offer","localRevision":1,"remoteRevision":-1,"queuedDescriptions":0},{"peer":"rPZsFAfDGbgO","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":null,"lobbyStatus":"open","humanCount":4,"manual":{"phase":"connected","gatheringComplete":true,"hasCode":false},"closed":false,"game":null},{"engine":"webkit","route":"http://127.0.0.1:5310/#/lobby/a47kmdh5g5","alerts":[],"diagnosticEvents":[{"atMs":7068,"source":"manual-rtc","stage":"setRemoteDescription","outcome":"fulfilled"},{"atMs":7069,"source":"manual-rtc","stage":"setLocalDescription","outcome":"fulfilled"},{"atMs":11076,"source":"manual-open","stage":"complete"},{"atMs":11091,"source":"signal-description","from":"rPZsFAfDGbgO","to":"57kqYxfEIftM","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":458,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":11502,"source":"signal-description","from":"rPZsFAfDGbgO","to":"57kqYxfEIftM","kind":"description","blobKeys":["description","generation","kind","revision"],"generation":1,"revision":1,"inReplyTo":null,"descriptionType":"offer","descriptionKeys":["sdp","type"],"sdpLength":720,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":11571,"source":"signal-description","from":"rPZsFAfDGbgO","to":"57kqYxfEIftM","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":2,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":457,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":13182,"source":"signal-description","from":"rPZsFAfDGbgO","to":"q30hmoYErQSA","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":3,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":457,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true},{"atMs":13250,"source":"signal-description","from":"rPZsFAfDGbgO","to":"9mylgSOvVRoz","kind":"description","blobKeys":["description","generation","inReplyTo","kind","revision"],"generation":4,"revision":1,"inReplyTo":1,"descriptionType":"answer","descriptionKeys":["sdp","type"],"sdpLength":435,"candidateLength":null,"candidateKeys":[],"canonicalFailure":null,"blobValidWithSyntheticEnvelope":true}],"roomOpen":true,"peerCount":3,"connectionError":null,"diagnostic":null,"signalingState":"connecting","peerStates":[{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"},{"state":"connected","route":"srflx"}],"unfinishedLinks":[{"peer":"57kqYxfEIftM","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"q30hmoYErQSA","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0},{"peer":"9mylgSOvVRoz","slot":"links","authenticated":true,"connection":"connected","ice":"connected","signaling":"stable","localRevision":1,"remoteRevision":1,"queuedDescriptions":0}],"startup":null,"lobbyStatus":"open","humanCount":4,"manual":{"phase":"connected","gatheringComplete":false,"hasCode":false},"closed":false,"game":null}]
  977  |       `Mixed-engine ${mode} acceptance failed. Sanitized peer/lobby diagnostics: ${JSON.stringify(diagnostics)}`,
  978  |       { cause: error },
  979  |     );
  980  |   } finally {
  981  |     clearInterval(progress);
  982  |     await Promise.allSettled(opened.contexts.map((context) => context.close()));
  983  |     await Promise.allSettled(opened.browsers.map((browser) => browser.close()));
  984  |   }
  985  | }
  986  | 
  987  | test('four mixed-engine contexts finish a signaling full-mesh game with matching audits', async ({
  988  |   playwright,
  989  | }, testInfo) => {
  990  |   test.skip(
  991  |     process.env.CP2P_MIXED_ENGINE_MODE !== 'signaling',
  992  |     'The workflow runs one connection mode per job',
  993  |   );
  994  |   test.setTimeout(240_000);
  995  |   const result = await runMode(playwright, 'signaling');
  996  |   await testInfo.attach('mixed-engine-summary', {
  997  |     body: JSON.stringify(result, null, 2),
  998  |     contentType: 'application/json',
  999  |   });
  1000 | });
  1001 | 
  1002 | test('four mixed-engine contexts finish a manual-relay full-mesh game with matching audits', async ({
  1003 |   playwright,
  1004 | }, testInfo) => {
  1005 |   test.skip(
  1006 |     process.env.CP2P_MIXED_ENGINE_MODE !== 'manual-relay',
  1007 |     'The workflow runs one connection mode per job',
  1008 |   );
  1009 |   test.setTimeout(300_000);
  1010 |   const result = await runMode(playwright, 'manual');
  1011 |   await testInfo.attach('mixed-engine-summary', {
  1012 |     body: JSON.stringify(result, null, 2),
  1013 |     contentType: 'application/json',
  1014 |   });
  1015 | });
  1016 | 
```
Read-only review. Do not execute commands or modify files. Review this frozen two-pass terminal audit refactor for security and correctness. Prior audit used four full certified prefix validations: public, omniscient, reconstruction public, reconstruction private. New audit authenticates the public branch then fuses independent LocalGame and VerifiedSessionDriver checking into its second authenticated replay, retaining only current-sequence hashes. Public reconstruction must still authenticate full history and revealed masters before callbacks. No acceptance deadlines or counts change.

Assess authentication and secret-check order; deferred error priority (later omniscient failure and terminal mismatch must beat earlier per-seat failure); exceptions/disposal and retained secrets; genuine independence and equality at every sequence including genesis; callback/context trust bypass or newly exposed API; behavioral changes; adequate regression coverage. The frozen audit-reference.ts imports CURRENT private-replay.ts, so explicitly assess whether its differential coverage is adequate or shares a blind spot. Distinguish concrete bugs from optional hardening. Give severity, exact file/function and minimal fix/tests.

Observed checks: vitest audit.test.ts + private-replay.test.ts run31437 PASS17/17,29.38s runner. Audit10/10 includes genuine terminal fixture, reference report equality, exactly2 validations/entry versus4 in reference, and early private discrepancy/later omniscient error precedence. Private-replay7/7 includes cleanup, changed beacon length, unrelated signed extension and bad certificate before master attribution. Shared test typecheck64487 PASS; scoped type-aware lint PASS. No fullgame/performance claim.


### CURRENT packages/protocol/src/audit.ts
import { fromBase64Url, hashValue, toBase64Url, toHex } from '@cp2p/codec';
import { scalarFromBytes } from '@cp2p/crypto';
import { LocalGame, RESOURCES, failure, success } from '@cp2p/engine';
import type { Engine, PrivateInputData, Result, Seat } from '@cp2p/engine';
import { decodeDeckCard } from './deck-draw.js';
import { createDeckSecretSource } from './deck-source.js';
import { entryHash } from './genesis.js';
import { verifyRevealedMaster } from './genesis-secrets.js';
import { createPrivateReplayObserver } from './private-replay-observer.js';
import type { PrivateReplayObserver } from './private-replay-observer.js';
import {
  initialProposalContext,
  replayCertifiedPrefix,
  replayCertifiedPrefixObserved,
} from './replay.js';
import type { ReplayPolicy } from './replay.js';
import { openStealContribution } from './steal-delivery.js';
import { createStealSecretSource } from './steal-source.js';
import type { AuditEntryRef, AuditInputError, AuditReport, AuditViolation } from './audit-types.js';
import type { ProposalContext } from './proposal.js';
import type { Genesis } from './types.js';

const MAX_DIAGNOSTICS = 16;

function isSeat(value: unknown): value is Seat {
  return typeof value === 'number' && Number.isInteger(value) && value >= 0 && value <= 5;
}

export interface AuditCertifiedGameInput {
  readonly genesisEntry: unknown;
  readonly entries: readonly unknown[];
  readonly engine: Engine;
  readonly policy: ReplayPolicy;
  readonly masters: readonly { readonly seat: Seat; readonly master: Uint8Array }[];
}

function ref(entry: Parameters<typeof entryHash>[0]): AuditEntryRef {
  return { seq: entry.seq, hash: entryHash(entry) };
}

function issue(seq: number, seat: Seat | null, kind: string): AuditViolation {
  return { seq, seat, kind, detail: kind };
}

function selectedResource(
  hand: Readonly<Record<string, number>>,
  index: number,
): (typeof RESOURCES)[number] | null {
  let cursor = index;
  for (const resource of RESOURCES) {
    cursor -= hand[resource] ?? 0;
    if (cursor < 0) return resource;
  }
  return null;
}

function privateDataFor(
  input: NonNullable<Parameters<LocalGame['applyRecorded']>[0]>,
  prior: ProposalContext,
  next: ProposalContext,
  game: LocalGame,
  masters: ReadonlyMap<Seat, Uint8Array>,
  genesis: Genesis,
): Result<Partial<Record<Seat, PrivateInputData>>> {
  if (input.kind !== 'system') return success({});
  if (input.type === 'CARD_DEALT') {
    if (!isSeat(input.seat) || !genesis.config.seats.includes(input.seat))
      return failure('audit-draw-seat', 'Certified draw seat is invalid');
    const deck = next.log.crypto?.decks.decks.find(
      (item) => item.commitment.definition.deckId === input.deck,
    );
    const slot = deck?.slots.find((item) => item.slotId === input.slotId);
    const master = masters.get(input.seat);
    if (!deck || !slot || slot.seat !== input.seat || !master)
      return failure('audit-draw-context', 'Certified draw lacks its original receipt or master');
    const source = createDeckSecretSource(master, deck.commitment.definition, input.seat);
    try {
      const decoded = decodeDeckCard(
        deck.setup,
        slot.receipt,
        source.lock(slot.receipt.operation.position),
        slot.unlockSigners,
      );
      return decoded.ok ? success({ [input.seat]: { card: decoded.value.card } }) : decoded;
    } finally {
      source.dispose();
    }
  }
  if (input.type === 'STEAL_RESULT') {
    const fixed = prior.log.crypto?.steal?.fixed;
    const operation = fixed?.operation;
    if (
      !fixed ||
      !operation ||
      input.thief !== operation.thief.seat ||
      input.victim !== operation.victim.seat
    )
      return failure('audit-steal-context', 'Certified steal lacks its fixed operation');
    const victimHand = game.privateView(operation.victim.seat)?.hand;
    const victimTotal = victimHand
      ? RESOURCES.reduce((sum, resource) => sum + (victimHand[resource] ?? 0), 0)
      : -1;
    const expected = victimHand ? selectedResource(victimHand, operation.index) : null;
    if (!expected || victimTotal !== operation.handSize)
      return failure('audit-steal-index', 'Frozen index differs from the omniscient victim hand');
    const master = masters.get(operation.thief.seat);
    const owner = genesis.seats.find((seat) => seat.seat === operation.thief.seat);
    if (!master || !owner)
      return failure('audit-steal-master', 'Original thief master is unavailable');
    const source = createStealSecretSource(
      master,
      genesis.ceremonyNonce,
      operation.thief.seat,
      owner.publicKey,
    );
    try {
      const opened = openStealContribution(
        operation,
        fixed.contribution,
        source.encryptionSecret(),
        fixed.signer,
      );
      if (!opened.ok) return opened;
      if (opened.value.resource !== expected)
        return failure(
          'audit-steal-resource',
          'Certified transfer differs from the frozen victim card',
        );
      return success({
        [operation.thief.seat]: { resource: expected },
        [operation.victim.seat]: { resource: expected },
      });
    } finally {
      source.dispose();
    }
  }
  return success({});
}

/** Reconstruct a finished certified game without treating bad reveal input as an accusation. */
export function auditCertifiedGame(input: AuditCertifiedGameInput): AuditReport {
  const violations: AuditViolation[] = [];
  const inputErrors: AuditInputError[] = [];
  const masters = new Map<Seat, Uint8Array>();
  let privateObserver: PrivateReplayObserver | undefined;
  let terminal: AuditEntryRef | null = null;
  let finalHead: AuditEntryRef | null = null;
  let historyError: { code: string } | null = null;
  let auditError: AuditReport['auditError'] = null;
  let finalHiddenVictoryPoints: AuditReport['finalHiddenVictoryPoints'] = null;
  let cheatFindings: AuditReport['cheatFindings'] = [];
  let missingSeats: Seat[] = [];
  let complete = false;
  const report = (): AuditReport => ({
    ok:
      complete &&
      violations.length === 0 &&
      inputErrors.length === 0 &&
      !historyError &&
      !auditError,
    complete,
    missingSeats,
    violations,
    inputErrors,
    cheatFindings,
    terminal,
    finalHead,
    historyError,
    auditError,
    finalHiddenVictoryPoints,
  });
  const processingFailure = (seq: number, code: string): AuditReport => {
    auditError = { seq, code };
    complete = false;
    return report();
  };
  try {
    const publicReplay = replayCertifiedPrefix(
      input.genesisEntry,
      input.entries,
      input.engine,
      input.policy,
      (entry, next) => {
        if (!terminal && next.log.state.result) terminal = ref(entry.entry);
        return success(undefined);
      },
    );
    if (!publicReplay.ok) {
      historyError = { code: publicReplay.error.code };
      return report();
    }
    const { context } = publicReplay.value;
    const { genesis, crypto } = context.log;
    finalHead = ref(context.log.head);
    cheatFindings = crypto?.cheats.slice(0, MAX_DIAGNOSTICS) ?? [];
    if (!terminal || !context.log.state.result) return report();
    if (genesis.security !== 'verified' || !crypto) {
      historyError = { code: 'audit-unverified-game' };
      return report();
    }
    if (!Array.isArray(input.masters)) {
      inputErrors.push({ seat: null, kind: 'master-list' });
      return report();
    }
    const seats = new Set(genesis.seats.map((seat) => seat.seat));
    const seen = new Set<Seat>();
    for (const reveal of input.masters) {
      if (!reveal || !seats.has(reveal.seat) || seen.has(reveal.seat)) {
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat: null, kind: 'master-seat-or-duplicate' });
        continue;
      }
      seen.add(reveal.seat);
      if (!(reveal.master instanceof Uint8Array) || reveal.master.length !== 32) {
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat: reveal.seat, kind: 'master-scalar' });
        continue;
      }
      const copy = reveal.master.slice();
      try {
        scalarFromBytes(copy, { nonzero: true });
      } catch {
        copy.fill(0);
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat: reveal.seat, kind: 'master-scalar' });
        continue;
      }
      masters.set(reveal.seat, copy);
    }
    missingSeats = genesis.seats.map((seat) => seat.seat).filter((seat) => !masters.has(seat));
    for (const [seat, master] of masters) {
      const verified = verifyRevealedMaster(genesis, crypto.decks, seat, toBase64Url(master));
      if (verified.ok) continue;
      if (verified.error.code === 'master-public-key' || verified.error.code === 'master-reveal') {
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat, kind: verified.error.code });
      } else if (
        [
          'master-encryption-key',
          'master-beacon-tip',
          'master-shuffle-key',
          'master-lock-key',
        ].includes(verified.error.code)
      ) {
        violations.push(issue(0, seat, verified.error.code));
      } else return processingFailure(0, verified.error.code);
    }
    complete = missingSeats.length === 0 && inputErrors.length === 0;
    if (!complete || violations.length) return report();

    const initial = initialProposalContext(input.genesisEntry, input.engine, input.policy);
    if (!initial.ok) {
      historyError = { code: initial.error.code };
      return report();
    }
    const recorded = LocalGame.createRecorded(
      input.engine,
      genesis.config,
      fromBase64Url(genesis.genesisSeed),
    );
    if (!recorded.ok) {
      return processingFailure(0, recorded.error.code);
    }
    const game = recorded.value;
    if (toHex(hashValue(game.state)) !== initial.value.log.head.stateHash) {
      return processingFailure(0, 'audit-genesis-state');
    }
    let privateHashes: ReadonlyMap<Seat, string> = new Map();
    const rememberPrivateHashes = (seq: number): Result<void> => {
      const hashes = new Map<Seat, string>();
      for (const seat of genesis.config.seats) {
        const privateState = game.privateView(seat);
        if (!privateState)
          return failure(
            'audit-omniscient-private-missing',
            'Omniscient private state is missing',
            {
              seq,
            },
          );
        hashes.set(seat, toHex(hashValue(privateState)));
      }
      privateHashes = hashes;
      return success(undefined);
    };
    const initialPrivateHashes = rememberPrivateHashes(initial.value.log.head.seq);
    if (!initialPrivateHashes.ok) return processingFailure(0, initialPrivateHashes.error.code);
    let privateFailure: Result<void> | undefined;
    const prepared = createPrivateReplayObserver({
      engine: input.engine,
      initial: () => success(initial.value),
      terminal: context,
      secrets: [...masters].map(([seat, master]) => ({ seat, master })),
      verifyPrivateState(seq, states) {
        if (
          states.size !== privateHashes.size ||
          [...states].some(([seat, state]) => toHex(hashValue(state)) !== privateHashes.get(seat))
        )
          return failure(
            'audit-private-state',
            'Reconstructed private state differs from the omniscient replay',
            { seq },
          );
        return success(undefined);
      },
    });
    if (prepared.ok) privateObserver = prepared.value;
    else privateFailure = prepared;
    let failureSeq = 0;
    let failureSeat: Seat | null = null;
    const privateReplay = replayCertifiedPrefixObserved(
      input.genesisEntry,
      publicReplay.value.entries,
      input.engine,
      input.policy,
      (entry, prior, next) => {
        failureSeq = entry.entry.seq;
        const recordedInput = entry.input;
        if (recordedInput) {
          failureSeat = null;
          try {
            const data = privateDataFor(recordedInput, prior, next, game, masters, genesis);
            if (!data.ok) {
              // Only this mismatch identifies the signer of the fixed hidden transfer.
              // A draw failure does not prove misconduct by the receiving player.
              if (data.error.code === 'audit-steal-resource' && recordedInput.kind === 'system')
                failureSeat = isSeat(recordedInput.victim) ? recordedInput.victim : null;
              return data;
            }
            const applied = game.applyRecorded(recordedInput, data.value);
            if (!applied.ok) return applied;
          } catch {
            return failure('audit-private-input', 'Could not reconstruct certified private input');
          }
        }
        if (
          toHex(hashValue(game.state)) !== next.log.head.stateHash ||
          toHex(hashValue(game.state)) !== toHex(hashValue(next.log.state))
        )
          return failure('audit-state-hash', 'Omniscient state differs from the certified state');
        const remembered = rememberPrivateHashes(entry.entry.seq);
        if (!remembered.ok) return remembered;
        if (privateObserver && !privateFailure) {
          try {
            const checked = privateObserver.onEntry(entry, prior, next);
            if (!checked.ok) privateFailure = checked;
          } catch {
            privateFailure = failure(
              'private-replay-failed',
              'Could not reconstruct the requested private seats',
            );
          }
        }
        return success(undefined);
      },
    );
    if (!privateReplay.ok) {
      if (
        [
          'driver-error',
          'audit-private-input',
          'audit-state-hash',
          'audit-omniscient-private-missing',
          'audit-draw-context',
          'audit-draw-seat',
          'audit-steal-context',
          'audit-steal-master',
          'steal-recipient-key',
          'deck-owner-lock',
          'missing-private-state',
        ].includes(privateReplay.error.code)
      )
        return processingFailure(failureSeq, privateReplay.error.code);
      violations.push(issue(failureSeq, failureSeat, privateReplay.error.code));
      complete = true;
      return report();
    }
    if (toHex(hashValue(game.state.result)) !== toHex(hashValue(context.log.state.result))) {
      return processingFailure((terminal as AuditEntryRef).seq, 'audit-terminal-result');
    }
    const crossCheck = privateFailure ?? success(undefined);
    if (!crossCheck.ok) {
      const details = crossCheck.error.details;
      const seq =
        details &&
        typeof details === 'object' &&
        'seq' in details &&
        typeof details.seq === 'number'
          ? details.seq
          : context.log.head.seq;
      if (
        [
          'private-replay-failed',
          'private-replay-beacon',
          'crypto-context-required',
          'verified-private-missing',
          'audit-private-state',
        ].includes(crossCheck.error.code)
      )
        return processingFailure(seq, crossCheck.error.code);
      violations.push(issue(seq, null, crossCheck.error.code));
    } else {
      privateObserver?.finishHistory();
      const counts: Partial<Record<Seat, number>> = {};
      for (const seat of genesis.config.seats) {
        const privateState = game.privateView(seat);
        const publicSeat = game.state.seats.find((item) => item.seat === seat);
        if (!privateState || !publicSeat)
          return processingFailure(context.log.head.seq, 'audit-final-private-state');
        counts[seat] = publicSeat.cardSlots.filter(
          (slot) => !slot.revealed && privateState.slots[slot.slotId] === 'victoryPoint',
        ).length;
      }
      finalHiddenVictoryPoints = counts;
    }
    complete = true;
    return report();
  } catch {
    return processingFailure(finalHead?.seq ?? 0, 'audit-internal-failure');
  } finally {
    privateObserver?.dispose();
    for (const master of masters.values()) master.fill(0);
  }
}


### CURRENT packages/protocol/src/audit.test.ts
import { SCALAR_ORDER, scalarToBytes } from '@cp2p/crypto';
import { RandomBot, createBotRng } from '../../bots/src/index.js';
import { success } from '@cp2p/engine';
import type { Engine } from '@cp2p/engine';
import { beforeAll, describe, expect, test, vi } from 'vitest';
import { auditCertifiedGame } from './audit.js';
import * as proposal from './proposal.js';
import { auditCertifiedGameReference } from './testing/audit-reference.js';
import { createTerminalAuditFixture } from './testing/audit-fixture.js';

type Fixture = Awaited<ReturnType<typeof createTerminalAuditFixture>>;
let fixture: Fixture;
const setupVertices = [
  'v:-1,-1,N',
  'v:-1,-1,S',
  'v:-1,0,S',
  'v:-1,1,S',
  'v:0,-1,S',
  'v:0,0,S',
  'v:0,2,N',
  'v:1,1,N',
];

beforeAll(async () => {
  const bot = new RandomBot();
  const rng = createBotRng(new Uint8Array(32).fill(59));
  let setupIndex = 0;
  fixture = await createTerminalAuditFixture({
    boardSeed: new Uint8Array(32).fill(50),
    // Protocol v6 nonce 7 deals a victory card first; no unrelated draws are needed.
    ceremonyNonce: new Uint8Array(32).fill(7),
    maxElapsedMs: 90_000,
    yieldTask: () => new Promise<void>((resolve) => setImmediate(resolve)),
    chooseCommand(host, pending) {
      const commands = host.getLegalCommands(pending.seat).commands;
      if (host.getState().turn.phase.at(-1)?.id === 'setup') {
        const settlement = commands.find((command) => command.type === 'PLACE_SETTLEMENT');
        if (settlement) {
          const vertex = setupVertices[setupIndex];
          setupIndex += 1;
          const selected = commands.find(
            (command) => command.type === 'PLACE_SETTLEMENT' && command.vertex === vertex,
          );
          if (!selected) throw new Error(`Audit setup vertex ${vertex} is not legal`);
          return selected;
        }
        const road = commands.find((command) => command.type === 'PLACE_ROAD');
        if (road) return road;
      }
      const endTurn = commands.find((command) => command.type === 'END_TURN');
      if (endTurn) return endTurn;
      const priv = host.getPrivate(pending.seat);
      if (!priv) throw new Error('Audit bot lacks its private seat');
      return bot.decide({ state: host.getState(), priv, seat: pending.seat }, pending, rng);
    },
  });
}, 120_000);

describe('certified end-game audit', () => {
  test('passes a complete certified victory and identifies the first result', () => {
    expect(
      fixture.entries.some(
        ({ entry }) => entry.payload.kind === 'system' && entry.payload.input.type === 'CARD_DEALT',
      ),
    ).toBe(true);
    const report = auditCertifiedGame(fixture);
    expect(report).toEqual(auditCertifiedGameReference(fixture));
    expect(report).toMatchObject({
      ok: true,
      complete: true,
      missingSeats: [],
      violations: [],
      inputErrors: [],
      historyError: null,
      auditError: null,
    });
    expect(report.terminal?.seq).toBeGreaterThan(0);
    expect(report.finalHead?.seq).toBeGreaterThanOrEqual(report.terminal?.seq ?? 0);
    expect(
      Object.keys(report.finalHiddenVictoryPoints ?? {})
        .map(Number)
        .toSorted((left, right) => left - right),
    ).toEqual([0, 1, 2, 3]);
    expect(Object.values(report.finalHiddenVictoryPoints ?? {}).every(Number.isSafeInteger)).toBe(
      true,
    );
    expect(fixture.entries[(report.terminal?.seq ?? 0) - 1]?.entry.payload.kind).toBe('command');
  }, 30_000);

  test('validates each certified entry twice while matching the four-pass reference', () => {
    const validated = vi.spyOn(proposal, 'validateCertifiedEntry');
    try {
      const report = auditCertifiedGame(fixture);
      expect(report.ok).toBe(true);
      expect(validated).toHaveBeenCalledTimes(fixture.entries.length * 2);
      validated.mockClear();
      expect(auditCertifiedGameReference(fixture)).toEqual(report);
      expect(validated).toHaveBeenCalledTimes(fixture.entries.length * 4);
    } finally {
      validated.mockRestore();
    }
  }, 30_000);

  test('requires a certified terminal result', () => {
    const report = auditCertifiedGame({ ...fixture, entries: fixture.entries.slice(0, -1) });
    expect(report.ok).toBe(false);
    expect(report.complete).toBe(false);
    expect(report.terminal).toBeNull();
    expect(report.finalHiddenVictoryPoints).toBeNull();
  });

  test('keeps missing and bad supplied masters out of owner violations', () => {
    const missing = auditCertifiedGame({ ...fixture, masters: fixture.masters.slice(1) });
    expect(missing).toMatchObject({
      ok: false,
      complete: false,
      missingSeats: [0],
      violations: [],
      finalHiddenVictoryPoints: null,
    });

    const wrong = auditCertifiedGame({
      ...fixture,
      masters: fixture.masters.map((row) =>
        row.seat === 0 ? { seat: row.seat, master: scalarToBytes(99n) } : row,
      ),
    });
    expect(wrong.ok).toBe(false);
    expect(wrong.violations).toEqual([]);
    expect(wrong.inputErrors).toContainEqual({ seat: 0, kind: 'master-public-key' });
  });

  test('detects a false private draw at the certified victory claim', () => {
    const draw = fixture.entries.find(
      ({ entry }) => entry.payload.kind === 'system' && entry.payload.input.type === 'CARD_DEALT',
    );
    expect(draw).toBeDefined();
    const original = fixture.engine;
    const altered: Engine = {
      ...original,
      applyAllPrivates(privates, before, input, privateData) {
        if (
          input.kind === 'system' &&
          input.type === 'CARD_DEALT' &&
          typeof input.seat === 'number'
        ) {
          return original.applyAllPrivates(privates, before, input, {
            ...privateData,
            [input.seat]: { card: 'knight' },
          });
        }
        return original.applyAllPrivates(privates, before, input, privateData);
      },
    };
    const report = auditCertifiedGame({ ...fixture, engine: altered });
    expect(report.ok).toBe(false);
    expect(report.complete).toBe(true);
    expect(report.finalHiddenVictoryPoints).toBeNull();
    expect(report.violations).toContainEqual({
      seq: report.terminal?.seq,
      seat: null,
      kind: 'private-victory-mismatch',
      detail: 'private-victory-mismatch',
    });
  }, 30_000);

  test('reports a private engine exception without accusing the drawing player', () => {
    const original = fixture.engine;
    const altered: Engine = {
      ...original,
      applyAllPrivates(privates, before, input, data) {
        if (input.kind === 'system' && input.type === 'CARD_DEALT')
          throw new Error('Local engine failed');
        return original.applyAllPrivates(privates, before, input, data);
      },
    };
    const report = auditCertifiedGame({ ...fixture, engine: altered });
    const draw = fixture.entries.find(
      ({ entry }) => entry.payload.kind === 'system' && entry.payload.input.type === 'CARD_DEALT',
    );
    expect(draw).toBeDefined();
    expect(report).toMatchObject({
      ok: false,
      complete: false,
      violations: [],
      auditError: { seq: draw?.entry.seq, code: 'driver-error' },
    });
  }, 30_000);

  test('catches a transient private-state disagreement even when final private states match', () => {
    const original = fixture.engine;
    let added = false;
    let removed = false;
    let present = false;
    const altered: Engine = {
      ...original,
      applyAllPrivates(privates, before, input, data) {
        const applied = original.applyAllPrivates(privates, before, input, data);
        if (!applied.ok) return applied;
        const owner = applied.value.get(0);
        if (!owner) throw new Error('Missing audit fixture owner');
        const ext = { ...owner.ext };
        if (input.kind === 'system' && input.type === 'START_SEAT') {
          ext.transientAuditProbe = { value: 1 };
          added = true;
        } else if (Object.hasOwn(ext, 'transientAuditProbe')) {
          delete ext.transientAuditProbe;
          removed = true;
        }
        present = Object.hasOwn(ext, 'transientAuditProbe');
        return success(new Map(applied.value).set(0, { ...owner, ext }));
      },
    };
    const firstInput = fixture.entries.find(
      ({ entry }) => entry.payload.kind === 'system' && entry.payload.input.type === 'START_SEAT',
    );
    expect(firstInput).toBeDefined();
    const report = auditCertifiedGame({ ...fixture, engine: altered });
    expect(added).toBe(true);
    expect(removed).toBe(true);
    expect(present).toBe(false);
    expect(report).toMatchObject({
      ok: false,
      complete: false,
      violations: [],
      auditError: { seq: firstInput?.entry.seq, code: 'audit-private-state' },
      finalHiddenVictoryPoints: null,
    });
  }, 30_000);

  test('retains later omniscient failure precedence over an earlier private disagreement', () => {
    const makeEngine = (): Engine => {
      const original = fixture.engine;
      return {
        ...original,
        applyAllPrivates(privates, before, input, data) {
          if (input.kind === 'system' && input.type === 'CARD_DEALT')
            throw new Error('Bounded omniscient failure probe');
          const applied = original.applyAllPrivates(privates, before, input, data);
          if (!applied.ok || input.kind !== 'system' || input.type !== 'START_SEAT') return applied;
          const owner = applied.value.get(0);
          if (!owner) throw new Error('Missing audit fixture owner');
          return success(
            new Map(applied.value).set(0, {
              ...owner,
              ext: { ...owner.ext, deferredAuditProbe: true },
            }),
          );
        },
      };
    };
    const draw = fixture.entries.find(
      ({ entry }) => entry.payload.kind === 'system' && entry.payload.input.type === 'CARD_DEALT',
    );
    expect(draw).toBeDefined();
    const report = auditCertifiedGame({ ...fixture, engine: makeEngine() });
    expect(report).toEqual(auditCertifiedGameReference({ ...fixture, engine: makeEngine() }));
    expect(report.auditError).toEqual({ seq: draw?.entry.seq, code: 'driver-error' });
    expect(report.violations).toEqual([]);
  }, 30_000);

  test('rejects an alternate encoding of the same scalar as bad reveal input', () => {
    let scalar = SCALAR_ORDER + 17n;
    const noncanonical = Uint8Array.from({ length: 32 }, () => {
      const byte = Number(scalar & 255n);
      scalar >>= 8n;
      return byte;
    });
    const report = auditCertifiedGame({
      ...fixture,
      masters: fixture.masters.map((row) =>
        row.seat === 0 ? { seat: row.seat, master: noncanonical } : row,
      ),
    });
    expect(report.violations).toEqual([]);
    expect(report.inputErrors).toContainEqual({ seat: 0, kind: 'master-scalar' });
    expect(report.complete).toBe(false);
  });

  test('rejects a corrupt certificate before evaluating any supplied secrets', () => {
    const entries = fixture.entries.map((item, index) =>
      index === 0 ? { ...item, certificate: [] } : item,
    );
    const report = auditCertifiedGame({ ...fixture, entries, masters: [] });
    expect(report.ok).toBe(false);
    expect(report.historyError).not.toBeNull();
    expect(report.inputErrors).toEqual([]);
    expect(report.violations).toEqual([]);
  });
});


### CURRENT packages/protocol/src/private-replay.ts
import { scalarFromBytes } from '@cp2p/crypto';
import { failure, success } from '@cp2p/engine';
import type { Engine, PrivateState, Result, Seat } from '@cp2p/engine';
import type { ProposalContext } from './proposal.js';
import {
  initialProposalContext,
  replayCertifiedPrefix,
  replayCertifiedPrefixObserved,
} from './replay.js';
import type { ReplayPolicy } from './replay.js';
import { createPrivateReplayObserver } from './private-replay-observer.js';
import type { PrivateReplayObserver } from './private-replay-observer.js';
import type { VerifiedSessionDriver } from './verified-session-driver.js';

export interface ReconstructedPrivateSeats {
  readonly context: ProposalContext;
  /** Contains only requested seats and checks their public openings after every entry. */
  readonly driver: VerifiedSessionDriver;
  /** Relinquish one owned seat without discarding other reconstructed seats. */
  releaseSeat(seat: Seat): void;
  /** Disposes the driver and clears its retained master copies. */
  dispose(): void;
}

/**
 * Reconstruct already-owned or authorized-revealed seats from certified history.
 * This does not request secrets, authorize disclosure, activate controllers or
 * constitute a complete game audit. The caller must establish the right to use
 * every supplied master before invoking it. Deck setup must be fully certified.
 * No partially rebuilt hand is returned.
 */
export function reconstructPrivateSeats(input: {
  readonly genesisEntry: unknown;
  readonly entries: readonly unknown[];
  readonly engine: Engine;
  readonly policy: ReplayPolicy;
  readonly secrets: readonly { readonly seat: Seat; readonly master: Uint8Array }[];
  /** Independent check of detached snapshots, provisional until the entire replay succeeds. */
  readonly verifyPrivateState?: (
    seq: number,
    states: ReadonlyMap<Seat, PrivateState>,
  ) => Result<void>;
}): Result<ReconstructedPrivateSeats> {
  const masters = new Map<Seat, Uint8Array>();
  let observer: PrivateReplayObserver | undefined;
  let retained = false;
  try {
    if (!Array.isArray(input.secrets) || input.secrets.length < 1 || input.secrets.length > 6)
      return failure('private-replay-seats', 'Supply one through six distinct owned seat secrets');
    for (const { seat, master } of input.secrets) {
      if (
        !Number.isSafeInteger(seat) ||
        seat < 0 ||
        seat > 5 ||
        masters.has(seat) ||
        !(master instanceof Uint8Array) ||
        master.length !== 32
      )
        return failure('private-replay-secrets', 'Seat secrets are malformed or duplicated');
      const copy = new Uint8Array(master);
      masters.set(seat, copy);
      scalarFromBytes(copy, { nonzero: true });
    }
    const publicReplay = replayCertifiedPrefix(
      input.genesisEntry,
      input.entries,
      input.engine,
      input.policy,
    );
    if (!publicReplay.ok)
      return failure('private-replay-history', 'Certified history could not be verified', {
        reason: publicReplay.error.code,
      });
    const prepared = createPrivateReplayObserver({
      engine: input.engine,
      initial: () => initialProposalContext(input.genesisEntry, input.engine, input.policy),
      terminal: publicReplay.value.context,
      secrets: [...masters].map(([seat, master]) => ({ seat, master })),
      ...(input.verifyPrivateState ? { verifyPrivateState: input.verifyPrivateState } : {}),
    });
    if (!prepared.ok) return prepared;
    observer = prepared.value;
    const rebuilt = replayCertifiedPrefixObserved(
      input.genesisEntry,
      publicReplay.value.entries,
      input.engine,
      input.policy,
      observer.onEntry,
    );
    if (!rebuilt.ok) return rebuilt;
    observer.finishHistory();
    retained = true;
    return success({
      context: rebuilt.value.context,
      driver: observer.driver,
      releaseSeat: observer.releaseSeat,
      dispose: observer.dispose,
    });
  } catch {
    return failure('private-replay-failed', 'Could not reconstruct the requested private seats');
  } finally {
    for (const master of masters.values()) master.fill(0);
    if (!retained) observer?.dispose();
  }
}


### CURRENT packages/protocol/src/private-replay-observer.ts
import { toBase64Url } from '@cp2p/codec';
import { scalarFromBytes } from '@cp2p/crypto';
import { failure, success } from '@cp2p/engine';
import type { Engine, PrivateState, Result, Seat } from '@cp2p/engine';
import { createBeaconSecretSource } from './beacon-source.js';
import type { BeaconSecretProvider } from './beacon-source.js';
import { deckCeremonyId } from './deck-genesis.js';
import { createDeckSecretSource } from './deck-source.js';
import { genesisDigest } from './genesis.js';
import { verifyRevealedMaster } from './genesis-secrets.js';
import { createHandSecretSource } from './hand-source.js';
import type { ProposalContext } from './proposal.js';
import type { CertifiedEntry } from './proposal.js';
import type { ValidatedEntry } from './log.js';
import { createStealSecretSource } from './steal-source.js';
import { VerifiedSessionDriver } from './verified-session-driver.js';

export interface PrivateReplayObserver {
  readonly driver: VerifiedSessionDriver;
  readonly onEntry: (
    entry: ValidatedEntry & CertifiedEntry,
    prior: ProposalContext,
    next: ProposalContext,
  ) => Result<void>;
  readonly finishHistory: () => void;
  readonly releaseSeat: (seat: Seat) => void;
  readonly dispose: () => void;
}

/** Package-internal driver observer. Its contexts are supplied only by authenticated replay callers. */
export function createPrivateReplayObserver(input: {
  readonly engine: Engine;
  readonly initial: () => Result<ProposalContext>;
  readonly terminal: ProposalContext;
  readonly secrets: readonly { readonly seat: Seat; readonly master: Uint8Array }[];
  readonly verifyPrivateState?: (
    seq: number,
    states: ReadonlyMap<Seat, PrivateState>,
  ) => Result<void>;
}): Result<PrivateReplayObserver> {
  const masters = new Map<Seat, Uint8Array>();
  const beacons = new Map<Seat, { length: number; provider: BeaconSecretProvider }>();
  let driver: VerifiedSessionDriver | undefined;
  let retained = false;
  const releaseSeat = (seat: Seat) => {
    driver?.relinquishSeats([seat]);
    const master = masters.get(seat);
    master?.fill(0);
    masters.delete(seat);
    const beacon = beacons.get(seat);
    beacon?.provider.dispose();
    beacons.delete(seat);
  };
  const dispose = () => {
    for (const seat of masters.keys()) releaseSeat(seat);
    driver?.dispose();
  };
  try {
    if (!Array.isArray(input.secrets) || input.secrets.length < 1 || input.secrets.length > 6)
      return failure('private-replay-seats', 'Supply one through six distinct owned seat secrets');
    for (const { seat, master } of input.secrets) {
      if (
        !Number.isSafeInteger(seat) ||
        seat < 0 ||
        seat > 5 ||
        masters.has(seat) ||
        !(master instanceof Uint8Array) ||
        master.length !== 32
      )
        return failure('private-replay-secrets', 'Seat secrets are malformed or duplicated');
      const copy = new Uint8Array(master);
      masters.set(seat, copy);
      scalarFromBytes(copy, { nonzero: true });
    }

    const { genesis, crypto } = input.terminal.log;
    if (genesis.security !== 'verified' || !crypto)
      return failure('private-replay-security', 'Private reconstruction requires verified history');
    for (const [seat, master] of masters) {
      const verified = verifyRevealedMaster(genesis, crypto.decks, seat, master);
      if (!verified.ok) return verified;
    }
    const initial = input.initial();
    if (!initial.ok) return initial;
    const initialBeacon = initial.value.log.crypto?.beacon;
    if (!initialBeacon)
      return failure('private-replay-beacon', 'Verified genesis has no beacon state');
    const ceremonyId = deckCeremonyId(genesis);
    for (const chain of initialBeacon.chains) {
      const master = masters.get(chain.seat);
      if (master)
        beacons.set(chain.seat, {
          length: chain.length,
          provider: createBeaconSecretSource(
            master,
            { ceremonyId, seat: chain.seat },
            chain.length,
          ),
        });
    }
    const getMaster = (seat: Seat): Uint8Array => {
      const master = masters.get(seat);
      if (!master) throw new Error('Seat is not owned by this private replay');
      return master;
    };
    driver = new VerifiedSessionDriver(
      input.engine,
      genesis,
      [...masters.keys()],
      (deckId, seat) => {
        const deck = crypto.decks.decks.find(
          (item) => item.commitment.definition.deckId === deckId,
        );
        if (!deck) throw new Error('Private replay deck is not in certified genesis');
        return createDeckSecretSource(getMaster(seat), deck.commitment.definition, seat);
      },
      (seat) => createHandSecretSource(getMaster(seat), genesisDigest(genesis), seat),
      (seat) => {
        const owner = genesis.seats.find((item) => item.seat === seat);
        if (!owner) throw new Error('Private replay seat is not in certified genesis');
        return createStealSecretSource(
          getMaster(seat),
          genesis.ceremonyNonce,
          seat,
          owner.publicKey,
        );
      },
    );
    const activeDriver = driver;
    const verifyPrivateState = (seq: number): Result<void> => {
      if (!input.verifyPrivateState) return success(undefined);
      const states = new Map<Seat, PrivateState>();
      for (const seat of masters.keys()) {
        const state = activeDriver.privateState(seat);
        if (!state)
          return failure('verified-private-missing', 'Owned private state is missing', { seq });
        states.set(seat, state);
      }
      return input.verifyPrivateState(seq, states);
    };
    const initialPrivateCheck = verifyPrivateState(initial.value.log.head.seq);
    if (!initialPrivateCheck.ok) return initialPrivateCheck;
    const onEntry = (
      entry: ValidatedEntry & CertifiedEntry,
      prior: ProposalContext,
      next: ProposalContext,
    ): Result<void> => {
      const beacon = next.log.crypto?.beacon;
      if (!beacon) return failure('private-replay-beacon', 'Certified beacon state is missing');
      for (const chain of beacon.chains) {
        let source = beacons.get(chain.seat);
        if (!source) continue;
        if (source.length !== chain.length) {
          source.provider.dispose();
          source = {
            length: chain.length,
            provider: createBeaconSecretSource(
              getMaster(chain.seat),
              { ceremonyId, seat: chain.seat },
              chain.length,
            ),
          };
          beacons.set(chain.seat, source);
        }
        const expected =
          chain.index > 0
            ? source.provider.source.link(chain.chainEpoch, chain.index)
            : chain.chainEpoch === 0
              ? source.provider.initialCommitment.tip
              : source.provider.source.extension(chain.chainEpoch).tip;
        try {
          if (toBase64Url(expected) !== chain.tip)
            return failure(
              'master-beacon-history',
              'Master does not reproduce a certified beacon link',
              {
                seat: chain.seat,
                seq: entry.entry.seq,
              },
            );
        } finally {
          expected.fill(0);
        }
      }
      const applied = activeDriver.committedEntry(entry, prior.log, next.log);
      if (!applied.ok) return applied;
      const checked = verifyPrivateState(entry.entry.seq);
      if (!checked.ok) return checked;
      return success(undefined);
    };
    const finishHistory = () => {
      // Chain sources are needed only for historical checks, not subsequent hand proofs.
      for (const source of beacons.values()) source.provider.dispose();
      beacons.clear();
    };
    retained = true;
    return success({ driver: activeDriver, onEntry, finishHistory, releaseSeat, dispose });
  } catch {
    return failure('private-replay-failed', 'Could not reconstruct the requested private seats');
  } finally {
    if (!retained) dispose();
  }
}


### CURRENT packages/protocol/src/replay.ts
import { canonicalDecode, canonicalEncode, hashValue, toHex } from '@cp2p/codec';
import { failure, success } from '@cp2p/engine';
import type { Engine, GameEvent, Input, Result } from '@cp2p/engine';
import { entryHash, genesisDigest, validateGenesisEntry } from './genesis.js';
import { ownImmutableGenesis } from './genesis-identity.js';
import { objectiveEvidenceSeq, validateObjectiveAccusation } from './control.js';
import { initializeCryptoContext } from './crypto-context.js';
import type { GenesisPolicy } from './genesis.js';
import type { ValidatedEntry } from './log.js';
import { advanceContext, proposerFor, validateCertifiedEntry } from './proposal.js';
import type { CertifiedEntry, ProposalContext } from './proposal.js';
import { authenticatedCheatSigner, verifyCheatProof } from './cheat-proof.js';
import type { CheatFinding } from './cheat-proof.js';
import { initialSeatAuthorities } from './authority.js';
import { initialTransferState } from './transfer-readiness.js';
import { advanceTimerAnchors } from './turn-timeout.js';

const MAX_HISTORICAL_CONTEXTS = 16;

export interface ReplayPolicy {
  genesis: GenesisPolicy;
  entry: ProposalContext['policy'];
}

export interface ReplayedPrefix {
  context: ProposalContext;
  entries: CertifiedEntry[];
  inputs: Input[];
  events: GameEvent[];
}

/** Genesis signatures establish the first voter set; transport peers have no say. */
export function initialProposalContext(
  genesisEntry: unknown,
  engine: Engine,
  policy: ReplayPolicy,
): Result<ProposalContext> {
  const checked = validateGenesisEntry(genesisEntry, engine, policy.genesis);
  if (!checked.ok) return checked;
  const { state, entry } = checked.value;
  const genesis = ownImmutableGenesis(checked.value.genesis);
  const authority = initialSeatAuthorities(genesis);
  if (!authority.ok) return authority;
  const transfer =
    genesis.security === 'verified' ? initialTransferState(genesis, entry) : success(undefined);
  if (!transfer.ok) return transfer;
  const crypto = initializeCryptoContext(
    genesis,
    engine,
    state,
    entry,
    policy.entry.randomDerivations,
    authority.value,
  );
  if (!crypto.ok) return crypto;
  const timers = advanceTimerAnchors(engine, state, entry);
  if (!timers.ok) return timers;
  return success({
    log: {
      genesis,
      engine,
      state,
      head: entry,
      lastNonces: new Map(),
      crypto: crypto.value,
      timers: timers.value,
      authority: authority.value,
      recovery: { authorizations: [], pending: null, offline: [], completed: [], void: null },
      ...(transfer.value ? { transfer: transfer.value } : {}),
    },
    membership: {
      genesisDigest: genesisDigest(genesis),
      epoch: 0,
      voters: genesis.seats
        .filter((seat) => seat.kind === 'human')
        .map(({ seat, publicKey }) => ({ seat, publicKey })),
    },
    excludedProposers: [],
    policy: policy.entry,
  });
}

/** Replay certificates in order. A claimed snapshot never supplies voter or nonce state. */
export function replayCertifiedPrefix(
  genesisEntry: unknown,
  entries: readonly unknown[],
  engine: Engine,
  policy: ReplayPolicy,
  onEntry?: (entry: ValidatedEntry & CertifiedEntry, next: ProposalContext) => Result<void>,
): Result<ReplayedPrefix> {
  return replayCertifiedPrefixObserved(
    genesisEntry,
    entries,
    engine,
    policy,
    onEntry ? (entry, _prior, next) => onEntry(entry, next) : undefined,
  );
}

/** Internal observation of contexts derived here; not a public package export. */
export function replayCertifiedPrefixObserved(
  genesisEntry: unknown,
  entries: readonly unknown[],
  engine: Engine,
  policy: ReplayPolicy,
  onEntry?: (
    entry: ValidatedEntry & CertifiedEntry,
    prior: ProposalContext,
    next: ProposalContext,
  ) => Result<void>,
): Result<ReplayedPrefix> {
  return replayCertifiedPrefixWithCache(genesisEntry, entries, engine, policy, new Map(), onEntry);
}

/** Successful findings are shared only within this certified ancestry. */
function replayCertifiedPrefixWithCache(
  genesisEntry: unknown,
  entries: readonly unknown[],
  engine: Engine,
  policy: ReplayPolicy,
  verifiedFindings: Map<string, CheatFinding>,
  onEntry?: (
    entry: ValidatedEntry & CertifiedEntry,
    prior: ProposalContext,
    next: ProposalContext,
  ) => Result<void>,
): Result<ReplayedPrefix> {
  const initial = initialProposalContext(genesisEntry, engine, policy);
  if (!initial.ok) return initial;
  const certified: CertifiedEntry[] = [];
  const historical = new Map<number, ProposalContext>();
  const cheatHistorical = new Map<number, ProposalContext>();
  const controllerTimeline = [
    {
      atSeq: 0,
      authority: initial.value.log.authority,
      epoch: initial.value.log.crypto?.epoch ?? initial.value.log.authority?.epoch ?? 0,
    },
  ];
  let context: ProposalContext = {
    ...initial.value,
    verifyHistoricalCheat: (claim) => {
      const atSeq = claim.evidence.at.seq;
      if (atSeq > certified.length)
        return failure('cheat-history', 'Certified evidence parent is unavailable');
      const parentEntry = atSeq === 0 ? initial.value.log.head : certified[atSeq - 1]?.entry;
      if (!parentEntry || claim.evidence.at.hash !== entryHash(parentEntry))
        return failure('cheat-history', 'Certified evidence parent hash does not match');
      const parentAuthority = controllerTimeline.findLast((item) => item.atSeq <= atSeq);
      if (
        !parentAuthority ||
        !authenticatedCheatSigner(
          claim,
          initial.value.log.genesis,
          parentAuthority.authority,
          parentAuthority.epoch,
        )
      )
        return failure('cheat-signature', 'Cheat evidence has no authenticated controller');
      const key = toHex(hashValue({ domain: 'cp2p/v1/cheat-claim-cache', claim }));
      const previous = verifiedFindings.get(key);
      if (previous) return success(previous);
      let parent = cheatHistorical.get(atSeq);
      if (!parent) {
        const replayed = replayCertifiedPrefixWithCache(
          genesisEntry,
          certified.slice(0, atSeq),
          engine,
          policy,
          verifiedFindings,
        );
        if (!replayed.ok) return replayed;
        parent = replayed.value.context;
      }
      cheatHistorical.delete(atSeq);
      cheatHistorical.set(atSeq, parent);
      if (cheatHistorical.size > MAX_HISTORICAL_CONTEXTS) {
        const oldest = cheatHistorical.keys().next().value;
        if (oldest !== undefined) cheatHistorical.delete(oldest);
      }
      return verifyCheatProof(claim, parent.log);
    },
    verifyHistoricalAccusation: (control) => {
      const atSeq = objectiveEvidenceSeq(control);
      if (atSeq < 1 || atSeq - 1 > certified.length)
        return failure('control-history', 'Certified evidence parent is unavailable');
      let parent = historical.get(atSeq);
      if (!parent) {
        const replayed = replayCertifiedPrefixWithCache(
          genesisEntry,
          certified.slice(0, atSeq - 1),
          engine,
          policy,
          verifiedFindings,
        );
        if (!replayed.ok) return replayed;
        parent = replayed.value.context;
      }
      // Pending proofs and round hints can reference different certified parents.
      // Keep recent parents together without retaining the whole game state history.
      historical.delete(atSeq);
      historical.set(atSeq, parent);
      if (historical.size > MAX_HISTORICAL_CONTEXTS) {
        const oldest = historical.keys().next().value;
        if (oldest !== undefined) historical.delete(oldest);
      }
      const checked = validateObjectiveAccusation(control, {
        log: parent.log,
        commandPolicy: parent.policy,
        membership: parent.membership,
        excludedProposers: parent.excludedProposers,
        proposerFor: (seq, term) =>
          proposerFor(seq, term, parent.membership, parent.excludedProposers),
      });
      return checked.ok ? success(entryHash(parent.log.head)) : checked;
    },
  };
  const inputs: Input[] = [];
  const events: GameEvent[] = [];
  for (const entry of entries) {
    const checked = validateCertifiedEntry(entry, context);
    if (!checked.ok) return checked;
    const next = checked.value;
    if (next.entry.payload.kind === 'cheat-proof') {
      const claim = next.entry.payload.claim;
      const finding = next.crypto?.cheats.find(
        (item) => item.seat === claim.seat && item.kind === claim.evidence.kind,
      );
      if (!finding)
        return failure('cheat-replay', 'Certified cheat record has no replayed finding');
      verifiedFindings.set(
        toHex(hashValue({ domain: 'cp2p/v1/cheat-claim-cache', claim })),
        finding,
      );
    }
    certified.push({ entry: next.entry, certificate: next.certificate });
    if (next.input !== null) inputs.push(next.input);
    events.push(...next.events);
    const advanced = advanceContext(context, next);
    if (!advanced.ok) return advanced;
    if (advanced.value.log.authority !== context.log.authority) {
      controllerTimeline.push({
        atSeq: next.entry.seq,
        authority: advanced.value.log.authority,
        epoch: advanced.value.log.crypto?.epoch ?? advanced.value.log.authority?.epoch ?? 0,
      });
    }
    const visited = onEntry?.(next, context, advanced.value);
    if (visited && !visited.ok) return visited;
    context = advanced.value;
  }
  return success({ context, entries: certified, inputs, events });
}

/** A cache for display/load speed, always checked against the certified replay before voting. */
export function snapshotFromContext(context: ProposalContext) {
  return canonicalDecode(
    canonicalEncode({
      genesisDigest: context.membership.genesisDigest,
      seq: context.log.head.seq,
      hash: entryHash(context.log.head),
      state: context.log.state,
      crypto: context.log.crypto,
      authority: context.log.authority ?? null,
      recovery: context.log.recovery ?? null,
      transfer: context.log.transfer ?? null,
      timers: context.log.timers ?? [],
      lastNonces: [...context.log.lastNonces].toSorted(([a], [b]) => a - b),
      membership: context.membership,
      excludedProposers: context.excludedProposers,
    }),
  );
}

export function verifyReplaySnapshot(value: unknown, context: ProposalContext): Result<void> {
  try {
    return toHex(hashValue(value)) === toHex(hashValue(snapshotFromContext(context)))
      ? success(undefined)
      : failure('snapshot-mismatch', 'Snapshot differs from the certified replay');
  } catch {
    return failure('snapshot-malformed', 'Snapshot is not canonical data');
  }
}


### CURRENT packages/protocol/src/testing/audit-reference.ts
// Frozen pre-fusion differential oracle; never exported from protocol/testing.
import { fromBase64Url, hashValue, toBase64Url, toHex } from '@cp2p/codec';
import { scalarFromBytes } from '@cp2p/crypto';
import { LocalGame, RESOURCES, failure, success } from '@cp2p/engine';
import type { Engine, PrivateInputData, Result, Seat } from '@cp2p/engine';
import { decodeDeckCard } from '../deck-draw.js';
import { createDeckSecretSource } from '../deck-source.js';
import { entryHash } from '../genesis.js';
import { verifyRevealedMaster } from '../genesis-secrets.js';
import { reconstructPrivateSeats } from '../private-replay.js';
import { initialProposalContext, replayCertifiedPrefix } from '../replay.js';
import type { ReplayPolicy } from '../replay.js';
import { openStealContribution } from '../steal-delivery.js';
import { createStealSecretSource } from '../steal-source.js';
import type {
  AuditEntryRef,
  AuditInputError,
  AuditReport,
  AuditViolation,
} from '../audit-types.js';
import type { ProposalContext } from '../proposal.js';
import type { Genesis } from '../types.js';

const MAX_DIAGNOSTICS = 16;

function isSeat(value: unknown): value is Seat {
  return typeof value === 'number' && Number.isInteger(value) && value >= 0 && value <= 5;
}

export interface AuditCertifiedGameInput {
  readonly genesisEntry: unknown;
  readonly entries: readonly unknown[];
  readonly engine: Engine;
  readonly policy: ReplayPolicy;
  readonly masters: readonly { readonly seat: Seat; readonly master: Uint8Array }[];
}

function ref(entry: Parameters<typeof entryHash>[0]): AuditEntryRef {
  return { seq: entry.seq, hash: entryHash(entry) };
}

function issue(seq: number, seat: Seat | null, kind: string): AuditViolation {
  return { seq, seat, kind, detail: kind };
}

function selectedResource(
  hand: Readonly<Record<string, number>>,
  index: number,
): (typeof RESOURCES)[number] | null {
  let cursor = index;
  for (const resource of RESOURCES) {
    cursor -= hand[resource] ?? 0;
    if (cursor < 0) return resource;
  }
  return null;
}

function privateDataFor(
  input: NonNullable<Parameters<LocalGame['applyRecorded']>[0]>,
  prior: ProposalContext,
  next: ProposalContext,
  game: LocalGame,
  masters: ReadonlyMap<Seat, Uint8Array>,
  genesis: Genesis,
): Result<Partial<Record<Seat, PrivateInputData>>> {
  if (input.kind !== 'system') return success({});
  if (input.type === 'CARD_DEALT') {
    if (!isSeat(input.seat) || !genesis.config.seats.includes(input.seat))
      return failure('audit-draw-seat', 'Certified draw seat is invalid');
    const deck = next.log.crypto?.decks.decks.find(
      (item) => item.commitment.definition.deckId === input.deck,
    );
    const slot = deck?.slots.find((item) => item.slotId === input.slotId);
    const master = masters.get(input.seat);
    if (!deck || !slot || slot.seat !== input.seat || !master)
      return failure('audit-draw-context', 'Certified draw lacks its original receipt or master');
    const source = createDeckSecretSource(master, deck.commitment.definition, input.seat);
    try {
      const decoded = decodeDeckCard(
        deck.setup,
        slot.receipt,
        source.lock(slot.receipt.operation.position),
        slot.unlockSigners,
      );
      return decoded.ok ? success({ [input.seat]: { card: decoded.value.card } }) : decoded;
    } finally {
      source.dispose();
    }
  }
  if (input.type === 'STEAL_RESULT') {
    const fixed = prior.log.crypto?.steal?.fixed;
    const operation = fixed?.operation;
    if (
      !fixed ||
      !operation ||
      input.thief !== operation.thief.seat ||
      input.victim !== operation.victim.seat
    )
      return failure('audit-steal-context', 'Certified steal lacks its fixed operation');
    const victimHand = game.privateView(operation.victim.seat)?.hand;
    const victimTotal = victimHand
      ? RESOURCES.reduce((sum, resource) => sum + (victimHand[resource] ?? 0), 0)
      : -1;
    const expected = victimHand ? selectedResource(victimHand, operation.index) : null;
    if (!expected || victimTotal !== operation.handSize)
      return failure('audit-steal-index', 'Frozen index differs from the omniscient victim hand');
    const master = masters.get(operation.thief.seat);
    const owner = genesis.seats.find((seat) => seat.seat === operation.thief.seat);
    if (!master || !owner)
      return failure('audit-steal-master', 'Original thief master is unavailable');
    const source = createStealSecretSource(
      master,
      genesis.ceremonyNonce,
      operation.thief.seat,
      owner.publicKey,
    );
    try {
      const opened = openStealContribution(
        operation,
        fixed.contribution,
        source.encryptionSecret(),
        fixed.signer,
      );
      if (!opened.ok) return opened;
      if (opened.value.resource !== expected)
        return failure(
          'audit-steal-resource',
          'Certified transfer differs from the frozen victim card',
        );
      return success({
        [operation.thief.seat]: { resource: expected },
        [operation.victim.seat]: { resource: expected },
      });
    } finally {
      source.dispose();
    }
  }
  return success({});
}

/** Reconstruct a finished certified game without treating bad reveal input as an accusation. */
export function auditCertifiedGameReference(input: AuditCertifiedGameInput): AuditReport {
  const violations: AuditViolation[] = [];
  const inputErrors: AuditInputError[] = [];
  const masters = new Map<Seat, Uint8Array>();
  let terminal: AuditEntryRef | null = null;
  let finalHead: AuditEntryRef | null = null;
  let historyError: { code: string } | null = null;
  let auditError: AuditReport['auditError'] = null;
  let finalHiddenVictoryPoints: AuditReport['finalHiddenVictoryPoints'] = null;
  let cheatFindings: AuditReport['cheatFindings'] = [];
  let missingSeats: Seat[] = [];
  let complete = false;
  const report = (): AuditReport => ({
    ok:
      complete &&
      violations.length === 0 &&
      inputErrors.length === 0 &&
      !historyError &&
      !auditError,
    complete,
    missingSeats,
    violations,
    inputErrors,
    cheatFindings,
    terminal,
    finalHead,
    historyError,
    auditError,
    finalHiddenVictoryPoints,
  });
  const processingFailure = (seq: number, code: string): AuditReport => {
    auditError = { seq, code };
    complete = false;
    return report();
  };
  try {
    const publicReplay = replayCertifiedPrefix(
      input.genesisEntry,
      input.entries,
      input.engine,
      input.policy,
      (entry, next) => {
        if (!terminal && next.log.state.result) terminal = ref(entry.entry);
        return success(undefined);
      },
    );
    if (!publicReplay.ok) {
      historyError = { code: publicReplay.error.code };
      return report();
    }
    const { context } = publicReplay.value;
    const { genesis, crypto } = context.log;
    finalHead = ref(context.log.head);
    cheatFindings = crypto?.cheats.slice(0, MAX_DIAGNOSTICS) ?? [];
    if (!terminal || !context.log.state.result) return report();
    if (genesis.security !== 'verified' || !crypto) {
      historyError = { code: 'audit-unverified-game' };
      return report();
    }
    if (!Array.isArray(input.masters)) {
      inputErrors.push({ seat: null, kind: 'master-list' });
      return report();
    }
    const seats = new Set(genesis.seats.map((seat) => seat.seat));
    const seen = new Set<Seat>();
    for (const reveal of input.masters) {
      if (!reveal || !seats.has(reveal.seat) || seen.has(reveal.seat)) {
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat: null, kind: 'master-seat-or-duplicate' });
        continue;
      }
      seen.add(reveal.seat);
      if (!(reveal.master instanceof Uint8Array) || reveal.master.length !== 32) {
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat: reveal.seat, kind: 'master-scalar' });
        continue;
      }
      const copy = reveal.master.slice();
      try {
        scalarFromBytes(copy, { nonzero: true });
      } catch {
        copy.fill(0);
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat: reveal.seat, kind: 'master-scalar' });
        continue;
      }
      masters.set(reveal.seat, copy);
    }
    missingSeats = genesis.seats.map((seat) => seat.seat).filter((seat) => !masters.has(seat));
    for (const [seat, master] of masters) {
      const verified = verifyRevealedMaster(genesis, crypto.decks, seat, toBase64Url(master));
      if (verified.ok) continue;
      if (verified.error.code === 'master-public-key' || verified.error.code === 'master-reveal') {
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat, kind: verified.error.code });
      } else if (
        [
          'master-encryption-key',
          'master-beacon-tip',
          'master-shuffle-key',
          'master-lock-key',
        ].includes(verified.error.code)
      ) {
        violations.push(issue(0, seat, verified.error.code));
      } else return processingFailure(0, verified.error.code);
    }
    complete = missingSeats.length === 0 && inputErrors.length === 0;
    if (!complete || violations.length) return report();

    const initial = initialProposalContext(input.genesisEntry, input.engine, input.policy);
    if (!initial.ok) {
      historyError = { code: initial.error.code };
      return report();
    }
    const recorded = LocalGame.createRecorded(
      input.engine,
      genesis.config,
      fromBase64Url(genesis.genesisSeed),
    );
    if (!recorded.ok) {
      return processingFailure(0, recorded.error.code);
    }
    const game = recorded.value;
    if (toHex(hashValue(game.state)) !== initial.value.log.head.stateHash) {
      return processingFailure(0, 'audit-genesis-state');
    }
    const privateHashes = new Map<number, ReadonlyMap<Seat, string>>();
    const rememberPrivateHashes = (seq: number): Result<void> => {
      const hashes = new Map<Seat, string>();
      for (const seat of genesis.config.seats) {
        const privateState = game.privateView(seat);
        if (!privateState)
          return failure(
            'audit-omniscient-private-missing',
            'Omniscient private state is missing',
            {
              seq,
            },
          );
        hashes.set(seat, toHex(hashValue(privateState)));
      }
      privateHashes.set(seq, hashes);
      return success(undefined);
    };
    const initialPrivateHashes = rememberPrivateHashes(initial.value.log.head.seq);
    if (!initialPrivateHashes.ok) return processingFailure(0, initialPrivateHashes.error.code);
    let prior = initial.value;
    let failureSeq = 0;
    let failureSeat: Seat | null = null;
    const privateReplay = replayCertifiedPrefix(
      input.genesisEntry,
      publicReplay.value.entries,
      input.engine,
      input.policy,
      (entry, next) => {
        failureSeq = entry.entry.seq;
        const recordedInput = entry.input;
        if (recordedInput) {
          failureSeat = null;
          try {
            const data = privateDataFor(recordedInput, prior, next, game, masters, genesis);
            if (!data.ok) {
              // Only this mismatch identifies the signer of the fixed hidden transfer.
              // A draw failure does not prove misconduct by the receiving player.
              if (data.error.code === 'audit-steal-resource' && recordedInput.kind === 'system')
                failureSeat = isSeat(recordedInput.victim) ? recordedInput.victim : null;
              return data;
            }
            const applied = game.applyRecorded(recordedInput, data.value);
            if (!applied.ok) return applied;
          } catch {
            return failure('audit-private-input', 'Could not reconstruct certified private input');
          }
        }
        if (
          toHex(hashValue(game.state)) !== next.log.head.stateHash ||
          toHex(hashValue(game.state)) !== toHex(hashValue(next.log.state))
        )
          return failure('audit-state-hash', 'Omniscient state differs from the certified state');
        prior = next;
        return rememberPrivateHashes(entry.entry.seq);
      },
    );
    if (!privateReplay.ok) {
      if (
        [
          'driver-error',
          'audit-private-input',
          'audit-state-hash',
          'audit-omniscient-private-missing',
          'audit-draw-context',
          'audit-draw-seat',
          'audit-steal-context',
          'audit-steal-master',
          'steal-recipient-key',
          'deck-owner-lock',
          'missing-private-state',
        ].includes(privateReplay.error.code)
      )
        return processingFailure(failureSeq, privateReplay.error.code);
      violations.push(issue(failureSeq, failureSeat, privateReplay.error.code));
      complete = true;
      return report();
    }
    if (toHex(hashValue(game.state.result)) !== toHex(hashValue(context.log.state.result))) {
      return processingFailure((terminal as AuditEntryRef).seq, 'audit-terminal-result');
    }
    const crossCheck = reconstructPrivateSeats({
      genesisEntry: input.genesisEntry,
      entries: publicReplay.value.entries,
      engine: input.engine,
      policy: input.policy,
      secrets: [...masters].map(([seat, master]) => ({ seat, master })),
      verifyPrivateState(seq, states) {
        const expected = privateHashes.get(seq);
        if (
          !expected ||
          states.size !== expected.size ||
          [...states].some(([seat, state]) => toHex(hashValue(state)) !== expected.get(seat))
        )
          return failure(
            'audit-private-state',
            'Reconstructed private state differs from the omniscient replay',
            { seq },
          );
        return success(undefined);
      },
    });
    if (!crossCheck.ok) {
      const details = crossCheck.error.details;
      const seq =
        details &&
        typeof details === 'object' &&
        'seq' in details &&
        typeof details.seq === 'number'
          ? details.seq
          : context.log.head.seq;
      if (
        [
          'private-replay-failed',
          'private-replay-beacon',
          'crypto-context-required',
          'verified-private-missing',
          'audit-private-state',
        ].includes(crossCheck.error.code)
      )
        return processingFailure(seq, crossCheck.error.code);
      violations.push(issue(seq, null, crossCheck.error.code));
    } else {
      crossCheck.value.dispose();
      const counts: Partial<Record<Seat, number>> = {};
      for (const seat of genesis.config.seats) {
        const privateState = game.privateView(seat);
        const publicSeat = game.state.seats.find((item) => item.seat === seat);
        if (!privateState || !publicSeat)
          return processingFailure(context.log.head.seq, 'audit-final-private-state');
        counts[seat] = publicSeat.cardSlots.filter(
          (slot) => !slot.revealed && privateState.slots[slot.slotId] === 'victoryPoint',
        ).length;
      }
      finalHiddenVictoryPoints = counts;
    }
    complete = true;
    return report();
  } catch {
    return processingFailure(finalHead?.seq ?? 0, 'audit-internal-failure');
  } finally {
    for (const master of masters.values()) master.fill(0);
  }
}


### CURRENT packages/protocol/src/private-replay.test.ts
import { fromBase64Url, hashValue, toBase64Url, toHex } from '@cp2p/codec';
import { scalarToBytes } from '@cp2p/crypto';
import { failure, success } from '@cp2p/engine';
import type { Result, Seat } from '@cp2p/engine';
import { beforeAll, describe, expect, test, vi } from 'vitest';
import { createBeaconSecretSource } from './beacon-source.js';
import {
  completeBeaconState,
  getBeaconExtensionOperation,
  getBeaconOperation,
} from './beacon-state.js';
import { signBeaconExtension } from './beacon-extension.js';
import { signBeaconReveal } from './beacon.js';
import { BEACON_EVIDENCE_PROTOCOL } from './crypto-context.js';
import { deckCeremonyId, validateDeckCeremony } from './deck-genesis.js';
import { createDeckSecretSource } from './deck-source.js';
import {
  GENESIS_PREVIOUS_HASH,
  entryHash,
  genesisBody,
  genesisDigest,
  genesisId,
  signEntry,
  signVerifiedGenesis,
} from './genesis.js';
import { createHandSecretSource } from './hand-source.js';
import { signCommand } from './log.js';
import { reconstructPrivateSeats } from './private-replay.js';
import { advanceContext, validateCertifiedEntry } from './proposal.js';
import type { CertifiedEntry } from './proposal.js';
import { initialProposalContext, replayCertifiedPrefix } from './replay.js';
import { createStealSecretSource } from './steal-source.js';
import { createGenesisDeckFixture } from './testing/deck-fixture.js';
import { createSimulationGenesis } from './testing/simulation-genesis.js';
import type { EntryPayload, Genesis } from './types.js';
import { VerifiedSessionDriver } from './verified-session-driver.js';
import { signVote } from './votes.js';

function checked<T>(value: Result<T>): T {
  if (!value.ok) throw new Error(`${value.error.code}: ${value.error.message}`);
  return value.value;
}

function required<T>(value: T | null | undefined): T {
  if (value === undefined || value === null)
    throw new Error('Missing private replay fixture value');
  return value;
}

const master = (seat: Seat) => scalarToBytes(BigInt(17 + seat));

function fixture() {
  const simulation = createSimulationGenesis({
    seed: 71,
    humanCount: 1,
    config: {
      modules: [{ id: 'base', version: '1.0.0' }],
      seats: [0, 1],
      options: {},
    },
  });
  const deck = createGenesisDeckFixture(
    { ...genesisBody(simulation.genesis), security: 'verified', commitments: {} },
    simulation.identities,
  );
  const source = createBeaconSecretSource(
    master(0),
    { ceremonyId: deckCeremonyId(deck.body), seat: 0 },
    1,
  );
  const body = {
    ...deck.body,
    commitments: {
      ...deck.body.commitments,
      beaconChains: [
        { seat: 0, ...source.initialCommitment, tip: toBase64Url(source.initialCommitment.tip) },
      ],
    },
  };
  source.dispose();
  const signer = required(simulation.identities.get(0));
  const genesis: Genesis = {
    ...body,
    gameId: genesisId(body),
    signatures: [checked(signVerifiedGenesis(body, deck.transcripts, 0, signer.secretKey))],
  };
  const state = simulation.engine.createGame(body.config, fromBase64Url(body.genesisSeed));
  const entry = signEntry(
    {
      seq: 0,
      term: 1,
      prevHash: GENESIS_PREVIOUS_HASH,
      payload: { kind: 'genesis', genesis },
      stateHash: toHex(hashValue(state)),
      sequencer: signer.peerId,
    },
    signer.secretKey,
  );
  const policy = {
    genesis: {
      verifyCommitments: (candidate: Genesis) => validateDeckCeremony(candidate, deck.transcripts),
    },
    entry: {},
  };
  return { simulation, deck, genesis, signer, entry, policy };
}

function history(data: ReturnType<typeof fixture>) {
  let context = checked(initialProposalContext(data.entry, data.simulation.engine, data.policy));
  const entries: CertifiedEntry[] = [];
  const driver = new VerifiedSessionDriver(
    data.simulation.engine,
    data.genesis,
    [0, 1],
    (deckId, seat) =>
      createDeckSecretSource(
        master(seat),
        required(
          context.log.crypto?.decks.decks.find(
            (item) => item.commitment.definition.deckId === deckId,
          ),
        ).commitment.definition,
        seat,
      ),
    (seat) => createHandSecretSource(master(seat), genesisDigest(data.genesis), seat),
    (seat) =>
      createStealSecretSource(
        master(seat),
        data.genesis.ceremonyNonce,
        seat,
        required(data.genesis.seats.find((item) => item.seat === seat)).publicKey,
      ),
  );
  const append = (payload: EntryPayload, stateHash = context.log.head.stateHash) => {
    const entry = signEntry(
      {
        seq: context.log.head.seq + 1,
        term: 1,
        prevHash: entryHash(context.log.head),
        payload,
        stateHash,
        sequencer: data.signer.peerId,
      },
      data.signer.secretKey,
    );
    const certified = {
      entry,
      certificate: [
        signVote(
          {
            genesisDigest: context.membership.genesisDigest,
            epoch: context.membership.epoch,
            seat: 0,
            seq: entry.seq,
            term: 1,
            phase: 'precommit',
            valueHash: entryHash(entry),
          },
          data.signer.secretKey,
        ),
      ],
    };
    const validated = checked(validateCertifiedEntry(certified, context));
    const next = checked(advanceContext(context, validated));
    checked(driver.committedEntry(validated, context.log, next.log));
    context = next;
    entries.push(certified);
  };
  for (const transcript of data.deck.transcripts)
    for (const pass of transcript.passes)
      append({
        kind: 'crypto',
        action: 'deck-pass',
        evidence: { deckId: transcript.deckId, pass },
      });
  const beacon = required(context.log.crypto).beacon;
  const operation = checked(getBeaconOperation(beacon));
  const source = createBeaconSecretSource(
    master(0),
    { ceremonyId: deckCeremonyId(data.genesis), seat: 0 },
    1,
  );
  const reveals = [signBeaconReveal(operation, 0, source.source.link(0, 1), data.signer.secretKey)];
  source.dispose();
  const outcome = checked(
    completeBeaconState(beacon, reveals, context.log.state, {
      seq: context.log.head.seq + 1,
      hash: 'c'.repeat(64),
    }),
  ).outcome;
  if (outcome.kind !== 'system') throw new Error('Expected initial seat outcome');
  const start = checked(data.simulation.engine.apply(context.log.state, outcome.input));
  append(
    {
      kind: 'system',
      input: outcome.input,
      evidence: { kind: 'proof', protocol: BEACON_EVIDENCE_PROTOCOL, data: reveals },
    },
    toHex(hashValue(start.state)),
  );
  // Four settlements and four roads, followed by the first roll request.
  for (let index = 0; index < 9; index++) {
    const pending = required(
      data.simulation.engine.getPending(context.log.state).find((item) => item.kind === 'player'),
    );
    if (pending.kind !== 'player') throw new Error('Expected player');
    const legal = data.simulation.engine.getLegalCommands(
      context.log.state,
      pending.seat,
      required(driver.privateState(pending.seat)),
    );
    const command = required(
      legal.commands.find((item) => item.type === 'ROLL_DICE') ?? legal.commands[0],
    );
    const body = {
      gameId: data.genesis.gameId,
      genesisDigest: genesisDigest(data.genesis),
      seat: pending.seat,
      nonce: (context.log.lastNonces.get(pending.seat) ?? 0) + 1,
      headSeq: context.log.head.seq,
      headHash: entryHash(context.log.head),
      command,
    };
    const evidence = checked(driver.prepareCommand(body, context.log));
    const signed = signCommand(
      { ...body, ...(evidence ? { evidence } : {}) },
      required(data.simulation.identities.get(pending.seat)).secretKey,
    );
    const applied = checked(
      data.simulation.engine.apply(context.log.state, {
        kind: 'command',
        seat: pending.seat,
        command,
      }),
    );
    append({ kind: 'command', signed }, toHex(hashValue(applied.state)));
  }
  return { entries, driver, append, context: () => context };
}

describe('certified private history reconstruction', () => {
  let base: ReturnType<typeof fixture>;
  beforeAll(() => {
    base = fixture();
  }, 20_000);
  const reconstruct = (entries: readonly unknown[], seats: readonly Seat[] = [0, 1]) =>
    reconstructPrivateSeats({
      genesisEntry: base.entry,
      entries,
      engine: base.simulation.engine,
      policy: base.policy,
      secrets: seats.map((seat) => ({ seat, master: master(seat) })),
    });

  test('rebuilds each exact hand from legal production and retains only requested seats', () => {
    const trace = history(base);
    try {
      expect(trace.context().log.state.seats.some((seat) => seat.resources.total > 0)).toBe(true);
      const callerMaster = Buffer.from(master(1));
      const visited: number[] = [];
      const observedSeats: Seat[][] = [];
      const recovered = checked(
        reconstructPrivateSeats({
          genesisEntry: base.entry,
          entries: trace.entries,
          engine: base.simulation.engine,
          policy: base.policy,
          secrets: [{ seat: 1, master: callerMaster }],
          verifyPrivateState(seq, states) {
            visited.push(seq);
            observedSeats.push([...states.keys()]);
            // A verifier receives detached snapshots, never the live owner state.
            const state = required(states.get(1));
            state.hand.brick = 999;
            state.slots.observerProbe = 'knight';
            state.ext.observerProbe = { changed: true };
            return success(undefined);
          },
        }),
      );
      expect(visited).toEqual(Array.from({ length: trace.entries.length + 1 }, (_, seq) => seq));
      expect(observedSeats).toEqual(visited.map(() => [1]));
      expect(recovered.driver.privateState(1)).toEqual(trace.driver.privateState(1));
      expect(recovered.driver.privateState(0)).toBeNull();
      expect(recovered.context.log.state).toEqual(trace.context().log.state);
      recovered.releaseSeat(1);
      expect(recovered.driver.privateState(1)).toBeNull();
      expect(callerMaster).toEqual(Buffer.from(master(1)));
      recovered.dispose();
    } finally {
      trace.driver.dispose();
    }
  });

  test.each([
    { rejectAt: 0, throws: false },
    { rejectAt: 1, throws: false },
    { rejectAt: 1, throws: true },
  ])('disposes rejected replay at $rejectAt, callback throws: $throws', ({ rejectAt, throws }) => {
    const trace = history(base);
    const visited: number[] = [];
    const callerMaster = master(1);
    const dispose = vi.spyOn(VerifiedSessionDriver.prototype, 'dispose');
    try {
      const result = reconstructPrivateSeats({
        genesisEntry: base.entry,
        entries: trace.entries,
        engine: base.simulation.engine,
        policy: base.policy,
        secrets: [{ seat: 1, master: callerMaster }],
        verifyPrivateState(seq) {
          visited.push(seq);
          if (seq !== rejectAt) return success(undefined);
          if (throws) throw new Error('Independent verifier failed');
          return failure('independent-private-mismatch', 'Independent reconstruction differs', {
            seq,
          });
        },
      });
      expect(result).toMatchObject({
        ok: false,
        error: throws
          ? { code: 'private-replay-failed' }
          : { code: 'independent-private-mismatch', details: { seq: rejectAt } },
      });
      expect(visited).toEqual(Array.from({ length: rejectAt + 1 }, (_, seq) => seq));
      expect(dispose).toHaveBeenCalledExactlyOnceWith();
      const disposed = required(dispose.mock.contexts[0]);
      if (!(disposed instanceof VerifiedSessionDriver)) throw new Error('Missing disposed driver');
      expect(disposed.privateState(1)).toBeNull();
      expect(callerMaster).toEqual(master(1));
    } finally {
      dispose.mockRestore();
      trace.driver.dispose();
    }
  });

  test('checks historical extensions against the master, including a changed chain length', () => {
    const trace = history(base);
    try {
      const operation = checked(
        getBeaconExtensionOperation(required(trace.context().log.crypto).beacon),
      );
      const source = createBeaconSecretSource(
        master(0),
        { ceremonyId: deckCeremonyId(base.genesis), seat: 0 },
        3,
      );
      const extension = source.source.extension(1);
      source.dispose();
      trace.append({
        kind: 'crypto',
        action: 'beacon-extend',
        evidence: [
          signBeaconExtension(operation, 0, extension.length, extension.tip, base.signer.secretKey),
        ],
      });
      const recovered = checked(reconstruct(trace.entries));
      expect(recovered.context.log.crypto?.beacon.chains[0]?.length).toBe(3);
      recovered.dispose();
    } finally {
      trace.driver.dispose();
    }
  });

  test('rejects an honestly signed extension unrelated to the committed master', () => {
    const trace = history(base);
    try {
      const operation = checked(
        getBeaconExtensionOperation(required(trace.context().log.crypto).beacon),
      );
      const badTip = new Uint8Array(32).fill(99);
      trace.append({
        kind: 'crypto',
        action: 'beacon-extend',
        evidence: [signBeaconExtension(operation, 0, 3, badTip, base.signer.secretKey)],
      });
      expect(
        replayCertifiedPrefix(base.entry, trace.entries, base.simulation.engine, base.policy).ok,
      ).toBe(true);
      expect(reconstruct(trace.entries)).toMatchObject({
        ok: false,
        error: { code: 'master-beacon-history' },
      });
    } finally {
      trace.driver.dispose();
    }
  });

  test('validates certificates before attributing any master mismatch', () => {
    const trace = history(base);
    try {
      const entries = structuredClone(trace.entries);
      required(entries[0]).certificate = [];
      const result = reconstructPrivateSeats({
        genesisEntry: base.entry,
        entries,
        engine: base.simulation.engine,
        policy: base.policy,
        secrets: [{ seat: 0, master: master(1) }],
      });
      expect(result).toMatchObject({ ok: false, error: { code: 'private-replay-history' } });
      expect(
        reconstructPrivateSeats({
          genesisEntry: base.entry,
          entries: trace.entries,
          engine: base.simulation.engine,
          policy: base.policy,
          secrets: [{ seat: 0, master: master(1) }],
        }),
      ).toMatchObject({ ok: false, error: { code: 'master-public-key' } });
    } finally {
      trace.driver.dispose();
    }
  });
});


### CURRENT packages/protocol/src/verified-session-driver.ts
import { canonicalDecode, canonicalEncode, hashValue, toHex } from '@cp2p/codec';
import { G, decodeScalar, encodePoint, encodeScalar, modScalar, scalePoint } from '@cp2p/crypto';
import type { SchnorrProof } from '@cp2p/crypto';
import { DEV_CARD_COUNTS, RESOURCES, failure, success } from '@cp2p/engine';
import type {
  Engine,
  GameState,
  Input,
  PrivateState,
  Result,
  Seat,
  Resource,
  SystemInput,
} from '@cp2p/engine';
import { decodeDeckCard, proveDeckReveal } from './deck-draw.js';
import type { LogContext, ValidatedEntry } from './log.js';
import type { SessionDriver } from './session-driver.js';
import type { DeckSecretSource, DeckSourceFactory } from './deck-source.js';
import type { HandSourceFactory } from './hand-source.js';
import { verifyHandOpening } from './hand-commitments.js';
import {
  handProofContext,
  planHandTransition,
  proveHandObligation,
  verifyHandProof,
  verifyHandProofs,
} from './hand-transition.js';
import type { HandProof, HandProofBinding, HandTransitionPlan } from './hand-transition.js';
import { authorizeTradeProof, verifyTradeProofRequest } from './trade-proof-delivery.js';
import type { IndexedHandProof, SignedTradeProofRequest } from './trade-proof-delivery.js';
import { composeCommandProofs } from './command-proofs.js';
import { countOperationId, countProofContext, proveCountOpening } from './count-reveal.js';
import type { CountOperation } from './count-reveal.js';
import { validateCountState } from './count-state.js';
import type { CommandBody, Genesis, SystemEvidence } from './types.js';
import type { CertifiedEntry } from './proposal.js';
import { entryHash, genesisDigest } from './genesis.js';
import {
  createStealContribution,
  createStealDispute,
  createStealReceipt,
  openStealContribution,
  recoverStealTransferOpening,
  stealOperationId,
} from './steal-delivery.js';
import type {
  FixedSteal,
  SignedStealContribution,
  SignedStealDispute,
  SignedStealReceipt,
  StealOpening,
  StealOperation,
} from './steal-delivery.js';
import type { StealSecretSource, StealSourceFactory } from './steal-source.js';
import { validateStealState, verifyStealResult } from './steal-state.js';
import { resolveArtifactSigner } from './authority.js';

type CommandWithoutEvidence = Omit<CommandBody, 'evidence'>;

function copyPrivate(state: PrivateState): PrivateState {
  return {
    seat: state.seat,
    hand: { ...state.hand },
    slots: { ...state.slots },
    ext: Object.fromEntries(
      Object.entries(state.ext).map(([key, value]) => [
        key,
        canonicalDecode(canonicalEncode(value)),
      ]),
    ),
  };
}

function wipePrivateBytes(value: unknown, seen = new WeakSet<object>()): void {
  if (!value || typeof value !== 'object' || seen.has(value)) return;
  seen.add(value);
  if (value instanceof Uint8Array) {
    value.fill(0);
    return;
  }
  for (const nested of Object.values(value)) wipePrivateBytes(nested, seen);
}

function resourceCounts(state: PrivateState): Record<Resource, number> {
  return {
    brick: state.hand.brick ?? -1,
    lumber: state.hand.lumber ?? -1,
    wool: state.hand.wool ?? -1,
    grain: state.hand.grain ?? -1,
    ore: state.hand.ore ?? -1,
  };
}

function validOwnedState(state: GameState, priv: PrivateState): Result<void> {
  const holder = state.seats.find((item) => item.seat === priv.seat);
  if (!holder) return failure('verified-private-seat', 'Owned seat is missing from public state');
  let total = 0;
  for (const resource of RESOURCES) {
    const count = priv.hand[resource];
    const min = holder.resources.min[resource] ?? 0;
    const max = holder.resources.max[resource] ?? 0;
    if (count === undefined || !Number.isSafeInteger(count) || count < min || count > max)
      return failure('verified-private-bounds', 'Owned resources are outside public bounds');
    total += count;
  }
  if (total !== holder.resources.total)
    return failure('verified-private-total', 'Owned resource total differs from public count');

  const publicSlots = new Map(holder.cardSlots.map((slot) => [slot.slotId, slot]));
  for (const [slotId, card] of Object.entries(priv.slots)) {
    const slot = publicSlots.get(slotId);
    if (!slot || slot.revealed !== undefined || !Object.hasOwn(DEV_CARD_COUNTS, card))
      return failure('verified-private-slots', 'Owned hidden card does not match a public slot');
  }
  for (const slot of holder.cardSlots)
    if (slot.revealed === undefined && !Object.hasOwn(priv.slots, slot.slotId))
      return failure('verified-private-slots', 'Owned private cards differ from public slots');
  return success(undefined);
}

/** Local verified-session private state. Only supplied seats are ever retained. */
export class VerifiedSessionDriver implements SessionDriver {
  private readonly digest: string;
  private readonly owned = new Set<Seat>();
  private privates = new Map<Seat, PrivateState>();
  private blindings = new Map<Seat, Record<(typeof RESOURCES)[number], string>>();
  private appliedHead: string | null = null;
  private disposed = false;
  private readonly deckRoutes = new Map<Seat, DeckSourceFactory>();
  private readonly handRoutes = new Map<Seat, HandSourceFactory>();
  private readonly stealRoutes = new Map<Seat, StealSourceFactory>();

  constructor(
    private readonly engine: Engine,
    private readonly genesis: Genesis,
    ownedSeats: readonly Seat[],
    private readonly createDeckSource: DeckSourceFactory,
    private readonly createHandSource?: HandSourceFactory,
    private readonly createStealSource?: StealSourceFactory,
  ) {
    if (genesis.security !== 'verified')
      throw new TypeError('Verified session driver requires verified genesis');
    this.digest = genesisDigest(genesis);
    if (ownedSeats.length === 0 || new Set(ownedSeats).size !== ownedSeats.length)
      throw new RangeError('At least one unique owned seat is required');
    const configured = new Set(genesis.config.seats);
    for (const seat of ownedSeats) {
      if (!configured.has(seat)) throw new RangeError('Owned seat is not configured in genesis');
      this.owned.add(seat);
      this.privates.set(seat, engine.createPrivateState(seat));
      const zero = encodeScalar(0n);
      this.blindings.set(seat, { brick: zero, lumber: zero, wool: zero, grain: zero, ore: zero });
    }
  }

  next(_context: LogContext): { input: SystemInput; evidence: SystemEvidence } | null {
    return null;
  }

  privateState(seat: Seat): PrivateState | null {
    if (this.disposed) return null;
    const state = this.privates.get(seat);
    return state ? copyPrivate(state) : null;
  }

  private verifyOwnedOpenings(
    context: LogContext,
    privates: ReadonlyMap<Seat, PrivateState> = this.privates,
    blindingsBySeat: ReadonlyMap<Seat, Record<Resource, string>> = this.blindings,
  ): Result<void> {
    if (!context.crypto)
      return failure('crypto-context-required', 'Verified hand needs replayed crypto state');
    for (const seat of this.owned) {
      const priv = privates.get(seat);
      const blindings = blindingsBySeat.get(seat);
      if (!priv || !blindings)
        return failure('verified-private-missing', 'Owned hand opening is missing');
      const valid = validOwnedState(context.state, priv);
      if (!valid.ok) return valid;
      const opened = verifyHandOpening(
        context.crypto.hands,
        this.genesis.config.seats,
        seat,
        priv.hand,
        blindings,
      );
      if (!opened.ok) return opened;
    }
    return success(undefined);
  }

  private currentStealContext(context: LogContext): Result<void> {
    if (
      genesisDigest(context.genesis) !== this.digest ||
      context.genesis.gameId !== this.genesis.gameId ||
      !context.crypto ||
      (this.appliedHead === null
        ? context.head.seq !== 0
        : entryHash(context.head) !== this.appliedHead)
    )
      return failure('verified-steal-context', 'Steal request has a stale or foreign parent');
    const openings = this.verifyOwnedOpenings(context);
    if (!openings.ok) return openings;
    const crypto = context.crypto;
    if (!crypto) return failure('crypto-context-required', 'Verified steal needs crypto state');
    const steal = validateStealState(
      crypto.steal,
      this.genesis,
      crypto.beacon,
      crypto.hands,
      context.state,
      crypto.epoch,
      context.authority,
    );
    return steal.ok ? success(undefined) : steal;
  }

  private checkedStealSource(seat: Seat): Result<StealSecretSource> {
    const factory = this.stealRoutes.get(seat) ?? this.createStealSource;
    if (!factory) return failure('steal-source', 'No steal secret source is configured');
    let source: StealSecretSource | null = null;
    try {
      source = factory(seat);
      const genesisKey = this.genesis.seats.find((item) => item.seat === seat)?.encryptionKey;
      if (!genesisKey || encodePoint(scalePoint(G, source.encryptionSecret())) !== genesisKey) {
        source.dispose();
        return failure(
          'steal-source-key',
          'Owned steal source differs from the genesis encryption key',
        );
      }
      return success(source);
    } catch {
      source?.dispose();
      return failure('steal-source-key', 'Could not derive the original owned encryption key');
    }
  }

  /** Fail before journal use if any locally owned seat cannot open its genesis key. */
  validateSources(): Result<void> {
    if (this.disposed) return failure('verified-driver-disposed', 'Verified driver is disposed');
    for (const seat of this.owned) {
      const checked = this.checkedStealSource(seat);
      if (!checked.ok) return checked;
      checked.value.dispose();
    }
    return success(undefined);
  }

  produceStealContribution(
    operation: StealOperation,
    seat: Seat,
    context: LogContext,
    signingKey: Uint8Array,
  ): Result<SignedStealContribution> {
    if (this.disposed) return failure('verified-driver-disposed', 'Verified driver is disposed');
    if (!this.owned.has(seat))
      return failure('seat-not-controllable', 'Verified driver does not own this steal victim');
    const current = this.currentStealContext(context);
    if (!current.ok) return current;
    const pending = context.crypto?.steal;
    const signer = resolveArtifactSigner(
      context.authority,
      context.genesis,
      context.crypto?.epoch ?? 0,
      seat,
    );
    if (!signer.ok) return signer;
    try {
      if (
        !pending ||
        pending.fixed ||
        pending.dispute ||
        pending.operation.victim.seat !== seat ||
        stealOperationId(pending.operation) !== stealOperationId(operation) ||
        operation.genesisDigest !== this.digest ||
        operation.epoch > (context.crypto?.epoch ?? -1) ||
        operation.thief.encryptionKey !==
          this.genesis.seats.find((item) => item.seat === operation.thief.seat)?.encryptionKey
      )
        return failure(
          'verified-steal-operation',
          'Victim request is not the current frozen steal',
        );
    } catch {
      return failure('verified-steal-operation', 'Victim request is malformed');
    }
    const priv = this.privates.get(seat);
    const blindings = this.blindings.get(seat);
    if (!priv || !blindings)
      return failure('verified-private-missing', 'Owned steal opening is missing');
    const sourceResult = this.checkedStealSource(seat);
    if (!sourceResult.ok) return sourceResult;
    const source = sourceResult.value;
    try {
      const seed = source.proofSeed('transfer', {
        protocol: 'steal-transfer-source-v1',
        operationId: stealOperationId(operation),
      });
      try {
        return createStealContribution(
          operation,
          resourceCounts(priv),
          blindings,
          seed,
          signingKey,
          signer.value,
        );
      } finally {
        seed.fill(0);
      }
    } catch {
      return failure('verified-steal-contribution', 'Could not prepare owned steal contribution');
    } finally {
      source.dispose();
    }
  }

  produceStealResponse(
    fixed: FixedSteal,
    seat: Seat,
    context: LogContext,
    signingKey: Uint8Array,
  ): Result<
    { kind: 'receipt'; value: SignedStealReceipt } | { kind: 'dispute'; value: SignedStealDispute }
  > {
    if (this.disposed) return failure('verified-driver-disposed', 'Verified driver is disposed');
    if (!this.owned.has(seat))
      return failure('seat-not-controllable', 'Verified driver does not own this steal recipient');
    const current = this.currentStealContext(context);
    if (!current.ok) return current;
    const pending = context.crypto?.steal;
    const signer = resolveArtifactSigner(
      context.authority,
      context.genesis,
      context.crypto?.epoch ?? 0,
      seat,
    );
    if (!signer.ok) return signer;
    try {
      if (
        !pending?.fixed ||
        pending.dispute ||
        pending.operation.thief.seat !== seat ||
        stealOperationId(pending.operation) !== stealOperationId(fixed.operation) ||
        toHex(hashValue(pending.fixed)) !== toHex(hashValue(fixed)) ||
        fixed.operation.genesisDigest !== this.digest ||
        fixed.operation.epoch > (context.crypto?.epoch ?? -1) ||
        fixed.operation.thief.encryptionKey !==
          this.genesis.seats.find((item) => item.seat === seat)?.encryptionKey
      )
        return failure(
          'verified-steal-fixed',
          'Recipient request differs from the certified fixed steal',
        );
    } catch {
      return failure('verified-steal-fixed', 'Recipient request is malformed');
    }
    const sourceResult = this.checkedStealSource(seat);
    if (!sourceResult.ok) return sourceResult;
    const source = sourceResult.value;
    try {
      const secret = source.encryptionSecret();
      const receipt = createStealReceipt(fixed, secret, signingKey, signer.value);
      if (receipt.ok) return success({ kind: 'receipt', value: receipt.value });
      if (
        ![
          'steal-opening-size',
          'steal-opening-type',
          'steal-opening-mismatch',
          'steal-opening',
        ].includes(receipt.error.code)
      )
        return receipt;
      const seed = source.proofSeed('dispute', {
        protocol: 'steal-dispute-source-v1',
        operationId: stealOperationId(fixed.operation),
        fixed: fixed.entry,
      });
      try {
        const dispute = createStealDispute(fixed, secret, signingKey, seed, signer.value);
        return dispute.ok ? success({ kind: 'dispute', value: dispute.value }) : dispute;
      } finally {
        seed.fill(0);
      }
    } catch {
      return failure('verified-steal-response', 'Could not prepare owned steal response');
    } finally {
      source.dispose();
    }
  }

  /** Derive one owned, exact Monopoly count opening for the frozen public request. */
  produceCountProof(
    operation: CountOperation,
    seat: Seat,
    context: LogContext,
  ): Result<{ count: number; proof: SchnorrProof }> {
    if (this.disposed) return failure('verified-driver-disposed', 'Verified driver is disposed');
    if (!this.owned.has(seat))
      return failure('seat-not-controllable', 'Verified driver does not own this victim');
    const crypto = context.crypto;
    if (
      genesisDigest(context.genesis) !== this.digest ||
      context.genesis.gameId !== this.genesis.gameId ||
      !crypto ||
      (this.appliedHead === null
        ? context.head.seq !== 0
        : entryHash(context.head) !== this.appliedHead)
    )
      return failure('verified-count-context', 'Count proof has a stale or foreign parent');
    const pending = crypto.counts;
    const validPending = validateCountState(
      pending,
      this.genesis,
      this.engine,
      context.state,
      crypto.hands,
      crypto.epoch,
      context.authority,
    );
    if (!validPending.ok) return validPending;
    let sameOperation = false;
    try {
      sameOperation =
        pending !== null && countOperationId(pending.operation) === countOperationId(operation);
    } catch {
      return failure('verified-count-operation', 'Count proof operation is malformed');
    }
    const victim = operation.victims.find((item) => item.seat === seat);
    const hand = crypto.hands.find((item) => item.seat === seat);
    if (
      !pending ||
      !sameOperation ||
      !pending.remaining.includes(seat) ||
      operation.genesisDigest !== this.digest ||
      operation.epoch > crypto.epoch ||
      !victim ||
      victim.commitment !== hand?.commitments[operation.resource]
    )
      return failure('verified-count-operation', 'Count proof is not the current victim request');
    const opened = this.verifyOwnedOpenings(context);
    if (!opened.ok) return opened;
    const priv = this.privates.get(seat);
    const blindings = this.blindings.get(seat);
    if (!priv || !blindings)
      return failure('verified-private-missing', 'Owned count opening is missing');
    const factory = this.handRoutes.get(seat) ?? this.createHandSource;
    if (!factory) return failure('hand-proof-source', 'No hand proof source is configured');
    const count = priv.hand[operation.resource];
    if (count === undefined)
      return failure('verified-private-missing', 'Owned count resource is missing');
    const blinding = blindings[operation.resource];
    let source: ReturnType<HandSourceFactory> | null = null;
    try {
      source = factory(seat);
      const proofContext = countProofContext(operation, seat, count);
      const seed = source.proofSeed(proofContext);
      try {
        const proof = proveCountOpening(operation, seat, count, blinding, seed);
        return proof.ok ? success({ count, proof: proof.value }) : proof;
      } finally {
        seed.fill(0);
      }
    } catch {
      return failure('verified-count-proof', 'Could not derive owned count proof');
    } finally {
      source?.dispose();
    }
  }

  private proveOwnedHand(
    plan: HandTransitionPlan,
    index: number,
    binding: HandProofBinding,
  ): Result<HandProof> {
    const obligation = plan.obligations[index];
    if (!obligation || !this.owned.has(obligation.seat))
      return failure('hand-proof-owner', 'A hand proof from another owner is required');
    const priv = this.privates.get(obligation.seat);
    const blindings = this.blindings.get(obligation.seat);
    if (!priv || !blindings)
      return failure('verified-private-missing', 'Owned hand opening is missing');
    const factory = this.handRoutes.get(obligation.seat) ?? this.createHandSource;
    if (!factory) return failure('hand-proof-source', 'No hand proof source is configured');
    let source: ReturnType<HandSourceFactory> | null = null;
    try {
      source = factory(obligation.seat);
      const seed = source.proofSeed(handProofContext(plan, index, binding));
      try {
        return proveHandObligation(plan, index, priv.hand, blindings, seed, binding);
      } finally {
        seed.fill(0);
      }
    } catch {
      return failure('hand-proof-generation', 'Could not derive the owned hand proof');
    } finally {
      source?.dispose();
    }
  }

  /** Return only the current trade counterparty's exact indexed obligations. */
  produceTradeProofs(
    request: SignedTradeProofRequest,
    context: LogContext,
  ): Result<readonly IndexedHandProof[]> {
    if (this.disposed) return failure('verified-driver-disposed', 'Verified driver is disposed');
    const verified = verifyTradeProofRequest(request, context);
    if (!verified.ok) return verified;
    const owner = verified.value.body.command.withSeat;
    if (!this.owned.has(owner))
      return failure(
        'seat-not-controllable',
        'Verified driver does not own this trade counterparty',
      );
    if (
      genesisDigest(context.genesis) !== this.digest ||
      context.genesis.gameId !== this.genesis.gameId ||
      (this.appliedHead === null
        ? context.head.seq !== 0
        : entryHash(context.head) !== this.appliedHead)
    )
      return failure('verified-trade-context', 'Trade proof has a stale or foreign parent');
    const authorized = authorizeTradeProof(verified.value.body, owner, context);
    if (!authorized.ok) return authorized;
    const opened = this.verifyOwnedOpenings(context);
    if (!opened.ok) return opened;
    const proofs: IndexedHandProof[] = [];
    for (const index of authorized.value.indices) {
      const proof = this.proveOwnedHand(authorized.value.plan, index, authorized.value.binding);
      if (!proof.ok) return proof;
      proofs.push({ index, proof: proof.value });
    }
    return success(proofs);
  }

  /** Attach proof material before the caller signs this exact command body. */
  prepareCommand(
    body: CommandWithoutEvidence,
    context: LogContext,
    external?: readonly IndexedHandProof[],
  ): Result<CommandBody['evidence']> {
    if (this.disposed) return failure('verified-driver-disposed', 'Verified driver is disposed');
    if (!this.owned.has(body.seat))
      return failure('seat-not-controllable', 'Verified driver does not own this seat');
    if (
      body.gameId !== context.genesis.gameId ||
      body.gameId !== this.genesis.gameId ||
      body.genesisDigest !== this.digest ||
      genesisDigest(context.genesis) !== this.digest ||
      body.headSeq !== context.head.seq ||
      body.headHash !== entryHash(context.head) ||
      (this.appliedHead === null ? context.head.seq !== 0 : body.headHash !== this.appliedHead) ||
      body.nonce !== (context.lastNonces.get(body.seat) ?? 0) + 1
    )
      return failure(
        'verified-command-context',
        'Command body differs from current certified context',
      );
    const openings = this.verifyOwnedOpenings(context);
    if (!openings.ok) return openings;
    const crypto = context.crypto;
    if (!crypto) return failure('crypto-context-required', 'Verified command needs crypto state');
    const input: Input = { kind: 'command', seat: body.seat, command: body.command };
    const preview = this.engine.apply(context.state, input);
    if (!preview.ok) return preview;
    const plan = planHandTransition(crypto.hands, context.state, input, preview.value);
    if (!plan.ok) return plan;
    const binding = {
      genesisDigest: this.digest,
      epoch: crypto.epoch,
      anchor: { seq: body.headSeq, hash: body.headHash },
      command: body,
    };
    if (external !== undefined && body.command.type !== 'CONFIRM_TRADE')
      return failure('hand-proof-external', 'External hand proofs require trade confirmation');
    const supplied = new Map<number, HandProof>();
    if (external !== undefined) {
      if (!Array.isArray(external))
        return failure('hand-proof-external', 'External trade proofs must be indexed');
      for (const item of external) {
        const obligation =
          item && Number.isSafeInteger(item.index) ? plan.value.obligations[item.index] : undefined;
        if (
          !item ||
          !Number.isSafeInteger(item.index) ||
          item.index < 0 ||
          supplied.has(item.index) ||
          !obligation ||
          (body.command.type === 'CONFIRM_TRADE' && obligation.seat !== body.command.withSeat) ||
          this.owned.has(obligation.seat)
        )
          return failure('hand-proof-external', 'External trade proof index is invalid');
        const verified = verifyHandProof(plan.value, item.index, item.proof, binding);
        if (!verified.ok) return verified;
        supplied.set(item.index, item.proof);
      }
    }
    for (const [index, obligation] of plan.value.obligations.entries())
      if (!this.owned.has(obligation.seat) && !supplied.has(index))
        return failure('hand-proof-owner', 'A hand proof from another owner is required');
    const handProofs: HandProof[] = [];
    for (let index = 0; index < plan.value.obligations.length; index++) {
      const obligation = plan.value.obligations[index];
      if (!obligation) throw new Error('Missing planned hand obligation');
      if (!this.owned.has(obligation.seat)) {
        const proof = supplied.get(index);
        if (!proof)
          return failure('hand-proof-owner', 'A hand proof from another owner is required');
        handProofs.push(proof);
        continue;
      }
      const proof = this.proveOwnedHand(plan.value, index, binding);
      if (!proof.ok) return proof;
      handProofs.push(proof.value);
    }
    const complete = verifyHandProofs(plan.value, handProofs, binding);
    if (!complete.ok) return complete;

    const revealSlots: string[] = [];
    for (const effect of preview.value.effects)
      if (effect.type === 'card-slot-revealed') {
        if (effect.seat !== body.seat)
          return failure('deck-reveal-owner', 'Command reveals another seat’s card slot');
        revealSlots.push(effect.slotId);
      }
    if (new Set(revealSlots).size !== revealSlots.length)
      return failure('deck-reveal-slots', 'Command has duplicate reveal slots');

    const data: {
      slotId: string;
      identity: string;
      proof: ReturnType<typeof proveDeckReveal>['proof'];
    }[] = [];
    for (const slotId of revealSlots) {
      const deck = crypto.decks.decks.find((item) =>
        item.slots.some((slot) => slot.slotId === slotId),
      );
      const slot = deck?.slots.find((item) => item.slotId === slotId);
      if (!deck || !slot)
        return failure('deck-reveal-owner', 'Reveal slot has no hidden deck receipt');
      if (slot.seat !== body.seat)
        return failure('deck-reveal-owner', 'Reveal slot is not owned by this seat');
      const publicSlot = context.state.seats
        .find((candidate) => candidate.seat === body.seat)
        ?.cardSlots.find((candidate) => candidate.slotId === slotId);
      if (
        !publicSlot ||
        publicSlot.revealed !== undefined ||
        publicSlot.deck !== deck.commitment.definition.deckId
      )
        return failure('deck-reveal-owner', 'Reveal slot is not an owned hidden public card');
      let source: DeckSecretSource | null = null;
      try {
        source = this.newSource(deck.commitment.definition.deckId, body.seat);
        const lock = source.lock(slot.receipt.operation.position);
        const decoded = decodeDeckCard(deck.setup, slot.receipt, lock, slot.unlockSigners);
        if (!decoded.ok) return decoded;
        if (
          (body.command.type === 'PLAY_DEV_CARD' && decoded.value.card !== body.command.card) ||
          (body.command.type === 'CLAIM_VICTORY' && decoded.value.card !== 'victoryPoint')
        )
          return failure('deck-reveal-kind', 'Owned card does not match the requested command');
        const revealContext = {
          genesisDigest: body.genesisDigest,
          epoch: crypto.epoch,
          anchor: { seq: body.headSeq, hash: body.headHash },
          seat: body.seat,
          nonce: body.nonce,
          command: body.command,
        };
        const seed = source.proofSeed('reveal', { ...revealContext, slotId });
        try {
          const reveal = proveDeckReveal(
            deck.setup,
            slot.receipt,
            decoded.value.identity,
            lock,
            seed,
            revealContext,
            slot.unlockSigners,
          );
          data.push({ slotId, ...reveal });
        } finally {
          seed.fill(0);
        }
      } catch {
        return failure('deck-reveal-proof', 'Could not derive the owned card reveal proof');
      } finally {
        source?.dispose();
      }
    }
    return success(composeCommandProofs(data, handProofs));
  }

  committedEntry(
    entry: ValidatedEntry & CertifiedEntry,
    before: LogContext,
    after: LogContext,
  ): Result<void> {
    if (this.disposed) return failure('verified-driver-disposed', 'Verified driver is disposed');
    if (
      genesisDigest(before.genesis) !== this.digest ||
      genesisDigest(after.genesis) !== this.digest ||
      (this.appliedHead === null
        ? before.head.seq !== 0
        : entryHash(before.head) !== this.appliedHead) ||
      entry.entry.seq !== before.head.seq + 1 ||
      entry.entry.prevHash !== entryHash(before.head) ||
      entryHash(entry.entry) !== entryHash(after.head)
    )
      return failure('verified-entry-context', 'Private update differs from certified history');
    const parentOpenings = this.verifyOwnedOpenings(before);
    if (!parentOpenings.ok) return parentOpenings;
    const input = entry.input;
    if (!input) {
      const afterOpenings = this.verifyOwnedOpenings(after);
      if (!afterOpenings.ok) return afterOpenings;
      this.appliedHead = entryHash(after.head);
      return success(undefined);
    }

    const privateData: Partial<Record<Seat, { card?: string; resource?: Resource }>> = {};
    const nextBlindings = new Map(this.blindings);
    if (input.kind === 'system' && input.type === 'STEAL_RESULT') {
      const steal = before.crypto?.steal;
      const payload = entry.entry.payload;
      if (
        !steal?.fixed ||
        steal.dispute ||
        !after.crypto ||
        after.crypto.steal !== null ||
        payload.kind !== 'system'
      )
        return failure(
          'verified-hidden-steal',
          'Certified hidden steal is missing its fixed operation',
        );
      const signer = resolveArtifactSigner(
        before.authority,
        before.genesis,
        before.crypto?.epoch ?? 0,
        steal.operation.thief.seat,
      );
      if (!signer.ok) return signer;
      const receipt = verifyStealResult(steal, input, payload.evidence, signer.value);
      if (!receipt.ok) return receipt;
      const { operation, fixed } = steal;
      let victimOpening: StealOpening | null = null;
      let thiefOpening: StealOpening | null = null;
      if (this.owned.has(operation.victim.seat)) {
        const seat = operation.victim.seat;
        const priv = this.privates.get(seat);
        const blindings = this.blindings.get(seat);
        if (!priv || !blindings)
          return failure('verified-private-missing', 'Victim private hand is missing');
        const sourceResult = this.checkedStealSource(seat);
        if (!sourceResult.ok) return sourceResult;
        const source = sourceResult.value;
        try {
          const seed = source.proofSeed('transfer', {
            protocol: 'steal-transfer-source-v1',
            operationId: stealOperationId(operation),
          });
          try {
            const recovered = recoverStealTransferOpening(
              operation,
              fixed.contribution,
              resourceCounts(priv),
              blindings,
              seed,
            );
            if (!recovered.ok) return recovered;
            victimOpening = recovered.value;
          } finally {
            seed.fill(0);
          }
        } catch {
          return failure(
            'verified-steal-victim',
            'Could not recover the certified victim transfer',
          );
        } finally {
          source.dispose();
        }
      }
      if (this.owned.has(operation.thief.seat)) {
        const sourceResult = this.checkedStealSource(operation.thief.seat);
        if (!sourceResult.ok) return sourceResult;
        const source = sourceResult.value;
        try {
          const opened = openStealContribution(
            operation,
            fixed.contribution,
            source.encryptionSecret(),
            fixed.signer,
          );
          if (!opened.ok) return opened;
          thiefOpening = opened.value;
        } catch {
          return failure('verified-steal-thief', 'Could not open the certified thief transfer');
        } finally {
          source.dispose();
        }
      }
      if (
        victimOpening &&
        thiefOpening &&
        toHex(hashValue(victimOpening)) !== toHex(hashValue(thiefOpening))
      )
        return failure(
          'verified-steal-opening',
          'Owned endpoints disagree about the fixed transfer',
        );
      for (const [seat, direction, opening] of [
        [operation.victim.seat, -1n, victimOpening],
        [operation.thief.seat, 1n, thiefOpening],
      ] as const) {
        if (!opening) continue;
        privateData[seat] = { resource: opening.resource };
        const parent = this.blindings.get(seat);
        if (!parent)
          return failure('verified-private-missing', 'Owned steal blindings are missing');
        const next = { ...parent };
        for (const resource of RESOURCES)
          next[resource] = encodeScalar(
            modScalar(
              decodeScalar(parent[resource]) +
                direction * decodeScalar(opening.blindings[resource]),
            ),
          );
        nextBlindings.set(seat, next);
      }
    }
    if (input.kind === 'system' && input.type === 'CARD_DEALT') {
      const owner = this.genesis.config.seats.find((seat) => seat === input.seat);
      if (owner === undefined || typeof input.deck !== 'string' || typeof input.slotId !== 'string')
        return failure('verified-deal-context', 'Certified deal has invalid deck, seat, or slot');
      const deck = after.crypto?.decks.decks.find(
        (item) => item.commitment.definition.deckId === input.deck,
      );
      const slot = deck?.slots.find((item) => item.slotId === input.slotId);
      if (!deck || !slot || slot.seat !== owner)
        return failure('verified-deal-receipt', 'Certified deal has no matching replayed receipt');
      if (this.owned.has(owner)) {
        let source: DeckSecretSource | null = null;
        try {
          source = this.newSource(input.deck, owner);
          const decoded = decodeDeckCard(
            deck.setup,
            slot.receipt,
            source.lock(slot.receipt.operation.position),
            slot.unlockSigners,
          );
          if (!decoded.ok) return decoded;
          privateData[owner] = { card: decoded.value.card };
        } catch {
          return failure('verified-deal-decode', 'Could not decode certified card for its owner');
        } finally {
          source?.dispose();
        }
      }
    }

    const next = new Map(this.privates);
    for (const seat of this.owned) {
      const prior = this.privates.get(seat);
      if (!prior) return failure('verified-private-missing', 'Owned private state is missing');
      const applied = this.engine.applyPrivate(prior, before.state, input, privateData[seat]);
      if (!applied.ok) return applied;
      if (applied.value.seat !== seat)
        return failure('verified-private-seat', 'Engine changed private-state ownership');
      const checked = validOwnedState(after.state, applied.value);
      if (!checked.ok) return checked;
      next.set(seat, applied.value);
    }
    const afterOpenings = this.verifyOwnedOpenings(after, next, nextBlindings);
    if (!afterOpenings.ok) return afterOpenings;
    this.privates = next;
    this.blindings = nextBlindings;
    this.appliedHead = entryHash(after.head);
    return success(undefined);
  }

  committed(_before: LogContext, _input: Input, _after: GameState): Result<void> {
    return failure('verified-entry-context', 'Verified driver requires certified entry callbacks');
  }

  /**
   * Copy reconstructed bot openings into this live driver at the same certified head.
   * The donor retains its master-backed source factories; its owning bundle must
   * remain alive until this driver is disposed.
   */
  adoptRecovered(donor: SessionDriver, context: LogContext): Result<void> {
    if (
      this.disposed ||
      !(donor instanceof VerifiedSessionDriver) ||
      donor.disposed ||
      donor === this
    )
      return failure('verified-adoption-driver', 'A live verified donor is required');
    const head = entryHash(context.head);
    if (
      !context.authority ||
      !context.crypto ||
      context.head.seq === 0 ||
      this.appliedHead !== head ||
      donor.appliedHead !== head ||
      this.engine !== donor.engine ||
      this.digest !== donor.digest ||
      this.digest !== genesisDigest(context.genesis) ||
      this.genesis.gameId !== donor.genesis.gameId ||
      context.genesis.gameId !== this.genesis.gameId ||
      context.head.stateHash !== toHex(hashValue(context.state))
    )
      return failure(
        'verified-adoption-context',
        'Donor and recipient need the same verified head',
      );
    const ownOpenings = this.verifyOwnedOpenings(context);
    if (!ownOpenings.ok) return ownOpenings;
    const donorOpenings = donor.verifyOwnedOpenings(context);
    if (!donorOpenings.ok) return donorOpenings;
    if (!donor.createHandSource || !donor.createStealSource)
      return failure('verified-adoption-source', 'Donor proof sources are missing');
    const checkedSources = donor.validateSources();
    if (!checkedSources.ok) return checkedSources;

    const states = new Map<Seat, { state: PrivateState; blindings: Record<Resource, string> }>();
    for (const seat of donor.owned) {
      const controller = context.authority.controllers.find((item) => item.seat === seat);
      const host = context.authority.controllers.find((item) => item.seat === controller?.hostSeat);
      const state = donor.privates.get(seat);
      const blindings = donor.blindings.get(seat);
      if (
        this.owned.has(seat) ||
        controller?.kind !== 'bot' ||
        controller.status !== 'active' ||
        host?.kind !== 'human' ||
        host.status !== 'active' ||
        !this.owned.has(host.seat) ||
        !state ||
        !blindings
      )
        return failure('verified-adoption-seat', 'Donor seat is not an active hosted bot');
      try {
        states.set(seat, { state: copyPrivate(state), blindings: { ...blindings } });
      } catch {
        return failure('verified-adoption-private', 'Donor private state could not be copied');
      }
    }
    if (states.size === 0) return failure('verified-adoption-seat', 'Donor has no recovered seats');

    for (const [seat, copied] of states) {
      this.owned.add(seat);
      this.privates.set(seat, copied.state);
      this.blindings.set(seat, copied.blindings);
      this.deckRoutes.set(seat, donor.deckRoutes.get(seat) ?? donor.createDeckSource);
      this.handRoutes.set(seat, donor.handRoutes.get(seat) ?? donor.createHandSource);
      this.stealRoutes.set(seat, donor.stealRoutes.get(seat) ?? donor.createStealSource);
    }
    return success(undefined);
  }

  relinquishSeats(seats: readonly Seat[]): void {
    for (const seat of seats) {
      if (!this.owned.delete(seat)) continue;
      const privateState = this.privates.get(seat);
      if (privateState) {
        for (const resource of Object.keys(privateState.hand)) privateState.hand[resource] = 0;
        for (const slot of Object.keys(privateState.slots)) delete privateState.slots[slot];
        for (const value of Object.values(privateState.ext)) wipePrivateBytes(value);
        for (const module of Object.keys(privateState.ext)) delete privateState.ext[module];
      }
      this.privates.delete(seat);
      this.blindings.delete(seat);
      this.deckRoutes.delete(seat);
      this.handRoutes.delete(seat);
      this.stealRoutes.delete(seat);
    }
  }

  dispose(): void {
    this.disposed = true;
    this.relinquishSeats([...this.owned]);
    this.deckRoutes.clear();
    this.handRoutes.clear();
    this.stealRoutes.clear();
  }

  private newSource(deckId: string, seat: Seat): DeckSecretSource {
    const source = (this.deckRoutes.get(seat) ?? this.createDeckSource)(deckId, seat);
    if (!source || typeof source.dispose !== 'function')
      throw new TypeError('Deck source factory returned an invalid source');
    return source;
  }
}


### CURRENT packages/protocol/src/audit-types.ts
import type { Seat } from '@cp2p/engine';
import type { CheatFinding } from './cheat-types.js';

export interface AuditEntryRef {
  readonly seq: number;
  readonly hash: string;
}

/** An authenticated inconsistency. A null seat makes no accusation about an owner. */
export interface AuditViolation {
  readonly seq: number;
  readonly seat: Seat | null;
  readonly kind: string;
  readonly detail: string;
}

/** Problems with supplied reveals are not findings against the original owner. */
export interface AuditInputError {
  readonly seat: Seat | null;
  readonly kind: string;
}

export interface AuditReport {
  readonly ok: boolean;
  readonly complete: boolean;
  readonly missingSeats: readonly Seat[];
  readonly violations: readonly AuditViolation[];
  readonly inputErrors: readonly AuditInputError[];
  readonly cheatFindings: readonly CheatFinding[];
  readonly terminal: AuditEntryRef | null;
  readonly finalHead: AuditEntryRef | null;
  readonly historyError: { readonly code: string } | null;
  /** Local reconstruction or engine failure, without attributing misconduct. */
  readonly auditError: { readonly seq: number; readonly code: string } | null;
  /** Hidden VP card counts, disclosed only after a complete successful audit. */
  readonly finalHiddenVictoryPoints: Partial<Record<Seat, number>> | null;
}


### CURRENT packages/protocol/src/index.ts
export const PACKAGE_NAME = '@cp2p/protocol';

export { createBeaconSecretSource } from './beacon-source.js';
export type { BeaconSecretProvider, BeaconSecretSourceContext } from './beacon-source.js';

export { MemoryBeaconContributionStore } from './beacon-contributions.js';
export { MemoryCheatCandidateStore } from './cheat-candidates.js';
export type { CheatCandidateStore } from './cheat-candidates.js';
export type {
  BeaconContribution,
  BeaconContributionStore,
  BeaconSecretSource,
} from './beacon-contributions.js';
export type { CryptoContext } from './crypto-context.js';
export { MemoryCountContributionStore } from './count-contributions.js';
export type { CountContributionStore, CountProofProducer } from './count-contributions.js';
export type { CountOperation, CountState, SignedCountContribution } from './count-reveal.js';
export { createHandSecretSource } from './hand-source.js';
export type { HandSecretSource, HandSourceFactory } from './hand-source.js';
export { createRandomDerivations, randomDerivations } from './random-derivations.js';
export type { RandomDerivation, RandomPending, BeaconOutcome } from './random-derivations.js';

export {
  GENESIS_PREVIOUS_HASH,
  entryBody,
  entryHash,
  genesisBody,
  genesisDigest,
  genesisId,
  signEntry,
  validateGenesis,
  validateGenesisEntry,
} from './genesis.js';
export type { GenesisPolicy, ValidatedGenesis } from './genesis.js';
export { validateGenesisOnlineStart } from './genesis-online-start.js';
export type { VerifiedOnlineStart } from './genesis-online-start.js';
export type { GenesisSeedMode } from './genesis-seed.js';
export { OnlineCeremony } from './online-ceremony.js';
export type {
  OnlineCeremonyOptions,
  OnlineCeremonyProgress,
  OnlineCeremonyResult,
  OnlineCeremonyPhase,
} from './online-ceremony.js';
export { signCommand, stubEvidence, validateNextEntry, validateSignedCommand } from './log.js';
export type { EntryPolicy, LogContext, ValidatedEntry } from './log.js';
export { validateExcludeProposerControl, validateObjectiveAccusation } from './control.js';
export type { ControlEvidenceContext } from './control.js';
export {
  authenticateCertifiedEntry,
  proposerFor,
  signProposal,
  validateCertifiedEntry,
  validateProposal,
} from './proposal.js';
export type {
  CertifiedEntry,
  ProposalBody,
  ProposalContext,
  SignedProposal,
  ValidatedProposal,
} from './proposal.js';
export { advanceContext } from './proposal.js';
export { certifiedEntrySchema } from './proposal.js';
export { genesisSchema, logEntrySchema } from './schemas.js';
export { MemorySafetyStore } from './safety-store.js';
export { createConsensusState, restoreConsensusState } from './consensus.js';
export { verifyRevealedMaster } from './genesis-secrets.js';
export { validateGenesisEscrow } from './genesis-escrow.js';
export { restoreRetiredSafety } from './retired-safety.js';
export {
  transferAuthorizationStatementSchema,
  transferChangeSchema,
  transferCheckDigest,
  transferEntryRef,
  TRANSFER_DEVICE_DOMAIN,
  TRANSFER_GAME_KEY_DOMAIN,
  TRANSFER_BOT_KEY_DOMAIN,
  TRANSFER_DESTINATION_CHECK_DOMAIN,
  TRANSFER_BOT_CHECK_DOMAIN,
} from './transfer-readiness.js';
export type {
  SeatTransferAuthorization,
  SeatTransferAuthorizationStatement,
  TransferReplacement,
} from './transfer-types.js';
export { TRANSFER_RETURN_INTENT_DOMAIN } from './transfer-readiness.js';
export {
  prepareTransferPrivate,
  importTransferPrivate,
  verifyTransferPrivateEnvelope,
  transferPrivateEnvelopeSchema,
  TRANSFER_PRIVATE_DOMAIN,
} from './transfer-private.js';
export type {
  TransferPrivateEnvelope,
  TransferPrivateStore,
  ImportedTransferPrivate,
} from './transfer-private.js';
export { transferActivationStatementSchema } from './transfer-readiness.js';
export {
  validatePendingTransferMaterial,
  validateRetiredTransferBinding,
  validateTransferOwnedMaterial,
} from './transfer-material.js';
export type { TransferOwnedMaterial, TransferOwnedSeat } from './transfer-material.js';
export type { SafetyStore, StoredSafety } from './safety-store.js';
export { MemoryProtocolJournal, journalSafetyStore } from './journal.js';
export type { JournalRecord, ProtocolJournal } from './journal.js';
export { P2PSession } from './p2p-session.js';
export { VerifiedSessionDriver } from './verified-session-driver.js';
export type { CertifiedHistory, P2PSessionOptions, SessionDriver } from './p2p-session.js';
export { ReplicatedLog } from './replicated-log.js';
export type {
  ReplicatedLogOptions,
  ReplicatedLogStatus,
  RecoveredReplicaOwnership,
} from './replicated-log.js';
export { chooseBotPending } from './bot-pending.js';
export {
  initialProposalContext,
  replayCertifiedPrefix,
  snapshotFromContext,
  verifyReplaySnapshot,
} from './replay.js';
export type { ReplayPolicy, ReplayedPrefix } from './replay.js';
export { decodeProtocolMessage, encodeProtocolMessage, protocolMessageSchema } from './messages.js';
export type { ProtocolMessage } from './messages.js';
export type {
  GameSession,
  SessionScheduler,
  SessionStatus,
  SessionTimer,
  SessionUpdate,
  SessionFairness,
  SubmitOptions,
} from './session-types.js';
export { phaseIdentity, timerKey } from './session-timing.js';
export { TURN_TIMEOUT_PROTOCOL } from './turn-timeout.js';
export type { TimerAnchor } from './turn-timeout.js';
export type { PeerId, ProtocolClock, Transport, Unsubscribe } from './transport.js';
export { PROTOCOL_VERSION } from './types.js';
export { DEFAULT_TAKEOVER_POLICY, takeoverPolicySchema } from './takeover-policy.js';
export type { TakeoverPolicy } from './takeover-policy.js';
export { LobbyController, verifyLobbyFreezeAgreement } from './lobby.js';
export type { LobbyControllerOptions, HostLobbyOptions, JoinLobbyOptions } from './lobby.js';
export { LOBBY_COLOURS } from './lobby-types.js';
export type {
  LobbyBotLevel,
  LobbyColour,
  LobbyDiagnostic,
  LobbyFreezeAck,
  LobbyFreezeAgreement,
  LobbyRequest,
  LobbySeat,
  LobbyState,
} from './lobby-types.js';
export {
  ONLINE_SEAT_BINDING_DOMAIN,
  ONLINE_SEAT_BINDING_PROTOCOL,
  signGameSeatBinding,
  verifyGameSeatBindings,
} from './online-bindings.js';
export type {
  GameSeatBindingBody,
  SignedGameSeatBinding,
  SignGameSeatBindingInput,
  VerifiedGameSeatBindings,
} from './online-bindings.js';
export { EscrowCeremony } from './escrow-ceremony.js';
export type { CeremonySend, EscrowCeremonyStore } from './escrow-ceremony.js';
export type { EscrowManifestApproval } from './escrow-lifecycle.js';
export type { EscrowShareAck, AcceptedEscrowShare } from './escrow-distribution.js';
export type { EscrowShareEnvelope } from './escrow-types.js';
export type {
  BotSeat,
  CommandBody,
  CommandEvidence,
  EntryBody,
  EntryPayload,
  ExcludeProposerControl,
  ObjectiveEvidence,
  Genesis,
  GenesisBody,
  GenesisSeat,
  HumanSeat,
  LogEntry,
  SeatSignature,
  SignedCommand,
  SystemEvidence,
} from './types.js';
export { MAX_MESSAGE_BYTES } from './validation.js';
export { quorumSize, signVote, validateVote, verifyCertificate } from './votes.js';
export type { ExpectedVote, SignedVote, VoteBody, VoteContext, VotePhase } from './votes.js';
export { decodeMessage, encodeMessage } from './wire.js';
export {
  initDeckSetup,
  validateDeckSetupState,
  deckSetupId,
  deckPassOperationId,
  applyDeckPass,
  signDeckShuffle,
  signDeckLock,
  replayDeckSetup,
} from './deck-setup.js';
export type { DeckDefinition, DeckSetupState, SignedDeckPass } from './deck-setup.js';
export { createDeckSecretSource } from './deck-source.js';
export type { DeckSecretSource, DeckSourceFactory } from './deck-source.js';
export {
  freezeDeckDraw,
  validateDeckDrawOperation,
  deckDrawOperationId,
  verifyDeckUnlockPrefix,
  signDeckUnlock,
  verifyDeckUnlock,
  completeDeckDraw,
  decodeDeckCard,
  proveDeckReveal,
  verifyDeckReveal,
} from './deck-draw.js';
export type {
  DeckDrawRequest,
  DeckDrawOperation,
  SignedDeckUnlock,
  DealtDeckCard,
  DeckRevealContext,
  DeckCardReveal,
} from './deck-draw.js';
export { prepareDeckUnlock } from './deck-outbox.js';
export type { DeckContributionStore } from './deck-outbox.js';
export { prepareDeckPass } from './deck-setup-outbox.js';

export {
  deckCeremonyId,
  genesisDeckDefinitions,
  deckPassHash,
  createDeckGenesisCommitment,
  validateDeckGenesisCommitments,
  validateDeckCeremony,
} from './deck-genesis.js';
export type { DeckGenesisCommitment } from './deck-genesis.js';
export { DECK_DRAW_PROTOCOL, DECK_REVEAL_PROTOCOL, decksReady } from './deck-ledger.js';
export type { DeckLedger, LedgerDeck, LedgerSlot } from './deck-ledger.js';

export { prepareGenesisConsent, MemoryGenesisConsentStore } from './genesis-outbox.js';
export type { GenesisConsentStore } from './genesis-outbox.js';

export { createStealSecretSource } from './steal-source.js';
export type { StealSecretSource, StealSourceFactory } from './steal-source.js';
export type { StealState } from './steal-state.js';
export { MemoryStealDeliveryStore } from './steal-contributions.js';
export type {
  StealContributionProducer,
  StealDeliveryStore,
  StealResponse,
  StealResponseProducer,
} from './steal-contributions.js';
export type {
  IndexedHandProof,
  SignedTradeProofRequest,
  SignedTradeProofResponse,
  TradeProofBody,
} from './trade-proof-delivery.js';

export { artifactSigner, resolveArtifactSigner } from './authority.js';
export type { ArtifactSigner, ControllerRecord, SeatAuthorities } from './authority-types.js';
export type {
  AuthorizedRecovery,
  RecoveryActivation,
  RecoveryActivationStatement,
  RecoveryAuthorization,
  RecoveryChange,
  RecoveryReadiness,
  RecoveryState,
  RecoveryVoid,
  RecoveryVoidReason,
  RecoveryVoidStatement,
} from './recovery-types.js';
export { recoveryCheckDigest } from './recovery-membership.js';
export {
  prepareRecoveryReadiness,
  loadPreparedRecoveryReadiness,
  loadActivatedRecoveryKeys,
} from './recovery-readiness.js';
export type { RecoveryApprovalCandidate, RecoveryApprovalPreview } from './recovery-facade.js';
export type {
  ActivatedRecoveryKeySet,
  RecoveryReadinessReplacement,
  RecoveryReadinessStore,
} from './recovery-readiness.js';
export {
  prepareRecoveryRelease,
  verifyRecoveryRelease,
  openRecoveryRelease,
  recoverAuthorizedMaster,
} from './recovery-release.js';
export type { RecoveryRelease, RecoveryReleaseStore } from './recovery-release.js';
export { produceRecoveryCheck, produceRecoveryCheckFromShares } from './recovery-check.js';
export { produceRecoveryVoidCheckFromShares } from './recovery-void.js';
export type { SignedRecoveryVoidCheck, RecoveryVoidCheckInput } from './recovery-void.js';
export type {
  ProducedRecoveryCheck,
  RecoveryCheckInput,
  RecoveryCheckStore,
  SignedRecoveryCheck,
} from './recovery-check.js';
export { RecoveryInbox } from './recovery-inbox.js';
export { loadRecoveryPrivate } from './recovery-private.js';
export type { RecoveryPrivateStore } from './recovery-private.js';
export { loadRecoveredHost } from './recovered-host.js';
export type { RecoveredHost, RecoveredHostInput } from './recovered-host.js';
export { RecoveryParticipant } from './recovery-participant.js';
export type {
  RecoveryParticipantOptions,
  PreparedRecoveryPackets,
} from './recovery-participant.js';
export { auditCertifiedGame } from './audit.js';
export type { AuditCertifiedGameInput } from './audit.js';
export type { AuditReport, AuditViolation, AuditInputError, AuditEntryRef } from './audit-types.js';
export {
  MasterRevealCoordinator,
  signedMasterRevealSchema,
  verifyMasterReveal,
} from './master-reveal.js';
export type {
  MasterRevealOptions,
  MasterRevealStore,
  MasterRevealVerdict,
  SignedMasterReveal,
} from './master-reveal.js';
export type {
  SessionAuditInput,
  SessionAuditJob,
  SessionAuditRunner,
  SessionAuditState,
} from './session-audit-types.js';


### CURRENT packages/protocol/src/testing.ts
export { createMemnet } from './testing/memnet.js';
export type { Memnet, MemnetLinkOptions, MemnetOptions } from './testing/memnet.js';
export { VirtualClock } from './testing/virtual-clock.js';
export type { VirtualClockOptions } from './testing/virtual-clock.js';
export { SimulationDriver } from './testing/simulation-driver.js';
export { createSimulationGenesis } from './testing/simulation-genesis.js';
export type { SimulationGenesisOptions, SimulationGenesis } from './testing/simulation-genesis.js';
export { createTerminalAuditFixture } from './testing/audit-fixture.js';
export { createVerifiedNetworkFixture } from './testing/verified-network-fixture.js';
export type {
  VerifiedNetworkAuditTiming,
  VerifiedNetworkFixtureOptions,
  VerifiedNetworkSessionOptions,
} from './testing/verified-network-fixture.js';
export { createVerifiedNonVoterActor } from './testing/verified-non-voter-actor.js';
export type {
  VerifiedNonVoterActor,
  VerifiedNonVoterActorOptions,
} from './testing/verified-non-voter-actor.js';
export { createRetiredSafety } from './retired-safety.js';
export { persistRecoveryPrivate } from './recovery-private.js';
export {
  createRecoveryFixture,
  signRecoveryFixtureEntry,
  certifyRecoveryFixtureEntry,
  advanceRecoveryFixture,
  certifyRecoveryFixtureFirstBeacon,
  recoveryFixtureKey,
  recoveryFixtureReadiness,
  signRecoveryFixtureAuthorization,
  signRecoveryFixtureActivation,
} from './testing/recovery-fixture.js';
export {
  TRANSFER_DEVICE_DOMAIN,
  TRANSFER_GAME_KEY_DOMAIN,
  TRANSFER_OWNER_GAME_DOMAIN,
  TRANSFER_DESTINATION_CHECK_DOMAIN,
  transferCheckDigest,
  transferEntryRef,
} from './transfer-readiness.js';
export { MemoryEscrowLifecycleStore } from './escrow-lifecycle.js';
export { acceptEscrowShare, escrowShareEnvelopeHash } from './escrow-distribution.js';
export { performVerifiedNetworkAudit } from './testing/verified-network-audit.js';
export type {
  VerifiedNetworkAuditRequest,
  VerifiedNetworkAuditResult,
  VerifiedNetworkAuditJob,
  VerifiedNetworkPrivateSnapshot,
} from './testing/verified-network-audit.js';


### PRIOR COMMITTED packages/protocol/src/audit.ts
import { fromBase64Url, hashValue, toBase64Url, toHex } from '@cp2p/codec';
import { scalarFromBytes } from '@cp2p/crypto';
import { LocalGame, RESOURCES, failure, success } from '@cp2p/engine';
import type { Engine, PrivateInputData, Result, Seat } from '@cp2p/engine';
import { decodeDeckCard } from './deck-draw.js';
import { createDeckSecretSource } from './deck-source.js';
import { entryHash } from './genesis.js';
import { verifyRevealedMaster } from './genesis-secrets.js';
import { reconstructPrivateSeats } from './private-replay.js';
import { initialProposalContext, replayCertifiedPrefix } from './replay.js';
import type { ReplayPolicy } from './replay.js';
import { openStealContribution } from './steal-delivery.js';
import { createStealSecretSource } from './steal-source.js';
import type { AuditEntryRef, AuditInputError, AuditReport, AuditViolation } from './audit-types.js';
import type { ProposalContext } from './proposal.js';
import type { Genesis } from './types.js';

const MAX_DIAGNOSTICS = 16;

function isSeat(value: unknown): value is Seat {
  return typeof value === 'number' && Number.isInteger(value) && value >= 0 && value <= 5;
}

export interface AuditCertifiedGameInput {
  readonly genesisEntry: unknown;
  readonly entries: readonly unknown[];
  readonly engine: Engine;
  readonly policy: ReplayPolicy;
  readonly masters: readonly { readonly seat: Seat; readonly master: Uint8Array }[];
}

function ref(entry: Parameters<typeof entryHash>[0]): AuditEntryRef {
  return { seq: entry.seq, hash: entryHash(entry) };
}

function issue(seq: number, seat: Seat | null, kind: string): AuditViolation {
  return { seq, seat, kind, detail: kind };
}

function selectedResource(
  hand: Readonly<Record<string, number>>,
  index: number,
): (typeof RESOURCES)[number] | null {
  let cursor = index;
  for (const resource of RESOURCES) {
    cursor -= hand[resource] ?? 0;
    if (cursor < 0) return resource;
  }
  return null;
}

function privateDataFor(
  input: NonNullable<Parameters<LocalGame['applyRecorded']>[0]>,
  prior: ProposalContext,
  next: ProposalContext,
  game: LocalGame,
  masters: ReadonlyMap<Seat, Uint8Array>,
  genesis: Genesis,
): Result<Partial<Record<Seat, PrivateInputData>>> {
  if (input.kind !== 'system') return success({});
  if (input.type === 'CARD_DEALT') {
    if (!isSeat(input.seat) || !genesis.config.seats.includes(input.seat))
      return failure('audit-draw-seat', 'Certified draw seat is invalid');
    const deck = next.log.crypto?.decks.decks.find(
      (item) => item.commitment.definition.deckId === input.deck,
    );
    const slot = deck?.slots.find((item) => item.slotId === input.slotId);
    const master = masters.get(input.seat);
    if (!deck || !slot || slot.seat !== input.seat || !master)
      return failure('audit-draw-context', 'Certified draw lacks its original receipt or master');
    const source = createDeckSecretSource(master, deck.commitment.definition, input.seat);
    try {
      const decoded = decodeDeckCard(
        deck.setup,
        slot.receipt,
        source.lock(slot.receipt.operation.position),
        slot.unlockSigners,
      );
      return decoded.ok ? success({ [input.seat]: { card: decoded.value.card } }) : decoded;
    } finally {
      source.dispose();
    }
  }
  if (input.type === 'STEAL_RESULT') {
    const fixed = prior.log.crypto?.steal?.fixed;
    const operation = fixed?.operation;
    if (
      !fixed ||
      !operation ||
      input.thief !== operation.thief.seat ||
      input.victim !== operation.victim.seat
    )
      return failure('audit-steal-context', 'Certified steal lacks its fixed operation');
    const victimHand = game.privateView(operation.victim.seat)?.hand;
    const victimTotal = victimHand
      ? RESOURCES.reduce((sum, resource) => sum + (victimHand[resource] ?? 0), 0)
      : -1;
    const expected = victimHand ? selectedResource(victimHand, operation.index) : null;
    if (!expected || victimTotal !== operation.handSize)
      return failure('audit-steal-index', 'Frozen index differs from the omniscient victim hand');
    const master = masters.get(operation.thief.seat);
    const owner = genesis.seats.find((seat) => seat.seat === operation.thief.seat);
    if (!master || !owner)
      return failure('audit-steal-master', 'Original thief master is unavailable');
    const source = createStealSecretSource(
      master,
      genesis.ceremonyNonce,
      operation.thief.seat,
      owner.publicKey,
    );
    try {
      const opened = openStealContribution(
        operation,
        fixed.contribution,
        source.encryptionSecret(),
        fixed.signer,
      );
      if (!opened.ok) return opened;
      if (opened.value.resource !== expected)
        return failure(
          'audit-steal-resource',
          'Certified transfer differs from the frozen victim card',
        );
      return success({
        [operation.thief.seat]: { resource: expected },
        [operation.victim.seat]: { resource: expected },
      });
    } finally {
      source.dispose();
    }
  }
  return success({});
}

/** Reconstruct a finished certified game without treating bad reveal input as an accusation. */
export function auditCertifiedGame(input: AuditCertifiedGameInput): AuditReport {
  const violations: AuditViolation[] = [];
  const inputErrors: AuditInputError[] = [];
  const masters = new Map<Seat, Uint8Array>();
  let terminal: AuditEntryRef | null = null;
  let finalHead: AuditEntryRef | null = null;
  let historyError: { code: string } | null = null;
  let auditError: AuditReport['auditError'] = null;
  let finalHiddenVictoryPoints: AuditReport['finalHiddenVictoryPoints'] = null;
  let cheatFindings: AuditReport['cheatFindings'] = [];
  let missingSeats: Seat[] = [];
  let complete = false;
  const report = (): AuditReport => ({
    ok:
      complete &&
      violations.length === 0 &&
      inputErrors.length === 0 &&
      !historyError &&
      !auditError,
    complete,
    missingSeats,
    violations,
    inputErrors,
    cheatFindings,
    terminal,
    finalHead,
    historyError,
    auditError,
    finalHiddenVictoryPoints,
  });
  const processingFailure = (seq: number, code: string): AuditReport => {
    auditError = { seq, code };
    complete = false;
    return report();
  };
  try {
    const publicReplay = replayCertifiedPrefix(
      input.genesisEntry,
      input.entries,
      input.engine,
      input.policy,
      (entry, next) => {
        if (!terminal && next.log.state.result) terminal = ref(entry.entry);
        return success(undefined);
      },
    );
    if (!publicReplay.ok) {
      historyError = { code: publicReplay.error.code };
      return report();
    }
    const { context } = publicReplay.value;
    const { genesis, crypto } = context.log;
    finalHead = ref(context.log.head);
    cheatFindings = crypto?.cheats.slice(0, MAX_DIAGNOSTICS) ?? [];
    if (!terminal || !context.log.state.result) return report();
    if (genesis.security !== 'verified' || !crypto) {
      historyError = { code: 'audit-unverified-game' };
      return report();
    }
    if (!Array.isArray(input.masters)) {
      inputErrors.push({ seat: null, kind: 'master-list' });
      return report();
    }
    const seats = new Set(genesis.seats.map((seat) => seat.seat));
    const seen = new Set<Seat>();
    for (const reveal of input.masters) {
      if (!reveal || !seats.has(reveal.seat) || seen.has(reveal.seat)) {
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat: null, kind: 'master-seat-or-duplicate' });
        continue;
      }
      seen.add(reveal.seat);
      if (!(reveal.master instanceof Uint8Array) || reveal.master.length !== 32) {
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat: reveal.seat, kind: 'master-scalar' });
        continue;
      }
      const copy = reveal.master.slice();
      try {
        scalarFromBytes(copy, { nonzero: true });
      } catch {
        copy.fill(0);
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat: reveal.seat, kind: 'master-scalar' });
        continue;
      }
      masters.set(reveal.seat, copy);
    }
    missingSeats = genesis.seats.map((seat) => seat.seat).filter((seat) => !masters.has(seat));
    for (const [seat, master] of masters) {
      const verified = verifyRevealedMaster(genesis, crypto.decks, seat, toBase64Url(master));
      if (verified.ok) continue;
      if (verified.error.code === 'master-public-key' || verified.error.code === 'master-reveal') {
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat, kind: verified.error.code });
      } else if (
        [
          'master-encryption-key',
          'master-beacon-tip',
          'master-shuffle-key',
          'master-lock-key',
        ].includes(verified.error.code)
      ) {
        violations.push(issue(0, seat, verified.error.code));
      } else return processingFailure(0, verified.error.code);
    }
    complete = missingSeats.length === 0 && inputErrors.length === 0;
    if (!complete || violations.length) return report();

    const initial = initialProposalContext(input.genesisEntry, input.engine, input.policy);
    if (!initial.ok) {
      historyError = { code: initial.error.code };
      return report();
    }
    const recorded = LocalGame.createRecorded(
      input.engine,
      genesis.config,
      fromBase64Url(genesis.genesisSeed),
    );
    if (!recorded.ok) {
      return processingFailure(0, recorded.error.code);
    }
    const game = recorded.value;
    if (toHex(hashValue(game.state)) !== initial.value.log.head.stateHash) {
      return processingFailure(0, 'audit-genesis-state');
    }
    const privateHashes = new Map<number, ReadonlyMap<Seat, string>>();
    const rememberPrivateHashes = (seq: number): Result<void> => {
      const hashes = new Map<Seat, string>();
      for (const seat of genesis.config.seats) {
        const privateState = game.privateView(seat);
        if (!privateState)
          return failure(
            'audit-omniscient-private-missing',
            'Omniscient private state is missing',
            {
              seq,
            },
          );
        hashes.set(seat, toHex(hashValue(privateState)));
      }
      privateHashes.set(seq, hashes);
      return success(undefined);
    };
    const initialPrivateHashes = rememberPrivateHashes(initial.value.log.head.seq);
    if (!initialPrivateHashes.ok) return processingFailure(0, initialPrivateHashes.error.code);
    let prior = initial.value;
    let failureSeq = 0;
    let failureSeat: Seat | null = null;
    const privateReplay = replayCertifiedPrefix(
      input.genesisEntry,
      publicReplay.value.entries,
      input.engine,
      input.policy,
      (entry, next) => {
        failureSeq = entry.entry.seq;
        const recordedInput = entry.input;
        if (recordedInput) {
          failureSeat = null;
          try {
            const data = privateDataFor(recordedInput, prior, next, game, masters, genesis);
            if (!data.ok) {
              // Only this mismatch identifies the signer of the fixed hidden transfer.
              // A draw failure does not prove misconduct by the receiving player.
              if (data.error.code === 'audit-steal-resource' && recordedInput.kind === 'system')
                failureSeat = isSeat(recordedInput.victim) ? recordedInput.victim : null;
              return data;
            }
            const applied = game.applyRecorded(recordedInput, data.value);
            if (!applied.ok) return applied;
          } catch {
            return failure('audit-private-input', 'Could not reconstruct certified private input');
          }
        }
        if (
          toHex(hashValue(game.state)) !== next.log.head.stateHash ||
          toHex(hashValue(game.state)) !== toHex(hashValue(next.log.state))
        )
          return failure('audit-state-hash', 'Omniscient state differs from the certified state');
        prior = next;
        return rememberPrivateHashes(entry.entry.seq);
      },
    );
    if (!privateReplay.ok) {
      if (
        [
          'driver-error',
          'audit-private-input',
          'audit-state-hash',
          'audit-omniscient-private-missing',
          'audit-draw-context',
          'audit-draw-seat',
          'audit-steal-context',
          'audit-steal-master',
          'steal-recipient-key',
          'deck-owner-lock',
          'missing-private-state',
        ].includes(privateReplay.error.code)
      )
        return processingFailure(failureSeq, privateReplay.error.code);
      violations.push(issue(failureSeq, failureSeat, privateReplay.error.code));
      complete = true;
      return report();
    }
    if (toHex(hashValue(game.state.result)) !== toHex(hashValue(context.log.state.result))) {
      return processingFailure((terminal as AuditEntryRef).seq, 'audit-terminal-result');
    }
    const crossCheck = reconstructPrivateSeats({
      genesisEntry: input.genesisEntry,
      entries: publicReplay.value.entries,
      engine: input.engine,
      policy: input.policy,
      secrets: [...masters].map(([seat, master]) => ({ seat, master })),
      verifyPrivateState(seq, states) {
        const expected = privateHashes.get(seq);
        if (
          !expected ||
          states.size !== expected.size ||
          [...states].some(([seat, state]) => toHex(hashValue(state)) !== expected.get(seat))
        )
          return failure(
            'audit-private-state',
            'Reconstructed private state differs from the omniscient replay',
            { seq },
          );
        return success(undefined);
      },
    });
    if (!crossCheck.ok) {
      const details = crossCheck.error.details;
      const seq =
        details &&
        typeof details === 'object' &&
        'seq' in details &&
        typeof details.seq === 'number'
          ? details.seq
          : context.log.head.seq;
      if (
        [
          'private-replay-failed',
          'private-replay-beacon',
          'crypto-context-required',
          'verified-private-missing',
          'audit-private-state',
        ].includes(crossCheck.error.code)
      )
        return processingFailure(seq, crossCheck.error.code);
      violations.push(issue(seq, null, crossCheck.error.code));
    } else {
      crossCheck.value.dispose();
      const counts: Partial<Record<Seat, number>> = {};
      for (const seat of genesis.config.seats) {
        const privateState = game.privateView(seat);
        const publicSeat = game.state.seats.find((item) => item.seat === seat);
        if (!privateState || !publicSeat)
          return processingFailure(context.log.head.seq, 'audit-final-private-state');
        counts[seat] = publicSeat.cardSlots.filter(
          (slot) => !slot.revealed && privateState.slots[slot.slotId] === 'victoryPoint',
        ).length;
      }
      finalHiddenVictoryPoints = counts;
    }
    complete = true;
    return report();
  } catch {
    return processingFailure(finalHead?.seq ?? 0, 'audit-internal-failure');
  } finally {
    for (const master of masters.values()) master.fill(0);
  }
}


### PRIOR COMMITTED packages/protocol/src/private-replay.ts
import { toBase64Url } from '@cp2p/codec';
import { scalarFromBytes } from '@cp2p/crypto';
import { failure, success } from '@cp2p/engine';
import type { Engine, PrivateState, Result, Seat } from '@cp2p/engine';
import { createBeaconSecretSource } from './beacon-source.js';
import type { BeaconSecretProvider } from './beacon-source.js';
import { deckCeremonyId } from './deck-genesis.js';
import { createDeckSecretSource } from './deck-source.js';
import { genesisDigest } from './genesis.js';
import { verifyRevealedMaster } from './genesis-secrets.js';
import { createHandSecretSource } from './hand-source.js';
import type { ProposalContext } from './proposal.js';
import { initialProposalContext, replayCertifiedPrefix } from './replay.js';
import type { ReplayPolicy } from './replay.js';
import { createStealSecretSource } from './steal-source.js';
import { VerifiedSessionDriver } from './verified-session-driver.js';

export interface ReconstructedPrivateSeats {
  readonly context: ProposalContext;
  /** Contains only requested seats and checks their public openings after every entry. */
  readonly driver: VerifiedSessionDriver;
  /** Relinquish one owned seat without discarding other reconstructed seats. */
  releaseSeat(seat: Seat): void;
  /** Disposes the driver and clears its retained master copies. */
  dispose(): void;
}

/**
 * Reconstruct already-owned or authorized-revealed seats from certified history.
 * This does not request secrets, authorize disclosure, activate controllers or
 * constitute a complete game audit. The caller must establish the right to use
 * every supplied master before invoking it. Deck setup must be fully certified.
 * No partially rebuilt hand is returned.
 */
export function reconstructPrivateSeats(input: {
  readonly genesisEntry: unknown;
  readonly entries: readonly unknown[];
  readonly engine: Engine;
  readonly policy: ReplayPolicy;
  readonly secrets: readonly { readonly seat: Seat; readonly master: Uint8Array }[];
  /** Independent check of detached snapshots, provisional until the entire replay succeeds. */
  readonly verifyPrivateState?: (
    seq: number,
    states: ReadonlyMap<Seat, PrivateState>,
  ) => Result<void>;
}): Result<ReconstructedPrivateSeats> {
  const masters = new Map<Seat, Uint8Array>();
  const beacons = new Map<Seat, { length: number; provider: BeaconSecretProvider }>();
  let driver: VerifiedSessionDriver | undefined;
  let retained = false;
  const releaseSeat = (seat: Seat) => {
    driver?.relinquishSeats([seat]);
    const master = masters.get(seat);
    master?.fill(0);
    masters.delete(seat);
    const beacon = beacons.get(seat);
    beacon?.provider.dispose();
    beacons.delete(seat);
  };
  const dispose = () => {
    for (const seat of masters.keys()) releaseSeat(seat);
    driver?.dispose();
  };
  try {
    if (!Array.isArray(input.secrets) || input.secrets.length < 1 || input.secrets.length > 6)
      return failure('private-replay-seats', 'Supply one through six distinct owned seat secrets');
    for (const { seat, master } of input.secrets) {
      if (
        !Number.isSafeInteger(seat) ||
        seat < 0 ||
        seat > 5 ||
        masters.has(seat) ||
        !(master instanceof Uint8Array) ||
        master.length !== 32
      )
        return failure('private-replay-secrets', 'Seat secrets are malformed or duplicated');
      const copy = new Uint8Array(master);
      masters.set(seat, copy);
      scalarFromBytes(copy, { nonzero: true });
    }

    // Authenticate the whole supplied branch before reporting any secret mismatch.
    // A corrupt imported certificate must not be attributed to a departed owner.
    const publicReplay = replayCertifiedPrefix(
      input.genesisEntry,
      input.entries,
      input.engine,
      input.policy,
    );
    if (!publicReplay.ok)
      return failure('private-replay-history', 'Certified history could not be verified', {
        reason: publicReplay.error.code,
      });
    const { genesis, crypto } = publicReplay.value.context.log;
    if (genesis.security !== 'verified' || !crypto)
      return failure('private-replay-security', 'Private reconstruction requires verified history');
    for (const [seat, master] of masters) {
      const verified = verifyRevealedMaster(genesis, crypto.decks, seat, master);
      if (!verified.ok) return verified;
    }
    const initial = initialProposalContext(input.genesisEntry, input.engine, input.policy);
    if (!initial.ok) return initial;
    const initialBeacon = initial.value.log.crypto?.beacon;
    if (!initialBeacon)
      return failure('private-replay-beacon', 'Verified genesis has no beacon state');
    const ceremonyId = deckCeremonyId(genesis);
    for (const chain of initialBeacon.chains) {
      const master = masters.get(chain.seat);
      if (master)
        beacons.set(chain.seat, {
          length: chain.length,
          provider: createBeaconSecretSource(
            master,
            { ceremonyId, seat: chain.seat },
            chain.length,
          ),
        });
    }
    const getMaster = (seat: Seat): Uint8Array => {
      const master = masters.get(seat);
      if (!master) throw new Error('Seat is not owned by this private replay');
      return master;
    };
    driver = new VerifiedSessionDriver(
      input.engine,
      genesis,
      [...masters.keys()],
      (deckId, seat) => {
        const deck = crypto.decks.decks.find(
          (item) => item.commitment.definition.deckId === deckId,
        );
        if (!deck) throw new Error('Private replay deck is not in certified genesis');
        return createDeckSecretSource(getMaster(seat), deck.commitment.definition, seat);
      },
      (seat) => createHandSecretSource(getMaster(seat), genesisDigest(genesis), seat),
      (seat) => {
        const owner = genesis.seats.find((item) => item.seat === seat);
        if (!owner) throw new Error('Private replay seat is not in certified genesis');
        return createStealSecretSource(
          getMaster(seat),
          genesis.ceremonyNonce,
          seat,
          owner.publicKey,
        );
      },
    );
    const activeDriver = driver;
    const verifyPrivateState = (seq: number): Result<void> => {
      if (!input.verifyPrivateState) return success(undefined);
      const states = new Map<Seat, PrivateState>();
      for (const seat of masters.keys()) {
        const state = activeDriver.privateState(seat);
        if (!state)
          return failure('verified-private-missing', 'Owned private state is missing', { seq });
        states.set(seat, state);
      }
      return input.verifyPrivateState(seq, states);
    };
    const initialPrivateCheck = verifyPrivateState(initial.value.log.head.seq);
    if (!initialPrivateCheck.ok) return initialPrivateCheck;
    let prior = initial.value;
    const rebuilt = replayCertifiedPrefix(
      input.genesisEntry,
      publicReplay.value.entries,
      input.engine,
      input.policy,
      (entry, next) => {
        const beacon = next.log.crypto?.beacon;
        if (!beacon) return failure('private-replay-beacon', 'Certified beacon state is missing');
        for (const chain of beacon.chains) {
          let source = beacons.get(chain.seat);
          if (!source) continue;
          if (source.length !== chain.length) {
            source.provider.dispose();
            source = {
              length: chain.length,
              provider: createBeaconSecretSource(
                getMaster(chain.seat),
                { ceremonyId, seat: chain.seat },
                chain.length,
              ),
            };
            beacons.set(chain.seat, source);
          }
          const expected =
            chain.index > 0
              ? source.provider.source.link(chain.chainEpoch, chain.index)
              : chain.chainEpoch === 0
                ? source.provider.initialCommitment.tip
                : source.provider.source.extension(chain.chainEpoch).tip;
          try {
            if (toBase64Url(expected) !== chain.tip)
              return failure(
                'master-beacon-history',
                'Master does not reproduce a certified beacon link',
                {
                  seat: chain.seat,
                  seq: entry.entry.seq,
                },
              );
          } finally {
            expected.fill(0);
          }
        }
        const applied = activeDriver.committedEntry(entry, prior.log, next.log);
        if (!applied.ok) return applied;
        const checked = verifyPrivateState(entry.entry.seq);
        if (!checked.ok) return checked;
        prior = next;
        return success(undefined);
      },
    );
    if (!rebuilt.ok) return rebuilt;
    // Chain sources are needed only for historical checks, not subsequent hand proofs.
    for (const source of beacons.values()) source.provider.dispose();
    beacons.clear();
    retained = true;
    return success({ context: rebuilt.value.context, driver: activeDriver, releaseSeat, dispose });
  } catch {
    return failure('private-replay-failed', 'Could not reconstruct the requested private seats');
  } finally {
    if (!retained) dispose();
  }
}


### PRIOR COMMITTED packages/protocol/src/replay.ts
import { canonicalDecode, canonicalEncode, hashValue, toHex } from '@cp2p/codec';
import { failure, success } from '@cp2p/engine';
import type { Engine, GameEvent, Input, Result } from '@cp2p/engine';
import { entryHash, genesisDigest, validateGenesisEntry } from './genesis.js';
import { ownImmutableGenesis } from './genesis-identity.js';
import { objectiveEvidenceSeq, validateObjectiveAccusation } from './control.js';
import { initializeCryptoContext } from './crypto-context.js';
import type { GenesisPolicy } from './genesis.js';
import type { ValidatedEntry } from './log.js';
import { advanceContext, proposerFor, validateCertifiedEntry } from './proposal.js';
import type { CertifiedEntry, ProposalContext } from './proposal.js';
import { authenticatedCheatSigner, verifyCheatProof } from './cheat-proof.js';
import type { CheatFinding } from './cheat-proof.js';
import { initialSeatAuthorities } from './authority.js';
import { initialTransferState } from './transfer-readiness.js';
import { advanceTimerAnchors } from './turn-timeout.js';

const MAX_HISTORICAL_CONTEXTS = 16;

export interface ReplayPolicy {
  genesis: GenesisPolicy;
  entry: ProposalContext['policy'];
}

export interface ReplayedPrefix {
  context: ProposalContext;
  entries: CertifiedEntry[];
  inputs: Input[];
  events: GameEvent[];
}

/** Genesis signatures establish the first voter set; transport peers have no say. */
export function initialProposalContext(
  genesisEntry: unknown,
  engine: Engine,
  policy: ReplayPolicy,
): Result<ProposalContext> {
  const checked = validateGenesisEntry(genesisEntry, engine, policy.genesis);
  if (!checked.ok) return checked;
  const { state, entry } = checked.value;
  const genesis = ownImmutableGenesis(checked.value.genesis);
  const authority = initialSeatAuthorities(genesis);
  if (!authority.ok) return authority;
  const transfer =
    genesis.security === 'verified' ? initialTransferState(genesis, entry) : success(undefined);
  if (!transfer.ok) return transfer;
  const crypto = initializeCryptoContext(
    genesis,
    engine,
    state,
    entry,
    policy.entry.randomDerivations,
    authority.value,
  );
  if (!crypto.ok) return crypto;
  const timers = advanceTimerAnchors(engine, state, entry);
  if (!timers.ok) return timers;
  return success({
    log: {
      genesis,
      engine,
      state,
      head: entry,
      lastNonces: new Map(),
      crypto: crypto.value,
      timers: timers.value,
      authority: authority.value,
      recovery: { authorizations: [], pending: null, offline: [], completed: [], void: null },
      ...(transfer.value ? { transfer: transfer.value } : {}),
    },
    membership: {
      genesisDigest: genesisDigest(genesis),
      epoch: 0,
      voters: genesis.seats
        .filter((seat) => seat.kind === 'human')
        .map(({ seat, publicKey }) => ({ seat, publicKey })),
    },
    excludedProposers: [],
    policy: policy.entry,
  });
}

/** Replay certificates in order. A claimed snapshot never supplies voter or nonce state. */
export function replayCertifiedPrefix(
  genesisEntry: unknown,
  entries: readonly unknown[],
  engine: Engine,
  policy: ReplayPolicy,
  onEntry?: (entry: ValidatedEntry & CertifiedEntry, next: ProposalContext) => Result<void>,
): Result<ReplayedPrefix> {
  return replayCertifiedPrefixWithCache(genesisEntry, entries, engine, policy, new Map(), onEntry);
}

/** Successful findings are shared only within this certified ancestry. */
function replayCertifiedPrefixWithCache(
  genesisEntry: unknown,
  entries: readonly unknown[],
  engine: Engine,
  policy: ReplayPolicy,
  verifiedFindings: Map<string, CheatFinding>,
  onEntry?: (entry: ValidatedEntry & CertifiedEntry, next: ProposalContext) => Result<void>,
): Result<ReplayedPrefix> {
  const initial = initialProposalContext(genesisEntry, engine, policy);
  if (!initial.ok) return initial;
  const certified: CertifiedEntry[] = [];
  const historical = new Map<number, ProposalContext>();
  const cheatHistorical = new Map<number, ProposalContext>();
  const controllerTimeline = [
    {
      atSeq: 0,
      authority: initial.value.log.authority,
      epoch: initial.value.log.crypto?.epoch ?? initial.value.log.authority?.epoch ?? 0,
    },
  ];
  let context: ProposalContext = {
    ...initial.value,
    verifyHistoricalCheat: (claim) => {
      const atSeq = claim.evidence.at.seq;
      if (atSeq > certified.length)
        return failure('cheat-history', 'Certified evidence parent is unavailable');
      const parentEntry = atSeq === 0 ? initial.value.log.head : certified[atSeq - 1]?.entry;
      if (!parentEntry || claim.evidence.at.hash !== entryHash(parentEntry))
        return failure('cheat-history', 'Certified evidence parent hash does not match');
      const parentAuthority = controllerTimeline.findLast((item) => item.atSeq <= atSeq);
      if (
        !parentAuthority ||
        !authenticatedCheatSigner(
          claim,
          initial.value.log.genesis,
          parentAuthority.authority,
          parentAuthority.epoch,
        )
      )
        return failure('cheat-signature', 'Cheat evidence has no authenticated controller');
      const key = toHex(hashValue({ domain: 'cp2p/v1/cheat-claim-cache', claim }));
      const previous = verifiedFindings.get(key);
      if (previous) return success(previous);
      let parent = cheatHistorical.get(atSeq);
      if (!parent) {
        const replayed = replayCertifiedPrefixWithCache(
          genesisEntry,
          certified.slice(0, atSeq),
          engine,
          policy,
          verifiedFindings,
        );
        if (!replayed.ok) return replayed;
        parent = replayed.value.context;
      }
      cheatHistorical.delete(atSeq);
      cheatHistorical.set(atSeq, parent);
      if (cheatHistorical.size > MAX_HISTORICAL_CONTEXTS) {
        const oldest = cheatHistorical.keys().next().value;
        if (oldest !== undefined) cheatHistorical.delete(oldest);
      }
      return verifyCheatProof(claim, parent.log);
    },
    verifyHistoricalAccusation: (control) => {
      const atSeq = objectiveEvidenceSeq(control);
      if (atSeq < 1 || atSeq - 1 > certified.length)
        return failure('control-history', 'Certified evidence parent is unavailable');
      let parent = historical.get(atSeq);
      if (!parent) {
        const replayed = replayCertifiedPrefixWithCache(
          genesisEntry,
          certified.slice(0, atSeq - 1),
          engine,
          policy,
          verifiedFindings,
        );
        if (!replayed.ok) return replayed;
        parent = replayed.value.context;
      }
      // Pending proofs and round hints can reference different certified parents.
      // Keep recent parents together without retaining the whole game state history.
      historical.delete(atSeq);
      historical.set(atSeq, parent);
      if (historical.size > MAX_HISTORICAL_CONTEXTS) {
        const oldest = historical.keys().next().value;
        if (oldest !== undefined) historical.delete(oldest);
      }
      const checked = validateObjectiveAccusation(control, {
        log: parent.log,
        commandPolicy: parent.policy,
        membership: parent.membership,
        excludedProposers: parent.excludedProposers,
        proposerFor: (seq, term) =>
          proposerFor(seq, term, parent.membership, parent.excludedProposers),
      });
      return checked.ok ? success(entryHash(parent.log.head)) : checked;
    },
  };
  const inputs: Input[] = [];
  const events: GameEvent[] = [];
  for (const entry of entries) {
    const checked = validateCertifiedEntry(entry, context);
    if (!checked.ok) return checked;
    const next = checked.value;
    if (next.entry.payload.kind === 'cheat-proof') {
      const claim = next.entry.payload.claim;
      const finding = next.crypto?.cheats.find(
        (item) => item.seat === claim.seat && item.kind === claim.evidence.kind,
      );
      if (!finding)
        return failure('cheat-replay', 'Certified cheat record has no replayed finding');
      verifiedFindings.set(
        toHex(hashValue({ domain: 'cp2p/v1/cheat-claim-cache', claim })),
        finding,
      );
    }
    certified.push({ entry: next.entry, certificate: next.certificate });
    if (next.input !== null) inputs.push(next.input);
    events.push(...next.events);
    const advanced = advanceContext(context, next);
    if (!advanced.ok) return advanced;
    if (advanced.value.log.authority !== context.log.authority) {
      controllerTimeline.push({
        atSeq: next.entry.seq,
        authority: advanced.value.log.authority,
        epoch: advanced.value.log.crypto?.epoch ?? advanced.value.log.authority?.epoch ?? 0,
      });
    }
    const visited = onEntry?.(next, advanced.value);
    if (visited && !visited.ok) return visited;
    context = advanced.value;
  }
  return success({ context, entries: certified, inputs, events });
}

/** A cache for display/load speed, always checked against the certified replay before voting. */
export function snapshotFromContext(context: ProposalContext) {
  return canonicalDecode(
    canonicalEncode({
      genesisDigest: context.membership.genesisDigest,
      seq: context.log.head.seq,
      hash: entryHash(context.log.head),
      state: context.log.state,
      crypto: context.log.crypto,
      authority: context.log.authority ?? null,
      recovery: context.log.recovery ?? null,
      transfer: context.log.transfer ?? null,
      timers: context.log.timers ?? [],
      lastNonces: [...context.log.lastNonces].toSorted(([a], [b]) => a - b),
      membership: context.membership,
      excludedProposers: context.excludedProposers,
    }),
  );
}

export function verifyReplaySnapshot(value: unknown, context: ProposalContext): Result<void> {
  try {
    return toHex(hashValue(value)) === toHex(hashValue(snapshotFromContext(context)))
      ? success(undefined)
      : failure('snapshot-mismatch', 'Snapshot differs from the certified replay');
  } catch {
    return failure('snapshot-malformed', 'Snapshot is not canonical data');
  }
}

Captured terminal excerpts from tool responses; complete stdout was not redirected during these runs. No fixture state or secret output is included.

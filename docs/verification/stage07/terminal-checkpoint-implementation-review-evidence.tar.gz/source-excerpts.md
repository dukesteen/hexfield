
## `packages/protocol/src/master-reveal.ts`


### Terminal types, private source map, factory, and standalone full-replay path (lines 65-145)

```ts
65:   readonly store: MasterRevealStore;
66:   /** Returns a fresh owned copy. Called only for a still-original local host. */
67:   readonly loadOwnedMaster: (seat: Seat) => Promise<Uint8Array | null>;
68:   /** Previously certified private recovery record for a recovered original seat. */
69:   readonly recoveryPrivateStore?: RecoveryPrivateStore;
70: }
71: /** Package-internal checkpoint. Only the replica's validated paths may supply it. */
72: export interface Terminal {
73:   readonly context: ProposalContext;
74:   readonly result: { readonly seq: number; readonly hash: string };
75:   readonly head: { readonly seq: number; readonly hash: string };
76:   readonly genesisHash: string;
77: }
78: const liveTerminalSources = new WeakMap<MasterRevealCoordinator, () => Promise<Result<Terminal>>>();
79: 
80: /** Internal replica adapter; deliberately absent from the package exports. */
81: export function createLiveMasterRevealCoordinator(
82:   options: MasterRevealOptions,
83:   readVerifiedTerminal: () => Promise<Result<Terminal>>,
84: ): MasterRevealCoordinator {
85:   const coordinator = new MasterRevealCoordinator(options);
86:   liveTerminalSources.set(coordinator, readVerifiedTerminal);
87:   return coordinator;
88: }
89: function sameRef(a: { seq: number; hash: string }, b: { seq: number; hash: string }): boolean {
90:   return a.seq === b.seq && a.hash === b.hash;
91: }
92: function sameBytes(a: Uint8Array, b: Uint8Array): boolean {
93:   return a.length === b.length && a.every((byte, i) => byte === b[i]);
94: }
95: function copyPacket(packet: SignedMasterReveal): SignedMasterReveal {
96:   return v.parse(signedMasterRevealSchema, canonicalDecode(canonicalEncode(packet)));
97: }
98: function acceptedId(result: Terminal['result'], genesis: string, seat: Seat): string {
99:   return `master-reveal/accepted/${genesis}/${result.seq}-${result.hash}/${seat}`;
100: }
101: 
102: /** Replay the durable branch; the first result entry, not the latest control, scopes reveals. */
103: async function terminal(
104:   options: Pick<MasterRevealOptions, 'journal' | 'engine' | 'policy'>,
105:   cached?: Terminal,
106: ): Promise<Result<Terminal>> {
107:   try {
108:     const record = await options.journal.load();
109:     if (!record) return failure('master-reveal-journal', 'Certified journal is absent');
110:     const head = record.entries.at(-1)?.entry ?? record.genesis;
111:     if (record.height !== head.seq + 1 || record.entries.length !== head.seq)
112:       return failure('master-reveal-journal', 'Journal height disagrees with its certified prefix');
113:     const headRef = { seq: head.seq, hash: entryHash(head) };
114:     const genesisHash = entryHash(record.genesis);
115:     if (cached && sameRef(cached.head, headRef) && cached.genesisHash === genesisHash)
116:       return success(cached);
117:     let first: Terminal['result'] | null = null;
118:     const replayed = replayCertifiedPrefix(
119:       record.genesis,
120:       record.entries,
121:       options.engine,
122:       options.policy,
123:       (entry, next) => {
124:         if (!first && next.log.state.result !== null)
125:           first = { seq: entry.entry.seq, hash: entryHash(entry.entry) };
126:         return success(undefined);
127:       },
128:     );
129:     if (!replayed.ok) return replayed;
130:     if (!first || replayed.value.context.log.state.result === null)
131:       return failure('master-reveal-unfinished', 'A certified engine result is required');
132:     return success({
133:       context: replayed.value.context,
134:       result: first,
135:       head: headRef,
136:       genesisHash,
137:     });
138:   } catch {
139:     return failure('master-reveal-journal', 'Could not read or replay certified journal');
140:   }
141: }
142: 
143: function publisher(
144:   context: ProposalContext,
145:   originalSeat: Seat,
```


### Coordinator terminal selection and historical accepted-receipt replay (lines 255-430)

```ts
255:   }
256:   const verdict = checkMaster(packet, context);
257:   return verdict.ok ? success({ packet, verdict: verdict.value }) : verdict;
258: }
259: 
260: /** Caller serializes prepare/receive with journal commits and holds its writer lease through send enqueue. */
261: export class MasterRevealCoordinator {
262:   private disposed = false;
263:   private terminalCache: Terminal | undefined;
264:   private readonly quarantined = new Map<Seat, string>();
265:   private readonly accepted = new Map<
266:     Seat,
267:     {
268:       packet: SignedMasterReveal;
269:       verdict: MasterRevealVerdict;
270:       master: Uint8Array;
271:       head: Terminal['head'];
272:     }
273:   >();
274:   constructor(private readonly options: MasterRevealOptions) {}
275:   private async terminal(): Promise<Result<Terminal>> {
276:     if (this.disposed) return failure('master-reveal-disposed', 'Reveal coordinator is closed');
277:     const live = liveTerminalSources.get(this);
278:     const loaded = live ? await live() : await terminal(this.options, this.terminalCache);
279:     if (this.disposed) return failure('master-reveal-disposed', 'Reveal coordinator is closed');
280:     if (loaded.ok) this.terminalCache = loaded.value;
281:     else this.terminalCache = undefined;
282:     return loaded;
283:   }
284:   async eligibleSeats(): Promise<Result<readonly Seat[]>> {
285:     const loaded = await this.terminal();
286:     if (!loaded.ok) return loaded;
287:     return success(
288:       loaded.value.context.log.genesis.seats
289:         .filter(({ seat }) => publisher(loaded.value.context, seat, this.options.localSeat).ok)
290:         .map(({ seat }) => seat),
291:     );
292:   }
293:   async metadata(): Promise<
294:     Result<{ result: Terminal['result']; head: Terminal['head']; accepted: readonly Seat[] }>
295:   > {
296:     const loaded = await this.terminal();
297:     return loaded.ok
298:       ? success({
299:           result: { ...loaded.value.result },
300:           head: { ...loaded.value.head },
301:           accepted: [...this.accepted.keys()],
302:         })
303:       : loaded;
304:   }
305:   /** Reauthenticate each durable receipt at the certified head where it was accepted. */
306:   async restoreAccepted(): Promise<Result<void>> {
307:     const latest = await this.terminal();
308:     if (!latest.ok) return latest;
309:     const { context, result, head, genesisHash } = latest.value;
310:     const genesis = genesisDigest(context.log.genesis);
311:     const saved: v.InferOutput<typeof acceptedRevealSchema>[] = [];
312:     const quarantined = new Map<Seat, string>();
313:     try {
314:       for (const { seat } of context.log.genesis.seats) {
315:         // oxlint-disable-next-line eslint/no-await-in-loop -- Bounded by the six-seat genesis roster.
316:         const bytes = await this.options.store.load(acceptedId(result, genesis, seat));
317:         if (this.disposed) {
318:           bytes?.fill(0);
319:           return failure('master-reveal-disposed', 'Reveal coordinator is closed');
320:         }
321:         if (!bytes) continue;
322:         try {
323:           const parsed = parseCanonical(canonicalDecode(bytes), acceptedRevealSchema);
324:           if (!parsed.ok || !sameBytes(canonicalEncode(parsed.value), bytes)) {
325:             quarantined.set(seat, 'master-reveal-accepted');
326:             continue;
327:           }
328:           if (
329:             parsed.value.packet.body.originalSeat !== seat ||
330:             parsed.value.packet.body.genesisDigest !== genesis ||
331:             !sameRef(parsed.value.packet.body.result, result) ||
332:             parsed.value.receivedAt.seq < result.seq ||
333:             parsed.value.receivedAt.seq > head.seq
334:           ) {
335:             quarantined.set(seat, 'master-reveal-scope');
336:             continue;
337:           }
338:           saved.push(parsed.value);
339:         } catch {
340:           quarantined.set(seat, 'master-reveal-accepted');
341:         } finally {
342:           bytes.fill(0);
343:         }
344:       }
345:       if (saved.length === 0) {
346:         for (const { master } of this.accepted.values()) master.fill(0);
347:         this.accepted.clear();
348:         this.quarantined.clear();
349:         for (const [seat, code] of quarantined) this.quarantined.set(seat, code);
350:         return success(undefined);
351:       }
352:       const record = await this.options.journal.load();
353:       if (this.disposed) return failure('master-reveal-disposed', 'Reveal coordinator is closed');
354:       const recordHead = record?.entries.at(-1)?.entry ?? record?.genesis;
355:       if (
356:         !record ||
357:         !recordHead ||
358:         !sameRef(head, { seq: recordHead.seq, hash: entryHash(recordHead) })
359:       )
360:         return failure('master-reveal-stale', 'Certified journal advanced during accepted restore');
361:       const wanted = new Map(saved.map((item) => [item.receivedAt.seq, item.receivedAt.hash]));
362:       const historical = new Map<number, Terminal>();
363:       const replayed = replayCertifiedPrefix(
364:         record.genesis,
365:         record.entries,
366:         this.options.engine,
367:         this.options.policy,
368:         (entry, next) => {
369:           if (wanted.get(entry.entry.seq) === entryHash(entry.entry))
370:             historical.set(entry.entry.seq, {
371:               context: next,
372:               result,
373:               head: { seq: entry.entry.seq, hash: entryHash(entry.entry) },
374:               genesisHash,
375:             });
376:           return success(undefined);
377:         },
378:       );
379:       if (!replayed.ok) return replayed;
380:       const accepted = new Map<
381:         Seat,
382:         {
383:           packet: SignedMasterReveal;
384:           verdict: MasterRevealVerdict;
385:           master: Uint8Array;
386:           head: Terminal['head'];
387:         }
388:       >();
389:       try {
390:         for (const item of saved) {
391:           const snapshot = historical.get(item.receivedAt.seq);
392:           if (!snapshot || !sameRef(snapshot.head, item.receivedAt)) {
393:             quarantined.set(item.packet.body.originalSeat, 'master-reveal-history');
394:             continue;
395:           }
396:           const checked = verifyMasterReveal(item.packet, snapshot);
397:           if (!checked.ok) {
398:             quarantined.set(item.packet.body.originalSeat, checked.error.code);
399:             continue;
400:           }
401:           const seat = checked.value.packet.body.originalSeat;
402:           accepted.set(seat, {
403:             packet: checked.value.packet,
404:             verdict: checked.value.verdict,
405:             master: fromBase64Url(checked.value.packet.body.master),
406:             head: item.receivedAt,
407:           });
408:         }
409:         const after = await this.terminal();
410:         if (!after.ok) return after;
411:         if (!sameRef(after.value.head, head))
412:           return failure(
413:             'master-reveal-stale',
414:             'Certified journal advanced during accepted restore',
415:           );
416:         for (const { master } of this.accepted.values()) master.fill(0);
417:         this.accepted.clear();
418:         for (const [seat, item] of accepted) this.accepted.set(seat, item);
419:         this.quarantined.clear();
420:         for (const [seat, code] of quarantined) this.quarantined.set(seat, code);
421:         accepted.clear();
422:         return success(undefined);
423:       } finally {
424:         for (const { master } of accepted.values()) master.fill(0);
425:       }
426:     } catch {
427:       if (this.disposed) return failure('master-reveal-disposed', 'Reveal coordinator is closed');
428:       return failure('master-reveal-accepted', 'Could not restore accepted reveals');
429:     }
430:   }
```


### Coordinator disposal (lines 610-628)

```ts
610:   quarantinedAccepted(): readonly { seat: Seat; code: string }[] {
611:     return [...this.quarantined].map(([seat, code]) => ({ seat, code }));
612:   }
613:   acceptedMasters(): readonly { seat: Seat; verdict: MasterRevealVerdict; master: Uint8Array }[] {
614:     return [...this.accepted].map(([seat, { verdict, master }]) => ({
615:       seat,
616:       verdict,
617:       master: master.slice(),
618:     }));
619:   }
620:   dispose(): void {
621:     if (this.disposed) return;
622:     this.disposed = true;
623:     for (const { master } of this.accepted.values()) master.fill(0);
624:     this.accepted.clear();
625:     this.quarantined.clear();
626:     this.terminalCache = undefined;
627:   }
628: }
```


## `packages/protocol/src/replicated-log.ts`


### Checkpoint fields and constructor policy/genesis binding (lines 250-410)

```ts
250: declare const structuredClone: <T>(value: T) => T;
251: 
252: /** Certified history plus one active, durable consensus height. */
253: export class ReplicatedLog {
254:   private controller: ConsensusController | null = null;
255:   private queue: Promise<unknown> = Promise.resolve();
256:   private readonly secretKey: Uint8Array;
257:   private readonly self: PeerId;
258:   private readonly genesisHash: string;
259:   private readonly matchesReplayPolicy: () => boolean;
260:   private readonly timers = new Map<string, unknown>();
261:   private readonly pending: PendingCommand[] = [];
262:   private membershipIntent: PendingMembership | null = null;
263:   private pendingRecoverySubmit: PendingMembership | null = null;
264:   private recoveryCandidateForApproval: RecoveryApprovalCandidate | null = null;
265:   private recoveryApproval: {
266:     parentHash: string;
267:     statementHash: string;
268:     generationHash: string;
269:   } | null = null;
270:   private recoveryApprovalRevision = 0;
271:   private readonly recoveryPresence = new Map<Seat, RecoveryPresenceObserver>();
272:   private pendingRecoveryProposal: SignedProposal | null = null;
273:   private readonly commands: SignedCommand[] = [];
274:   private readonly rejectedCommands = new Set<string>();
275:   private readonly rejectedProposals = new Set<string>();
276:   private readonly beaconInbox = new BeaconInbox();
277:   private recoveryParticipant: RecoveryParticipant | null = null;
278:   private masterRevealCoordinator: MasterRevealCoordinator | null = null;
279:   private firstResult: EntryRef | null = null;
280:   private terminalCheckpoint: Terminal | null = null;
281:   private masterRevealsRestored = false;
282:   private readonly acceptedMasterSeats = new Set<Seat>();
283:   private readonly localMasterReveals = new Map<
284:     Seat,
285:     { headHash: string; packet: SignedMasterReveal; verdict: MasterRevealVerdict }
286:   >();
287:   private readonly rejectedMasterReveals = new Set<string>();
288:   private readonly revealWorkByPeer = new Map<PeerId, { startedAt: number; seen: Set<string> }>();
289:   private readonly beaconSources = new Map<Seat, BeaconSecretSource>();
290:   private createDeckSource: DeckSourceFactory | undefined;
291:   private preparedRecovery: { headHash: string; packets: PreparedRecoveryPackets } | null = null;
292:   private recoverySendCursor = 0;
293:   private readonly sentRecoveryPackets = new Set<string>();
294:   private recoveryAdmissionScope: string | null = null;
295:   private recoveryCheckScope: string | null = null;
296:   private readonly recoveryReleasesByPeer = new Map<PeerId, Set<string>>();
297:   private readonly recoveryChecksByPeer = new Map<PeerId, Set<string>>();
298:   private readonly deckInbox = new DeckInbox();
299:   private readonly countInbox = new CountInbox();
300:   private readonly stealInbox = new StealInbox();
301:   private readonly deckSetupPasses: LocalConfiguration['passes'];
302:   private readonly deckKeys: LocalConfiguration['keys'];
303:   private readonly rejectedDeckContributions = new Set<string>();
304:   private readonly rejectedCountContributions = new Set<string>();
305:   private readonly rejectedStealMessages = new Set<string>();
306:   private readonly pendingTradeProofs = new Map<
307:     string,
308:     { request: SignedTradeProofRequest; ownerHost: PeerId }
309:   >();
310:   private readonly tradeProofResponses = new Map<
311:     string,
312:     { requestBytes: Uint8Array; responseBytes: Uint8Array; requester: PeerId }
313:   >();
314:   private readonly tradeProofRequestsByFinalizer = new Map<Seat, Set<string>>();
315:   private readonly tradeProofWorkByPeer = new Map<
316:     PeerId,
317:     { startedAt: number; seen: Set<string> }
318:   >();
319:   private sentStealStage: string | null = null;
320:   private preparedSteal: { readonly stage: string; readonly bytes: Uint8Array } | null = null;
321:   private readonly sentCountContributions = new Set<Seat>();
322:   private sentCountOperation: string | null = null;
323:   private preparedDeckPrefix: string | null = null;
324:   private sentDeckPrefix: string | null = null;
325:   private readonly sentBeaconOperations = new Set<string>();
326:   private readonly timerObserver: LocalTimerObserver;
327:   private timedVoteRetry: {
328:     parentHash: string;
329:     anchorHash: string;
330:     proposal: SignedProposal | null;
331:     handle: unknown;
332:   } | null = null;
333:   private accusation: ExcludeProposerControl | null = null;
334:   private readonly cheatCandidates = new Map<string, CheatClaim>();
335:   private readonly unsubscribers: Unsubscribe[] = [];
336:   private readonly queuedByPeer = new Map<PeerId, number>();
337:   private readonly invalidByPeer = new Map<PeerId, number>();
338:   private readonly blockedPeers = new Set<PeerId>();
339:   /** Only certified human generations may request a read-only catch-up after retirement. */
340:   private readonly historicalHumanPeers = new Set<PeerId>();
341:   private readonly expensiveByPeer = new Map<PeerId, { startedAt: number; seen: Set<string> }>();
342:   private readonly cheatWorkByPeer = new Map<PeerId, { startedAt: number; seen: Set<string> }>();
343:   private readonly historicalCheatWorkByPeer = new Map<
344:     PeerId,
345:     { startedAt: number; seen: Set<string> }
346:   >();
347:   private cheatGossipCursor = 0;
348:   private lastSyncRequest: { fromSeq: number; sentAt: number } | null = null;
349:   private queuedMessages = 0;
350:   private pulseTimer: unknown = null;
351:   private disposed = false;
352:   private contextCheckQueued = false;
353:   private controllerAnchor: {
354:     seq: number;
355:     hash: string;
356:     genesisDigest: string;
357:     voters: readonly string[];
358:     membership: VoteContext;
359:   } | null = null;
360:   private derivedRepair: {
361:     stopped: ConsensusController;
362:     anchor: NonNullable<ReplicatedLog['controllerAnchor']>;
363:     heldCommits: Map<string, CertifiedEntry>;
364:     lastRequestAt: number;
365:     replayed?: {
366:       context: ProposalContext;
367:       entries: CertifiedEntry[];
368:       snapshotHash: string;
369:       prefixHash: string;
370:       firstResult: EntryRef | null;
371:     };
372:   } | null = null;
373: 
374:   private constructor(
375:     private readonly options: ReplicatedLogOptions,
376:     private readonly genesisEntry: LogEntry,
377:     private context: ProposalContext,
378:     private entries: CertifiedEntry[],
379:     local: LocalConfiguration,
380:   ) {
381:     this.genesisHash = entryHash(genesisEntry);
382:     const { engine, policy } = options;
383:     const { genesis, entry } = policy;
384:     const { allowStub, verifyCommitments } = genesis;
385:     this.matchesReplayPolicy = () =>
386:       this.options === options &&
387:       options.engine === engine &&
388:       options.policy === policy &&
389:       policy.genesis === genesis &&
390:       policy.entry === entry &&
391:       genesis.allowStub === allowStub &&
392:       genesis.verifyCommitments === verifyCommitments;
393:     this.secretKey = local.signingKey;
394:     this.deckKeys = local.keys;
395:     this.deckSetupPasses = local.passes;
396:     this.createDeckSource = options.createDeckSource;
397:     this.timerObserver = new LocalTimerObserver(options.clock, context.log.timers ?? []);
398:     if (options.beaconSource) this.beaconSources.set(options.seat, options.beaconSource);
399:     for (const [seat, source] of options.beaconSources ?? []) this.beaconSources.set(seat, source);
400:     const identity = identityFromSecret(this.secretKey);
401:     this.self = identity.peerId;
402:     identity.secretKey.fill(0);
403:     this.refreshHistoricalHumanPeers();
404:   }
405: 
406:   static async create(options: ReplicatedLogOptions): Promise<Result<ReplicatedLog>> {
407:     const initial = initialProposalContext(options.genesisEntry, options.engine, options.policy);
408:     if (!initial.ok) return initial;
409:     const key = checkLocalKey(options, initial.value);
410:     if (!key.ok) return key;
```


### Full restore and first-result capture (lines 430-520)

```ts
430:     return ReplicatedLog.restore(options);
431:   }
432: 
433:   static async restore(options: ReplicatedLogOptions): Promise<Result<ReplicatedLog>> {
434:     let record: Awaited<ReturnType<ProtocolJournal['load']>>;
435:     try {
436:       record = await options.journal.load();
437:     } catch {
438:       return failure('replica-storage', 'Could not read the certified journal');
439:     }
440:     if (!record) return failure('replica-missing', 'Certified journal or safety state is missing');
441:     const requested = initialProposalContext(options.genesisEntry, options.engine, options.policy);
442:     if (!requested.ok) return requested;
443:     if (!sameBytes(canonicalEncode(requested.value.log.head), canonicalEncode(record.genesis)))
444:       return failure('replica-genesis', 'Requested genesis differs from the certified journal');
445:     let firstResult: EntryRef | null = null;
446:     const replayed = replayCertifiedPrefix(
447:       record.genesis,
448:       record.entries,
449:       options.engine,
450:       options.policy,
451:       (entry, next) => {
452:         if (!firstResult && next.log.state.result !== null)
453:           firstResult = { seq: entry.entry.seq, hash: entryHash(entry.entry) };
454:         return success(undefined);
455:       },
456:     );
457:     if (!replayed.ok) return replayed;
458:     const context = replayed.value.context;
459:     if (record.height !== context.log.head.seq + 1 || !record.safety)
460:       return failure('replica-journal', 'Certified prefix and active safety height disagree');
461:     let localPublicKey: string;
462:     try {
463:       const identity = identityFromSecret(options.secretKey);
464:       localPublicKey = identity.peerId;
465:       identity.secretKey.fill(0);
466:     } catch {
467:       return failure('replica-key', 'Local signing key is invalid');
468:     }
469:     if (
470:       !context.membership.voters.some(
471:         (voter) => voter.seat === options.seat && voter.publicKey === localPublicKey,
472:       )
473:     ) {
474:       let marker: unknown;
475:       try {
476:         marker = canonicalDecode(record.safety.bytes);
477:       } catch {
478:         return failure('replica-retirement', 'Retired signing record is malformed');
479:       }
480:       const checked = restoreRetiredSafety(marker, context, options.seat, localPublicKey);
481:       if (!checked.ok) return checked;
482:       return failure('replica-retired', 'This signing key was retired by certified membership');
483:     }
484:     const key = checkLocalKey(options, context);
485:     if (!key.ok) return key;
486:     const replica = new ReplicatedLog(
487:       options,
488:       record.genesis,
489:       context,
490:       replayed.value.entries,
491:       key.value,
492:     );
493:     replica.firstResult = firstResult;
494:     const opened = await replica.openController();
495:     if (!opened.ok) {
496:       replica.dispose();
497:       return opened;
498:     }
499:     const initialized = await replica.enqueue(async () => {
500:       const installed = await replica.installAuthorityOwnership();
501:       if (!installed.ok) return installed;
502:       const recovered = await replica.recoverPersistedAccusation();
503:       if (!recovered.ok) return recovered;
504:       const cheats = await replica.recoverCheatCandidates();
505:       if (!cheats.ok) return cheats;
506:       replica.attachTransport();
507:       replica.observeAllRecoveryPresence();
508:       replica.broadcastNextCheatClaim();
509:       const resumed = await replica.activeController().resume();
510:       if (!resumed.ok) return resumed;
511:       replica.mintTerminalCheckpoint();
512:       await replica.captureCertifiedDelivery();
513:       const offered = await replica.offerAvailableInput();
514:       if (!offered.ok) return offered;
515:       // A one-shot commit hint can arrive before restore attaches its listener.
516:       // Request the next certified height while an authenticated peer is present.
517:       return replica.requestSync(replica.context.log.head.seq + 1);
518:     });
519:     if (!initialized.ok) {
520:       replica.dispose();
```


### Full repair replay, safety restore, resume, and remint (lines 546-690)

```ts
546:   private async repairNow(snapshot?: unknown): Promise<Result<void>> {
547:     const hold = this.derivedRepair;
548:     if (hold) await hold.stopped.settled();
549:     else {
550:       const state = this.activeController().snapshot();
551:       if (!state.ok) return state;
552:       if (state.value.haltKind !== 'certified-validation')
553:         return failure('replica-repair', 'Only a certified validation halt can be repaired');
554:     }
555:     this.terminalCheckpoint = null;
556:     if (
557:       hold?.replayed &&
558:       snapshot !== undefined &&
559:       // verifyReplaySnapshot uses this same canonical hash equality.
560:       toHex(hashValue(snapshot)) !== hold.replayed.snapshotHash
561:     )
562:       return failure('snapshot-mismatch', 'Snapshot differs from the certified replay');
563:     let record: Awaited<ReturnType<ProtocolJournal['load']>>;
564:     try {
565:       record = await this.options.journal.load();
566:     } catch {
567:       return failure('replica-storage', 'Could not read the certified journal for repair');
568:     }
569:     if (!record)
570:       return this.failClosed('replica-journal', 'Certified journal is missing during repair');
571:     if (
572:       !sameBytes(canonicalEncode(record.genesis), canonicalEncode(this.genesisEntry)) ||
573:       !sameBytes(canonicalEncode(record.genesis), canonicalEncode(this.options.genesisEntry))
574:     )
575:       return this.failClosed('replica-genesis', 'Repair journal differs from the original genesis');
576:     const prefixHash = toHex(hashValue({ genesis: record.genesis, entries: record.entries }));
577:     if (hold?.replayed && prefixHash !== hold.replayed.prefixHash)
578:       return this.failClosed('replica-journal', 'Certified journal changed during repair');
579:     let firstResult: EntryRef | null = hold?.replayed?.firstResult ?? null;
580:     const replayed = hold?.replayed
581:       ? success(hold.replayed)
582:       : replayCertifiedPrefix(
583:           record.genesis,
584:           record.entries,
585:           this.options.engine,
586:           this.options.policy,
587:           (entry, next) => {
588:             if (!firstResult && next.log.state.result !== null)
589:               firstResult = { seq: entry.entry.seq, hash: entryHash(entry.entry) };
590:             return success(undefined);
591:           },
592:         );
593:     if (!replayed.ok)
594:       return hold ? this.failClosed(replayed.error.code, replayed.error.message) : replayed;
595:     const fresh = replayed.value.context;
596:     if (
597:       record.height !== fresh.log.head.seq + 1 ||
598:       fresh.log.head.seq !== (hold?.anchor.seq ?? this.context.log.head.seq) ||
599:       entryHash(fresh.log.head) !== (hold?.anchor.hash ?? entryHash(this.context.log.head))
600:     )
601:       return this.failClosed('replica-journal', 'Certified parent changed during repair');
602:     if (hold && !hold.stopped.opensOn(fresh))
603:       return this.failClosed(
604:         'replica-authority',
605:         'Durable replay differs from the controller opening context',
606:       );
607:     if (hold && !hold.replayed)
608:       hold.replayed = {
609:         context: fresh,
610:         entries: replayed.value.entries,
611:         snapshotHash: toHex(hashValue(snapshotFromContext(fresh))),
612:         prefixHash,
613:         firstResult,
614:       };
615:     if (hold && snapshot === undefined)
616:       return failure('replica-repairing', 'Derived repair requires a replay-verified snapshot');
617:     if (snapshot !== undefined) {
618:       const checked = verifyReplaySnapshot(snapshot, fresh);
619:       if (!checked.ok) return checked;
620:     }
621:     let restored: ConsensusController | null = null;
622:     if (hold) {
623:       const safety = record.safety;
624:       if (!hold.stopped.matchesPersistedRecord(safety))
625:         return this.failClosed(
626:           'consensus-write-conflict',
627:           'Durable vote or lock record changed during repair',
628:         );
629:       const local = checkLocalKey(this.options, fresh);
630:       if (!local.ok) return this.failClosed(local.error.code, local.error.message);
631:       for (const key of local.value.keys.values()) key.fill(0);
632:       const opened = await this.restoreController(fresh, true);
633:       if (!opened.ok) return this.failClosed(opened.error.code, opened.error.message);
634:       restored = opened.value;
635:       let stillStored: Awaited<ReturnType<ProtocolJournal['loadSafety']>>;
636:       try {
637:         stillStored = await this.options.journal.loadSafety(record.height);
638:       } catch {
639:         restored.dispose();
640:         return failure('replica-storage', 'Could not recheck durable safety during repair');
641:       }
642:       if (!stillStored || !hold.stopped.matchesPersistedRecord(stillStored)) {
643:         restored.dispose();
644:         return this.failClosed(
645:           'consensus-write-conflict',
646:           'Durable safety changed while restoring repair',
647:         );
648:       }
649:     }
650:     if (!hold) this.activeController().dispose();
651:     this.controller = null;
652:     this.context = fresh;
653:     this.firstResult = firstResult;
654:     this.timerObserver.advance(fresh.log.timers ?? []);
655:     this.clearTimedVoteRetry();
656:     this.clearRecoveryCandidate();
657:     this.rejectedCommands.clear();
658:     this.rejectedProposals.clear();
659:     this.rejectedDeckContributions.clear();
660:     this.rejectedCountContributions.clear();
661:     this.rejectedStealMessages.clear();
662:     this.rejectedMasterReveals.clear();
663:     this.preparedDeckPrefix = null;
664:     this.sentDeckPrefix = null;
665:     this.entries = replayed.value.entries;
666:     this.refreshHistoricalHumanPeers();
667:     for (const [id, claim] of this.cheatCandidates)
668:       if (!this.verifiedCheatClaim(claim).ok) this.cheatCandidates.delete(id);
669:     if (!restored) {
670:       const opened = await this.openController();
671:       if (!opened.ok) return this.failClosed(opened.error.code, opened.error.message);
672:       const resumed = await this.activeController().dispatch({ kind: 'resume-after-replay' });
673:       if (resumed.ok) this.mintTerminalCheckpoint();
674:       return resumed;
675:     }
676:     this.installController(restored, fresh);
677:     this.derivedRepair = null;
678:     const resumed = await restored.resume();
679:     if (!resumed.ok) return resumed;
680:     this.mintTerminalCheckpoint();
681:     for (const certified of hold?.heldCommits.values() ?? []) {
682:       // oxlint-disable-next-line no-await-in-loop -- Retained untrusted hints are fully validated on the freshly restored parent.
683:       const accepted = await this.acceptCertified(certified);
684:       if (!accepted.ok && FATAL_CONTROLLER_ERRORS.has(accepted.error.code)) return accepted;
685:     }
686:     this.schedulePulse();
687:     return this.requestSync(this.context.log.head.seq + 1);
688:   }
689: 
690:   /** Resolves on matching commitment; another committed value requires renewed intent. */
```


### Replica disposal (lines 1000-1020)

```ts
1000:       // oxlint-disable-next-line eslint/no-await-in-loop -- Follow-up tasks may join the serialized queue while it resolves.
1001:       await current;
1002:     } while (current !== this.queue);
1003:   }
1004: 
1005:   dispose(): void {
1006:     if (this.disposed) return;
1007:     this.disposed = true;
1008:     this.terminalCheckpoint = null;
1009:     this.derivedRepair?.stopped.dispose();
1010:     this.derivedRepair = null;
1011:     this.pendingTradeProofs.clear();
1012:     this.tradeProofResponses.clear();
1013:     this.tradeProofRequestsByFinalizer.clear();
1014:     this.tradeProofWorkByPeer.clear();
1015:     this.cheatWorkByPeer.clear();
1016:     this.historicalCheatWorkByPeer.clear();
1017:     this.cheatCandidates.clear();
1018:     this.recoveryParticipant?.dispose();
1019:     this.recoveryParticipant = null;
1020:     this.clearRecoveryCandidate();
```


### Derived-repair entry and checkpoint invalidation (lines 1285-1310)

```ts
1285:     return success(undefined);
1286:   }
1287: 
1288:   private enterDerivedRepair(): boolean {
1289:     this.terminalCheckpoint = null;
1290:     if (this.derivedRepair) return true;
1291:     if (!this.controller || !this.controllerAnchor) return false;
1292:     const stopped = this.controller;
1293:     stopped.dispose();
1294:     this.controller = null;
1295:     this.derivedRepair = {
1296:       stopped,
1297:       anchor: this.controllerAnchor,
1298:       heldCommits: new Map(),
1299:       lastRequestAt: -Infinity,
1300:     };
1301:     this.clearConsensusTimers();
1302:     this.clearTimedVoteRetry();
1303:     this.status({ kind: 'halted', code: 'consensus-context' });
1304:     this.requestDerivedSnapshot();
1305:     this.schedulePulse();
1306:     return true;
1307:   }
1308: 
1309:   private requestDerivedSnapshot(): Result<void> {
1310:     const hold = this.derivedRepair;
```


### Serialized operation queue and context-fault quarantine (lines 1350-1405)

```ts
1350:   private receiveDuringRepair(from: PeerId, message: ProtocolMessage): Promise<Result<void>> {
1351:     const hold = this.derivedRepair;
1352:     if (!hold || !hold.anchor.voters.includes(from)) return Promise.resolve(success(undefined));
1353:     if (message.t === 'SNAPSHOT_RES') {
1354:       if (
1355:         message.genesisDigest !== hold.anchor.genesisDigest ||
1356:         message.atSeq !== hold.anchor.seq ||
1357:         !this.admitExpensiveRequest(from, `snapshot-response/${toHex(hashValue(message.snapshot))}`)
1358:       )
1359:         return Promise.resolve(success(undefined));
1360:       return this.repairNow(message.snapshot);
1361:     }
1362:     if (message.t === 'COMMIT') this.retainHeldCommit(message.certified);
1363:     if (message.t === 'PING') return Promise.resolve(this.send(from, { t: 'PONG', n: message.n }));
1364:     return Promise.resolve(success(undefined));
1365:   }
1366: 
1367:   private enqueue<T>(
1368:     operation: () => Promise<Result<T>>,
1369:     duringRepair = false,
1370:   ): Promise<Result<T>> {
1371:     const result = this.queue.then(async (): Promise<Result<T>> => {
1372:       if (this.disposed) return failure('replica-disposed', 'Replicated log is closed');
1373:       if (this.controller?.hasContextFault() && this.enterDerivedRepair())
1374:         return failure('consensus-context', 'Certified context changed; awaiting durable replay');
1375:       if (this.derivedRepair && !duringRepair)
1376:         return failure('replica-repairing', 'Awaiting certified derived-state repair');
1377:       const repairing = this.derivedRepair;
1378:       try {
1379:         const outcome = await operation();
1380:         if (
1381:           ((!repairing && this.derivedRepair) ||
1382:             this.controller?.hasContextFault() ||
1383:             (!outcome.ok && outcome.error.code === 'consensus-context')) &&
1384:           this.enterDerivedRepair()
1385:         )
1386:           return failure('consensus-context', 'Certified context changed; awaiting durable replay');
1387:         if (!outcome.ok && FATAL_CONTROLLER_ERRORS.has(outcome.error.code)) {
1388:           this.status({ kind: 'halted', code: outcome.error.code });
1389:           this.dispose();
1390:         }
1391:         return outcome;
1392:       } catch {
1393:         if (
1394:           ((!repairing && this.derivedRepair) || this.controller?.hasContextFault()) &&
1395:           this.enterDerivedRepair()
1396:         )
1397:           return failure('consensus-context', 'Certified context changed; awaiting durable replay');
1398:         this.status({ kind: 'halted', code: 'replica-transition' });
1399:         this.dispose();
1400:         return failure('replica-transition', 'Replicated log transition failed');
1401:       }
1402:     });
1403:     this.queue = result;
1404:     return result;
1405:   }
```


### Live coordinator, mint, full checkpoint validity checks (lines 1840-1945)

```ts
1840:           cause: remembered.error.code,
1841:         },
1842:       );
1843:     }
1844:     return remembered.value ? this.offerAvailableInput() : success(undefined);
1845:   }
1846: 
1847:   private revealCoordinator(): MasterRevealCoordinator | null {
1848:     if (!this.options.masterReveal || this.context.log.state.result === null) return null;
1849:     this.masterRevealCoordinator ??= createLiveMasterRevealCoordinator(
1850:       {
1851:         ...this.options.masterReveal,
1852:         journal: this.options.journal,
1853:         engine: this.options.engine,
1854:         policy: this.options.policy,
1855:         localSeat: this.options.seat,
1856:         signingKey: this.secretKey,
1857:       },
1858:       () => this.readTerminalCheckpoint(),
1859:     );
1860:     return this.masterRevealCoordinator;
1861:   }
1862: 
1863:   /** Called only after certified commit, or full replay and controller restoration. */
1864:   private mintTerminalCheckpoint(): void {
1865:     this.terminalCheckpoint =
1866:       !this.disposed && !this.derivedRepair && this.firstResult && this.context.log.state.result
1867:         ? Object.freeze({
1868:             context: this.context,
1869:             result: Object.freeze({ ...this.firstResult }),
1870:             head: Object.freeze({
1871:               seq: this.context.log.head.seq,
1872:               hash: entryHash(this.context.log.head),
1873:             }),
1874:             genesisHash: this.genesisHash,
1875:           })
1876:         : null;
1877:   }
1878: 
1879:   /** Reuse prior validation only while its controller and durable branch still agree. */
1880:   private async readTerminalCheckpoint(): Promise<Result<Terminal>> {
1881:     const checkpoint = this.terminalCheckpoint;
1882:     const controller = this.controller;
1883:     const current = (): boolean => {
1884:       if (
1885:         !checkpoint ||
1886:         !controller ||
1887:         this.disposed ||
1888:         this.derivedRepair ||
1889:         this.terminalCheckpoint !== checkpoint ||
1890:         this.controller !== controller ||
1891:         this.context !== checkpoint.context
1892:       )
1893:         return false;
1894:       try {
1895:         const state = controller.snapshot();
1896:         if (
1897:           this.matchesReplayPolicy() &&
1898:           state.ok &&
1899:           !state.value.halted &&
1900:           controller.opensOn(checkpoint.context)
1901:         )
1902:           return true;
1903:       } catch {
1904:         // A mutated policy getter is not a new authority to disclose a master.
1905:       }
1906:       if (this.terminalCheckpoint === checkpoint) this.terminalCheckpoint = null;
1907:       return false;
1908:     };
1909:     if (!checkpoint || !controller || !current())
1910:       return failure('master-reveal-context', 'Verified terminal context is unavailable');
1911:     try {
1912:       const record = await this.options.journal.load();
1913:       if (!current())
1914:         return failure('master-reveal-stale', 'Verified terminal context changed during read');
1915:       const head = record?.entries.at(-1)?.entry ?? record?.genesis;
1916:       if (
1917:         !record ||
1918:         !head ||
1919:         record.height !== head.seq + 1 ||
1920:         record.entries.length !== head.seq ||
1921:         head.seq !== checkpoint.head.seq ||
1922:         entryHash(head) !== checkpoint.head.hash ||
1923:         entryHash(record.genesis) !== checkpoint.genesisHash ||
1924:         !controller.matchesPersistedRecord(record.safety)
1925:       )
1926:         return failure('master-reveal-journal', 'Durable journal differs from verified checkpoint');
1927:       return success(checkpoint);
1928:     } catch {
1929:       return failure('master-reveal-journal', 'Could not read verified terminal journal');
1930:     }
1931:   }
1932: 
1933:   private rememberMasterReveal(reveal: {
1934:     packet: SignedMasterReveal;
1935:     verdict: MasterRevealVerdict;
1936:   }): void {
1937:     const seat = reveal.packet.body.originalSeat;
1938:     if (this.acceptedMasterSeats.has(seat)) return;
1939:     try {
1940:       this.options.onMasterReveal?.({
1941:         packet: structuredReveal(reveal.packet),
1942:         verdict: reveal.verdict,
1943:       });
1944:       this.acceptedMasterSeats.add(seat);
1945:     } catch {
```


### Historical receipt restore, live receive, and prepare paths (lines 1945-2045)

```ts
1945:     } catch {
1946:       this.status({ kind: 'rejected', code: 'master-reveal-observer' });
1947:     }
1948:   }
1949: 
1950:   private async restoreMasterReveals(coordinator: MasterRevealCoordinator): Promise<Result<void>> {
1951:     if (!this.masterRevealsRestored) {
1952:       const restored = await coordinator.restoreAccepted();
1953:       if (this.disposed) return failure('replica-disposed', 'Replica closed during reveal restore');
1954:       if (!restored.ok) return restored;
1955:       this.masterRevealsRestored = true;
1956:       for (const { code } of coordinator.quarantinedAccepted())
1957:         this.status({ kind: 'rejected', code });
1958:     }
1959:     for (const reveal of coordinator.reveals()) this.rememberMasterReveal(reveal);
1960:     return success(undefined);
1961:   }
1962: 
1963:   private async receiveMasterReveal(
1964:     from: PeerId,
1965:     packet: SignedMasterReveal,
1966:   ): Promise<Result<void>> {
1967:     if (
1968:       !this.context.log.state.result ||
1969:       packet.body.genesisDigest !== this.context.membership.genesisDigest ||
1970:       this.acceptedMasterSeats.has(packet.body.originalSeat)
1971:     )
1972:       return success(undefined);
1973:     if (!this.context.membership.voters.some((voter) => voter.publicKey === from))
1974:       return failure('master-reveal-relay', 'Reveal relay is not a current voter');
1975:     const coordinator = this.revealCoordinator();
1976:     if (!coordinator) return success(undefined);
1977:     const hash = toHex(hashValue(packet));
1978:     if (
1979:       this.rejectedMasterReveals.has(hash) ||
1980:       !this.admitExpensiveRequest(
1981:         from,
1982:         `master-reveal/${packet.body.originalSeat}/${hash}`,
1983:         'reveal',
1984:       )
1985:     )
1986:       return success(undefined);
1987:     const restored = await this.restoreMasterReveals(coordinator);
1988:     if (!restored.ok) return restored;
1989:     if (this.acceptedMasterSeats.has(packet.body.originalSeat)) return success(undefined);
1990:     const checked = await coordinator.receive(packet);
1991:     if (this.disposed) return failure('replica-disposed', 'Replica closed during master reveal');
1992:     if (!checked.ok) {
1993:       if (
1994:         [
1995:           'master-reveal-publisher',
1996:           'master-reveal-signature',
1997:           'master-reveal-result',
1998:           'master-reveal-f0',
1999:           'master-reveal-conflict',
2000:         ].includes(checked.error.code)
2001:       ) {
2002:         rememberRejection(this.rejectedMasterReveals, hash);
2003:         if (checked.error.code !== 'master-reveal-signature') this.strikePeer(from);
2004:       }
2005:       return checked;
2006:     }
2007:     this.rememberMasterReveal(checked.value);
2008:     return success(undefined);
2009:   }
2010: 
2011:   private async prepareMasterReveals(retransmit: boolean): Promise<Result<void>> {
2012:     if (this.context.log.recovery?.void) return success(undefined);
2013:     const coordinator = this.revealCoordinator();
2014:     if (!coordinator) return success(undefined);
2015:     const restored = await this.restoreMasterReveals(coordinator);
2016:     if (!restored.ok) {
2017:       this.status({ kind: 'rejected', code: restored.error.code });
2018:       return success(undefined);
2019:     }
2020:     const headHash = entryHash(this.context.log.head);
2021:     const eligible = await coordinator.eligibleSeats();
2022:     if (this.disposed) return failure('replica-disposed', 'Replica closed during master reveal');
2023:     if (!eligible.ok) {
2024:       this.status({ kind: 'rejected', code: eligible.error.code });
2025:       return success(undefined);
2026:     }
2027:     const metadata = await coordinator.metadata();
2028:     if (this.disposed) return failure('replica-disposed', 'Replica closed during master reveal');
2029:     if (!metadata.ok || metadata.value.head.hash !== headHash) {
2030:       this.status({
2031:         kind: 'rejected',
2032:         code: metadata.ok ? 'master-reveal-stale' : metadata.error.code,
2033:       });
2034:       return success(undefined);
2035:     }
2036:     for (const seat of eligible.value) {
2037:       const saved = this.localMasterReveals.get(seat);
2038:       if (saved?.headHash === headHash) {
2039:         this.rememberMasterReveal(saved);
2040:         if (retransmit) {
2041:           const sent = this.broadcast({ t: 'MASTER_REVEAL', reveal: saved.packet });
2042:           if (!sent.ok) this.status({ kind: 'rejected', code: sent.error.code });
2043:         }
2044:         continue;
2045:       }
```


### Certified commit CAS, first-result transition, controller reopen and remint (lines 4035-4140)

```ts
4035:       }
4036:     }
4037:     await this.handleEffects(effects, index + 1);
4038:   }
4039: 
4040:   private async persistCommit(certified: CertifiedEntry): Promise<void> {
4041:     const prior = this.activeController().snapshot();
4042:     if (!prior.ok) throw new Error(`Voting record failed: ${prior.error.code}`);
4043:     const previous = this.context;
4044:     const checked = validateCertifiedEntry(certified, previous);
4045:     if (!checked.ok) throw new Error(`Certified entry failed replay: ${checked.error.code}`);
4046:     const advanced = advanceContext(previous, checked.value);
4047:     if (!advanced.ok) throw new Error(`Certified context failed: ${advanced.error.code}`);
4048:     const next = advanced.value;
4049:     this.terminalCheckpoint = null;
4050:     const controlProof =
4051:       checked.value.entry.payload.kind === 'control'
4052:         ? objectiveProofParentHash(checked.value.entry.payload, previous)
4053:         : null;
4054:     if (controlProof && !controlProof.ok)
4055:       throw new Error(`Committed accusation proof failed: ${controlProof.error.code}`);
4056:     const provenOffender =
4057:       prior.value.provenOffender ??
4058:       (checked.value.entry.payload.kind === 'control' && controlProof?.ok
4059:         ? {
4060:             control: checked.value.entry.payload,
4061:             atSeq: objectiveEvidenceSeq(checked.value.entry.payload),
4062:             parentHash: controlProof.value,
4063:           }
4064:         : null);
4065:     const pendingAccusation =
4066:       checked.value.entry.payload.kind === 'control' ? null : prior.value.pendingAccusation;
4067:     const retired = !next.membership.voters.some(
4068:       (voter) => voter.seat === this.options.seat && voter.publicKey === this.self,
4069:     );
4070:     const nextSafety = retired
4071:       ? createRetiredSafety(previous, certified, this.options.seat, prior.value)
4072:       : createConsensusState(next, this.options.seat, provenOffender, pendingAccusation);
4073:     if (!nextSafety.ok) throw new Error(`Next voting state failed: ${nextSafety.error.code}`);
4074:     const current = await this.options.journal.loadSafety(certified.entry.seq);
4075:     const snapshot = this.activeController().snapshot();
4076:     if (
4077:       !snapshot.ok ||
4078:       !current ||
4079:       current.revision !== this.activeController().persistedRevision() ||
4080:       !sameBytes(current.bytes, canonicalEncode(snapshot.value)) ||
4081:       !(await this.options.journal.commit(
4082:         certified.entry.seq,
4083:         this.activeController().persistedRevision(),
4084:         certified,
4085:         canonicalEncode(nextSafety.value),
4086:       ))
4087:     )
4088:       throw new Error('Certified journal commit lost its safety CAS');
4089:     this.activeController().dispose();
4090:     this.context = next;
4091:     if (!this.firstResult && previous.log.state.result === null && next.log.state.result !== null)
4092:       this.firstResult = { seq: checked.value.entry.seq, hash: entryHash(checked.value.entry) };
4093:     this.observeAllRecoveryPresence();
4094:     if (checked.value.entry.payload.kind === 'membership') this.pruneRetiredBotOwnership();
4095:     this.timerObserver.advance(next.log.timers ?? []);
4096:     this.clearTimedVoteRetry();
4097:     this.clearRecoveryCandidate();
4098:     this.pendingTradeProofs.clear();
4099:     this.tradeProofResponses.clear();
4100:     this.tradeProofRequestsByFinalizer.clear();
4101:     this.entries.push({ entry: checked.value.entry, certificate: [...checked.value.certificate] });
4102:     this.rememberHumanActivation(checked.value.entry);
4103:     if (checked.value.entry.payload.kind === 'cheat-proof') {
4104:       const id = cheatCandidateId(checked.value.entry.payload.claim);
4105:       this.cheatCandidates.delete(id);
4106:       try {
4107:         await this.options.cheatCandidateStore?.delete(id);
4108:       } catch {
4109:         // A stale auxiliary record is removed during restore after certified replay.
4110:       }
4111:     }
4112:     if (this.lastSyncRequest && next.log.head.seq >= this.lastSyncRequest.fromSeq)
4113:       this.lastSyncRequest = null;
4114:     this.commands.length = 0;
4115:     this.rejectedCommands.clear();
4116:     this.rejectedProposals.clear();
4117:     this.rejectedDeckContributions.clear();
4118:     this.rejectedCountContributions.clear();
4119:     this.rejectedStealMessages.clear();
4120:     this.sentCountContributions.clear();
4121:     this.sentBeaconOperations.clear();
4122:     this.preparedRecovery = null;
4123:     this.sentRecoveryPackets.clear();
4124:     this.accusation = pendingAccusation;
4125:     this.clearConsensusTimers();
4126:     this.refreshPreparedStealStage();
4127:     if (!retired) {
4128:       const opened = await this.openController();
4129:       if (!opened.ok) throw new Error(`Next voting controller failed: ${opened.error.code}`);
4130:       this.mintTerminalCheckpoint();
4131:     }
4132:     try {
4133:       this.options.onCommit?.(
4134:         detachedValidated(checked.value),
4135:         detachedContext(previous),
4136:         detachedContext(next),
4137:       );
4138:     } catch {
4139:       this.status({ kind: 'halted', code: 'commit-application' });
4140:       this.dispose();
```


## `packages/protocol/src/consensus.ts`


### Context stamp includes context/log/policy/engine fields and runtime references (lines 215-260)

```ts
215:       if (typeof property?.value === 'function')
216:         references.push([`${name}/${key}`, property.value]);
217:       if (property?.get) references.push([`${name}/${key}/get`, Reflect.get(property, 'get')]);
218:       if (property?.set) references.push([`${name}/${key}/set`, Reflect.get(property, 'set')]);
219:     }
220:     current = Object.getPrototypeOf(current);
221:   }
222:   return references;
223: }
224: 
225: function contextStamp(context: ProposalContext): ContextStamp {
226:   const functions: (readonly [string, unknown])[] = [
227:     ...runtimeReferences(context, 'context'),
228:     ...runtimeReferences(context.log, 'log'),
229:     ...runtimeReferences(context.log.engine, 'engine'),
230:     ...runtimeReferences(context.policy, 'policy'),
231:     ...(context.policy.randomDerivations
232:       ? runtimeReferences(context.policy.randomDerivations, 'randomDerivations')
233:       : [['randomDerivations', null] as const]),
234:   ];
235:   const { engine, ...log } = context.log;
236:   const other = nonfunctions(context);
237:   delete other.log;
238:   delete other.policy;
239:   return {
240:     contextBytes: canonicalEncode({
241:       ...other,
242:       log: {
243:         ...log,
244:         lastNonces: [...log.lastNonces],
245:         engine: nonfunctions(engine),
246:       },
247:       policy: {
248:         ...nonfunctions(context.policy),
249:         randomDerivations: nonfunctions(context.policy.randomDerivations ?? {}),
250:       },
251:     }),
252:     functions,
253:   };
254: }
255: 
256: function sameContextStamp(left: ContextStamp, right: ContextStamp): boolean {
257:   return (
258:     sameBytes(left.contextBytes, right.contextBytes) &&
259:     left.functions.length === right.functions.length &&
260:     left.functions.every(
```


### Owned state opening-context comparison and context-fault guard (lines 1640-1725)

```ts
1640:     admitValue?: LocalVoteAdmissibility,
1641:   ): Result<ConsensusTransition>;
1642:   commit(): Result<void>;
1643:   discard(): void;
1644: }
1645: 
1646: class OwnedConsensusStateImpl implements OwnedConsensusState {
1647:   private pending: ConsensusState | null = null;
1648: 
1649:   constructor(
1650:     private state: ConsensusState,
1651:     private readonly context: ProposalContext,
1652:     private readonly stamp: ContextStamp,
1653:   ) {
1654:     ownedStates.add(state);
1655:   }
1656: 
1657:   matchesOpenedContext(candidate: ProposalContext): boolean {
1658:     try {
1659:       const replayed = contextStamp(candidate);
1660:       // Full replay rebuilds these record wrappers and ancestry closures. Engine,
1661:       // policy, prototypes and their function references must remain identical.
1662:       const rebuilt = new Set([
1663:         'context',
1664:         // runtimeReferences depth zero repeats the wrapper itself; deeper
1665:         // prototype references remain part of the comparison.
1666:         'context/prototype/0',
1667:         'log',
1668:         'log/prototype/0',
1669:         'context/verifyHistoricalCheat',
1670:         'context/verifyHistoricalAccusation',
1671:       ]);
1672:       const openedFunctions = this.stamp.functions.filter(([name]) => !rebuilt.has(name));
1673:       const replayedFunctions = replayed.functions.filter(([name]) => !rebuilt.has(name));
1674:       return (
1675:         sameBytes(this.stamp.contextBytes, replayed.contextBytes) &&
1676:         openedFunctions.length === replayedFunctions.length &&
1677:         openedFunctions.every(
1678:           ([name, reference], index) =>
1679:             name === replayedFunctions[index]?.[0] && reference === replayedFunctions[index]?.[1],
1680:         )
1681:       );
1682:     } catch {
1683:       return false;
1684:     }
1685:   }
1686: 
1687:   private checkContext(): Result<void> {
1688:     let current: ContextStamp;
1689:     try {
1690:       current = contextStamp(this.context);
1691:     } catch {
1692:       return failure('consensus-context', 'Certified context changed to noncanonical data');
1693:     }
1694:     if (sameContextStamp(this.stamp, current)) return success(undefined);
1695:     if (this.pending)
1696:       return failure('consensus-context', 'Certified context changed during persistence');
1697:     // Once the opening stamp differs, this context cannot validate stored
1698:     // proposals or locks. Only durable replay may establish their authority.
1699:     return failure('consensus-context', 'Certified context changed; restore this voting record');
1700:   }
1701: 
1702:   snapshot(): Result<ConsensusState> {
1703:     const checked = this.checkContext();
1704:     return checked.ok ? success(copyConsensusStateData(this.state)) : checked;
1705:   }
1706: 
1707:   dispatch(
1708:     event: ConsensusEvent,
1709:     secretKey: Uint8Array,
1710:     admitValue?: LocalVoteAdmissibility,
1711:   ): Result<ConsensusTransition> {
1712:     const checked = this.checkContext();
1713:     if (!checked.ok) return checked;
1714:     if (this.pending) return failure('consensus-pending', 'Persist the previous transition first');
1715:     let next: Result<ConsensusTransition>;
1716:     switch (event.kind) {
1717:       case 'input-available':
1718:         next = inputAvailable(this.state, this.context);
1719:         break;
1720:       case 'propose':
1721:         next = propose(this.state, this.context, secretKey, event.candidate, admitValue);
1722:         break;
1723:       case 'proposal':
1724:         next = receiveProposal(this.state, this.context, secretKey, event.proposal, admitValue);
1725:         break;
```


## `packages/protocol/src/consensus-controller.ts`


### Controller restore, detached snapshot, halted/context status, persisted safety matching (lines 1-195)

```ts
1: import { canonicalDecode, canonicalEncode, sha256, toHex } from '@cp2p/codec';
2: import { identityFromSecret } from '@cp2p/crypto';
3: import { failure, success } from '@cp2p/engine';
4: import type { Result, Seat } from '@cp2p/engine';
5: import {
6:   copyConsensusStateData,
7:   createConsensusState,
8:   openOwnedConsensusState,
9:   recoverConsensusEffects,
10:   restoreConsensusState,
11: } from './consensus.js';
12: import type {
13:   ConsensusEffect,
14:   ConsensusEvent,
15:   LocalVoteAdmissibility,
16:   OwnedConsensusState,
17:   ConsensusState,
18:   ConsensusTransition,
19: } from './consensus.js';
20: import type { ProposalContext } from './proposal.js';
21: import type { SafetyStore, StoredSafety } from './safety-store.js';
22: import { MAX_MESSAGE_BYTES } from './validation.js';
23: 
24: export type { ConsensusEvent } from './consensus.js';
25: 
26: export interface ConsensusControllerOptions {
27:   context: ProposalContext;
28:   seat: Seat;
29:   secretKey: Uint8Array;
30:   /** One record for this game/key/height, retained across controller crashes. */
31:   store: SafetyStore;
32:   /** Repair must reuse exact durable bytes without normalizing newly found terminal evidence. */
33:   requireExactRestore?: boolean;
34:   /** Effects are at-least-once. Handlers must deduplicate committed sequence/value. */
35:   onEffects: (effects: readonly ConsensusEffect[]) => void | Promise<void>;
36:   /** Local admission only. It must not alter replay or objective validity. */
37:   beforePersist?: (previous: ConsensusState, next: ConsensusState) => Result<void>;
38:   admitLocalValue?: LocalVoteAdmissibility;
39: }
40: 
41: /**
42:  * Serializes a single height's transitions and persists before emission.
43:  * Opening the next height requires a separately persisted certified parent.
44:  */
45: export class ConsensusController {
46:   private queue: Promise<unknown> = Promise.resolve();
47:   private stopped = false;
48:   private contextFault = false;
49:   private persistedBytes: Uint8Array;
50:   private readonly secretKey: Uint8Array;
51:   private readonly rejectedProposals = new Map<string, { code: string; message: string }>();
52: 
53:   private constructor(
54:     private readonly options: ConsensusControllerOptions,
55:     private state: ConsensusState,
56:     private revision: number,
57:     private readonly owned: OwnedConsensusState,
58:   ) {
59:     this.secretKey = options.secretKey.slice();
60:     this.persistedBytes = canonicalEncode(state);
61:   }
62: 
63:   /** Only for a genuinely new height; existing or lost stores are not reset here. */
64:   static async create(options: ConsensusControllerOptions): Promise<Result<ConsensusController>> {
65:     const validKey = checkLocalKey(options);
66:     if (!validKey.ok) return validKey;
67:     const initial = createConsensusState(options.context, options.seat);
68:     if (!initial.ok) return initial;
69:     try {
70:       if (await options.store.load())
71:         return failure(
72:           'consensus-store-exists',
73:           'Restore existing vote records instead of resetting',
74:         );
75:       const owned = openOwnedConsensusState(initial.value, options.context, options.seat);
76:       if (!owned.ok) return owned;
77:       const saved = await options.store.save(null, canonicalEncode(initial.value));
78:       if (!saved)
79:         return failure('consensus-write-conflict', 'Another writer initialized this voting record');
80:       return success(new ConsensusController(options, initial.value, 0, owned.value));
81:     } catch {
82:       return failure('consensus-storage', 'Could not persist the initial voting record');
83:     }
84:   }
85: 
86:   /** An absent or damaged record fails closed; this never creates round-one state. */
87:   static async restore(options: ConsensusControllerOptions): Promise<Result<ConsensusController>> {
88:     const validKey = checkLocalKey(options);
89:     if (!validKey.ok) return validKey;
90:     let record: StoredSafety | null;
91:     try {
92:       record = await options.store.load();
93:     } catch {
94:       return failure('consensus-storage', 'Could not read the voting record');
95:     }
96:     if (!record)
97:       return failure(
98:         'consensus-store-missing',
99:         'The voting record is missing; key replacement is required',
100:       );
101:     if (!Number.isSafeInteger(record.revision) || record.revision < 0)
102:       return failure('consensus-storage', 'Stored voting revision is invalid');
103:     let restored: Result<ConsensusState>;
104:     try {
105:       restored = restoreConsensusState(
106:         canonicalDecode(record.bytes),
107:         options.context,
108:         options.seat,
109:       );
110:     } catch {
111:       return failure('consensus-storage', 'Stored voting data is not valid canonical data');
112:     }
113:     if (!restored.ok) return restored;
114:     let revision = record.revision;
115:     const normalized = canonicalEncode(restored.value);
116:     if (!sameBytes(normalized, record.bytes)) {
117:       if (options.requireExactRestore || restored.value.haltKind !== 'terminal')
118:         return failure('consensus-restore', 'Voting record changed without a terminal proof');
119:       try {
120:         if (!(await options.store.save(revision, normalized)))
121:           return failure('consensus-write-conflict', 'Voting record changed during terminal halt');
122:       } catch {
123:         return failure('consensus-storage', 'Could not persist the verified terminal halt');
124:       }
125:       revision++;
126:     }
127:     const owned = openOwnedConsensusState(restored.value, options.context, options.seat);
128:     return owned.ok
129:       ? success(new ConsensusController(options, restored.value, revision, owned.value))
130:       : owned;
131:   }
132: 
133:   /** Returns a detached, verified snapshot, never the mutable internal record. */
134:   snapshot(): Result<ConsensusState> {
135:     const snapshot = this.owned.snapshot();
136:     if (!snapshot.ok) {
137:       this.stopVoting(snapshot.error.code);
138:       return snapshot;
139:     }
140:     if (!sameBytes(canonicalEncode(snapshot.value), canonicalEncode(this.state))) {
141:       this.stopVoting();
142:       return failure('consensus-restore', 'Restore to persist newly verified terminal evidence');
143:     }
144:     return snapshot;
145:   }
146: 
147:   /** The opening stamp remains usable after the mutable derived context fails its guard. */
148:   opensOn(context: ProposalContext): boolean {
149:     return this.owned.matchesOpenedContext(context);
150:   }
151: 
152:   hasContextFault(): boolean {
153:     return this.contextFault;
154:   }
155: 
156:   settled(): Promise<void> {
157:     return this.queue.then(
158:       () => undefined,
159:       () => undefined,
160:     );
161:   }
162: 
163:   matchesPersistedRecord(record: StoredSafety): boolean {
164:     return record.revision === this.revision && sameBytes(record.bytes, this.persistedBytes);
165:   }
166: 
167:   /** Expected CAS revision for atomically committing this controller's height. */
168:   persistedRevision(): number {
169:     return this.revision;
170:   }
171: 
172:   /** Call after restoring to retransmit signed records and re-arm timers. */
173:   resume(): Promise<Result<void>> {
174:     return this.enqueue(async () => {
175:       const snapshot = this.snapshot();
176:       if (!snapshot.ok) return snapshot;
177:       const recovered = recoverConsensusEffects(this.state, this.options.context);
178:       if (!recovered.ok) {
179:         this.stopVoting();
180:         return recovered;
181:       }
182:       return this.emit(recovered.value);
183:     });
184:   }
185: 
186:   dispatch(event: ConsensusEvent): Promise<Result<void>> {
187:     return this.enqueue(async () => {
188:       if (event.kind === 'proposal' && this.isRecordedProposalReplay(event.proposal)) {
189:         const checked = this.snapshot();
190:         return checked.ok ? success(undefined) : checked;
191:       }
192:       const proposalKey = event.kind === 'proposal' ? this.proposalKey(event.proposal) : null;
193:       const rejected = proposalKey ? this.rejectedProposals.get(proposalKey) : undefined;
194:       if (rejected) {
195:         const checked = this.snapshot();
```


## `packages/protocol/src/replay.ts`


### Certified prefix replay and per-entry callback (lines 80-250)

```ts
80:   });
81: }
82: 
83: /** Replay certificates in order. A claimed snapshot never supplies voter or nonce state. */
84: export function replayCertifiedPrefix(
85:   genesisEntry: unknown,
86:   entries: readonly unknown[],
87:   engine: Engine,
88:   policy: ReplayPolicy,
89:   onEntry?: (entry: ValidatedEntry & CertifiedEntry, next: ProposalContext) => Result<void>,
90: ): Result<ReplayedPrefix> {
91:   return replayCertifiedPrefixWithCache(genesisEntry, entries, engine, policy, new Map(), onEntry);
92: }
93: 
94: /** Successful findings are shared only within this certified ancestry. */
95: function replayCertifiedPrefixWithCache(
96:   genesisEntry: unknown,
97:   entries: readonly unknown[],
98:   engine: Engine,
99:   policy: ReplayPolicy,
100:   verifiedFindings: Map<string, CheatFinding>,
101:   onEntry?: (entry: ValidatedEntry & CertifiedEntry, next: ProposalContext) => Result<void>,
102: ): Result<ReplayedPrefix> {
103:   const initial = initialProposalContext(genesisEntry, engine, policy);
104:   if (!initial.ok) return initial;
105:   const certified: CertifiedEntry[] = [];
106:   const historical = new Map<number, ProposalContext>();
107:   const cheatHistorical = new Map<number, ProposalContext>();
108:   const controllerTimeline = [
109:     {
110:       atSeq: 0,
111:       authority: initial.value.log.authority,
112:       epoch: initial.value.log.crypto?.epoch ?? initial.value.log.authority?.epoch ?? 0,
113:     },
114:   ];
115:   let context: ProposalContext = {
116:     ...initial.value,
117:     verifyHistoricalCheat: (claim) => {
118:       const atSeq = claim.evidence.at.seq;
119:       if (atSeq > certified.length)
120:         return failure('cheat-history', 'Certified evidence parent is unavailable');
121:       const parentEntry = atSeq === 0 ? initial.value.log.head : certified[atSeq - 1]?.entry;
122:       if (!parentEntry || claim.evidence.at.hash !== entryHash(parentEntry))
123:         return failure('cheat-history', 'Certified evidence parent hash does not match');
124:       const parentAuthority = controllerTimeline.findLast((item) => item.atSeq <= atSeq);
125:       if (
126:         !parentAuthority ||
127:         !authenticatedCheatSigner(
128:           claim,
129:           initial.value.log.genesis,
130:           parentAuthority.authority,
131:           parentAuthority.epoch,
132:         )
133:       )
134:         return failure('cheat-signature', 'Cheat evidence has no authenticated controller');
135:       const key = toHex(hashValue({ domain: 'cp2p/v1/cheat-claim-cache', claim }));
136:       const previous = verifiedFindings.get(key);
137:       if (previous) return success(previous);
138:       let parent = cheatHistorical.get(atSeq);
139:       if (!parent) {
140:         const replayed = replayCertifiedPrefixWithCache(
141:           genesisEntry,
142:           certified.slice(0, atSeq),
143:           engine,
144:           policy,
145:           verifiedFindings,
146:         );
147:         if (!replayed.ok) return replayed;
148:         parent = replayed.value.context;
149:       }
150:       cheatHistorical.delete(atSeq);
151:       cheatHistorical.set(atSeq, parent);
152:       if (cheatHistorical.size > MAX_HISTORICAL_CONTEXTS) {
153:         const oldest = cheatHistorical.keys().next().value;
154:         if (oldest !== undefined) cheatHistorical.delete(oldest);
155:       }
156:       return verifyCheatProof(claim, parent.log);
157:     },
158:     verifyHistoricalAccusation: (control) => {
159:       const atSeq = objectiveEvidenceSeq(control);
160:       if (atSeq < 1 || atSeq - 1 > certified.length)
161:         return failure('control-history', 'Certified evidence parent is unavailable');
162:       let parent = historical.get(atSeq);
163:       if (!parent) {
164:         const replayed = replayCertifiedPrefixWithCache(
165:           genesisEntry,
166:           certified.slice(0, atSeq - 1),
167:           engine,
168:           policy,
169:           verifiedFindings,
170:         );
171:         if (!replayed.ok) return replayed;
172:         parent = replayed.value.context;
173:       }
174:       // Pending proofs and round hints can reference different certified parents.
175:       // Keep recent parents together without retaining the whole game state history.
176:       historical.delete(atSeq);
177:       historical.set(atSeq, parent);
178:       if (historical.size > MAX_HISTORICAL_CONTEXTS) {
179:         const oldest = historical.keys().next().value;
180:         if (oldest !== undefined) historical.delete(oldest);
181:       }
182:       const checked = validateObjectiveAccusation(control, {
183:         log: parent.log,
184:         commandPolicy: parent.policy,
185:         membership: parent.membership,
186:         excludedProposers: parent.excludedProposers,
187:         proposerFor: (seq, term) =>
188:           proposerFor(seq, term, parent.membership, parent.excludedProposers),
189:       });
190:       return checked.ok ? success(entryHash(parent.log.head)) : checked;
191:     },
192:   };
193:   const inputs: Input[] = [];
194:   const events: GameEvent[] = [];
195:   for (const entry of entries) {
196:     const checked = validateCertifiedEntry(entry, context);
197:     if (!checked.ok) return checked;
198:     const next = checked.value;
199:     if (next.entry.payload.kind === 'cheat-proof') {
200:       const claim = next.entry.payload.claim;
201:       const finding = next.crypto?.cheats.find(
202:         (item) => item.seat === claim.seat && item.kind === claim.evidence.kind,
203:       );
204:       if (!finding)
205:         return failure('cheat-replay', 'Certified cheat record has no replayed finding');
206:       verifiedFindings.set(
207:         toHex(hashValue({ domain: 'cp2p/v1/cheat-claim-cache', claim })),
208:         finding,
209:       );
210:     }
211:     certified.push({ entry: next.entry, certificate: next.certificate });
212:     if (next.input !== null) inputs.push(next.input);
213:     events.push(...next.events);
214:     const advanced = advanceContext(context, next);
215:     if (!advanced.ok) return advanced;
216:     if (advanced.value.log.authority !== context.log.authority) {
217:       controllerTimeline.push({
218:         atSeq: next.entry.seq,
219:         authority: advanced.value.log.authority,
220:         epoch: advanced.value.log.crypto?.epoch ?? advanced.value.log.authority?.epoch ?? 0,
221:       });
222:     }
223:     const visited = onEntry?.(next, advanced.value);
224:     if (visited && !visited.ok) return visited;
225:     context = advanced.value;
226:   }
227:   return success({ context, entries: certified, inputs, events });
228: }
229: 
230: /** A cache for display/load speed, always checked against the certified replay before voting. */
231: export function snapshotFromContext(context: ProposalContext) {
232:   return canonicalDecode(
233:     canonicalEncode({
234:       genesisDigest: context.membership.genesisDigest,
235:       seq: context.log.head.seq,
236:       hash: entryHash(context.log.head),
237:       state: context.log.state,
238:       crypto: context.log.crypto,
239:       authority: context.log.authority ?? null,
240:       recovery: context.log.recovery ?? null,
241:       transfer: context.log.transfer ?? null,
242:       timers: context.log.timers ?? [],
243:       lastNonces: [...context.log.lastNonces].toSorted(([a], [b]) => a - b),
244:       membership: context.membership,
245:       excludedProposers: context.excludedProposers,
246:     }),
247:   );
248: }
249: 
250: export function verifyReplaySnapshot(value: unknown, context: ProposalContext): Result<void> {
```


## `packages/protocol/src/journal.ts`


### ProtocolJournal contract and durable load/commit semantics (lines 1-129)

```ts
1: import { canonicalDecode, canonicalEncode } from '@cp2p/codec';
2: import * as v from 'valibot';
3: import { entryHash } from './genesis.js';
4: import { certifiedEntrySchema } from './proposal.js';
5: import type { CertifiedEntry } from './proposal.js';
6: import type { SafetyStore, StoredSafety } from './safety-store.js';
7: import { logEntrySchema } from './schemas.js';
8: import type { LogEntry } from './types.js';
9: 
10: export interface JournalRecord {
11:   genesis: LogEntry;
12:   entries: CertifiedEntry[];
13:   /** The next height, initialized atomically with the committed parent. */
14:   height: number;
15:   safety: StoredSafety;
16: }
17: 
18: /** All writes are atomic. Failed writes must leave both history and votes intact. */
19: export interface ProtocolJournal {
20:   load(): Promise<JournalRecord | null>;
21:   initialize(genesis: LogEntry, safety: Uint8Array): Promise<boolean>;
22:   loadSafety(height: number): Promise<StoredSafety | null>;
23:   saveSafety(height: number, revision: number, bytes: Uint8Array): Promise<boolean>;
24:   commit(
25:     height: number,
26:     safetyRevision: number,
27:     certified: CertifiedEntry,
28:     nextSafety: Uint8Array,
29:   ): Promise<boolean>;
30: }
31: 
32: /**
33:  * A height's controller can restore and update its votes, but cannot initialize
34:  * missing records. Only the journal's certified-parent transaction opens a height.
35:  */
36: export function journalSafetyStore(journal: ProtocolJournal, height: number): SafetyStore {
37:   return {
38:     load: () => journal.loadSafety(height),
39:     save: (revision, bytes) =>
40:       revision === null ? Promise.resolve(false) : journal.saveSafety(height, revision, bytes),
41:   };
42: }
43: 
44: function copySafety(record: StoredSafety): StoredSafety {
45:   return { revision: record.revision, bytes: record.bytes.slice() };
46: }
47: 
48: function copyEntry(entry: LogEntry): LogEntry {
49:   return v.parse(logEntrySchema, canonicalDecode(canonicalEncode(entry)));
50: }
51: 
52: function copyCertified(certified: CertifiedEntry): CertifiedEntry {
53:   return v.parse(certifiedEntrySchema, canonicalDecode(canonicalEncode(certified)));
54: }
55: 
56: /** Retain this object across simulated process crashes. It has no reset operation. */
57: export class MemoryProtocolJournal implements ProtocolJournal {
58:   private record: JournalRecord | null = null;
59: 
60:   async load(): Promise<JournalRecord | null> {
61:     const record = this.record;
62:     return record === null
63:       ? null
64:       : {
65:           genesis: copyEntry(record.genesis),
66:           entries: record.entries.map(copyCertified),
67:           height: record.height,
68:           safety: copySafety(record.safety),
69:         };
70:   }
71: 
72:   async initialize(genesis: LogEntry, safety: Uint8Array): Promise<boolean> {
73:     if (this.record !== null || genesis.seq !== 0 || !(safety instanceof Uint8Array)) return false;
74:     this.record = {
75:       genesis: copyEntry(genesis),
76:       entries: [],
77:       height: 1,
78:       safety: { revision: 0, bytes: safety.slice() },
79:     };
80:     return true;
81:   }
82: 
83:   async loadSafety(height: number): Promise<StoredSafety | null> {
84:     return this.record?.height === height ? copySafety(this.record.safety) : null;
85:   }
86: 
87:   async saveSafety(height: number, revision: number, bytes: Uint8Array): Promise<boolean> {
88:     const record = this.record;
89:     if (
90:       record === null ||
91:       record.height !== height ||
92:       record.safety.revision !== revision ||
93:       !Number.isSafeInteger(revision) ||
94:       revision < 0 ||
95:       !Number.isSafeInteger(revision + 1) ||
96:       !(bytes instanceof Uint8Array)
97:     )
98:       return false;
99:     record.safety = { revision: revision + 1, bytes: bytes.slice() };
100:     return true;
101:   }
102: 
103:   async commit(
104:     height: number,
105:     safetyRevision: number,
106:     certified: CertifiedEntry,
107:     nextSafety: Uint8Array,
108:   ): Promise<boolean> {
109:     const record = this.record;
110:     if (
111:       record === null ||
112:       record.height !== height ||
113:       record.safety.revision !== safetyRevision ||
114:       certified.entry.seq !== height ||
115:       !Number.isSafeInteger(height + 1) ||
116:       !(nextSafety instanceof Uint8Array)
117:     )
118:       return false;
119:     const parent = record.entries.at(-1)?.entry ?? record.genesis;
120:     if (certified.entry.prevHash !== entryHash(parent)) return false;
121:     // Copy before mutation: a failed copy cannot append a partial transaction.
122:     const stored = copyCertified(certified);
123:     const safety = { revision: 0, bytes: nextSafety.slice() };
124:     record.entries.push(stored);
125:     record.height = height + 1;
126:     record.safety = safety;
127:     return true;
128:   }
129: }
```


## `packages/protocol/src/index.ts`


### Public master-reveal exports (lines 310-335)

```ts
310: export { loadRecoveredHost } from './recovered-host.js';
311: export type { RecoveredHost, RecoveredHostInput } from './recovered-host.js';
312: export { RecoveryParticipant } from './recovery-participant.js';
313: export type {
314:   RecoveryParticipantOptions,
315:   PreparedRecoveryPackets,
316: } from './recovery-participant.js';
317: export { auditCertifiedGame } from './audit.js';
318: export type { AuditCertifiedGameInput } from './audit.js';
319: export type { AuditReport, AuditViolation, AuditInputError, AuditEntryRef } from './audit-types.js';
320: export {
321:   MasterRevealCoordinator,
322:   signedMasterRevealSchema,
323:   verifyMasterReveal,
324: } from './master-reveal.js';
325: export type {
326:   MasterRevealOptions,
327:   MasterRevealStore,
328:   MasterRevealVerdict,
329:   SignedMasterReveal,
330: } from './master-reveal.js';
331: export type {
332:   SessionAuditInput,
333:   SessionAuditJob,
334:   SessionAuditRunner,
335:   SessionAuditState,
```


## `packages/protocol/package.json`


### Package export map (lines 1-31)

```ts
1: {
2:   "name": "@cp2p/protocol",
3:   "version": "0.0.0",
4:   "private": true,
5:   "type": "module",
6:   "sideEffects": false,
7:   "exports": {
8:     ".": {
9:       "types": "./src/index.ts",
10:       "@cp2p/source": "./src/index.ts",
11:       "default": "./dist/index.js"
12:     },
13:     "./testing": {
14:       "types": "./src/testing.ts",
15:       "@cp2p/source": "./src/testing.ts",
16:       "default": "./dist/testing.js"
17:     }
18:   },
19:   "scripts": {
20:     "build": "tsc -b"
21:   },
22:   "dependencies": {
23:     "@cp2p/codec": "workspace:*",
24:     "@cp2p/crypto": "workspace:*",
25:     "@cp2p/engine": "workspace:*",
26:     "valibot": "^1.0.0"
27:   },
28:   "devDependencies": {
29:     "fast-check": "^4.0.0"
30:   }
31: }
```

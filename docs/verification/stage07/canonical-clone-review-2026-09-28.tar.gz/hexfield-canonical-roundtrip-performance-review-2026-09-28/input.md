Read-only performance design review for Claude Opus 5.5, medium effort. Do not execute tools or edit code. Propose the smallest safe next improvement. Do not broaden caches or change signing, quorum, admission checks or deadlines.

The paired profiles used isolated Node 22.23.3 trees, real-crypto scenario 6, seed 42, game index 0 and unchanged 60-second diagnostic caps. The only source difference was the full owned-genesis text memo. Baseline reached revision 148 / turn 28; candidate reached 147 / 28. There was NO measured overall progress gain. Inclusive contextStamp samples fell from 6,913.6 to 3,952.7 ms. Candidate inclusive costs include canonicalDecode 12,478.4 ms, copyConsensusStateData 6,523.8 ms and canonicalEncode 16,408.7 ms. These costs overlap. All 459 source and 217 compiled-JavaScript hashes per tree remained unchanged. The exact comparison is included below.

Root proposes an internal canonicalClone path that generates canonical text from the supplied VALUE, then parses its OWN output. This could remove redundant UTF-8 conversion and canonicalDecode re-encoding for a roundtrip created entirely inside the codec. Do not expose a helper accepting caller-provided trusted text, bytes or flags. Public untrusted canonicalDecode must keep full canonical byte equality and all existing rejections. Network parseCanonical must keep its 256 KiB limit based on UTF-8 BYTES, not JavaScript string length, and every schema check.

Current boundaries:
- copyConsensusStateData runs v.parse(stateSchema, canonicalDecode(canonicalEncode(state))). Copies must remain detached and schema-checked. The function confers no authority, including when its caller supplies an arbitrary value.
- Private ownedStates WeakSet membership permits internal transition processing; cloning must not create membership or validation authority.
- transition serializes its generated copy, decodes those same bytes and checks stateSchema again.
- restoreConsensusState copies unknown input, then validates all votes, locks and certified context. Durable safety records intentionally have no network 256 KiB cap.
- ConsensusController reads untrusted durable BYTES through public canonicalDecode. Keep that byte validation. Keep all snapshot, dispatch and persistence call points and exact context stamps.

Please assess the own-output clone semantics against the old roundtrip for Uint8Array and byte tags; sparse or extra-property arrays; null-prototype and __proto__ records; reserved $b records; -0, non-finite and fractional numbers; surrogates and Unicode; accessors, prototypes and cycles; detached ownership; schema behavior and error classification. Identify the smallest first consumers. Explain whether parseCanonical should remain unchanged initially, or whether a later clone-and-size helper can safely preserve its byte limit.

Return minimal pseudocode/API, precise scope, meaningful differential/property tests and safety/controller integration checks. Distinguish measured costs from expected gains and remaining uncertainty. No broader cache or implementation is requested yet.

### packages/codec/src/canonical.ts
import { utf8ToBytes } from '@noble/hashes/utils.js';

/** Values accepted by the canonical JSON-like encoder. */
export type CanonicalValue =
  | null
  | boolean
  | number
  | string
  | Uint8Array
  | readonly CanonicalValue[]
  | { readonly [key: string]: CanonicalValue };

const BYTE_TAG = '$b';
const BASE64URL = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';

interface Utf8Decoder {
  decode(input: Uint8Array): string;
}

interface Utf8DecoderConstructor {
  new (label?: string, options?: { fatal?: boolean }): Utf8Decoder;
}

declare const TextDecoder: Utf8DecoderConstructor;

function decoder(): Utf8Decoder {
  return new TextDecoder('utf-8', { fatal: true });
}

function toBase64UrlInternal(bytes: Uint8Array): string {
  let encoded = '';
  for (let index = 0; index < bytes.length; index += 3) {
    const first = bytes[index] ?? 0;
    const hasSecond = index + 1 < bytes.length;
    const hasThird = index + 2 < bytes.length;
    const second = hasSecond ? (bytes[index + 1] ?? 0) : 0;
    const third = hasThird ? (bytes[index + 2] ?? 0) : 0;
    const group = (first << 16) | (second << 8) | third;
    encoded += BASE64URL.charAt((group >>> 18) & 63);
    encoded += BASE64URL.charAt((group >>> 12) & 63);
    if (hasSecond) encoded += BASE64URL.charAt((group >>> 6) & 63);
    if (hasThird) encoded += BASE64URL.charAt(group & 63);
  }
  return encoded;
}

function fromBase64UrlInternal(encoded: string): Uint8Array {
  if (!/^[A-Za-z0-9_-]*$/.test(encoded) || encoded.length % 4 === 1) {
    throw new TypeError('Byte tag must use unpadded base64url.');
  }
  const length = Math.floor((encoded.length * 6) / 8);
  const bytes = new Uint8Array(length);
  let accumulator = 0;
  let bitCount = 0;
  let outputIndex = 0;
  for (const character of encoded) {
    const value = BASE64URL.indexOf(character);
    if (value < 0) throw new TypeError('Byte tag must use unpadded base64url.');
    accumulator = (accumulator << 6) | value;
    bitCount += 6;
    if (bitCount >= 8) {
      bitCount -= 8;
      bytes[outputIndex] = (accumulator >>> bitCount) & 255;
      outputIndex += 1;
      accumulator &= (1 << bitCount) - 1;
    }
  }
  if (toBase64UrlInternal(bytes) !== encoded) {
    throw new TypeError('Byte tag must use canonical base64url.');
  }
  return bytes;
}

function isPlainObject(value: object): boolean {
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function encodeValue(value: unknown, ancestors: WeakSet<object>): string {
  if (value === null) return 'null';
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  if (typeof value === 'string') return JSON.stringify(value);
  if (typeof value === 'number') {
    if (!Number.isInteger(value)) {
      throw new TypeError('Canonical encoding accepts integers only.');
    }
    return JSON.stringify(value);
  }
  if (value instanceof Uint8Array) {
    return `{"${BYTE_TAG}":${JSON.stringify(toBase64UrlInternal(value))}}`;
  }
  if (typeof value !== 'object') {
    throw new TypeError(`Unsupported canonical value: ${typeof value}.`);
  }
  if (ancestors.has(value))
    throw new TypeError('Canonical encoding does not accept cyclic values.');
  ancestors.add(value);
  try {
    if (Array.isArray(value)) {
      const ownKeys = Reflect.ownKeys(value);
      if (ownKeys.length !== value.length + 1 || ownKeys.some((key) => typeof key === 'symbol')) {
        throw new TypeError('Canonical arrays cannot have holes or extra properties.');
      }
      const items: string[] = [];
      for (let index = 0; index < value.length; index += 1) {
        if (!Object.hasOwn(value, index))
          throw new TypeError('Canonical arrays cannot have holes.');
        const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
        if (!descriptor || !('value' in descriptor) || !descriptor.enumerable) {
          throw new TypeError('Canonical arrays must contain plain data elements.');
        }
        items.push(encodeValue(descriptor.value, ancestors));
      }
      return `[${items.join(',')}]`;
    }
    if (!isPlainObject(value)) throw new TypeError('Canonical objects must be plain records.');

    const ownKeys = Reflect.ownKeys(value);
    if (ownKeys.some((key) => typeof key !== 'string')) {
      throw new TypeError('Canonical objects cannot contain symbol keys.');
    }
    const keys: string[] = [];
    for (const key of ownKeys) {
      if (typeof key !== 'string')
        throw new TypeError('Canonical objects cannot contain symbol keys.');
      keys.push(key);
    }
    if (keys.length === 1 && keys[0] === BYTE_TAG) {
      throw new TypeError('An exact one-key $b object is reserved for Uint8Array values.');
    }
    const entries = keys.toSorted().map((key) => {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor || !('value' in descriptor) || !descriptor.enumerable) {
        throw new TypeError('Canonical objects must contain enumerable data properties.');
      }
      return `${JSON.stringify(key)}:${encodeValue(descriptor.value, ancestors)}`;
    });
    return `{${entries.join(',')}}`;
  } finally {
    ancestors.delete(value);
  }
}

/** Internal text representation for exact in-process comparisons; wire data remains UTF-8. */
export function canonicalText(value: unknown): string {
  return encodeValue(value, new WeakSet<object>());
}

/** Encodes plain JSON-like values as canonical UTF-8 bytes. */
export function canonicalEncode(value: unknown): Uint8Array {
  return utf8ToBytes(canonicalText(value));
}

function isPlainRecord(value: unknown): value is Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function decodeTagged(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(decodeTagged);
  if (typeof value !== 'object' || value === null) return value;
  if (!isPlainRecord(value)) throw new TypeError('Decoded objects must be plain records.');
  const keys = Object.keys(value);
  if (keys.length === 1 && keys[0] === BYTE_TAG) {
    const encoded = value[BYTE_TAG];
    if (typeof encoded !== 'string') throw new TypeError('Byte tag value must be a string.');
    return fromBase64UrlInternal(encoded);
  }
  const decoded: Record<string, unknown> = {};
  for (const key of keys) {
    Object.defineProperty(decoded, key, {
      value: decodeTagged(value[key]),
      enumerable: true,
      writable: true,
      configurable: true,
    });
  }
  return decoded;
}

/** Decodes canonical UTF-8 bytes and byte tags, rejecting alternate JSON representations. */
export function canonicalDecode(bytes: Uint8Array): unknown {
  if (!(bytes instanceof Uint8Array)) throw new TypeError('Canonical input must be a Uint8Array.');
  let parsed: unknown;
  try {
    parsed = JSON.parse(decoder().decode(bytes)) as unknown;
  } catch (error) {
    throw new TypeError(`Invalid canonical JSON bytes: ${String(error)}`, { cause: error });
  }
  const value = decodeTagged(parsed);
  const encoded = canonicalEncode(value);
  if (encoded.length !== bytes.length || encoded.some((byte, index) => byte !== bytes[index])) {
    throw new TypeError('Input bytes are not in canonical encoding.');
  }
  return value;
}

/** Converts bytes to unpadded base64url. */
export function toBase64Url(bytes: Uint8Array): string {
  return toBase64UrlInternal(bytes);
}

/** Converts canonical unpadded base64url to bytes. */
export function fromBase64Url(encoded: string): Uint8Array {
  return fromBase64UrlInternal(encoded);
}


### packages/codec/src/canonical.test.ts
import { describe, expect, test } from 'vitest';
import * as publicCodec from './index.js';
import { canonicalText } from './internal.js';
import {
  canonicalDecode,
  canonicalEncode,
  fromBase64Url,
  hashValue,
  sha256,
  toBase64Url,
  toHex,
} from './index.js';

function utf8(bytes: Uint8Array): string {
  return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
}

function mustThrow(action: () => unknown): void {
  expect(action).toThrow(/./);
}

describe('canonical codec', () => {
  test('internal canonical text preserves Unicode distinctions without a wire change', () => {
    expect(Object.hasOwn(publicCodec, 'canonicalText')).toBe(false);
    for (const value of ['é', 'e\u0301', '🌲', '\ud800', '\ud801']) {
      expect(canonicalText({ text: value })).toBe(`{"text":${JSON.stringify(value)}}`);
      expect(new TextEncoder().encode(canonicalText({ text: value }))).toEqual(
        canonicalEncode({ text: value }),
      );
      expect(canonicalDecode(canonicalEncode({ text: value }))).toEqual({ text: value });
    }
    // UTF-8 encoders replace lone surrogates in raw strings. Canonical JSON
    // escapes them, so the guard must continue distinguishing the originals.
    expect(canonicalText('\ud800')).not.toBe(canonicalText('\ud801'));
    expect(canonicalText('é')).not.toBe(canonicalText('e\u0301'));
  });

  test('sorts keys by UTF-16 code units and ignores insertion order', () => {
    const first = { z: 1, a: { y: 2, x: 3 }, '😀': 4, ä: 5 };
    const second = { ä: 5, '😀': 4, a: { x: 3, y: 2 }, z: 1 };
    expect(canonicalEncode(first)).toEqual(canonicalEncode(second));
    expect(utf8(canonicalEncode(first))).toBe('{"a":{"x":3,"y":2},"z":1,"ä":5,"😀":4}');
  });

  test('round-trips JSON-like values and nested byte arrays', () => {
    const value = {
      empty: new Uint8Array(),
      nested: [null, true, -3, 'snowman ☃', new Uint8Array([0, 1, 127, 128, 255])],
      object: { $b: 'ordinary because this has another key', value: 7 },
    };
    expect(canonicalDecode(canonicalEncode(value))).toEqual(value);
    const specialKeyValue: Record<string, unknown> = {};
    Object.defineProperty(specialKeyValue, '__proto__', {
      value: 1,
      enumerable: true,
      writable: true,
      configurable: true,
    });
    expect(canonicalDecode(canonicalEncode(specialKeyValue))).toEqual(specialKeyValue);
    expect(utf8(canonicalEncode(new Uint8Array([0, 1, 2, 253, 254, 255])))).toBe(
      '{"$b":"AAEC_f7_"}',
    );
  });

  test('rejects reserved one-key byte-tag objects on encode', () => {
    mustThrow(() => canonicalEncode({ $b: 'AA' }));
    mustThrow(() => canonicalEncode({ $b: 1 }));
    expect(canonicalDecode(canonicalEncode({ $b: 'ordinary', extra: 1 }))).toEqual({
      $b: 'ordinary',
      extra: 1,
    });
  });

  test('rejects floats, undefined, holes, unsupported objects and cycles', () => {
    expect(() => canonicalEncode(1.25)).toThrow(/./);
    mustThrow(() => canonicalEncode(Number.NaN));
    mustThrow(() => canonicalEncode(Number.POSITIVE_INFINITY));
    mustThrow(() => canonicalEncode({ missing: undefined }));
    const sparse: unknown[] = [];
    sparse.length = 2;
    sparse[1] = 1;
    mustThrow(() => canonicalEncode(sparse));
    mustThrow(() => canonicalEncode(new Date(0)));
    const cyclic: { self?: unknown } = {};
    cyclic.self = cyclic;
    mustThrow(() => canonicalEncode(cyclic));
  });

  test('encodes repeated object references like duplicated values', () => {
    const shared = { count: 0 };
    expect(canonicalEncode([shared, shared])).toEqual(
      canonicalEncode([{ count: 0 }, { count: 0 }]),
    );
  });

  test('decodes only canonical JSON and canonical byte tags', () => {
    mustThrow(() => canonicalDecode(new TextEncoder().encode('{ "a":1}')));
    mustThrow(() => canonicalDecode(new TextEncoder().encode('{"b":1,"a":2}')));
    mustThrow(() => canonicalDecode(new TextEncoder().encode('{"a":1,"a":1}')));
    mustThrow(() => canonicalDecode(new TextEncoder().encode('{"$b":1}')));
    mustThrow(() => canonicalDecode(new TextEncoder().encode('{"$b":"AA=="}')));
    mustThrow(() => canonicalDecode(new TextEncoder().encode('{"$b":"AB"}')));
    mustThrow(() => canonicalDecode(new Uint8Array([0xff])));
    expect(canonicalDecode(new TextEncoder().encode('{"$b":"AA"}'))).toEqual(new Uint8Array([0]));
  });

  test('base64url helpers use canonical unpadded encoding', () => {
    for (const bytes of [
      new Uint8Array(),
      new Uint8Array([0]),
      new Uint8Array([255]),
      new Uint8Array([1, 2, 3, 4]),
    ]) {
      expect(fromBase64Url(toBase64Url(bytes))).toEqual(bytes);
    }
    expect(toBase64Url(new Uint8Array([0, 0, 0]))).toBe('AAAA');
    mustThrow(() => fromBase64Url('A'));
    mustThrow(() => fromBase64Url('AA=='));
    mustThrow(() => fromBase64Url('AB'));
  });

  test('pins SHA-256 and canonical value hashes to known answers', () => {
    const bytes = new TextEncoder().encode('{"a":1,"b":2}');
    expect(toHex(sha256(bytes))).toBe(
      '43258cff783fe7036d8a43033f830adfc60ec037382473548ac742b888292777',
    );
    expect(toHex(hashValue({ b: 2, a: 1 }))).toBe(
      '43258cff783fe7036d8a43033f830adfc60ec037382473548ac742b888292777',
    );
  });
});


### packages/codec/src/internal.ts
export { canonicalText } from './canonical.js';


### packages/codec/package.json
{
  "name": "@cp2p/codec",
  "version": "0.0.0",
  "private": true,
  "type": "module",
  "sideEffects": false,
  "exports": {
    ".": {
      "types": "./src/index.ts",
      "@cp2p/source": "./src/index.ts",
      "default": "./dist/index.js"
    },
    "./internal": {
      "types": "./src/internal.ts",
      "@cp2p/source": "./src/internal.ts",
      "default": "./dist/internal.js"
    }
  },
  "scripts": {
    "build": "tsc -b"
  },
  "dependencies": {
    "@noble/hashes": "^2.0.0"
  },
  "devDependencies": {
    "fast-check": "^4.0.0"
  }
}


### packages/protocol/src/validation.ts
import { canonicalDecode, canonicalEncode } from '@cp2p/codec';
import { failure, success } from '@cp2p/engine';
import type { Result } from '@cp2p/engine';
import * as v from 'valibot';

export const MAX_MESSAGE_BYTES = 256 * 1024;

/** Copy and validate untrusted data before retaining any of its references. */
export function parseCanonical<T>(value: unknown, schema: v.GenericSchema<unknown, T>): Result<T> {
  try {
    const bytes = canonicalEncode(value);
    if (bytes.byteLength > MAX_MESSAGE_BYTES)
      return failure('message-too-large', 'Protocol value exceeds 256 KiB');
    const parsed = v.safeParse(schema, canonicalDecode(bytes));
    return parsed.success
      ? success(parsed.output)
      : failure('invalid-envelope', 'Protocol value does not match its schema');
  } catch {
    return failure('invalid-encoding', 'Protocol value is not canonical data');
  }
}


### packages/protocol/src/consensus-controller.ts
import { canonicalDecode, canonicalEncode, sha256, toHex } from '@cp2p/codec';
import { identityFromSecret } from '@cp2p/crypto';
import { failure, success } from '@cp2p/engine';
import type { Result, Seat } from '@cp2p/engine';
import {
  copyConsensusStateData,
  createConsensusState,
  openOwnedConsensusState,
  recoverConsensusEffects,
  restoreConsensusState,
} from './consensus.js';
import type {
  ConsensusEffect,
  ConsensusEvent,
  LocalVoteAdmissibility,
  OwnedConsensusState,
  ConsensusState,
  ConsensusTransition,
} from './consensus.js';
import type { ProposalContext } from './proposal.js';
import type { SafetyStore, StoredSafety } from './safety-store.js';
import { MAX_MESSAGE_BYTES } from './validation.js';

export type { ConsensusEvent } from './consensus.js';

export interface ConsensusControllerOptions {
  context: ProposalContext;
  seat: Seat;
  secretKey: Uint8Array;
  /** One record for this game/key/height, retained across controller crashes. */
  store: SafetyStore;
  /** Repair must reuse exact durable bytes without normalizing newly found terminal evidence. */
  requireExactRestore?: boolean;
  /** Effects are at-least-once. Handlers must deduplicate committed sequence/value. */
  onEffects: (effects: readonly ConsensusEffect[]) => void | Promise<void>;
  /** Local admission only. It must not alter replay or objective validity. */
  beforePersist?: (previous: ConsensusState, next: ConsensusState) => Result<void>;
  admitLocalValue?: LocalVoteAdmissibility;
}

/**
 * Serializes a single height's transitions and persists before emission.
 * Opening the next height requires a separately persisted certified parent.
 */
export class ConsensusController {
  private queue: Promise<unknown> = Promise.resolve();
  private stopped = false;
  private contextFault = false;
  private persistedBytes: Uint8Array;
  private readonly secretKey: Uint8Array;
  private readonly rejectedProposals = new Map<string, { code: string; message: string }>();

  private constructor(
    private readonly options: ConsensusControllerOptions,
    private state: ConsensusState,
    private revision: number,
    private readonly owned: OwnedConsensusState,
  ) {
    this.secretKey = options.secretKey.slice();
    this.persistedBytes = canonicalEncode(state);
  }

  /** Only for a genuinely new height; existing or lost stores are not reset here. */
  static async create(options: ConsensusControllerOptions): Promise<Result<ConsensusController>> {
    const validKey = checkLocalKey(options);
    if (!validKey.ok) return validKey;
    const initial = createConsensusState(options.context, options.seat);
    if (!initial.ok) return initial;
    try {
      if (await options.store.load())
        return failure(
          'consensus-store-exists',
          'Restore existing vote records instead of resetting',
        );
      const owned = openOwnedConsensusState(initial.value, options.context, options.seat);
      if (!owned.ok) return owned;
      const saved = await options.store.save(null, canonicalEncode(initial.value));
      if (!saved)
        return failure('consensus-write-conflict', 'Another writer initialized this voting record');
      return success(new ConsensusController(options, initial.value, 0, owned.value));
    } catch {
      return failure('consensus-storage', 'Could not persist the initial voting record');
    }
  }

  /** An absent or damaged record fails closed; this never creates round-one state. */
  static async restore(options: ConsensusControllerOptions): Promise<Result<ConsensusController>> {
    const validKey = checkLocalKey(options);
    if (!validKey.ok) return validKey;
    let record: StoredSafety | null;
    try {
      record = await options.store.load();
    } catch {
      return failure('consensus-storage', 'Could not read the voting record');
    }
    if (!record)
      return failure(
        'consensus-store-missing',
        'The voting record is missing; key replacement is required',
      );
    if (!Number.isSafeInteger(record.revision) || record.revision < 0)
      return failure('consensus-storage', 'Stored voting revision is invalid');
    let restored: Result<ConsensusState>;
    try {
      restored = restoreConsensusState(
        canonicalDecode(record.bytes),
        options.context,
        options.seat,
      );
    } catch {
      return failure('consensus-storage', 'Stored voting data is not valid canonical data');
    }
    if (!restored.ok) return restored;
    let revision = record.revision;
    const normalized = canonicalEncode(restored.value);
    if (!sameBytes(normalized, record.bytes)) {
      if (options.requireExactRestore || restored.value.haltKind !== 'terminal')
        return failure('consensus-restore', 'Voting record changed without a terminal proof');
      try {
        if (!(await options.store.save(revision, normalized)))
          return failure('consensus-write-conflict', 'Voting record changed during terminal halt');
      } catch {
        return failure('consensus-storage', 'Could not persist the verified terminal halt');
      }
      revision++;
    }
    const owned = openOwnedConsensusState(restored.value, options.context, options.seat);
    return owned.ok
      ? success(new ConsensusController(options, restored.value, revision, owned.value))
      : owned;
  }

  /** Returns a detached, verified snapshot, never the mutable internal record. */
  snapshot(): Result<ConsensusState> {
    const snapshot = this.owned.snapshot();
    if (!snapshot.ok) {
      this.stopVoting(snapshot.error.code);
      return snapshot;
    }
    if (!sameBytes(canonicalEncode(snapshot.value), canonicalEncode(this.state))) {
      this.stopVoting();
      return failure('consensus-restore', 'Restore to persist newly verified terminal evidence');
    }
    return snapshot;
  }

  /** The opening stamp remains usable after the mutable derived context fails its guard. */
  opensOn(context: ProposalContext): boolean {
    return this.owned.matchesOpenedContext(context);
  }

  hasContextFault(): boolean {
    return this.contextFault;
  }

  settled(): Promise<void> {
    return this.queue.then(
      () => undefined,
      () => undefined,
    );
  }

  matchesPersistedRecord(record: StoredSafety): boolean {
    return record.revision === this.revision && sameBytes(record.bytes, this.persistedBytes);
  }

  /** Expected CAS revision for atomically committing this controller's height. */
  persistedRevision(): number {
    return this.revision;
  }

  /** Call after restoring to retransmit signed records and re-arm timers. */
  resume(): Promise<Result<void>> {
    return this.enqueue(async () => {
      const snapshot = this.snapshot();
      if (!snapshot.ok) return snapshot;
      const recovered = recoverConsensusEffects(this.state, this.options.context);
      if (!recovered.ok) {
        this.stopVoting();
        return recovered;
      }
      return this.emit(recovered.value);
    });
  }

  dispatch(event: ConsensusEvent): Promise<Result<void>> {
    return this.enqueue(async () => {
      if (event.kind === 'proposal' && this.isRecordedProposalReplay(event.proposal)) {
        const checked = this.snapshot();
        return checked.ok ? success(undefined) : checked;
      }
      const proposalKey = event.kind === 'proposal' ? this.proposalKey(event.proposal) : null;
      const rejected = proposalKey ? this.rejectedProposals.get(proposalKey) : undefined;
      if (rejected) {
        const checked = this.snapshot();
        if (!checked.ok) return checked;
        return failure(rejected.code, rejected.message, {
          proposalEntryRejected: true,
          cached: true,
        });
      }
      const next = this.reduce(event);
      if (!next.ok) {
        if (next.error.code === 'consensus-restore' || next.error.code === 'consensus-context')
          this.stopVoting(next.error.code);
        else if (
          proposalKey &&
          next.error.details?.proposalEntryRejected === true &&
          next.error.details.proposalControl !== true
        ) {
          // Entry validation depends on this controller's fixed certified parent,
          // not its current round/votes. Controls can discover a second offender
          // after another proof is retained, so always reconsider them.
          this.rejectedProposals.set(proposalKey, {
            code: next.error.code,
            message: next.error.message,
          });
          if (this.rejectedProposals.size > 16) {
            const oldest = this.rejectedProposals.keys().next().value;
            if (oldest !== undefined) this.rejectedProposals.delete(oldest);
          }
        }
        return next;
      }
      const candidate = next.value.state;
      const admitted = this.options.beforePersist?.(
        copyConsensusStateData(this.state),
        copyConsensusStateData(candidate),
      );
      if (admitted && !admitted.ok) {
        this.owned.discard();
        return admitted;
      }
      let persistedBytes: Uint8Array;
      try {
        const bytes = canonicalEncode(candidate);
        persistedBytes = bytes.slice();
        if (!(await this.options.store.save(this.revision, bytes))) {
          this.owned.discard();
          this.stopped = true;
          return failure(
            'consensus-write-conflict',
            'Voting stopped because a newer record exists',
          );
        }
      } catch {
        this.owned.discard();
        this.stopped = true;
        return failure(
          'consensus-storage',
          'Voting stopped because its state could not be persisted',
        );
      }
      this.persistedBytes = persistedBytes;
      this.revision += 1;
      const committed = this.owned.commit();
      if (!committed.ok) {
        this.owned.discard();
        this.stopVoting(committed.error.code);
        return committed;
      }
      this.state = copyConsensusStateData(candidate);
      // A dispose/crash during the write must not transmit after the write resolves.
      if (this.stopped)
        return failure('consensus-stopped', 'Controller stopped during persistence');
      return this.emit(next.value.effects);
    });
  }

  dispose(): void {
    this.stopVoting();
  }

  private stopVoting(code?: string): void {
    if (code === 'consensus-context') this.contextFault = true;
    this.stopped = true;
    this.secretKey.fill(0);
    this.rejectedProposals.clear();
  }

  private proposalKey(value: unknown): string | null {
    try {
      const bytes = canonicalEncode(value);
      return bytes.length <= MAX_MESSAGE_BYTES ? toHex(sha256(bytes)) : null;
    } catch {
      return null;
    }
  }

  /** Stored proposals were validated before persistence; exact replays need no transition. */
  private isRecordedProposalReplay(value: unknown): boolean {
    let bytes: Uint8Array;
    try {
      bytes = canonicalEncode(value);
    } catch {
      return false;
    }
    if (bytes.byteLength > MAX_MESSAGE_BYTES) return false;
    const recorded = [
      ...this.state.proposals,
      ...this.state.hints.flatMap((hint) => (hint.kind === 'proposal' ? [hint.proposal] : [])),
    ].find((proposal) => sameBytes(bytes, canonicalEncode(proposal)));
    if (!recorded) return false;
    // A proposal retained before entering its round may still need its first vote.
    return !(
      recorded.body.entry.term === this.state.round &&
      this.state.step === 'propose' &&
      !this.state.votes.some(
        (vote) =>
          vote.body.seat === this.state.localSeat &&
          vote.body.term === this.state.round &&
          vote.body.phase === 'prevote',
      )
    );
  }

  private enqueue(operation: () => Promise<Result<void>>): Promise<Result<void>> {
    const result = this.queue.then(async (): Promise<Result<void>> => {
      if (this.stopped)
        return failure('consensus-stopped', 'Restore the persisted record before continuing');
      try {
        return await operation();
      } catch {
        this.owned.discard();
        this.stopVoting();
        return failure('consensus-controller', 'Consensus transition failed; voting has stopped');
      }
    });
    this.queue = result;
    return result;
  }

  private reduce(event: ConsensusEvent): Result<ConsensusTransition> {
    return this.owned.dispatch(event, this.secretKey, this.options.admitLocalValue);
  }

  private async emit(effects: readonly ConsensusEffect[]): Promise<Result<void>> {
    if (effects.length === 0) return success(undefined);
    try {
      await this.options.onEffects(effects);
      return success(undefined);
    } catch {
      // The saved state can reproduce signed messages after a partial delivery.
      this.stopped = true;
      return failure('consensus-effects', 'Effect delivery failed; restore before retrying');
    }
  }
}

function sameBytes(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  for (let index = 0; index < a.length; index++) if (a[index] !== b[index]) return false;
  return true;
}

function checkLocalKey(options: ConsensusControllerOptions): Result<void> {
  try {
    const identity = identityFromSecret(options.secretKey);
    const voter = options.context.membership.voters.find((member) => member.seat === options.seat);
    return voter?.publicKey === identity.peerId
      ? success(undefined)
      : failure('consensus-key', 'The local key does not match the certified voter');
  } catch {
    return failure('consensus-key', 'The local voting key is invalid');
  }
}


### docs/verification/stage07/genesis-text-profile-2026-09-28.md
# Exact owned-genesis text: bounded profile

The context guard now compares full signed-genesis canonical text separately from the rest of the context. Only detached, deeply frozen, byte-free genesis objects created at the existing ownership boundary receive an identity-scoped text memo. Mutable or byte-containing objects still receive full encoding on every check. The text includes gameId and signatures; no digest substitutes for exact content. All runtime references and guard call points remain checked.

The matched profiles demonstrate less work in the context stamp, **without a measured gain in game progress**. Both runs are diagnostics stopped at the unchanged 60-second limit, not acceptance passes.

| Measurement                        | Baseline    | Candidate   |
| ---------------------------------- | ----------- | ----------- |
| Certified revision / turn          | 148 / 28    | 147 / 28    |
| contextStamp inclusive samples     | 6,913.6 ms  | 3,952.7 ms  |
| canonicalText inclusive samples    | 21,863.4 ms | 19,254.4 ms |
| sameContextStamp inclusive samples | 84.8 ms     | 81.7 ms     |
| session flush calls                | 5,500       | 5,497       |
| session flush wall total           | 45,893.1 ms | 43,024.8 ms |

Context-stamp samples fell 42.8%; inclusive sample times overlap and must not be added. Sampling variance and other work prevent attributing an end-to-end gain to this pair. Remaining candidate costs include canonicalDecode (12,478.4 ms) and copyConsensusStateData (6,523.8 ms). No further cache changes are part of this change.

Both runs used isolated copies of the prior paired candidate at f203c5b, Node 22.23.3, real-crypto scenario 6, seed 42, game index 0 and the same 60-second cap. The sole source differences were genesis-identity.ts and consensus.ts. All 459 source and 217 compiled JavaScript hashes per tree matched before and after. Handles were baseline 55290 and candidate 1544; each ended at the diagnostic deadline with exit 1. No other tests or builds ran during either profile.

A separate same-fixture read-only measurement (75655) found the initial stamp contains 75,858 characters: direct genesis 30,735 (40.52%), head 31,103, crypto 8,022 and state 3,374. The sequence-zero head embeds another copy of genesis. Later field proportions were not measured. The measurement ran after both profiles and emitted only sizes.

Correctness run 50372 passed 54/54 tests in 1.52 seconds: genesis identity 7, consensus 15 and controller 32. Regressions cover full gameId/signatures/nested mutable changes during persistence, equivalent mutable replacement, owned input isolation and byte-containing fallback. Shared test typecheck, scoped type-aware lint and formatting (16013) passed; both isolated production builds passed.

[Profile archive](genesis-text-profile-2026-09-28.tar.gz) includes both compressed CPU profiles, diagnostics, manifests, scripts and the exact production-source overlays. SHA-256: `b345cf1e18ff2e0dce90f0ee2ef6963beb5ee99b511744f09dd9bec82d408c8b`.


### packages/protocol/src/consensus.ts lines 130–191
130:     proposal: signedProposalSchema,
131:   }),
132:   v.strictObject({
133:     kind: v.literal('vote'),
134:     seat: seatSchema,
135:     round: positiveIntegerSchema,
136:     vote: signedVoteSchema,
137:   }),
138: ]);
139: const equivocationSchema = v.variant('kind', [
140:   v.strictObject({
141:     kind: v.literal('proposal'),
142:     seat: seatSchema,
143:     round: positiveIntegerSchema,
144:     first: signedProposalSchema,
145:     second: signedProposalSchema,
146:   }),
147:   v.strictObject({
148:     kind: v.literal('vote'),
149:     seat: seatSchema,
150:     round: positiveIntegerSchema,
151:     phase: v.picklist(['prevote', 'precommit']),
152:     first: signedVoteSchema,
153:     second: signedVoteSchema,
154:   }),
155: ]);
156: const certifiedSchema = v.strictObject({
157:   entry: logEntrySchema,
158:   certificate: v.array(signedVoteSchema),
159: });
160: const stateSchema = v.strictObject({
161:   version: v.literal(1),
162:   genesisDigest: key32Schema,
163:   epoch: nonnegativeIntegerSchema,
164:   height: positiveIntegerSchema,
165:   parentHash: hashSchema,
166:   contextHash: hashSchema,
167:   localSeat: seatSchema,
168:   localPublicKey: key32Schema,
169:   round: positiveIntegerSchema,
170:   step: v.picklist(['propose', 'prevote', 'precommit']),
171:   inputKnown: v.boolean(),
172:   timers: v.strictObject({ propose: v.boolean(), prevote: v.boolean(), precommit: v.boolean() }),
173:   proposals: v.array(signedProposalSchema),
174:   votes: v.array(signedVoteSchema),
175:   hints: v.pipe(v.array(hintSchema), v.maxLength(6)),
176:   equivocations: v.array(equivocationSchema),
177:   pendingAccusation: v.nullable(excludeProposerControlSchema),
178:   provenOffender: v.nullable(
179:     v.strictObject({
180:       control: excludeProposerControlSchema,
181:       atSeq: positiveIntegerSchema,
182:       parentHash: hashSchema,
183:     }),
184:   ),
185:   locked: v.nullable(quorumValueSchema),
186:   valid: v.nullable(quorumValueSchema),
187:   decision: v.nullable(certifiedSchema),
188:   halted: v.nullable(v.string()),
189:   haltKind: v.nullable(v.picklist(['certified-validation', 'terminal'])),
190:   unappliedCertificate: v.nullable(certifiedSchema),
191: });

### packages/protocol/src/consensus.ts lines 195–275
195:   contextText: string;
196:   functions: readonly (readonly [string, unknown])[];
197: }
198: 
199: // Only an OwnedConsensusState's private state enters this set. Public transition
200: // functions continue to verify every caller-supplied state in full.
201: const ownedStates = new WeakSet<ConsensusState>();
202: 
203: function nonfunctions(value: object): Record<string, unknown> {
204:   return Object.fromEntries(Object.entries(value).filter(([, item]) => typeof item !== 'function'));
205: }
206: 
207: function runtimeReferences(value: object, name: string): (readonly [string, unknown])[] {
208:   const references: (readonly [string, unknown])[] = [[name, value]];
209:   let current: object | null = value;
210:   for (let depth = 0; current && current !== Object.prototype && depth < 8; depth++) {
211:     references.push([`${name}/prototype/${depth}`, current]);
212:     for (const key of Object.getOwnPropertyNames(current).toSorted()) {
213:       const property = Object.getOwnPropertyDescriptor(current, key);
214:       if (typeof property?.value === 'function')
215:         references.push([`${name}/${key}`, property.value]);
216:       if (property?.get) references.push([`${name}/${key}/get`, Reflect.get(property, 'get')]);
217:       if (property?.set) references.push([`${name}/${key}/set`, Reflect.get(property, 'set')]);
218:     }
219:     current = Object.getPrototypeOf(current);
220:   }
221:   return references;
222: }
223: 
224: function contextStamp(context: ProposalContext): ContextStamp {
225:   const functions: (readonly [string, unknown])[] = [
226:     ...runtimeReferences(context, 'context'),
227:     ...runtimeReferences(context.log, 'log'),
228:     ...runtimeReferences(context.log.engine, 'engine'),
229:     ...runtimeReferences(context.policy, 'policy'),
230:     ...(context.policy.randomDerivations
231:       ? runtimeReferences(context.policy.randomDerivations, 'randomDerivations')
232:       : [['randomDerivations', null] as const]),
233:   ];
234:   const { engine, genesis, ...log } = context.log;
235:   const other = nonfunctions(context);
236:   delete other.log;
237:   delete other.policy;
238:   return {
239:     genesisText: genesisContextText(genesis),
240:     contextText: canonicalText({
241:       ...other,
242:       log: {
243:         ...log,
244:         lastNonces: [...log.lastNonces],
245:         engine: nonfunctions(engine),
246:       },
247:       policy: {
248:         ...nonfunctions(context.policy),
249:         randomDerivations: nonfunctions(context.policy.randomDerivations ?? {}),
250:       },
251:     }),
252:     functions,
253:   };
254: }
255: 
256: function sameContextStamp(left: ContextStamp, right: ContextStamp): boolean {
257:   return (
258:     left.genesisText === right.genesisText &&
259:     left.contextText === right.contextText &&
260:     left.functions.length === right.functions.length &&
261:     left.functions.every(
262:       ([name, value], index) =>
263:         name === right.functions[index]?.[0] && value === right.functions[index]?.[1],
264:     )
265:   );
266: }
267: 
268: /** Detached schema-checked data for observer callbacks; it confers no validation authority. */
269: export function copyConsensusStateData(state: ConsensusState): ConsensusState {
270:   return v.parse(stateSchema, canonicalDecode(canonicalEncode(state)));
271: }
272: 
273: function bound(state: ConsensusState, context: ProposalContext, localSeat: Seat): boolean {
274:   const member = context.membership.voters.find((voter) => voter.seat === localSeat);
275:   return (

### packages/protocol/src/consensus.ts lines 739–766
739: function transition(
740:   state: ConsensusState,
741:   context: ProposalContext,
742:   action: (copy: ConsensusState, effects: ConsensusEffect[]) => Result<void>,
743: ): Result<ConsensusTransition> {
744:   const restored = ownedStates.has(state)
745:     ? success(copyConsensusStateData(state))
746:     : restoreConsensusState(state, context, state.localSeat);
747:   if (!restored.ok) return restored;
748:   const copy = restored.value;
749:   const effects: ConsensusEffect[] = [];
750:   const applied = action(copy, effects);
751:   if (!applied.ok) return applied;
752:   try {
753:     const bytes = canonicalEncode(copy);
754:     const parsed = v.safeParse(stateSchema, canonicalDecode(bytes));
755:     if (!parsed.success)
756:       return failure('consensus-restore', 'Transition produced malformed safety state');
757:     if (ownedStates.has(state)) ownedStates.add(copy);
758:   } catch {
759:     return failure('consensus-restore', 'Transition produced malformed safety state');
760:   }
761:   return success({ state: copy, effects });
762: }
763: 
764: /** Only call this for a genuinely new height after the certified parent is stored. */
765: export function createConsensusState(
766:   context: ProposalContext,

### packages/protocol/src/consensus.ts lines 847–883
847:   value: unknown,
848:   context: ProposalContext,
849:   localSeat: Seat,
850: ): Result<ConsensusState> {
851:   let state: ConsensusState;
852:   try {
853:     // Persisted safety state is not a network envelope and may exceed its 256 KiB cap.
854:     const parsed = v.safeParse(stateSchema, canonicalDecode(canonicalEncode(value)));
855:     if (!parsed.success) return failure('consensus-restore', 'Safety record schema is malformed');
856:     state = parsed.output;
857:   } catch {
858:     return failure('consensus-restore', 'Safety record is not canonical data');
859:   }
860:   if (!bound(state, context, localSeat))
861:     return failure(
862:       'consensus-context',
863:       'Safety record belongs to another height, parent, game, epoch or key',
864:     );
865:   try {
866:     const proposalCounts = new Map<number, number>();
867:     for (const proposal of state.proposals) {
868:       const round = proposal.body.entry.term;
869:       const count = (proposalCounts.get(round) ?? 0) + 1;
870:       if (count > 2)
871:         return failure('consensus-restore', 'Safety record retains too many proposals per round');
872:       proposalCounts.set(round, count);
873:       if (!validateProposal(proposal, context).ok)
874:         return failure('consensus-restore', 'Stored proposal is invalid');
875:     }
876:     for (const vote of state.votes) {
877:       if (
878:         !validateVote(vote, context.membership).ok ||
879:         vote.body.seq !== state.height ||
880:         vote.body.term > state.round
881:       )
882:         return failure('consensus-restore', 'Stored vote is invalid');
883:     }

### packages/protocol/src/consensus.ts lines 1648–1787
1648:   private pending: ConsensusState | null = null;
1649: 
1650:   constructor(
1651:     private state: ConsensusState,
1652:     private readonly context: ProposalContext,
1653:     private readonly stamp: ContextStamp,
1654:   ) {
1655:     ownedStates.add(state);
1656:   }
1657: 
1658:   matchesOpenedContext(candidate: ProposalContext): boolean {
1659:     try {
1660:       const replayed = contextStamp(candidate);
1661:       // Full replay rebuilds these record wrappers and ancestry closures. Engine,
1662:       // policy, prototypes and their function references must remain identical.
1663:       const rebuilt = new Set([
1664:         'context',
1665:         // runtimeReferences depth zero repeats the wrapper itself; deeper
1666:         // prototype references remain part of the comparison.
1667:         'context/prototype/0',
1668:         'log',
1669:         'log/prototype/0',
1670:         'context/verifyHistoricalCheat',
1671:         'context/verifyHistoricalAccusation',
1672:       ]);
1673:       const openedFunctions = this.stamp.functions.filter(([name]) => !rebuilt.has(name));
1674:       const replayedFunctions = replayed.functions.filter(([name]) => !rebuilt.has(name));
1675:       return (
1676:         this.stamp.genesisText === replayed.genesisText &&
1677:         this.stamp.contextText === replayed.contextText &&
1678:         openedFunctions.length === replayedFunctions.length &&
1679:         openedFunctions.every(
1680:           ([name, reference], index) =>
1681:             name === replayedFunctions[index]?.[0] && reference === replayedFunctions[index]?.[1],
1682:         )
1683:       );
1684:     } catch {
1685:       return false;
1686:     }
1687:   }
1688: 
1689:   private checkContext(): Result<void> {
1690:     let current: ContextStamp;
1691:     try {
1692:       current = contextStamp(this.context);
1693:     } catch {
1694:       return failure('consensus-context', 'Certified context changed to noncanonical data');
1695:     }
1696:     if (sameContextStamp(this.stamp, current)) return success(undefined);
1697:     if (this.pending)
1698:       return failure('consensus-context', 'Certified context changed during persistence');
1699:     // Once the opening stamp differs, this context cannot validate stored
1700:     // proposals or locks. Only durable replay may establish their authority.
1701:     return failure('consensus-context', 'Certified context changed; restore this voting record');
1702:   }
1703: 
1704:   snapshot(): Result<ConsensusState> {
1705:     const checked = this.checkContext();
1706:     return checked.ok ? success(copyConsensusStateData(this.state)) : checked;
1707:   }
1708: 
1709:   dispatch(
1710:     event: ConsensusEvent,
1711:     secretKey: Uint8Array,
1712:     admitValue?: LocalVoteAdmissibility,
1713:   ): Result<ConsensusTransition> {
1714:     const checked = this.checkContext();
1715:     if (!checked.ok) return checked;
1716:     if (this.pending) return failure('consensus-pending', 'Persist the previous transition first');
1717:     let next: Result<ConsensusTransition>;
1718:     switch (event.kind) {
1719:       case 'input-available':
1720:         next = inputAvailable(this.state, this.context);
1721:         break;
1722:       case 'propose':
1723:         next = propose(this.state, this.context, secretKey, event.candidate, admitValue);
1724:         break;
1725:       case 'proposal':
1726:         next = receiveProposal(this.state, this.context, secretKey, event.proposal, admitValue);
1727:         break;
1728:       case 'vote':
1729:         next = receiveVote(this.state, this.context, secretKey, event.vote, admitValue);
1730:         break;
1731:       case 'commit':
1732:         next = receiveCommit(this.state, this.context, event.certified);
1733:         break;
1734:       case 'stage-accusation':
1735:         next = stageAccusation(this.state, this.context, event.control);
1736:         break;
1737:       case 'clear-stale-accusation':
1738:         next = clearStaleAccusation(this.state, this.context);
1739:         break;
1740:       case 'terminal-halt':
1741:         next = terminalHalt(this.state, this.context, event.reason);
1742:         break;
1743:       case 'resume-after-replay':
1744:         next = resumeAfterReplay(this.state, this.context);
1745:         break;
1746:       case 'timeout':
1747:         next = timeout(this.state, this.context, secretKey, event.phase, event.round, admitValue);
1748:         break;
1749:       default: {
1750:         const unknownEvent: never = event;
1751:         return failure('consensus-event', `Unknown consensus event: ${String(unknownEvent)}`);
1752:       }
1753:     }
1754:     const after = this.checkContext();
1755:     if (!after.ok) return after;
1756:     if (!next.ok) return next;
1757:     this.pending = copyConsensusStateData(next.value.state);
1758:     ownedStates.add(this.pending);
1759:     return success({ state: copyConsensusStateData(this.pending), effects: next.value.effects });
1760:   }
1761: 
1762:   commit(): Result<void> {
1763:     if (!this.pending) throw new Error('No persisted consensus transition to install');
1764:     let current: ContextStamp;
1765:     try {
1766:       current = contextStamp(this.context);
1767:     } catch {
1768:       return failure('consensus-context', 'Certified context changed during persistence');
1769:     }
1770:     if (!sameContextStamp(this.stamp, current))
1771:       return failure('consensus-context', 'Certified context changed during persistence');
1772:     this.state = this.pending;
1773:     this.pending = null;
1774:     return success(undefined);
1775:   }
1776: 
1777:   discard(): void {
1778:     this.pending = null;
1779:   }
1780: }
1781: 
1782: export function openOwnedConsensusState(
1783:   value: ConsensusState,
1784:   context: ProposalContext,
1785:   seat: Seat,
1786: ): Result<OwnedConsensusState> {
1787:   const restored = restoreConsensusState(value, context, seat);

### Exact paired comparison
{
  "baseline": {
    "revision": 148,
    "turn": 28,
    "elapsedMilliseconds": 60057.549166,
    "terminalReachedMilliseconds": null,
    "operationTimings": {
      "sessionFlush": {
        "calls": 5500,
        "totalMilliseconds": 45893.13604699972,
        "maximumMilliseconds": 1022.9615409999969
      },
      "networkDelivery": {
        "calls": 5415,
        "totalMilliseconds": 680.7530950000928,
        "maximumMilliseconds": 37.99370800000179
      },
      "botDecide": {
        "calls": 85,
        "totalMilliseconds": 39.44220899996799,
        "maximumMilliseconds": 4.159625000000233
      },
      "actorExport": {
        "calls": 128,
        "totalMilliseconds": 324.54782899997736,
        "maximumMilliseconds": 11.737957999997889
      },
      "actorAdvance": {
        "calls": 128,
        "totalMilliseconds": 3270.4591309999814,
        "maximumMilliseconds": 243.6214579999978
      },
      "actorDecide": {
        "calls": 24,
        "totalMilliseconds": 10.049415999990742,
        "maximumMilliseconds": 1.1015000000006694
      }
    },
    "inclusiveSampleMilliseconds": {
      "contextStamp": 6913.6010000000715,
      "sameContextStamp": 84.83500000000001,
      "canonicalText": 21863.39200000024,
      "encodeValue": 21784.222000000238,
      "genesisContextText": 0,
      "canonicalEncode": 15880.496999999737,
      "canonicalDecode": 12174.189999999911,
      "copyConsensusStateData": 6413.338000000046,
      "validateCertifiedEntry": 7259.223000000082,
      "validateNextEntry": 10542.931999999968,
      "persistCommit": 13764.506999999863
    },
    "callerSampleMilliseconds": {
      "canonicalText": {
        "canonicalEncode canonical.js:129": 15075.999999999767,
        "contextStamp consensus.js:107": 6787.392000000069
      },
      "contextStamp": {
        "checkContext consensus.js:1177": 4970.785000000016,
        "commit consensus.js:1249": 1669.0639999999978,
        "openOwnedConsensusState consensus.js:1269": 272.585,
        "dispatch consensus.js:1197": 1.167
      }
    },
    "topSelfSampleMilliseconds": {
      "encodeValue canonical.js:56": 17357.135999999693,
      "mod modular.js:32": 9063.577000000068,
      "pow2 modular.js:124": 4352.636999999995,
      " canonical.js:111": 4153.668999999997,
      "canonicalDecode canonical.js:164": 3314.986999999997,
      "(garbage collector) :0": 2401.469999999998,
      "decodeTagged canonical.js:138": 2120.9249999999925,
      "fromBase64UrlInternal canonical.js:25": 1699.1669999999972,
      "process sha2.js:72": 1424.0729999999978,
      " canonical.js:176": 1128.3249999999998,
      "mul modular.js:728": 826.7910000000004,
      "invert modular.js:150": 778.2240000000007,
      "~run index.mjs:6325": 599.0449999999996,
      " schema-values.js:8": 511.7449999999995,
      "~run index.mjs:991": 492.66899999999964,
      "Point edwards.js:114": 460.1229999999997,
      "encode encoding:351": 361.0819999999998,
      "visit json.js:3": 277.75
    },
    "sourceUnchanged": true,
    "compiledUnchanged": true,
    "profiledWallMilliseconds": 60463.75
  },
  "candidate": {
    "revision": 147,
    "turn": 28,
    "elapsedMilliseconds": 60002.288167,
    "terminalReachedMilliseconds": null,
    "operationTimings": {
      "sessionFlush": {
        "calls": 5497,
        "totalMilliseconds": 43024.8322319999,
        "maximumMilliseconds": 1093.9521250000034
      },
      "networkDelivery": {
        "calls": 5411,
        "totalMilliseconds": 792.756700000089,
        "maximumMilliseconds": 155.69962499999383
      },
      "botDecide": {
        "calls": 85,
        "totalMilliseconds": 36.70375000002241,
        "maximumMilliseconds": 1.724291999998968
      },
      "actorExport": {
        "calls": 127,
        "totalMilliseconds": 301.75041600003533,
        "maximumMilliseconds": 7.216584000001603
      },
      "actorAdvance": {
        "calls": 127,
        "totalMilliseconds": 3083.219630000018,
        "maximumMilliseconds": 242.08062500000233
      },
      "actorDecide": {
        "calls": 23,
        "totalMilliseconds": 8.379211000003124,
        "maximumMilliseconds": 0.9843330000003334
      }
    },
    "inclusiveSampleMilliseconds": {
      "contextStamp": 3952.6809999999928,
      "sameContextStamp": 81.70099999999998,
      "canonicalText": 19254.413999999935,
      "encodeValue": 19189.255999999925,
      "genesisContextText": 1.25,
      "canonicalEncode": 16408.68899999969,
      "canonicalDecode": 12478.436999999894,
      "copyConsensusStateData": 6523.756000000065,
      "validateCertifiedEntry": 7469.124000000089,
      "validateNextEntry": 10747.620999999974,
      "persistCommit": 13346.456999999828
    },
    "callerSampleMilliseconds": {
      "canonicalText": {
        "canonicalEncode canonical.js:129": 15472.517999999709,
        "contextStamp consensus.js:108": 3776.561999999993,
        "ownImmutableGenesis genesis-identity.js:6": 5.334
      },
      "contextStamp": {
        "checkContext consensus.js:1181": 2888.6699999999955,
        "commit consensus.js:1253": 897.8830000000004,
        "openOwnedConsensusState consensus.js:1273": 163.62800000000001,
        " consensus-controller.js:141": 1.25,
        "snapshot consensus.js:1197": 1.25
      },
      "genesisContextText": {
        "contextStamp consensus.js:108": 1.25
      }
    },
    "topSelfSampleMilliseconds": {
      "encodeValue canonical.js:56": 15504.82699999972,
      "mod modular.js:32": 9683.925000000034,
      "pow2 modular.js:124": 4975.432000000022,
      " canonical.js:111": 3482.3859999999954,
      "canonicalDecode canonical.js:164": 3202.6279999999933,
      "(garbage collector) :0": 2380.897,
      "decodeTagged canonical.js:138": 2151.4829999999943,
      "fromBase64UrlInternal canonical.js:25": 1662.0509999999967,
      "process sha2.js:72": 1463.0879999999986,
      " canonical.js:176": 1313.6470000000006,
      "invert modular.js:150": 926.3180000000015,
      "mul modular.js:728": 918.1670000000003,
      "~run index.mjs:6325": 564.7899999999995,
      " schema-values.js:8": 505.5389999999994,
      "~run index.mjs:991": 503.66999999999945,
      "Point edwards.js:114": 456.58699999999993,
      "encode encoding:351": 435.83299999999986,
      "runCT curve.js:374": 398.0839999999995
    },
    "sourceUnchanged": true,
    "compiledUnchanged": true,
    "profiledWallMilliseconds": 60362.334
  },
  "scope": "Sequential60s diagnostics; unchanged scenario6 realcrypto seed42/index0. Not acceptance. Exact2productionfile overlay, isolated pinned Node22.23.3. Inclusive sample costs are not additive."
}

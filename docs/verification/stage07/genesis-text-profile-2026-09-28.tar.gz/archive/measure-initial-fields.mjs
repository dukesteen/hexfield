import { createVerifiedNetworkFixture } from './baseline/packages/protocol/dist/testing.js';
import { initialProposalContext } from './baseline/packages/protocol/dist/index.js';
import { canonicalText } from './baseline/packages/codec/dist/internal.js';
const fixture = createVerifiedNetworkFixture({ seed: 42, gameIndex: 0 });
try {
  const result = initialProposalContext(fixture.entry, fixture.engine, fixture.sessionOptions(0).policy);
  if (!result.ok) throw new Error(result.error.code);
  const context = result.value;
  const nonfunctions = value => Object.fromEntries(Object.entries(value).filter(([, item]) => typeof item !== 'function'));
  const { engine, ...log } = context.log;
  const other = nonfunctions(context);
  delete other.log;
  delete other.policy;
  const normalizedLog = { ...log, lastNonces: [...log.lastNonces], engine: nonfunctions(engine) };
  const normalized = { ...other, log: normalizedLog, policy: { ...nonfunctions(context.policy), randomDerivations: nonfunctions(context.policy.randomDerivations ?? {}) } };
  const fieldCharacters = Object.fromEntries(Object.entries(normalizedLog).map(([key,value]) => [key,canonicalText(value).length]));
  const totalCharacters = canonicalText(normalized).length;
  console.log(JSON.stringify({ seed:42, gameIndex:0, seq:context.log.head.seq, totalCharacters, fieldCharacters, directGenesisShare:fieldCharacters.genesis/totalCharacters, note:'Initial context only. The seq-zero head also embeds signed genesis; later field proportions are not measured. No fixture values or private states emitted.' },null,2));
} finally { fixture.dispose(); }

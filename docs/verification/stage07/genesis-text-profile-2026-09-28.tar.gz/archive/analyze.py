from pathlib import Path
from collections import defaultdict
import hashlib,json
root=Path('/private/tmp/hexfield-genesis-text-paired-2026-09-28');archive=root/'archive';summary={}
for side in ['baseline','candidate']:
 tree=root/side
 def manifest(paths):return [{'path':str(p.relative_to(tree)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(paths)]
 sources=[p for prefix in ['packages','tools'] for p in (tree/prefix).glob('*/src/**/*.ts')]
 compiled=[p for prefix in ['packages','tools'] for p in (tree/prefix).glob('*/dist/**/*.js')]
 for kind,paths in [('source',sources),('compiled',compiled)]:
  records=manifest(paths);(archive/(side+'-'+kind+'-after.json')).write_text(json.dumps(records,indent=2)+'\n');assert records==json.loads((archive/(side+'-'+kind+'-before.json')).read_text()),(side,kind)
 profile=json.loads((root/(side+'-profile')/(side+'.cpuprofile')).read_text());nodes={n['id']:n for n in profile['nodes']};parent={c:n['id'] for n in nodes.values() for c in n.get('children',[])}
 inclusive=defaultdict(float);selfcost=defaultdict(float);callers=defaultdict(lambda:defaultdict(float));memo={}
 def label(node):
  f=node['callFrame'];return f['functionName']+' '+Path(f['url']).name+':'+str(f['lineNumber']+1)
 def chain(i):
  if i not in memo:memo[i]=[i]+(chain(parent[i]) if i in parent else [])
  return memo[i]
 for sample,dt in zip(profile['samples'],profile['timeDeltas']):
  weight=dt/1000;stack=chain(sample);selfcost[label(nodes[sample])]+=weight;seen=set();functions=set()
  for j,i in enumerate(stack):
   key=label(nodes[i]);fn=nodes[i]['callFrame']['functionName']
   if key not in seen:inclusive[key]+=weight;seen.add(key)
   if fn in ['contextStamp','canonicalText','genesisContextText'] and fn not in functions:
    functions.add(fn);caller=label(nodes[stack[j+1]]) if j+1<len(stack) else '<root>';callers[fn][caller]+=weight
 result=json.loads((archive/(side+'-result.json')).read_text());failure=result['failures'][0]['message'];diagnostic=json.loads(failure[failure.index('{'):]);public=diagnostic['public']
 functions=['contextStamp','sameContextStamp','canonicalText','encodeValue','genesisContextText','canonicalEncode','canonicalDecode','copyConsensusStateData','validateCertifiedEntry','validateNextEntry','persistCommit']
 totals={fn:sum(value for key,value in inclusive.items() if key.split(' ')[0]==fn) for fn in functions}
 summary[side]={'revision':public['revision'],'turn':public['turn'],'elapsedMilliseconds':diagnostic['elapsedMilliseconds'],'terminalReachedMilliseconds':diagnostic.get('terminalReachedMilliseconds'),'operationTimings':diagnostic['operationTimings'],'inclusiveSampleMilliseconds':totals,'callerSampleMilliseconds':{fn:dict(sorted(c.items(),key=lambda x:-x[1])) for fn,c in callers.items()},'topSelfSampleMilliseconds':dict(sorted(selfcost.items(),key=lambda x:-x[1])[:18]),'sourceUnchanged':True,'compiledUnchanged':True,'profiledWallMilliseconds':(profile['endTime']-profile['startTime'])/1000}
summary['scope']='Sequential60s diagnostics; unchanged scenario6 realcrypto seed42/index0. Not acceptance. Exact2productionfile overlay, isolated pinned Node22.23.3. Inclusive sample costs are not additive.'
(archive/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({side:{key:summary[side][key] for key in ['revision','turn','inclusiveSampleMilliseconds','sourceUnchanged','compiledUnchanged']} for side in ['baseline','candidate']},indent=2))

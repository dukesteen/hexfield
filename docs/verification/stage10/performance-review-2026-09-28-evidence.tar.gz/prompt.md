Review a TypeScript peer-to-peer board game's remaining performance bottlenecks. Read-only review; do not run tools. We need concrete safe implementation changes, not looser tests. User explicitly requests Claude Opus 5.5, medium effort.

Current evidence: strict agreement is mandatory. Mutable caller contexts, engine functions/policies, corrupt durable safety, dispose across awaits must fail closed. Protocol compatibility not required. All nine realcrypto failure scenarios must complete standard 10 VP games and independent audits; tests use fixed seed42, unchanged 900s limit. Scenario2 latency+dup continues progressing at head520/turn82 but expires900s (sessionFlush873s). Scenario5 reaches terminal869 at714s, starts ALL four independent audit jobs (metrics invocations wrongly increments only on completion), still verifying186s later at900s. Scenario6 reaches terminal1064 near893s and runs out of time. Persistence lifecycle now PASSED. Mixed browser manual game reaches terminal88 at~280s, verifying290s, combineddriver/audit poll timesout294s; no demonstrated deadlock. Timelimits and required security cannot be loosened just to pass.

Previous owned-genesis digest memo reduced sampled genesisDigest from9.8s to0.5s in60s profile; samebudget work116->174entries (multiple files changed, not causal isolation). Canonical encoding still21.6s inclusive, contextStamp6.8s, canonicalDecode5.2s, hashValue3.4s. We provide actualprofile, source for consensus context guards, codec, audit/reconstruction/replay. Need prioritize one small safe live-game optimization and one audit optimization. auditCertifiedGame presently repeats certified-prefix validation four times: public replay, omniscient pass, reconstruction public pass, reconstruction private pass. Independent per-seat algorithm cross-check is required; cryptographic replay need not be redundantly repeated inside same audit if safely reused. Do NOT suggest trusting caller-provided contexts or skipping independent audits.

Please inspect and propose exact design, security hazards, minimal meaningful tests and measurement. Consider (A) package-private checked encoding cache only for transitively immutable owned plain data (never mutable descendants, Uint8Array, Maps, accessors; no authority based on caller-supplied cached hashes), (B) a private audit/reconstruction core consuming a freshly validated replay without accepting an unsafe external verified flag. Explain whether each is worthwhile versus alternative. Preserve exact observable validation/report semantics if feasible. No code editing; return concise implementable recommendation with confidence and uncertainties.


FILE packages/codec/src/canonical.ts
import { utf8ToBytes } from '@noble/hashes/utils.js';

/** Values accepted by the canonical JSON-like encoder. */
export type CanonicalValue =
  | null
  | boolean
  | number
  | string
  | Uint8Array
  | readonly CanonicalValue[]
  | { readonly [key: string]: CanonicalValue };

const BYTE_TAG = '$b';
const BASE64URL = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';

interface Utf8Decoder {
  decode(input: Uint8Array): string;
}

interface Utf8DecoderConstructor {
  new (label?: string, options?: { fatal?: boolean }): Utf8Decoder;
}

declare const TextDecoder: Utf8DecoderConstructor;

function decoder(): Utf8Decoder {
  return new TextDecoder('utf-8', { fatal: true });
}

function toBase64UrlInternal(bytes: Uint8Array): string {
  let encoded = '';
  for (let index = 0; index < bytes.length; index += 3) {
    const first = bytes[index] ?? 0;
    const hasSecond = index + 1 < bytes.length;
    const hasThird = index + 2 < bytes.length;
    const second = hasSecond ? (bytes[index + 1] ?? 0) : 0;
    const third = hasThird ? (bytes[index + 2] ?? 0) : 0;
    const group = (first << 16) | (second << 8) | third;
    encoded += BASE64URL.charAt((group >>> 18) & 63);
    encoded += BASE64URL.charAt((group >>> 12) & 63);
    if (hasSecond) encoded += BASE64URL.charAt((group >>> 6) & 63);
    if (hasThird) encoded += BASE64URL.charAt(group & 63);
  }
  return encoded;
}

function fromBase64UrlInternal(encoded: string): Uint8Array {
  if (!/^[A-Za-z0-9_-]*$/.test(encoded) || encoded.length % 4 === 1) {
    throw new TypeError('Byte tag must use unpadded base64url.');
  }
  const length = Math.floor((encoded.length * 6) / 8);
  const bytes = new Uint8Array(length);
  let accumulator = 0;
  let bitCount = 0;
  let outputIndex = 0;
  for (const character of encoded) {
    const value = BASE64URL.indexOf(character);
    if (value < 0) throw new TypeError('Byte tag must use unpadded base64url.');
    accumulator = (accumulator << 6) | value;
    bitCount += 6;
    if (bitCount >= 8) {
      bitCount -= 8;
      bytes[outputIndex] = (accumulator >>> bitCount) & 255;
      outputIndex += 1;
      accumulator &= (1 << bitCount) - 1;
    }
  }
  if (toBase64UrlInternal(bytes) !== encoded) {
    throw new TypeError('Byte tag must use canonical base64url.');
  }
  return bytes;
}

function isPlainObject(value: object): boolean {
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function encodeValue(value: unknown, ancestors: WeakSet<object>): string {
  if (value === null) return 'null';
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  if (typeof value === 'string') return JSON.stringify(value);
  if (typeof value === 'number') {
    if (!Number.isInteger(value)) {
      throw new TypeError('Canonical encoding accepts integers only.');
    }
    return JSON.stringify(value);
  }
  if (value instanceof Uint8Array) {
    return `{"${BYTE_TAG}":${JSON.stringify(toBase64UrlInternal(value))}}`;
  }
  if (typeof value !== 'object') {
    throw new TypeError(`Unsupported canonical value: ${typeof value}.`);
  }
  if (ancestors.has(value))
    throw new TypeError('Canonical encoding does not accept cyclic values.');
  ancestors.add(value);
  try {
    if (Array.isArray(value)) {
      const ownKeys = Reflect.ownKeys(value);
      if (ownKeys.length !== value.length + 1 || ownKeys.some((key) => typeof key === 'symbol')) {
        throw new TypeError('Canonical arrays cannot have holes or extra properties.');
      }
      const items: string[] = [];
      for (let index = 0; index < value.length; index += 1) {
        if (!Object.hasOwn(value, index))
          throw new TypeError('Canonical arrays cannot have holes.');
        const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
        if (!descriptor || !('value' in descriptor) || !descriptor.enumerable) {
          throw new TypeError('Canonical arrays must contain plain data elements.');
        }
        items.push(encodeValue(descriptor.value, ancestors));
      }
      return `[${items.join(',')}]`;
    }
    if (!isPlainObject(value)) throw new TypeError('Canonical objects must be plain records.');

    const ownKeys = Reflect.ownKeys(value);
    if (ownKeys.some((key) => typeof key !== 'string')) {
      throw new TypeError('Canonical objects cannot contain symbol keys.');
    }
    const keys: string[] = [];
    for (const key of ownKeys) {
      if (typeof key !== 'string')
        throw new TypeError('Canonical objects cannot contain symbol keys.');
      keys.push(key);
    }
    if (keys.length === 1 && keys[0] === BYTE_TAG) {
      throw new TypeError('An exact one-key $b object is reserved for Uint8Array values.');
    }
    const entries = keys.toSorted().map((key) => {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor || !('value' in descriptor) || !descriptor.enumerable) {
        throw new TypeError('Canonical objects must contain enumerable data properties.');
      }
      return `${JSON.stringify(key)}:${encodeValue(descriptor.value, ancestors)}`;
    });
    return `{${entries.join(',')}}`;
  } finally {
    ancestors.delete(value);
  }
}

/** Encodes plain JSON-like values as canonical UTF-8 bytes. */
export function canonicalEncode(value: unknown): Uint8Array {
  return utf8ToBytes(encodeValue(value, new WeakSet<object>()));
}

function isPlainRecord(value: unknown): value is Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function decodeTagged(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(decodeTagged);
  if (typeof value !== 'object' || value === null) return value;
  if (!isPlainRecord(value)) throw new TypeError('Decoded objects must be plain records.');
  const keys = Object.keys(value);
  if (keys.length === 1 && keys[0] === BYTE_TAG) {
    const encoded = value[BYTE_TAG];
    if (typeof encoded !== 'string') throw new TypeError('Byte tag value must be a string.');
    return fromBase64UrlInternal(encoded);
  }
  const decoded: Record<string, unknown> = {};
  for (const key of keys) {
    Object.defineProperty(decoded, key, {
      value: decodeTagged(value[key]),
      enumerable: true,
      writable: true,
      configurable: true,
    });
  }
  return decoded;
}

/** Decodes canonical UTF-8 bytes and byte tags, rejecting alternate JSON representations. */
export function canonicalDecode(bytes: Uint8Array): unknown {
  if (!(bytes instanceof Uint8Array)) throw new TypeError('Canonical input must be a Uint8Array.');
  let parsed: unknown;
  try {
    parsed = JSON.parse(decoder().decode(bytes)) as unknown;
  } catch (error) {
    throw new TypeError(`Invalid canonical JSON bytes: ${String(error)}`, { cause: error });
  }
  const value = decodeTagged(parsed);
  const encoded = canonicalEncode(value);
  if (encoded.length !== bytes.length || encoded.some((byte, index) => byte !== bytes[index])) {
    throw new TypeError('Input bytes are not in canonical encoding.');
  }
  return value;
}

/** Converts bytes to unpadded base64url. */
export function toBase64Url(bytes: Uint8Array): string {
  return toBase64UrlInternal(bytes);
}

/** Converts canonical unpadded base64url to bytes. */
export function fromBase64Url(encoded: string): Uint8Array {
  return fromBase64UrlInternal(encoded);
}


FILE packages/protocol/src/genesis-identity.ts
import { canonicalDecode, canonicalEncode, hashValue, toBase64Url } from '@cp2p/codec';
import type { Genesis, GenesisBody } from './types.js';

const immutableDigests = new WeakMap<GenesisBody, string>();

/** Internal ownership boundary; callers never supply a trusted digest or cache entry. */
export function ownImmutableGenesis(input: Genesis): Genesis {
  // oxlint-disable-next-line typescript/no-unsafe-type-assertion -- Canonical round-trip preserves the validated genesis shape.
  const owned = canonicalDecode(canonicalEncode(input)) as Genesis;
  const objects: object[] = [];
  function collect(value: unknown): boolean {
    if (value === null || typeof value !== 'object') return true;
    // Typed-array storage remains mutable even when its surrounding records are frozen.
    if (value instanceof Uint8Array) return false;
    objects.push(value);
    return Object.values(value).every(collect);
  }
  if (!collect(owned)) return owned;
  const digest = genesisDigest(owned);
  for (const object of objects) Object.freeze(object);
  immutableDigests.set(owned, digest);
  return owned;
}

/** Explicit fields prevent gameId or signatures becoming part of their own hash. */
export function genesisBody(genesis: GenesisBody): GenesisBody {
  return {
    protocolVersion: genesis.protocolVersion,
    engineVersion: genesis.engineVersion,
    config: genesis.config,
    seats: genesis.seats,
    genesisSeed: genesis.genesisSeed,
    ceremonyNonce: genesis.ceremonyNonce,
    security: genesis.security,
    takeover: genesis.takeover,
    commitments: genesis.commitments,
    createdAt: genesis.createdAt,
  };
}

export function genesisId(body: GenesisBody): string {
  return genesisDigest(body).slice(0, 22);
}

/** The full digest binds protocol signatures; gameId is only its routing alias. */
export function genesisDigest(body: GenesisBody): string {
  return (
    immutableDigests.get(body) ??
    toBase64Url(hashValue({ domain: 'cp2p/v1/genesis-body', body: genesisBody(body) }))
  );
}


FILE packages/protocol/src/consensus.ts
import { canonicalDecode, canonicalEncode, hashValue, toHex } from '@cp2p/codec';
import { parsePeerId } from '@cp2p/crypto';
import { failure, success } from '@cp2p/engine';
import type { Result, Seat } from '@cp2p/engine';
import * as v from 'valibot';
import { objectiveEvidenceSeq } from './control.js';
import { entryBody, entryHash, genesisDigest, signEntry } from './genesis.js';
import {
  authenticateProposalControlEvidence,
  authenticateCertifiedEntry,
  objectiveProofParentHash,
  proposerFor,
  signedProposalSchema,
  signProposal,
  validateCertifiedEntry,
  validateObjectiveForProposal,
  validateProposal,
} from './proposal.js';
import type { CertifiedEntry, ProposalContext, SignedProposal } from './proposal.js';
import {
  hashSchema,
  key32Schema,
  nonnegativeIntegerSchema,
  positiveIntegerSchema,
  seatSchema,
} from './schema-values.js';
import { excludeProposerControlSchema, logEntrySchema } from './schemas.js';
import type { PeerId } from './transport.js';
import {
  quorumSize,
  signedVoteSchema,
  signVote,
  validateVote,
  verifyCertificate,
} from './votes.js';
import type { SignedVote, VotePhase } from './votes.js';
import type { ExcludeProposerControl, LogEntry } from './types.js';

export type ConsensusStep = 'propose' | 'prevote' | 'precommit';
export type TimeoutPhase = ConsensusStep;
/** Local voting policy; it never changes proposal or certified-entry validity. */
export type LocalVoteAdmissibility = (proposal: SignedProposal) => boolean;

export interface QuorumValue {
  round: number;
  hash: string;
  proposal: SignedProposal;
  prevotes: SignedVote[];
}

export type RoundHint =
  | { kind: 'proposal'; seat: Seat; round: number; proposal: SignedProposal }
  | { kind: 'vote'; seat: Seat; round: number; vote: SignedVote };

export type Equivocation =
  | { kind: 'proposal'; seat: Seat; round: number; first: SignedProposal; second: SignedProposal }
  | {
      kind: 'vote';
      seat: Seat;
      round: number;
      phase: VotePhase;
      first: SignedVote;
      second: SignedVote;
    };

/** One objective first-offender proof carried across certified heights. */
export interface ProvenOffender {
  control: ExcludeProposerControl;
  atSeq: number;
  parentHash: string;
}

/** All safety-relevant records for one height. Persist this whole value atomically. */
export interface ConsensusState {
  version: 1;
  genesisDigest: string;
  epoch: number;
  height: number;
  parentHash: string;
  contextHash: string;
  localSeat: Seat;
  localPublicKey: PeerId;
  round: number;
  step: ConsensusStep;
  inputKnown: boolean;
  timers: { propose: boolean; prevote: boolean; precommit: boolean };
  proposals: SignedProposal[];
  votes: SignedVote[];
  hints: RoundHint[];
  equivocations: Equivocation[];
  pendingAccusation: ExcludeProposerControl | null;
  provenOffender: ProvenOffender | null;
  locked: QuorumValue | null;
  valid: QuorumValue | null;
  decision: CertifiedEntry | null;
  halted: string | null;
  haltKind: 'certified-validation' | 'terminal' | null;
  unappliedCertificate: CertifiedEntry | null;
}

/** The adapter must persist next state before acting on any effect. */
export type ConsensusEffect =
  | { kind: 'broadcast-proposal'; proposal: SignedProposal }
  | { kind: 'broadcast-vote'; vote: SignedVote }
  | { kind: 'schedule-timeout'; phase: TimeoutPhase; round: number }
  | { kind: 'request-value'; round: number; validHash: string | null }
  | { kind: 'request-proposal'; round: number; hash: string }
  | { kind: 'commit'; certified: CertifiedEntry }
  | { kind: 'equivocation'; evidence: Equivocation }
  | { kind: 'halt'; reason: string };

export interface ConsensusTransition {
  state: ConsensusState;
  effects: ConsensusEffect[];
}

const quorumValueSchema = v.strictObject({
  round: positiveIntegerSchema,
  hash: hashSchema,
  proposal: signedProposalSchema,
  prevotes: v.array(signedVoteSchema),
});
const hintSchema = v.variant('kind', [
  v.strictObject({
    kind: v.literal('proposal'),
    seat: seatSchema,
    round: positiveIntegerSchema,
    proposal: signedProposalSchema,
  }),
  v.strictObject({
    kind: v.literal('vote'),
    seat: seatSchema,
    round: positiveIntegerSchema,
    vote: signedVoteSchema,
  }),
]);
const equivocationSchema = v.variant('kind', [
  v.strictObject({
    kind: v.literal('proposal'),
    seat: seatSchema,
    round: positiveIntegerSchema,
    first: signedProposalSchema,
    second: signedProposalSchema,
  }),
  v.strictObject({
    kind: v.literal('vote'),
    seat: seatSchema,
    round: positiveIntegerSchema,
    phase: v.picklist(['prevote', 'precommit']),
    first: signedVoteSchema,
    second: signedVoteSchema,
  }),
]);
const certifiedSchema = v.strictObject({
  entry: logEntrySchema,
  certificate: v.array(signedVoteSchema),
});
const stateSchema = v.strictObject({
  version: v.literal(1),
  genesisDigest: key32Schema,
  epoch: nonnegativeIntegerSchema,
  height: positiveIntegerSchema,
  parentHash: hashSchema,
  contextHash: hashSchema,
  localSeat: seatSchema,
  localPublicKey: key32Schema,
  round: positiveIntegerSchema,
  step: v.picklist(['propose', 'prevote', 'precommit']),
  inputKnown: v.boolean(),
  timers: v.strictObject({ propose: v.boolean(), prevote: v.boolean(), precommit: v.boolean() }),
  proposals: v.array(signedProposalSchema),
  votes: v.array(signedVoteSchema),
  hints: v.pipe(v.array(hintSchema), v.maxLength(6)),
  equivocations: v.array(equivocationSchema),
  pendingAccusation: v.nullable(excludeProposerControlSchema),
  provenOffender: v.nullable(
    v.strictObject({
      control: excludeProposerControlSchema,
      atSeq: positiveIntegerSchema,
      parentHash: hashSchema,
    }),
  ),
  locked: v.nullable(quorumValueSchema),
  valid: v.nullable(quorumValueSchema),
  decision: v.nullable(certifiedSchema),
  halted: v.nullable(v.string()),
  haltKind: v.nullable(v.picklist(['certified-validation', 'terminal'])),
  unappliedCertificate: v.nullable(certifiedSchema),
});

interface ContextStamp {
  contextBytes: Uint8Array;
  functions: readonly (readonly [string, unknown])[];
}

// Only an OwnedConsensusState's private state enters this set. Public transition
// functions continue to verify every caller-supplied state in full.
const ownedStates = new WeakSet<ConsensusState>();

function sameBytes(left: Uint8Array, right: Uint8Array): boolean {
  return left.length === right.length && left.every((byte, index) => byte === right[index]);
}

function nonfunctions(value: object): Record<string, unknown> {
  return Object.fromEntries(Object.entries(value).filter(([, item]) => typeof item !== 'function'));
}

function runtimeReferences(value: object, name: string): (readonly [string, unknown])[] {
  const references: (readonly [string, unknown])[] = [[name, value]];
  let current: object | null = value;
  for (let depth = 0; current && current !== Object.prototype && depth < 8; depth++) {
    references.push([`${name}/prototype/${depth}`, current]);
    for (const key of Object.getOwnPropertyNames(current).toSorted()) {
      const property = Object.getOwnPropertyDescriptor(current, key);
      if (typeof property?.value === 'function')
        references.push([`${name}/${key}`, property.value]);
      if (property?.get) references.push([`${name}/${key}/get`, Reflect.get(property, 'get')]);
      if (property?.set) references.push([`${name}/${key}/set`, Reflect.get(property, 'set')]);
    }
    current = Object.getPrototypeOf(current);
  }
  return references;
}

function contextStamp(context: ProposalContext): ContextStamp {
  const functions: (readonly [string, unknown])[] = [
    ...runtimeReferences(context, 'context'),
    ...runtimeReferences(context.log, 'log'),
    ...runtimeReferences(context.log.engine, 'engine'),
    ...runtimeReferences(context.policy, 'policy'),
    ...(context.policy.randomDerivations
      ? runtimeReferences(context.policy.randomDerivations, 'randomDerivations')
      : [['randomDerivations', null] as const]),
  ];
  const { engine, ...log } = context.log;
  const other = nonfunctions(context);
  delete other.log;
  delete other.policy;
  return {
    contextBytes: canonicalEncode({
      ...other,
      log: {
        ...log,
        lastNonces: [...log.lastNonces],
        engine: nonfunctions(engine),
      },
      policy: {
        ...nonfunctions(context.policy),
        randomDerivations: nonfunctions(context.policy.randomDerivations ?? {}),
      },
    }),
    functions,
  };
}

function sameContextStamp(left: ContextStamp, right: ContextStamp): boolean {
  return (
    sameBytes(left.contextBytes, right.contextBytes) &&
    left.functions.length === right.functions.length &&
    left.functions.every(
      ([name, value], index) =>
        name === right.functions[index]?.[0] && value === right.functions[index]?.[1],
    )
  );
}

/** Detached schema-checked data for observer callbacks; it confers no validation authority. */
export function copyConsensusStateData(state: ConsensusState): ConsensusState {
  return v.parse(stateSchema, canonicalDecode(canonicalEncode(state)));
}

function bound(state: ConsensusState, context: ProposalContext, localSeat: Seat): boolean {
  const member = context.membership.voters.find((voter) => voter.seat === localSeat);
  return (
    member !== undefined &&
    state.genesisDigest === genesisDigest(context.log.genesis) &&
    state.genesisDigest === context.membership.genesisDigest &&
    state.epoch === context.membership.epoch &&
    state.height === context.log.head.seq + 1 &&
    state.parentHash === entryHash(context.log.head) &&
    state.contextHash === consensusContextHash(context) &&
    state.localSeat === localSeat &&
    state.localPublicKey === member.publicKey
  );
}

function consensusContextHash(context: ProposalContext): string {
  return toHex(
    hashValue({
      voters: context.membership.voters,
      excludedProposers: [...context.excludedProposers].toSorted((a, b) => a - b),
      crypto: context.log.crypto,
    }),
  );
}

function localPeer(state: ConsensusState): PeerId {
  return state.localPublicKey;
}

function sameVote(a: SignedVote, b: SignedVote): boolean {
  return a.body.valueHash === b.body.valueHash;
}

function hasUnrecordedOwnVote(state: ConsensusState, proof: readonly SignedVote[]): boolean {
  return proof.some(
    (vote) =>
      vote.body.seat === state.localSeat &&
      vote.body.seq === state.height &&
      !state.votes.some(
        (stored) =>
          stored.body.seat === vote.body.seat &&
          stored.body.seq === vote.body.seq &&
          stored.body.term === vote.body.term &&
          stored.body.phase === vote.body.phase &&
          stored.body.valueHash === vote.body.valueHash &&
          stored.sig === vote.sig,
      ),
  );
}

function hasUnrecordedOwnEntry(state: ConsensusState, entry: LogEntry): boolean {
  return (
    entry.sequencer === state.localPublicKey &&
    !state.proposals.some(
      (stored) => proposalHash(stored) === entryHash(entry) && stored.body.entry.sig === entry.sig,
    )
  );
}

function proposalHash(proposal: SignedProposal): string {
  return entryHash(proposal.body.entry);
}

function proposalSeat(proposal: SignedProposal, context: ProposalContext): Seat | undefined {
  return context.membership.voters.find(
    (voter) => voter.publicKey === proposal.body.entry.sequencer,
  )?.seat;
}

function ownVote(state: ConsensusState, phase: VotePhase): SignedVote | undefined {
  return state.votes.find(
    (vote) =>
      vote.body.seat === state.localSeat &&
      vote.body.term === state.round &&
      vote.body.phase === phase,
  );
}

function votesAt(state: ConsensusState, round: number, phase: VotePhase): SignedVote[] {
  return state.votes.filter((vote) => vote.body.term === round && vote.body.phase === phase);
}

function quorumFor(
  state: ConsensusState,
  context: ProposalContext,
  round: number,
  phase: VotePhase,
  hash: string | null,
): SignedVote[] | null {
  const votes = votesAt(state, round, phase)
    .filter((vote) => vote.body.valueHash === hash)
    .toSorted((a, b) => a.body.seat - b.body.seat);
  return votes.length >= quorumSize(context.membership.voters.length)
    ? votes.slice(0, quorumSize(context.membership.voters.length))
    : null;
}

function anyQuorum(
  state: ConsensusState,
  context: ProposalContext,
  round: number,
  phase: VotePhase,
): boolean {
  return votesAt(state, round, phase).length >= quorumSize(context.membership.voters.length);
}

function proposalAt(
  state: ConsensusState,
  round: number,
  hash: string,
): SignedProposal | undefined {
  return state.proposals.find(
    (proposal) => proposal.body.entry.term === round && proposalHash(proposal) === hash,
  );
}

function signLocalVote(
  state: ConsensusState,
  context: ProposalContext,
  secretKey: Uint8Array,
  phase: VotePhase,
  hash: string | null,
  effects: ConsensusEffect[],
  admitValue?: LocalVoteAdmissibility,
): Result<void> {
  if (ownVote(state, phase)) return success(undefined);
  if (hash !== null && admitValue) {
    const proposal = proposalAt(state, state.round, hash);
    if (
      !proposal ||
      !admitValue(v.parse(signedProposalSchema, canonicalDecode(canonicalEncode(proposal))))
    )
      hash = null;
  }
  try {
    const vote = signVote(
      {
        genesisDigest: state.genesisDigest,
        epoch: state.epoch,
        seat: state.localSeat,
        seq: state.height,
        term: state.round,
        phase,
        valueHash: hash,
      },
      secretKey,
    );
    const valid = validateVote(vote, context.membership);
    if (!valid.ok) return valid;
    state.votes.push(valid.value);
    effects.push({ kind: 'broadcast-vote', vote: valid.value });
    state.step = phase;
    return success(undefined);
  } catch {
    return failure(
      'consensus-key',
      'Local signing key is unavailable or does not match this voter',
    );
  }
}

function recordVote(state: ConsensusState, vote: SignedVote, effects: ConsensusEffect[]): void {
  const first = state.votes.find(
    (item) =>
      item.body.seat === vote.body.seat &&
      item.body.term === vote.body.term &&
      item.body.phase === vote.body.phase,
  );
  if (!first) {
    state.votes.push(vote);
    return;
  }
  if (sameVote(first, vote)) return;
  if (
    state.equivocations.some(
      (item) =>
        item.kind === 'vote' &&
        item.seat === vote.body.seat &&
        item.round === vote.body.term &&
        item.phase === vote.body.phase,
    )
  )
    return;
  const evidence: Equivocation = {
    kind: 'vote',
    seat: vote.body.seat,
    round: vote.body.term,
    phase: vote.body.phase,
    first,
    second: vote,
  };
  state.equivocations.push(evidence);
  effects.push({ kind: 'equivocation', evidence });
}

function recordProposal(
  state: ConsensusState,
  context: ProposalContext,
  proposal: SignedProposal,
  effects: ConsensusEffect[],
): void {
  const seat = proposalSeat(proposal, context);
  if (seat === undefined) return;
  const sameRound = state.proposals.filter(
    (item) => item.body.entry.term === proposal.body.entry.term,
  );
  if (sameRound.some((item) => proposalHash(item) === proposalHash(proposal))) return;
  // Two signed conflicts are enough for objective equivocation evidence. Further
  // variants cannot add safety information and must not grow the durable record.
  if (sameRound.length >= 2) return;
  for (const first of sameRound) {
    if (
      proposalHash(first) !== proposalHash(proposal) &&
      !state.equivocations.some(
        (item) =>
          item.kind === 'proposal' && item.seat === seat && item.round === proposal.body.entry.term,
      )
    ) {
      const evidence: Equivocation = {
        kind: 'proposal',
        seat,
        round: proposal.body.entry.term,
        first,
        second: proposal,
      };
      state.equivocations.push(evidence);
      effects.push({ kind: 'equivocation', evidence });
    }
  }
  state.proposals.push(proposal);
}

function addHint(state: ConsensusState, hint: RoundHint): void {
  const existing = state.hints.findIndex((item) => item.seat === hint.seat);
  if (existing < 0) state.hints.push(hint);
  else if ((state.hints[existing]?.round ?? 0) < hint.round) state.hints[existing] = hint;
}

function halt(state: ConsensusState, reason: string, effects: ConsensusEffect[]): void {
  if (state.halted !== null) return;
  state.halted = reason;
  state.haltKind = 'terminal';
  state.unappliedCertificate = null;
  effects.push({ kind: 'halt', reason });
}

function terminalFault(state: ConsensusState, reason: string, effects: ConsensusEffect[]): void {
  if (state.haltKind === 'terminal') return;
  state.halted = reason;
  state.haltKind = 'terminal';
  state.unappliedCertificate = null;
  effects.push({ kind: 'halt', reason });
}

function haltForControlFault(
  state: ConsensusState,
  context: ProposalContext,
  control: ExcludeProposerControl,
  effects: ConsensusEffect[],
): boolean {
  if (control.offender === state.localSeat) {
    terminalFault(state, 'Objective evidence implicates the local signing key', effects);
    return true;
  }
  if (
    (state.provenOffender && state.provenOffender.control.offender !== control.offender) ||
    context.excludedProposers.some((seat) => seat !== control.offender)
  ) {
    terminalFault(state, 'Objective evidence proves a second Byzantine voter', effects);
    return true;
  }
  return false;
}

function haltForEntryControlFault(
  state: ConsensusState,
  context: ProposalContext,
  entry: LogEntry,
  effects: ConsensusEffect[],
): boolean {
  return entry.payload.kind === 'control'
    ? haltForControlFault(state, context, entry.payload, effects)
    : false;
}

function haltForCertifiedValue(
  state: ConsensusState,
  certified: CertifiedEntry,
  errorCode: string,
  effects: ConsensusEffect[],
): void {
  if (state.halted !== null) return;
  const reason = `Certified value failed deterministic validation: ${errorCode}`;
  state.halted = reason;
  state.haltKind = 'certified-validation';
  state.unappliedCertificate = certified;
  effects.push({ kind: 'halt', reason });
}

function haltIfFaultThresholdExceeded(
  state: ConsensusState,
  context: ProposalContext,
  effects: ConsensusEffect[],
): void {
  const equivocators = new Set<Seat>([
    ...state.equivocations.map((item) => item.seat),
    ...context.excludedProposers,
  ]);
  if (state.provenOffender) equivocators.add(state.provenOffender.control.offender);
  if (equivocators.has(state.localSeat)) {
    terminalFault(state, 'Objective evidence implicates the local signing key', effects);
    return;
  }
  const tolerated = context.membership.voters.length === 1 ? 0 : 1;
  if (equivocators.size > tolerated)
    terminalFault(state, 'Objective evidence proves a second Byzantine voter', effects);
}

function enterRound(
  state: ConsensusState,
  context: ProposalContext,
  round: number,
  effects: ConsensusEffect[],
): void {
  if (round <= state.round) return;
  state.round = round;
  state.step = 'propose';
  state.timers = { propose: false, prevote: false, precommit: false };
  const ready = state.hints.filter((hint) => hint.round === round);
  state.hints = state.hints.filter((hint) => hint.round > round);
  for (const hint of ready) {
    if (hint.kind === 'vote') recordVote(state, hint.vote, effects);
    else recordProposal(state, context, hint.proposal, effects);
  }
  if (
    proposerFor(state.height, round, context.membership, context.excludedProposers).seat ===
    state.localSeat
  )
    effects.push({ kind: 'request-value', round, validHash: state.valid?.hash ?? null });
  if (state.inputKnown) {
    state.timers.propose = true;
    effects.push({ kind: 'schedule-timeout', phase: 'propose', round });
  }
}

function maybeJump(
  state: ConsensusState,
  context: ProposalContext,
  effects: ConsensusEffect[],
): void {
  // One authenticated hint per voter bounds future-round memory. The second-highest
  // round is supported by two distinct voters; one Byzantine voter cannot force it.
  const rounds = state.hints.map((hint) => hint.round).toSorted((a, b) => b - a);
  const second = rounds[1];
  if (second !== undefined && second > state.round) enterRound(state, context, second, effects);
}

function maybeCommit(
  state: ConsensusState,
  context: ProposalContext,
  effects: ConsensusEffect[],
): void {
  const rounds = [
    ...new Set(
      state.votes.filter((vote) => vote.body.phase === 'precommit').map((vote) => vote.body.term),
    ),
  ].toSorted((a, b) => a - b);
  for (const round of rounds) {
    for (const hash of new Set(
      votesAt(state, round, 'precommit').map((vote) => vote.body.valueHash),
    )) {
      if (hash === null) continue;
      const certificate = quorumFor(state, context, round, 'precommit', hash);
      if (!certificate) continue;
      const proposal = proposalAt(state, round, hash);
      if (!proposal) {
        effects.push({ kind: 'request-proposal', round, hash });
        continue;
      }
      const certified = { entry: proposal.body.entry, certificate };
      const checked = validateCertifiedEntry(certified, context);
      if (!checked.ok) {
        const authenticated = authenticateCertifiedEntry(certified, context);
        if (authenticated.ok)
          haltForCertifiedValue(state, authenticated.value, checked.error.code, effects);
        else
          halt(
            state,
            `Certified proof failed authentication: ${authenticated.error.code}`,
            effects,
          );
        continue;
      }
      if (haltForEntryControlFault(state, context, checked.value.entry, effects)) return;
      if (state.decision && entryHash(state.decision.entry) !== hash) {
        halt(state, 'Conflicting certified values', effects);
        continue;
      }
      if (!state.decision) {
        state.decision = certified;
        effects.push({ kind: 'commit', certified });
      }
    }
  }
}

function drive(
  state: ConsensusState,
  context: ProposalContext,
  secretKey: Uint8Array,
  effects: ConsensusEffect[],
  admitValue?: LocalVoteAdmissibility,
): Result<void> {
  maybeCommit(state, context, effects);
  if (state.halted !== null || state.decision !== null) return success(undefined);
  if (state.step === 'propose') {
    const waitingProposal = state.proposals.find((item) => item.body.entry.term === state.round);
    if (waitingProposal) {
      const voted = prevoteProposal(
        state,
        context,
        secretKey,
        waitingProposal,
        effects,
        admitValue,
      );
      if (!voted.ok) return voted;
    }
  }
  const q = quorumSize(context.membership.voters.length);
  for (const proposal of state.proposals.filter((item) => item.body.entry.term === state.round)) {
    const hash = proposalHash(proposal);
    const prevotes = quorumFor(state, context, state.round, 'prevote', hash);
    if (prevotes && (state.valid === null || state.valid.round < state.round)) {
      state.valid = { round: state.round, hash, proposal, prevotes };
    }
    if (prevotes && state.step === 'prevote' && !ownVote(state, 'precommit')) {
      state.locked = { round: state.round, hash, proposal, prevotes };
      const signed = signLocalVote(
        state,
        context,
        secretKey,
        'precommit',
        hash,
        effects,
        admitValue,
      );
      if (!signed.ok) return signed;
    }
  }
  if (state.step === 'prevote' && quorumFor(state, context, state.round, 'prevote', null)) {
    const signed = signLocalVote(state, context, secretKey, 'precommit', null, effects);
    if (!signed.ok) return signed;
  }
  if (!state.timers.prevote && votesAt(state, state.round, 'prevote').length >= q) {
    state.timers.prevote = true;
    effects.push({ kind: 'schedule-timeout', phase: 'prevote', round: state.round });
  }
  if (!state.timers.precommit && anyQuorum(state, context, state.round, 'precommit')) {
    state.timers.precommit = true;
    effects.push({ kind: 'schedule-timeout', phase: 'precommit', round: state.round });
  }
  maybeCommit(state, context, effects);
  return success(undefined);
}

function transition(
  state: ConsensusState,
  context: ProposalContext,
  action: (copy: ConsensusState, effects: ConsensusEffect[]) => Result<void>,
): Result<ConsensusTransition> {
  const restored = ownedStates.has(state)
    ? success(copyConsensusStateData(state))
    : restoreConsensusState(state, context, state.localSeat);
  if (!restored.ok) return restored;
  const copy = restored.value;
  const effects: ConsensusEffect[] = [];
  const applied = action(copy, effects);
  if (!applied.ok) return applied;
  try {
    const bytes = canonicalEncode(copy);
    const parsed = v.safeParse(stateSchema, canonicalDecode(bytes));
    if (!parsed.success)
      return failure('consensus-restore', 'Transition produced malformed safety state');
    if (ownedStates.has(state)) ownedStates.add(copy);
  } catch {
    return failure('consensus-restore', 'Transition produced malformed safety state');
  }
  return success({ state: copy, effects });
}

/** Only call this for a genuinely new height after the certified parent is stored. */
export function createConsensusState(
  context: ProposalContext,
  localSeat: Seat,
  provenOffender: ProvenOffender | null = null,
  pendingAccusation: ExcludeProposerControl | null = null,
): Result<ConsensusState> {
  const member = context.membership.voters.find((voter) => voter.seat === localSeat);
  if (!member || context.membership.genesisDigest !== genesisDigest(context.log.genesis))
    return failure('consensus-context', 'Local seat or genesis is not in certified membership');
  try {
    for (const voter of context.membership.voters) parsePeerId(voter.publicKey);
    quorumSize(context.membership.voters.length);
    if (
      new Set(context.membership.voters.map((voter) => voter.seat)).size !==
        context.membership.voters.length ||
      new Set(context.membership.voters.map((voter) => voter.publicKey)).size !==
        context.membership.voters.length
    )
      return failure('consensus-context', 'Certified voter set has duplicate seats or keys');
    if (
      context.membership.voters.some((voter, index, voters) => {
        const previous = voters[index - 1];
        return previous !== undefined && voter.seat <= previous.seat;
      }) ||
      new Set(context.excludedProposers).size !== context.excludedProposers.length ||
      context.excludedProposers.some(
        (seat) => !context.membership.voters.some((voter) => voter.seat === seat),
      )
    )
      return failure(
        'consensus-context',
        'Certified voter order or proposer exclusions are malformed',
      );
    proposerFor(context.log.head.seq + 1, 1, context.membership, context.excludedProposers);
  } catch {
    return failure('consensus-context', 'Certified voter set is malformed');
  }
  const state: ConsensusState = {
    version: 1,
    genesisDigest: context.membership.genesisDigest,
    epoch: context.membership.epoch,
    height: context.log.head.seq + 1,
    parentHash: entryHash(context.log.head),
    contextHash: consensusContextHash(context),
    localSeat,
    localPublicKey: member.publicKey,
    round: 1,
    step: 'propose',
    inputKnown: false,
    timers: { propose: false, prevote: false, precommit: false },
    proposals: [],
    votes: [],
    hints: [],
    equivocations: [],
    pendingAccusation,
    provenOffender,
    locked: null,
    valid: null,
    decision: null,
    halted: null,
    haltKind: null,
    unappliedCertificate: null,
  };
  if (provenOffender) {
    const checked = objectiveProofParentHash(provenOffender.control, context);
    if (!checked.ok || checked.value !== provenOffender.parentHash)
      return failure('consensus-context', 'First-offender proof has no certified parent');
    haltForControlFault(state, context, provenOffender.control, []);
  }
  if (
    pendingAccusation &&
    (!provenOffender ||
      toHex(hashValue(pendingAccusation)) !== toHex(hashValue(provenOffender.control)))
  )
    return failure('consensus-context', 'Pending accusation has no matching first proof');
  if (context.excludedProposers.includes(localSeat))
    terminalFault(state, 'Certified prefix excludes the local signing key', []);
  return success(state);
}

/** Never replace a malformed safety record with a fresh round-one state. */
export function restoreConsensusState(
  value: unknown,
  context: ProposalContext,
  localSeat: Seat,
): Result<ConsensusState> {
  let state: ConsensusState;
  try {
    // Persisted safety state is not a network envelope and may exceed its 256 KiB cap.
    const parsed = v.safeParse(stateSchema, canonicalDecode(canonicalEncode(value)));
    if (!parsed.success) return failure('consensus-restore', 'Safety record schema is malformed');
    state = parsed.output;
  } catch {
    return failure('consensus-restore', 'Safety record is not canonical data');
  }
  if (!bound(state, context, localSeat))
    return failure(
      'consensus-context',
      'Safety record belongs to another height, parent, game, epoch or key',
    );
  try {
    const proposalCounts = new Map<number, number>();
    for (const proposal of state.proposals) {
      const round = proposal.body.entry.term;
      const count = (proposalCounts.get(round) ?? 0) + 1;
      if (count > 2)
        return failure('consensus-restore', 'Safety record retains too many proposals per round');
      proposalCounts.set(round, count);
      if (!validateProposal(proposal, context).ok)
        return failure('consensus-restore', 'Stored proposal is invalid');
    }
    for (const vote of state.votes) {
      if (
        !validateVote(vote, context.membership).ok ||
        vote.body.seq !== state.height ||
        vote.body.term > state.round
      )
        return failure('consensus-restore', 'Stored vote is invalid');
    }
    if (
      new Set(state.votes.map((vote) => `${vote.body.seat}/${vote.body.term}/${vote.body.phase}`))
        .size !== state.votes.length
    )
      return failure('consensus-restore', 'Safety record contains duplicate votes');
    if (state.proposals.some((proposal) => proposal.body.entry.term > state.round))
      return failure('consensus-restore', 'Stored proposal is ahead of the persisted round');
    for (const hint of state.hints) {
      if (
        hint.round <= state.round ||
        (hint.kind === 'vote'
          ? !validateVote(hint.vote, context.membership).ok ||
            hint.vote.body.seat !== hint.seat ||
            hint.vote.body.term !== hint.round ||
            hint.vote.body.seq !== state.height
          : !validateProposal(hint.proposal, context).ok ||
            proposalSeat(hint.proposal, context) !== hint.seat ||
            hint.proposal.body.entry.term !== hint.round)
      )
        return failure('consensus-restore', 'Stored future-round hint is invalid');
    }
    if (new Set(state.hints.map((hint) => hint.seat)).size !== state.hints.length)
      return failure('consensus-restore', 'Safety record has duplicate future-round hints');
    for (const record of [state.valid, state.locked]) {
      if (!record) continue;
      if (
        record.round > state.round ||
        record.hash !== proposalHash(record.proposal) ||
        record.proposal.body.entry.term !== record.round ||
        !validateProposal(record.proposal, context).ok ||
        !verifyCertificate(record.prevotes, context.membership, {
          seq: state.height,
          term: record.round,
          phase: 'prevote',
          valueHash: record.hash,
        }).ok
      )
        return failure('consensus-restore', 'Stored lock or valid-value proof is invalid');
    }
    if (
      state.locked &&
      !state.votes.some(
        (vote) =>
          vote.body.seat === localSeat &&
          vote.body.term === state.locked?.round &&
          vote.body.phase === 'precommit' &&
          vote.body.valueHash === state.locked?.hash,
      )
    )
      return failure('consensus-restore', 'Stored lock has no matching local precommit');
    if (
      state.locked &&
      (!state.valid ||
        state.valid.round < state.locked.round ||
        (state.valid.round === state.locked.round && state.valid.hash !== state.locked.hash))
    )
      return failure('consensus-restore', 'Stored valid proof does not cover the local lock');
    const ownProposals = state.proposals.filter(
      (proposal) => proposalSeat(proposal, context) === localSeat,
    );
    if (
      new Set(ownProposals.map((proposal) => proposal.body.entry.term)).size !== ownProposals.length
    )
      return failure('consensus-restore', 'Safety record contains conflicting local proposals');
    const localCommitVotes = state.votes
      .filter(
        (vote) =>
          vote.body.seat === localSeat &&
          vote.body.phase === 'precommit' &&
          vote.body.valueHash !== null,
      )
      .toSorted((a, b) => b.body.term - a.body.term);
    const latestCommit = localCommitVotes[0];
    if (
      latestCommit &&
      (!state.locked ||
        state.locked.round !== latestCommit.body.term ||
        state.locked.hash !== latestCommit.body.valueHash)
    )
      return failure(
        'consensus-restore',
        'Latest local non-nil precommit has no matching persisted lock',
      );
    const localThisRound = state.votes.filter(
      (vote) => vote.body.seat === localSeat && vote.body.term === state.round,
    );
    if (state.step === 'propose' && localThisRound.length > 0)
      return failure('consensus-restore', 'Propose step conflicts with signed local vote');
    if (state.step !== 'propose' && !localThisRound.some((vote) => vote.body.phase === 'prevote'))
      return failure('consensus-restore', 'Voting step has no signed local prevote');
    if (state.step === 'prevote' && localThisRound.some((vote) => vote.body.phase === 'precommit'))
      return failure('consensus-restore', 'Prevote step conflicts with signed local precommit');
    if (
      state.step === 'precommit' &&
      !localThisRound.some((vote) => vote.body.phase === 'precommit')
    )
      return failure('consensus-restore', 'Precommit step has no signed local precommit');
    if (state.timers.propose && !state.inputKnown)
      return failure('consensus-restore', 'Proposal timer is inconsistent');
    if (
      !state.inputKnown &&
      (state.proposals.length > 0 || state.hints.some((hint) => hint.kind === 'proposal'))
    )
      return failure('consensus-restore', 'Stored proposal has no known-input marker');
    if (
      state.timers.prevote &&
      votesAt(state, state.round, 'prevote').length < quorumSize(context.membership.voters.length)
    )
      return failure('consensus-restore', 'Prevote timer has no quorum');
    if (state.timers.precommit && !anyQuorum(state, context, state.round, 'precommit'))
      return failure('consensus-restore', 'Precommit timer has no quorum');
    if (state.decision && !validateCertifiedEntry(state.decision, context).ok)
      return failure('consensus-restore', 'Stored decision certificate is invalid');
    if (
      (state.decision && hasUnrecordedOwnEntry(state, state.decision.entry)) ||
      (state.unappliedCertificate && hasUnrecordedOwnEntry(state, state.unappliedCertificate.entry))
    )
      return failure('consensus-restore', 'Safety proof contains an unrecorded local entry');
    if ((state.halted === null) !== (state.haltKind === null))
      return failure('consensus-restore', 'Stored halt reason and kind disagree');
    if (state.haltKind === 'certified-validation') {
      if (
        state.decision !== null ||
        state.unappliedCertificate === null ||
        state.unappliedCertificate.entry.seq !== state.height ||
        !authenticateCertifiedEntry(state.unappliedCertificate, context).ok
      )
        return failure('consensus-restore', 'Stored unapplied certificate is invalid');
    } else if (state.unappliedCertificate !== null) {
      return failure(
        'consensus-restore',
        'Only a certified-validation halt can retain a certificate',
      );
    }
    if (state.equivocations.length > 0) {
      for (const evidence of state.equivocations) {
        const checked =
          evidence.kind === 'vote'
            ? validateVote(evidence.first, context.membership).ok &&
              validateVote(evidence.second, context.membership).ok
            : validateProposal(evidence.first, context).ok &&
              validateProposal(evidence.second, context).ok;
        const sameTarget =
          evidence.kind === 'vote'
            ? evidence.first.body.seat === evidence.seat &&
              evidence.second.body.seat === evidence.seat &&
              evidence.first.body.seq === state.height &&
              evidence.second.body.seq === state.height &&
              evidence.first.body.term === evidence.round &&
              evidence.second.body.term === evidence.round &&
              evidence.first.body.phase === evidence.phase &&
              evidence.second.body.phase === evidence.phase &&
              evidence.first.body.valueHash !== evidence.second.body.valueHash
            : proposalSeat(evidence.first, context) === evidence.seat &&
              proposalSeat(evidence.second, context) === evidence.seat &&
              evidence.first.body.entry.term === evidence.round &&
              evidence.second.body.entry.term === evidence.round &&
              proposalHash(evidence.first) !== proposalHash(evidence.second);
        if (!checked || !sameTarget)
          return failure('consensus-restore', 'Stored equivocation evidence is invalid');
      }
    }
    if (state.provenOffender) {
      const proof = state.provenOffender;
      if (
        proof.atSeq > state.height ||
        (proof.atSeq === state.height && proof.parentHash !== state.parentHash)
      )
        return failure(
          'consensus-restore',
          'First-offender proof has a different height or parent',
        );
      const checked = objectiveProofParentHash(proof.control, context);
      if (!checked.ok || checked.value !== proof.parentHash)
        return failure('consensus-restore', 'First-offender proof has no certified parent');
    }
    if (state.pendingAccusation) {
      if (
        !state.provenOffender ||
        state.provenOffender.atSeq > state.height ||
        toHex(hashValue(state.provenOffender.control)) !== toHex(hashValue(state.pendingAccusation))
      )
        return failure('consensus-restore', 'Pending accusation has no matching current proof');
      const alreadyExcluded = context.excludedProposers.includes(state.pendingAccusation.offender);
      if (!alreadyExcluded && !validateObjectiveForProposal(state.pendingAccusation, context).ok)
        return failure('consensus-restore', 'Pending accusation is not objectively proven');
    }
    const referencedVotes = [
      ...state.proposals.flatMap((proposal) => proposal.body.prevotes),
      ...state.hints.flatMap((hint) =>
        hint.kind === 'vote' ? [hint.vote] : hint.proposal.body.prevotes,
      ),
      ...(state.valid?.prevotes ?? []),
      ...(state.locked?.prevotes ?? []),
      ...(state.decision?.certificate ?? []),
      ...(state.unappliedCertificate?.certificate ?? []),
      ...state.equivocations.flatMap((evidence) =>
        evidence.kind === 'vote'
          ? [evidence.first, evidence.second]
          : [...evidence.first.body.prevotes, ...evidence.second.body.prevotes],
      ),
    ];
    if (hasUnrecordedOwnVote(state, referencedVotes))
      return failure('consensus-restore', 'Safety proof contains an unrecorded local vote');
    const controls: ExcludeProposerControl[] = [];
    const includeControl = (entry: LogEntry): void => {
      if (entry.payload.kind === 'control') controls.push(entry.payload);
    };
    for (const proposal of state.proposals) includeControl(proposal.body.entry);
    for (const hint of state.hints)
      if (hint.kind === 'proposal') includeControl(hint.proposal.body.entry);
    if (state.valid) includeControl(state.valid.proposal.body.entry);
    if (state.locked) includeControl(state.locked.proposal.body.entry);
    if (state.decision) includeControl(state.decision.entry);
    if (state.provenOffender) controls.push(state.provenOffender.control);
    if (state.pendingAccusation) controls.push(state.pendingAccusation);
    for (const evidence of state.equivocations)
      controls.push({
        kind: 'control',
        action: 'exclude-proposer',
        offender: evidence.seat,
        evidence:
          evidence.kind === 'vote'
            ? { kind: 'vote-equivocation', first: evidence.first, second: evidence.second }
            : { kind: 'proposal-equivocation', first: evidence.first, second: evidence.second },
      });
    let observedOffender: Seat | null = null;
    for (const control of controls) {
      if (observedOffender !== null && observedOffender !== control.offender)
        terminalFault(state, 'Objective evidence proves a second Byzantine voter', []);
      observedOffender ??= control.offender;
      if (haltForControlFault(state, context, control, [])) break;
    }
    if (context.excludedProposers.includes(localSeat))
      terminalFault(state, 'Certified prefix excludes the local signing key', []);
    return success(state);
  } catch {
    return failure('consensus-restore', 'Safety record could not be verified');
  }
}

/** Signal that an applicable input exists; only then does proposal timing begin. */
export function inputAvailable(
  state: ConsensusState,
  context: ProposalContext,
): Result<ConsensusTransition> {
  return transition(state, context, (copy, effects) => {
    if (copy.decision || copy.halted) return success(undefined);
    copy.inputKnown = true;
    if (copy.step !== 'propose' || copy.timers.propose) return success(undefined);
    copy.timers.propose = true;
    effects.push({ kind: 'schedule-timeout', phase: 'propose', round: copy.round });
    if (
      proposerFor(copy.height, copy.round, context.membership, context.excludedProposers).seat ===
      copy.localSeat
    )
      effects.push({
        kind: 'request-value',
        round: copy.round,
        validHash: copy.valid?.hash ?? null,
      });
    return success(undefined);
  });
}

function retainAccusation(
  copy: ConsensusState,
  context: ProposalContext,
  control: ExcludeProposerControl,
  effects: ConsensusEffect[],
): Result<void> {
  const checked = objectiveProofParentHash(control, context);
  if (!checked.ok) return checked;
  if (haltForControlFault(copy, context, control, effects)) return success(undefined);
  if (context.excludedProposers.includes(control.offender) || copy.decision || copy.halted)
    return success(undefined);
  const evidence = control.evidence;
  const proposals =
    evidence.kind === 'proposal-equivocation'
      ? [evidence.first, evidence.second]
      : evidence.kind === 'vote-equivocation'
        ? []
        : [evidence.proposal];
  const votes =
    evidence.kind === 'vote-equivocation'
      ? [evidence.first, evidence.second]
      : proposals.flatMap((proposal) => proposal.body.prevotes);
  const retainedHistoricalProof =
    copy.provenOffender !== null &&
    copy.provenOffender.atSeq < copy.height &&
    toHex(hashValue(copy.provenOffender.control)) === toHex(hashValue(control));
  if (
    !retainedHistoricalProof &&
    (hasUnrecordedOwnVote(
      copy,
      votes.filter((vote) => validateVote(vote, context.membership).ok),
    ) ||
      proposals.some(
        (proposal) =>
          proposal.body.entry.sequencer === copy.localPublicKey &&
          !copy.proposals.some(
            (stored) =>
              stored.sig === proposal.sig && proposalHash(stored) === proposalHash(proposal),
          ),
      ))
  ) {
    halt(copy, 'Accusation contains an unrecorded local signature', effects);
    return success(undefined);
  }
  if (copy.pendingAccusation) return success(undefined);
  copy.provenOffender ??= {
    control,
    atSeq: objectiveEvidenceSeq(control),
    parentHash: checked.value,
  };
  copy.pendingAccusation = control;
  return success(undefined);
}

/** Retain an authenticated accusation before the adapter can gossip it. */
export function stageAccusation(
  state: ConsensusState,
  context: ProposalContext,
  control: ExcludeProposerControl,
): Result<ConsensusTransition> {
  return transition(state, context, (copy, effects) =>
    retainAccusation(copy, context, control, effects),
  );
}

/** Remove only an accusation already represented by the certified exclusion. */
export function clearStaleAccusation(
  state: ConsensusState,
  context: ProposalContext,
): Result<ConsensusTransition> {
  return transition(state, context, (copy) => {
    if (
      copy.pendingAccusation &&
      copy.provenOffender &&
      context.excludedProposers.includes(copy.pendingAccusation.offender) &&
      toHex(hashValue(copy.pendingAccusation)) === toHex(hashValue(copy.provenOffender.control))
    )
      copy.pendingAccusation = null;
    return success(undefined);
  });
}

/** Caller may invoke only after authenticating a conflicting certified history. */
export function terminalHalt(
  state: ConsensusState,
  context: ProposalContext,
  reason: string,
): Result<ConsensusTransition> {
  return transition(state, context, (copy, effects) => {
    halt(copy, reason, effects);
    return success(undefined);
  });
}

/** The local proposer signs a fresh or its latest quorum-backed value. */
export function propose(
  state: ConsensusState,
  context: ProposalContext,
  secretKey: Uint8Array,
  candidate?: LogEntry,
  admitValue?: LocalVoteAdmissibility,
): Result<ConsensusTransition> {
  return transition(state, context, (copy, effects) => {
    if (copy.decision || copy.halted || copy.step !== 'propose') return success(undefined);
    const proposer = proposerFor(
      copy.height,
      copy.round,
      context.membership,
      context.excludedProposers,
    );
    if (proposer.seat !== copy.localSeat)
      return failure('consensus-proposer', 'Only the selected proposer may sign');
    if (
      copy.proposals.some(
        (item) =>
          item.body.entry.term === copy.round && item.body.entry.sequencer === localPeer(copy),
      )
    )
      return success(undefined);
    const source = copy.valid?.proposal.body.entry ?? candidate;
    if (!source) return failure('consensus-value', 'No applicable proposal value is available');
    copy.inputKnown = true;
    try {
      const entry = signEntry(
        { ...entryBody(source), term: copy.round, sequencer: localPeer(copy) },
        secretKey,
      );
      const proposal = signProposal(
        {
          genesisDigest: copy.genesisDigest,
          epoch: copy.epoch,
          entry,
          validRound: copy.valid?.round ?? null,
          prevotes: copy.valid?.prevotes ?? [],
        },
        secretKey,
      );
      const checked = validateProposal(proposal, context);
      if (!checked.ok) return checked;
      if (checked.value.proposal.body.entry.payload.kind === 'control') {
        const retained = retainAccusation(
          copy,
          context,
          checked.value.proposal.body.entry.payload,
          effects,
        );
        if (!retained.ok || copy.halted) return retained;
      }
      recordProposal(copy, context, checked.value.proposal, effects);
      effects.push({ kind: 'broadcast-proposal', proposal: checked.value.proposal });
      const voted = prevoteProposal(
        copy,
        context,
        secretKey,
        checked.value.proposal,
        effects,
        admitValue,
      );
      if (!voted.ok) return voted;
      return drive(copy, context, secretKey, effects, admitValue);
    } catch {
      return failure(
        'consensus-key',
        'Local proposal key is unavailable or does not match this voter',
      );
    }
  });
}

function prevoteProposal(
  state: ConsensusState,
  context: ProposalContext,
  secretKey: Uint8Array,
  proposal: SignedProposal,
  effects: ConsensusEffect[],
  admitValue?: LocalVoteAdmissibility,
): Result<void> {
  if (proposal.body.entry.term !== state.round || state.step !== 'propose')
    return success(undefined);
  const hash = proposalHash(proposal);
  const accepts =
    !state.locked ||
    state.locked.hash === hash ||
    (proposal.body.validRound !== null && proposal.body.validRound >= state.locked.round);
  return signLocalVote(
    state,
    context,
    secretKey,
    'prevote',
    accepts ? hash : null,
    effects,
    admitValue,
  );
}

export function receiveProposal(
  state: ConsensusState,
  context: ProposalContext,
  secretKey: Uint8Array,
  value: unknown,
  admitValue?: LocalVoteAdmissibility,
): Result<ConsensusTransition> {
  return transition(state, context, (copy, effects) => {
    const checked = validateProposal(value, context);
    if (!checked.ok) {
      const evidence = authenticateProposalControlEvidence(value, context);
      if (evidence.ok && haltForControlFault(copy, context, evidence.value, effects))
        return success(undefined);
      return checked;
    }
    const proposal = checked.value.proposal;
    if (proposal.body.entry.payload.kind === 'control') {
      const retained = retainAccusation(copy, context, proposal.body.entry.payload, effects);
      if (!retained.ok || copy.halted) return retained;
    }
    if (hasUnrecordedOwnVote(copy, proposal.body.prevotes)) {
      halt(
        copy,
        'Unrecorded local vote in proposal proof indicates a stale safety record',
        effects,
      );
      return success(undefined);
    }
    const seat = proposalSeat(proposal, context);
    if (seat === undefined) return failure('consensus-proposer', 'Proposal signer is not a voter');
    const round = proposal.body.entry.term;
    if (
      seat === copy.localSeat &&
      !copy.proposals.some(
        (known) =>
          known.body.entry.term === round && proposalHash(known) === proposalHash(proposal),
      ) &&
      !copy.hints.some(
        (known) =>
          known.kind === 'proposal' &&
          known.round === round &&
          proposalHash(known.proposal) === proposalHash(proposal),
      )
    ) {
      halt(
        copy,
        'Unrecorded local proposal indicates a stale safety record or duplicate writer',
        effects,
      );
      return success(undefined);
    }
    if (copy.halted) return success(undefined);
    copy.inputKnown = true;
    if (round > copy.round) {
      addHint(copy, { kind: 'proposal', seat, round, proposal });
      maybeJump(copy, context, effects);
      if (round > copy.round) return success(undefined);
    }
    recordProposal(copy, context, proposal, effects);
    if (
      !copy.proposals.some(
        (known) =>
          known.body.entry.term === round && proposalHash(known) === proposalHash(proposal),
      )
    )
      return success(undefined);
    haltIfFaultThresholdExceeded(copy, context, effects);
    if (copy.halted) return success(undefined);
    if (copy.decision) return drive(copy, context, secretKey, effects, admitValue);
    const voted = prevoteProposal(copy, context, secretKey, proposal, effects, admitValue);
    return voted.ok ? drive(copy, context, secretKey, effects, admitValue) : voted;
  });
}

export function receiveVote(
  state: ConsensusState,
  context: ProposalContext,
  secretKey: Uint8Array,
  value: unknown,
  admitValue?: LocalVoteAdmissibility,
): Result<ConsensusTransition> {
  return transition(state, context, (copy, effects) => {
    const checked = validateVote(value, context.membership);
    if (!checked.ok) return checked;
    const vote = checked.value;
    if (vote.body.seq !== copy.height)
      return failure('consensus-height', 'Vote belongs to another height');
    if (
      vote.body.seat === copy.localSeat &&
      !copy.votes.some(
        (known) =>
          known.body.seat === copy.localSeat &&
          known.body.term === vote.body.term &&
          known.body.phase === vote.body.phase &&
          sameVote(known, vote),
      )
    ) {
      halt(
        copy,
        'Unrecorded local vote indicates a stale safety record or duplicate writer',
        effects,
      );
      return success(undefined);
    }
    if (copy.halted) return success(undefined);
    if (vote.body.term > copy.round) {
      addHint(copy, { kind: 'vote', seat: vote.body.seat, round: vote.body.term, vote });
      maybeJump(copy, context, effects);
      if (vote.body.term > copy.round) return success(undefined);
    }
    recordVote(copy, vote, effects);
    haltIfFaultThresholdExceeded(copy, context, effects);
    return copy.halted ? success(undefined) : drive(copy, context, secretKey, effects, admitValue);
  });
}

/** A complete old-round certificate remains valid after local round changes. */
export function receiveCommit(
  state: ConsensusState,
  context: ProposalContext,
  value: unknown,
): Result<ConsensusTransition> {
  return transition(state, context, (copy, effects) => {
    const authenticated = authenticateCertifiedEntry(value, context);
    if (!authenticated.ok) return authenticated;
    const entry = authenticated.value.entry;
    if (entry.seq <= context.log.head.seq)
      return failure('stale-entry', 'Entry was already superseded');
    if (entry.seq > context.log.head.seq + 1)
      return failure('missing-ancestor', 'Fetch missing log entries before validating this entry');
    if (hasUnrecordedOwnVote(copy, authenticated.value.certificate)) {
      halt(
        copy,
        'Unrecorded local vote in commit certificate indicates a stale safety record',
        effects,
      );
      return success(undefined);
    }
    if (hasUnrecordedOwnEntry(copy, entry)) {
      halt(copy, 'Unrecorded local entry indicates a stale safety record', effects);
      return success(undefined);
    }
    const checked = validateCertifiedEntry(authenticated.value, context);
    if (!checked.ok) {
      haltForCertifiedValue(copy, authenticated.value, checked.error.code, effects);
      return success(undefined);
    }
    if (haltForEntryControlFault(copy, context, checked.value.entry, effects))
      return success(undefined);
    const certified: CertifiedEntry = {
      entry: checked.value.entry,
      certificate: [...checked.value.certificate],
    };
    if (copy.decision && entryHash(copy.decision.entry) !== checked.value.hash)
      halt(copy, 'Conflicting certified values', effects);
    else if (!copy.decision && !copy.halted) {
      copy.decision = certified;
      effects.push({ kind: 'commit', certified });
    }
    return success(undefined);
  });
}

/** Resume only a certified-value halt after reconstructing the same prefix in a fresh engine. */
export function resumeAfterReplay(
  state: ConsensusState,
  freshContext: ProposalContext,
): Result<ConsensusTransition> {
  const restored = restoreConsensusState(state, freshContext, state.localSeat);
  if (!restored.ok) return restored;
  const copy = restored.value;
  if (copy.haltKind !== 'certified-validation' || copy.unappliedCertificate === null)
    return failure('consensus-repair-unavailable', 'This halt cannot be cleared by replay');
  const checked = validateCertifiedEntry(copy.unappliedCertificate, freshContext);
  if (!checked.ok)
    return failure('consensus-repair-incomplete', 'Certified value still fails replay validation');
  const effects: ConsensusEffect[] = [];
  if (haltForEntryControlFault(copy, freshContext, checked.value.entry, effects))
    return success({ state: copy, effects });
  const certified: CertifiedEntry = {
    entry: checked.value.entry,
    certificate: [...checked.value.certificate],
  };
  copy.decision = certified;
  copy.halted = null;
  copy.haltKind = null;
  copy.unappliedCertificate = null;
  return success({ state: copy, effects: [{ kind: 'commit', certified }] });
}

export function timeout(
  state: ConsensusState,
  context: ProposalContext,
  secretKey: Uint8Array,
  phase: TimeoutPhase,
  round: number,
  admitValue?: LocalVoteAdmissibility,
): Result<ConsensusTransition> {
  return transition(state, context, (copy, effects) => {
    if (copy.decision || copy.halted || round !== copy.round || !copy.timers[phase])
      return success(undefined);
    if (phase === 'propose' && copy.step === 'propose') {
      const signed = signLocalVote(copy, context, secretKey, 'prevote', null, effects);
      return signed.ok ? drive(copy, context, secretKey, effects, admitValue) : signed;
    }
    if (phase === 'prevote' && copy.step === 'propose') {
      const prevoted = signLocalVote(copy, context, secretKey, 'prevote', null, effects);
      if (!prevoted.ok) return prevoted;
    }
    if (phase === 'prevote' && copy.step === 'prevote') {
      const signed = signLocalVote(copy, context, secretKey, 'precommit', null, effects);
      return signed.ok ? drive(copy, context, secretKey, effects, admitValue) : signed;
    }
    if (phase === 'precommit') {
      enterRound(copy, context, copy.round + 1, effects);
      return drive(copy, context, secretKey, effects, admitValue);
    }
    return success(undefined);
  });
}

/** Re-arm durable timers and retransmit signed local messages after restart.
 * Commit delivery is at least once; the consumer deduplicates by height/value.
 */
export function recoverConsensusEffects(
  state: ConsensusState,
  context: ProposalContext,
): Result<ConsensusEffect[]> {
  const restored = restoreConsensusState(state, context, state.localSeat);
  if (!restored.ok) return restored;
  const current = restored.value;
  if (current.halted) return success([{ kind: 'halt', reason: current.halted }]);
  const effects: ConsensusEffect[] = [];
  const signed = [
    ...current.proposals
      .filter((proposal) => proposalSeat(proposal, context) === current.localSeat)
      .map((proposal) => ({
        round: proposal.body.entry.term,
        order: 0,
        effect: { kind: 'broadcast-proposal' as const, proposal },
      })),
    ...current.votes
      .filter((vote) => vote.body.seat === current.localSeat)
      .map((vote) => ({
        round: vote.body.term,
        order: 1,
        effect: { kind: 'broadcast-vote' as const, vote },
      })),
  ].toSorted((a, b) => b.round - a.round || a.order - b.order);
  effects.push(...signed.map(({ effect }) => effect));
  if (current.decision) {
    effects.push({ kind: 'commit', certified: current.decision });
    return success(effects);
  }
  if (current.step === 'propose' && current.timers.propose)
    effects.push({ kind: 'schedule-timeout', phase: 'propose', round: current.round });
  if ((current.step === 'propose' || current.step === 'prevote') && current.timers.prevote)
    effects.push({ kind: 'schedule-timeout', phase: 'prevote', round: current.round });
  if (current.timers.precommit)
    effects.push({ kind: 'schedule-timeout', phase: 'precommit', round: current.round });
  if (
    current.step === 'propose' &&
    proposerFor(current.height, current.round, context.membership, context.excludedProposers)
      .seat === current.localSeat &&
    !current.proposals.some(
      (proposal) =>
        proposal.body.entry.term === current.round &&
        proposalSeat(proposal, context) === current.localSeat,
    )
  )
    effects.push({
      kind: 'request-value',
      round: current.round,
      validHash: current.valid?.hash ?? null,
    });
  return success(effects);
}

export type ConsensusEvent =
  | { kind: 'input-available' }
  | { kind: 'propose'; candidate?: LogEntry }
  | { kind: 'proposal'; proposal: unknown }
  | { kind: 'vote'; vote: unknown }
  | { kind: 'commit'; certified: unknown }
  | { kind: 'stage-accusation'; control: ExcludeProposerControl }
  | { kind: 'clear-stale-accusation' }
  | { kind: 'terminal-halt'; reason: string }
  | { kind: 'resume-after-replay' }
  | { kind: 'timeout'; phase: TimeoutPhase; round: number };

/** Private, validated state for one controller height. Public reducers stay fully validating. */
export interface OwnedConsensusState {
  matchesOpenedContext(candidate: ProposalContext): boolean;
  snapshot(): Result<ConsensusState>;
  dispatch(
    event: ConsensusEvent,
    secretKey: Uint8Array,
    admitValue?: LocalVoteAdmissibility,
  ): Result<ConsensusTransition>;
  commit(): Result<void>;
  discard(): void;
}

class OwnedConsensusStateImpl implements OwnedConsensusState {
  private pending: ConsensusState | null = null;

  constructor(
    private state: ConsensusState,
    private readonly context: ProposalContext,
    private readonly stamp: ContextStamp,
  ) {
    ownedStates.add(state);
  }

  matchesOpenedContext(candidate: ProposalContext): boolean {
    try {
      const replayed = contextStamp(candidate);
      // Full replay rebuilds these record wrappers and ancestry closures. Engine,
      // policy, prototypes and their function references must remain identical.
      const rebuilt = new Set([
        'context',
        // runtimeReferences depth zero repeats the wrapper itself; deeper
        // prototype references remain part of the comparison.
        'context/prototype/0',
        'log',
        'log/prototype/0',
        'context/verifyHistoricalCheat',
        'context/verifyHistoricalAccusation',
      ]);
      const openedFunctions = this.stamp.functions.filter(([name]) => !rebuilt.has(name));
      const replayedFunctions = replayed.functions.filter(([name]) => !rebuilt.has(name));
      return (
        sameBytes(this.stamp.contextBytes, replayed.contextBytes) &&
        openedFunctions.length === replayedFunctions.length &&
        openedFunctions.every(
          ([name, reference], index) =>
            name === replayedFunctions[index]?.[0] && reference === replayedFunctions[index]?.[1],
        )
      );
    } catch {
      return false;
    }
  }

  private checkContext(): Result<void> {
    let current: ContextStamp;
    try {
      current = contextStamp(this.context);
    } catch {
      return failure('consensus-context', 'Certified context changed to noncanonical data');
    }
    if (sameContextStamp(this.stamp, current)) return success(undefined);
    if (this.pending)
      return failure('consensus-context', 'Certified context changed during persistence');
    // Once the opening stamp differs, this context cannot validate stored
    // proposals or locks. Only durable replay may establish their authority.
    return failure('consensus-context', 'Certified context changed; restore this voting record');
  }

  snapshot(): Result<ConsensusState> {
    const checked = this.checkContext();
    return checked.ok ? success(copyConsensusStateData(this.state)) : checked;
  }

  dispatch(
    event: ConsensusEvent,
    secretKey: Uint8Array,
    admitValue?: LocalVoteAdmissibility,
  ): Result<ConsensusTransition> {
    const checked = this.checkContext();
    if (!checked.ok) return checked;
    if (this.pending) return failure('consensus-pending', 'Persist the previous transition first');
    let next: Result<ConsensusTransition>;
    switch (event.kind) {
      case 'input-available':
        next = inputAvailable(this.state, this.context);
        break;
      case 'propose':
        next = propose(this.state, this.context, secretKey, event.candidate, admitValue);
        break;
      case 'proposal':
        next = receiveProposal(this.state, this.context, secretKey, event.proposal, admitValue);
        break;
      case 'vote':
        next = receiveVote(this.state, this.context, secretKey, event.vote, admitValue);
        break;
      case 'commit':
        next = receiveCommit(this.state, this.context, event.certified);
        break;
      case 'stage-accusation':
        next = stageAccusation(this.state, this.context, event.control);
        break;
      case 'clear-stale-accusation':
        next = clearStaleAccusation(this.state, this.context);
        break;
      case 'terminal-halt':
        next = terminalHalt(this.state, this.context, event.reason);
        break;
      case 'resume-after-replay':
        next = resumeAfterReplay(this.state, this.context);
        break;
      case 'timeout':
        next = timeout(this.state, this.context, secretKey, event.phase, event.round, admitValue);
        break;
      default: {
        const unknownEvent: never = event;
        return failure('consensus-event', `Unknown consensus event: ${String(unknownEvent)}`);
      }
    }
    const after = this.checkContext();
    if (!after.ok) return after;
    if (!next.ok) return next;
    this.pending = copyConsensusStateData(next.value.state);
    ownedStates.add(this.pending);
    return success({ state: copyConsensusStateData(this.pending), effects: next.value.effects });
  }

  commit(): Result<void> {
    if (!this.pending) throw new Error('No persisted consensus transition to install');
    let current: ContextStamp;
    try {
      current = contextStamp(this.context);
    } catch {
      return failure('consensus-context', 'Certified context changed during persistence');
    }
    if (!sameContextStamp(this.stamp, current))
      return failure('consensus-context', 'Certified context changed during persistence');
    this.state = this.pending;
    this.pending = null;
    return success(undefined);
  }

  discard(): void {
    this.pending = null;
  }
}

export function openOwnedConsensusState(
  value: ConsensusState,
  context: ProposalContext,
  seat: Seat,
): Result<OwnedConsensusState> {
  const restored = restoreConsensusState(value, context, seat);
  if (!restored.ok) return restored;
  try {
    return success(new OwnedConsensusStateImpl(restored.value, context, contextStamp(context)));
  } catch {
    return failure('consensus-restore', 'Certified context is not canonical data');
  }
}


FILE packages/protocol/src/consensus-controller.ts
import { canonicalDecode, canonicalEncode, sha256, toHex } from '@cp2p/codec';
import { identityFromSecret } from '@cp2p/crypto';
import { failure, success } from '@cp2p/engine';
import type { Result, Seat } from '@cp2p/engine';
import {
  copyConsensusStateData,
  createConsensusState,
  openOwnedConsensusState,
  recoverConsensusEffects,
  restoreConsensusState,
} from './consensus.js';
import type {
  ConsensusEffect,
  ConsensusEvent,
  LocalVoteAdmissibility,
  OwnedConsensusState,
  ConsensusState,
  ConsensusTransition,
} from './consensus.js';
import type { ProposalContext } from './proposal.js';
import type { SafetyStore, StoredSafety } from './safety-store.js';
import { MAX_MESSAGE_BYTES } from './validation.js';

export type { ConsensusEvent } from './consensus.js';

export interface ConsensusControllerOptions {
  context: ProposalContext;
  seat: Seat;
  secretKey: Uint8Array;
  /** One record for this game/key/height, retained across controller crashes. */
  store: SafetyStore;
  /** Repair must reuse exact durable bytes without normalizing newly found terminal evidence. */
  requireExactRestore?: boolean;
  /** Effects are at-least-once. Handlers must deduplicate committed sequence/value. */
  onEffects: (effects: readonly ConsensusEffect[]) => void | Promise<void>;
  /** Local admission only. It must not alter replay or objective validity. */
  beforePersist?: (previous: ConsensusState, next: ConsensusState) => Result<void>;
  admitLocalValue?: LocalVoteAdmissibility;
}

/**
 * Serializes a single height's transitions and persists before emission.
 * Opening the next height requires a separately persisted certified parent.
 */
export class ConsensusController {
  private queue: Promise<unknown> = Promise.resolve();
  private stopped = false;
  private contextFault = false;
  private persistedBytes: Uint8Array;
  private readonly secretKey: Uint8Array;
  private readonly rejectedProposals = new Map<string, { code: string; message: string }>();

  private constructor(
    private readonly options: ConsensusControllerOptions,
    private state: ConsensusState,
    private revision: number,
    private readonly owned: OwnedConsensusState,
  ) {
    this.secretKey = options.secretKey.slice();
    this.persistedBytes = canonicalEncode(state);
  }

  /** Only for a genuinely new height; existing or lost stores are not reset here. */
  static async create(options: ConsensusControllerOptions): Promise<Result<ConsensusController>> {
    const validKey = checkLocalKey(options);
    if (!validKey.ok) return validKey;
    const initial = createConsensusState(options.context, options.seat);
    if (!initial.ok) return initial;
    try {
      if (await options.store.load())
        return failure(
          'consensus-store-exists',
          'Restore existing vote records instead of resetting',
        );
      const owned = openOwnedConsensusState(initial.value, options.context, options.seat);
      if (!owned.ok) return owned;
      const saved = await options.store.save(null, canonicalEncode(initial.value));
      if (!saved)
        return failure('consensus-write-conflict', 'Another writer initialized this voting record');
      return success(new ConsensusController(options, initial.value, 0, owned.value));
    } catch {
      return failure('consensus-storage', 'Could not persist the initial voting record');
    }
  }

  /** An absent or damaged record fails closed; this never creates round-one state. */
  static async restore(options: ConsensusControllerOptions): Promise<Result<ConsensusController>> {
    const validKey = checkLocalKey(options);
    if (!validKey.ok) return validKey;
    let record: StoredSafety | null;
    try {
      record = await options.store.load();
    } catch {
      return failure('consensus-storage', 'Could not read the voting record');
    }
    if (!record)
      return failure(
        'consensus-store-missing',
        'The voting record is missing; key replacement is required',
      );
    if (!Number.isSafeInteger(record.revision) || record.revision < 0)
      return failure('consensus-storage', 'Stored voting revision is invalid');
    let restored: Result<ConsensusState>;
    try {
      restored = restoreConsensusState(
        canonicalDecode(record.bytes),
        options.context,
        options.seat,
      );
    } catch {
      return failure('consensus-storage', 'Stored voting data is not valid canonical data');
    }
    if (!restored.ok) return restored;
    let revision = record.revision;
    const normalized = canonicalEncode(restored.value);
    if (!sameBytes(normalized, record.bytes)) {
      if (options.requireExactRestore || restored.value.haltKind !== 'terminal')
        return failure('consensus-restore', 'Voting record changed without a terminal proof');
      try {
        if (!(await options.store.save(revision, normalized)))
          return failure('consensus-write-conflict', 'Voting record changed during terminal halt');
      } catch {
        return failure('consensus-storage', 'Could not persist the verified terminal halt');
      }
      revision++;
    }
    const owned = openOwnedConsensusState(restored.value, options.context, options.seat);
    return owned.ok
      ? success(new ConsensusController(options, restored.value, revision, owned.value))
      : owned;
  }

  /** Returns a detached, verified snapshot, never the mutable internal record. */
  snapshot(): Result<ConsensusState> {
    const snapshot = this.owned.snapshot();
    if (!snapshot.ok) {
      this.stopVoting(snapshot.error.code);
      return snapshot;
    }
    if (!sameBytes(canonicalEncode(snapshot.value), canonicalEncode(this.state))) {
      this.stopVoting();
      return failure('consensus-restore', 'Restore to persist newly verified terminal evidence');
    }
    return snapshot;
  }

  /** The opening stamp remains usable after the mutable derived context fails its guard. */
  opensOn(context: ProposalContext): boolean {
    return this.owned.matchesOpenedContext(context);
  }

  hasContextFault(): boolean {
    return this.contextFault;
  }

  settled(): Promise<void> {
    return this.queue.then(
      () => undefined,
      () => undefined,
    );
  }

  matchesPersistedRecord(record: StoredSafety): boolean {
    return record.revision === this.revision && sameBytes(record.bytes, this.persistedBytes);
  }

  /** Expected CAS revision for atomically committing this controller's height. */
  persistedRevision(): number {
    return this.revision;
  }

  /** Call after restoring to retransmit signed records and re-arm timers. */
  resume(): Promise<Result<void>> {
    return this.enqueue(async () => {
      const snapshot = this.snapshot();
      if (!snapshot.ok) return snapshot;
      const recovered = recoverConsensusEffects(this.state, this.options.context);
      if (!recovered.ok) {
        this.stopVoting();
        return recovered;
      }
      return this.emit(recovered.value);
    });
  }

  dispatch(event: ConsensusEvent): Promise<Result<void>> {
    return this.enqueue(async () => {
      if (event.kind === 'proposal' && this.isRecordedProposalReplay(event.proposal)) {
        const checked = this.snapshot();
        return checked.ok ? success(undefined) : checked;
      }
      const proposalKey = event.kind === 'proposal' ? this.proposalKey(event.proposal) : null;
      const rejected = proposalKey ? this.rejectedProposals.get(proposalKey) : undefined;
      if (rejected) {
        const checked = this.snapshot();
        if (!checked.ok) return checked;
        return failure(rejected.code, rejected.message, {
          proposalEntryRejected: true,
          cached: true,
        });
      }
      const next = this.reduce(event);
      if (!next.ok) {
        if (next.error.code === 'consensus-restore' || next.error.code === 'consensus-context')
          this.stopVoting(next.error.code);
        else if (
          proposalKey &&
          next.error.details?.proposalEntryRejected === true &&
          next.error.details.proposalControl !== true
        ) {
          // Entry validation depends on this controller's fixed certified parent,
          // not its current round/votes. Controls can discover a second offender
          // after another proof is retained, so always reconsider them.
          this.rejectedProposals.set(proposalKey, {
            code: next.error.code,
            message: next.error.message,
          });
          if (this.rejectedProposals.size > 16) {
            const oldest = this.rejectedProposals.keys().next().value;
            if (oldest !== undefined) this.rejectedProposals.delete(oldest);
          }
        }
        return next;
      }
      const candidate = next.value.state;
      const admitted = this.options.beforePersist?.(
        copyConsensusStateData(this.state),
        copyConsensusStateData(candidate),
      );
      if (admitted && !admitted.ok) {
        this.owned.discard();
        return admitted;
      }
      let persistedBytes: Uint8Array;
      try {
        const bytes = canonicalEncode(candidate);
        persistedBytes = bytes.slice();
        if (!(await this.options.store.save(this.revision, bytes))) {
          this.owned.discard();
          this.stopped = true;
          return failure(
            'consensus-write-conflict',
            'Voting stopped because a newer record exists',
          );
        }
      } catch {
        this.owned.discard();
        this.stopped = true;
        return failure(
          'consensus-storage',
          'Voting stopped because its state could not be persisted',
        );
      }
      this.persistedBytes = persistedBytes;
      this.revision += 1;
      const committed = this.owned.commit();
      if (!committed.ok) {
        this.owned.discard();
        this.stopVoting(committed.error.code);
        return committed;
      }
      this.state = copyConsensusStateData(candidate);
      // A dispose/crash during the write must not transmit after the write resolves.
      if (this.stopped)
        return failure('consensus-stopped', 'Controller stopped during persistence');
      return this.emit(next.value.effects);
    });
  }

  dispose(): void {
    this.stopVoting();
  }

  private stopVoting(code?: string): void {
    if (code === 'consensus-context') this.contextFault = true;
    this.stopped = true;
    this.secretKey.fill(0);
    this.rejectedProposals.clear();
  }

  private proposalKey(value: unknown): string | null {
    try {
      const bytes = canonicalEncode(value);
      return bytes.length <= MAX_MESSAGE_BYTES ? toHex(sha256(bytes)) : null;
    } catch {
      return null;
    }
  }

  /** Stored proposals were validated before persistence; exact replays need no transition. */
  private isRecordedProposalReplay(value: unknown): boolean {
    let bytes: Uint8Array;
    try {
      bytes = canonicalEncode(value);
    } catch {
      return false;
    }
    if (bytes.byteLength > MAX_MESSAGE_BYTES) return false;
    const recorded = [
      ...this.state.proposals,
      ...this.state.hints.flatMap((hint) => (hint.kind === 'proposal' ? [hint.proposal] : [])),
    ].find((proposal) => sameBytes(bytes, canonicalEncode(proposal)));
    if (!recorded) return false;
    // A proposal retained before entering its round may still need its first vote.
    return !(
      recorded.body.entry.term === this.state.round &&
      this.state.step === 'propose' &&
      !this.state.votes.some(
        (vote) =>
          vote.body.seat === this.state.localSeat &&
          vote.body.term === this.state.round &&
          vote.body.phase === 'prevote',
      )
    );
  }

  private enqueue(operation: () => Promise<Result<void>>): Promise<Result<void>> {
    const result = this.queue.then(async (): Promise<Result<void>> => {
      if (this.stopped)
        return failure('consensus-stopped', 'Restore the persisted record before continuing');
      try {
        return await operation();
      } catch {
        this.owned.discard();
        this.stopVoting();
        return failure('consensus-controller', 'Consensus transition failed; voting has stopped');
      }
    });
    this.queue = result;
    return result;
  }

  private reduce(event: ConsensusEvent): Result<ConsensusTransition> {
    return this.owned.dispatch(event, this.secretKey, this.options.admitLocalValue);
  }

  private async emit(effects: readonly ConsensusEffect[]): Promise<Result<void>> {
    if (effects.length === 0) return success(undefined);
    try {
      await this.options.onEffects(effects);
      return success(undefined);
    } catch {
      // The saved state can reproduce signed messages after a partial delivery.
      this.stopped = true;
      return failure('consensus-effects', 'Effect delivery failed; restore before retrying');
    }
  }
}

function sameBytes(a: Uint8Array, b: Uint8Array): boolean {
  return a.length === b.length && a.every((byte, index) => byte === b[index]);
}

function checkLocalKey(options: ConsensusControllerOptions): Result<void> {
  try {
    const identity = identityFromSecret(options.secretKey);
    const voter = options.context.membership.voters.find((member) => member.seat === options.seat);
    return voter?.publicKey === identity.peerId
      ? success(undefined)
      : failure('consensus-key', 'The local key does not match the certified voter');
  } catch {
    return failure('consensus-key', 'The local voting key is invalid');
  }
}


FILE packages/protocol/src/audit.ts
import { fromBase64Url, hashValue, toBase64Url, toHex } from '@cp2p/codec';
import { scalarFromBytes } from '@cp2p/crypto';
import { LocalGame, RESOURCES, failure, success } from '@cp2p/engine';
import type { Engine, PrivateInputData, Result, Seat } from '@cp2p/engine';
import { decodeDeckCard } from './deck-draw.js';
import { createDeckSecretSource } from './deck-source.js';
import { entryHash } from './genesis.js';
import { verifyRevealedMaster } from './genesis-secrets.js';
import { reconstructPrivateSeats } from './private-replay.js';
import { initialProposalContext, replayCertifiedPrefix } from './replay.js';
import type { ReplayPolicy } from './replay.js';
import { openStealContribution } from './steal-delivery.js';
import { createStealSecretSource } from './steal-source.js';
import type { AuditEntryRef, AuditInputError, AuditReport, AuditViolation } from './audit-types.js';
import type { ProposalContext } from './proposal.js';
import type { Genesis } from './types.js';

const MAX_DIAGNOSTICS = 16;

function isSeat(value: unknown): value is Seat {
  return typeof value === 'number' && Number.isInteger(value) && value >= 0 && value <= 5;
}

export interface AuditCertifiedGameInput {
  readonly genesisEntry: unknown;
  readonly entries: readonly unknown[];
  readonly engine: Engine;
  readonly policy: ReplayPolicy;
  readonly masters: readonly { readonly seat: Seat; readonly master: Uint8Array }[];
}

function ref(entry: Parameters<typeof entryHash>[0]): AuditEntryRef {
  return { seq: entry.seq, hash: entryHash(entry) };
}

function issue(seq: number, seat: Seat | null, kind: string): AuditViolation {
  return { seq, seat, kind, detail: kind };
}

function selectedResource(
  hand: Readonly<Record<string, number>>,
  index: number,
): (typeof RESOURCES)[number] | null {
  let cursor = index;
  for (const resource of RESOURCES) {
    cursor -= hand[resource] ?? 0;
    if (cursor < 0) return resource;
  }
  return null;
}

function privateDataFor(
  input: NonNullable<Parameters<LocalGame['applyRecorded']>[0]>,
  prior: ProposalContext,
  next: ProposalContext,
  game: LocalGame,
  masters: ReadonlyMap<Seat, Uint8Array>,
  genesis: Genesis,
): Result<Partial<Record<Seat, PrivateInputData>>> {
  if (input.kind !== 'system') return success({});
  if (input.type === 'CARD_DEALT') {
    if (!isSeat(input.seat) || !genesis.config.seats.includes(input.seat))
      return failure('audit-draw-seat', 'Certified draw seat is invalid');
    const deck = next.log.crypto?.decks.decks.find(
      (item) => item.commitment.definition.deckId === input.deck,
    );
    const slot = deck?.slots.find((item) => item.slotId === input.slotId);
    const master = masters.get(input.seat);
    if (!deck || !slot || slot.seat !== input.seat || !master)
      return failure('audit-draw-context', 'Certified draw lacks its original receipt or master');
    const source = createDeckSecretSource(master, deck.commitment.definition, input.seat);
    try {
      const decoded = decodeDeckCard(
        deck.setup,
        slot.receipt,
        source.lock(slot.receipt.operation.position),
        slot.unlockSigners,
      );
      return decoded.ok ? success({ [input.seat]: { card: decoded.value.card } }) : decoded;
    } finally {
      source.dispose();
    }
  }
  if (input.type === 'STEAL_RESULT') {
    const fixed = prior.log.crypto?.steal?.fixed;
    const operation = fixed?.operation;
    if (
      !fixed ||
      !operation ||
      input.thief !== operation.thief.seat ||
      input.victim !== operation.victim.seat
    )
      return failure('audit-steal-context', 'Certified steal lacks its fixed operation');
    const victimHand = game.privateView(operation.victim.seat)?.hand;
    const victimTotal = victimHand
      ? RESOURCES.reduce((sum, resource) => sum + (victimHand[resource] ?? 0), 0)
      : -1;
    const expected = victimHand ? selectedResource(victimHand, operation.index) : null;
    if (!expected || victimTotal !== operation.handSize)
      return failure('audit-steal-index', 'Frozen index differs from the omniscient victim hand');
    const master = masters.get(operation.thief.seat);
    const owner = genesis.seats.find((seat) => seat.seat === operation.thief.seat);
    if (!master || !owner)
      return failure('audit-steal-master', 'Original thief master is unavailable');
    const source = createStealSecretSource(
      master,
      genesis.ceremonyNonce,
      operation.thief.seat,
      owner.publicKey,
    );
    try {
      const opened = openStealContribution(
        operation,
        fixed.contribution,
        source.encryptionSecret(),
        fixed.signer,
      );
      if (!opened.ok) return opened;
      if (opened.value.resource !== expected)
        return failure(
          'audit-steal-resource',
          'Certified transfer differs from the frozen victim card',
        );
      return success({
        [operation.thief.seat]: { resource: expected },
        [operation.victim.seat]: { resource: expected },
      });
    } finally {
      source.dispose();
    }
  }
  return success({});
}

/** Reconstruct a finished certified game without treating bad reveal input as an accusation. */
export function auditCertifiedGame(input: AuditCertifiedGameInput): AuditReport {
  const violations: AuditViolation[] = [];
  const inputErrors: AuditInputError[] = [];
  const masters = new Map<Seat, Uint8Array>();
  let terminal: AuditEntryRef | null = null;
  let finalHead: AuditEntryRef | null = null;
  let historyError: { code: string } | null = null;
  let auditError: AuditReport['auditError'] = null;
  let finalHiddenVictoryPoints: AuditReport['finalHiddenVictoryPoints'] = null;
  let cheatFindings: AuditReport['cheatFindings'] = [];
  let missingSeats: Seat[] = [];
  let complete = false;
  const report = (): AuditReport => ({
    ok:
      complete &&
      violations.length === 0 &&
      inputErrors.length === 0 &&
      !historyError &&
      !auditError,
    complete,
    missingSeats,
    violations,
    inputErrors,
    cheatFindings,
    terminal,
    finalHead,
    historyError,
    auditError,
    finalHiddenVictoryPoints,
  });
  const processingFailure = (seq: number, code: string): AuditReport => {
    auditError = { seq, code };
    complete = false;
    return report();
  };
  try {
    const publicReplay = replayCertifiedPrefix(
      input.genesisEntry,
      input.entries,
      input.engine,
      input.policy,
      (entry, next) => {
        if (!terminal && next.log.state.result) terminal = ref(entry.entry);
        return success(undefined);
      },
    );
    if (!publicReplay.ok) {
      historyError = { code: publicReplay.error.code };
      return report();
    }
    const { context } = publicReplay.value;
    const { genesis, crypto } = context.log;
    finalHead = ref(context.log.head);
    cheatFindings = crypto?.cheats.slice(0, MAX_DIAGNOSTICS) ?? [];
    if (!terminal || !context.log.state.result) return report();
    if (genesis.security !== 'verified' || !crypto) {
      historyError = { code: 'audit-unverified-game' };
      return report();
    }
    if (!Array.isArray(input.masters)) {
      inputErrors.push({ seat: null, kind: 'master-list' });
      return report();
    }
    const seats = new Set(genesis.seats.map((seat) => seat.seat));
    const seen = new Set<Seat>();
    for (const reveal of input.masters) {
      if (!reveal || !seats.has(reveal.seat) || seen.has(reveal.seat)) {
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat: null, kind: 'master-seat-or-duplicate' });
        continue;
      }
      seen.add(reveal.seat);
      if (!(reveal.master instanceof Uint8Array) || reveal.master.length !== 32) {
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat: reveal.seat, kind: 'master-scalar' });
        continue;
      }
      const copy = reveal.master.slice();
      try {
        scalarFromBytes(copy, { nonzero: true });
      } catch {
        copy.fill(0);
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat: reveal.seat, kind: 'master-scalar' });
        continue;
      }
      masters.set(reveal.seat, copy);
    }
    missingSeats = genesis.seats.map((seat) => seat.seat).filter((seat) => !masters.has(seat));
    for (const [seat, master] of masters) {
      const verified = verifyRevealedMaster(genesis, crypto.decks, seat, toBase64Url(master));
      if (verified.ok) continue;
      if (verified.error.code === 'master-public-key' || verified.error.code === 'master-reveal') {
        if (inputErrors.length < MAX_DIAGNOSTICS)
          inputErrors.push({ seat, kind: verified.error.code });
      } else if (
        [
          'master-encryption-key',
          'master-beacon-tip',
          'master-shuffle-key',
          'master-lock-key',
        ].includes(verified.error.code)
      ) {
        violations.push(issue(0, seat, verified.error.code));
      } else return processingFailure(0, verified.error.code);
    }
    complete = missingSeats.length === 0 && inputErrors.length === 0;
    if (!complete || violations.length) return report();

    const initial = initialProposalContext(input.genesisEntry, input.engine, input.policy);
    if (!initial.ok) {
      historyError = { code: initial.error.code };
      return report();
    }
    const recorded = LocalGame.createRecorded(
      input.engine,
      genesis.config,
      fromBase64Url(genesis.genesisSeed),
    );
    if (!recorded.ok) {
      return processingFailure(0, recorded.error.code);
    }
    const game = recorded.value;
    if (toHex(hashValue(game.state)) !== initial.value.log.head.stateHash) {
      return processingFailure(0, 'audit-genesis-state');
    }
    const privateHashes = new Map<number, ReadonlyMap<Seat, string>>();
    const rememberPrivateHashes = (seq: number): Result<void> => {
      const hashes = new Map<Seat, string>();
      for (const seat of genesis.config.seats) {
        const privateState = game.privateView(seat);
        if (!privateState)
          return failure(
            'audit-omniscient-private-missing',
            'Omniscient private state is missing',
            {
              seq,
            },
          );
        hashes.set(seat, toHex(hashValue(privateState)));
      }
      privateHashes.set(seq, hashes);
      return success(undefined);
    };
    const initialPrivateHashes = rememberPrivateHashes(initial.value.log.head.seq);
    if (!initialPrivateHashes.ok) return processingFailure(0, initialPrivateHashes.error.code);
    let prior = initial.value;
    let failureSeq = 0;
    let failureSeat: Seat | null = null;
    const privateReplay = replayCertifiedPrefix(
      input.genesisEntry,
      publicReplay.value.entries,
      input.engine,
      input.policy,
      (entry, next) => {
        failureSeq = entry.entry.seq;
        const recordedInput = entry.input;
        if (recordedInput) {
          failureSeat = null;
          try {
            const data = privateDataFor(recordedInput, prior, next, game, masters, genesis);
            if (!data.ok) {
              // Only this mismatch identifies the signer of the fixed hidden transfer.
              // A draw failure does not prove misconduct by the receiving player.
              if (data.error.code === 'audit-steal-resource' && recordedInput.kind === 'system')
                failureSeat = isSeat(recordedInput.victim) ? recordedInput.victim : null;
              return data;
            }
            const applied = game.applyRecorded(recordedInput, data.value);
            if (!applied.ok) return applied;
          } catch {
            return failure('audit-private-input', 'Could not reconstruct certified private input');
          }
        }
        if (
          toHex(hashValue(game.state)) !== next.log.head.stateHash ||
          toHex(hashValue(game.state)) !== toHex(hashValue(next.log.state))
        )
          return failure('audit-state-hash', 'Omniscient state differs from the certified state');
        prior = next;
        return rememberPrivateHashes(entry.entry.seq);
      },
    );
    if (!privateReplay.ok) {
      if (
        [
          'driver-error',
          'audit-private-input',
          'audit-state-hash',
          'audit-omniscient-private-missing',
          'audit-draw-context',
          'audit-draw-seat',
          'audit-steal-context',
          'audit-steal-master',
          'steal-recipient-key',
          'deck-owner-lock',
          'missing-private-state',
        ].includes(privateReplay.error.code)
      )
        return processingFailure(failureSeq, privateReplay.error.code);
      violations.push(issue(failureSeq, failureSeat, privateReplay.error.code));
      complete = true;
      return report();
    }
    if (toHex(hashValue(game.state.result)) !== toHex(hashValue(context.log.state.result))) {
      return processingFailure((terminal as AuditEntryRef).seq, 'audit-terminal-result');
    }
    const crossCheck = reconstructPrivateSeats({
      genesisEntry: input.genesisEntry,
      entries: publicReplay.value.entries,
      engine: input.engine,
      policy: input.policy,
      secrets: [...masters].map(([seat, master]) => ({ seat, master })),
      verifyPrivateState(seq, states) {
        const expected = privateHashes.get(seq);
        if (
          !expected ||
          states.size !== expected.size ||
          [...states].some(([seat, state]) => toHex(hashValue(state)) !== expected.get(seat))
        )
          return failure(
            'audit-private-state',
            'Reconstructed private state differs from the omniscient replay',
            { seq },
          );
        return success(undefined);
      },
    });
    if (!crossCheck.ok) {
      const details = crossCheck.error.details;
      const seq =
        details &&
        typeof details === 'object' &&
        'seq' in details &&
        typeof details.seq === 'number'
          ? details.seq
          : context.log.head.seq;
      if (
        [
          'private-replay-failed',
          'private-replay-beacon',
          'crypto-context-required',
          'verified-private-missing',
          'audit-private-state',
        ].includes(crossCheck.error.code)
      )
        return processingFailure(seq, crossCheck.error.code);
      violations.push(issue(seq, null, crossCheck.error.code));
    } else {
      crossCheck.value.dispose();
      const counts: Partial<Record<Seat, number>> = {};
      for (const seat of genesis.config.seats) {
        const privateState = game.privateView(seat);
        const publicSeat = game.state.seats.find((item) => item.seat === seat);
        if (!privateState || !publicSeat)
          return processingFailure(context.log.head.seq, 'audit-final-private-state');
        counts[seat] = publicSeat.cardSlots.filter(
          (slot) => !slot.revealed && privateState.slots[slot.slotId] === 'victoryPoint',
        ).length;
      }
      finalHiddenVictoryPoints = counts;
    }
    complete = true;
    return report();
  } catch {
    return processingFailure(finalHead?.seq ?? 0, 'audit-internal-failure');
  } finally {
    for (const master of masters.values()) master.fill(0);
  }
}


FILE packages/protocol/src/private-replay.ts
import { toBase64Url } from '@cp2p/codec';
import { scalarFromBytes } from '@cp2p/crypto';
import { failure, success } from '@cp2p/engine';
import type { Engine, PrivateState, Result, Seat } from '@cp2p/engine';
import { createBeaconSecretSource } from './beacon-source.js';
import type { BeaconSecretProvider } from './beacon-source.js';
import { deckCeremonyId } from './deck-genesis.js';
import { createDeckSecretSource } from './deck-source.js';
import { genesisDigest } from './genesis.js';
import { verifyRevealedMaster } from './genesis-secrets.js';
import { createHandSecretSource } from './hand-source.js';
import type { ProposalContext } from './proposal.js';
import { initialProposalContext, replayCertifiedPrefix } from './replay.js';
import type { ReplayPolicy } from './replay.js';
import { createStealSecretSource } from './steal-source.js';
import { VerifiedSessionDriver } from './verified-session-driver.js';

export interface ReconstructedPrivateSeats {
  readonly context: ProposalContext;
  /** Contains only requested seats and checks their public openings after every entry. */
  readonly driver: VerifiedSessionDriver;
  /** Relinquish one owned seat without discarding other reconstructed seats. */
  releaseSeat(seat: Seat): void;
  /** Disposes the driver and clears its retained master copies. */
  dispose(): void;
}

/**
 * Reconstruct already-owned or authorized-revealed seats from certified history.
 * This does not request secrets, authorize disclosure, activate controllers or
 * constitute a complete game audit. The caller must establish the right to use
 * every supplied master before invoking it. Deck setup must be fully certified.
 * No partially rebuilt hand is returned.
 */
export function reconstructPrivateSeats(input: {
  readonly genesisEntry: unknown;
  readonly entries: readonly unknown[];
  readonly engine: Engine;
  readonly policy: ReplayPolicy;
  readonly secrets: readonly { readonly seat: Seat; readonly master: Uint8Array }[];
  /** Independent check of detached snapshots, provisional until the entire replay succeeds. */
  readonly verifyPrivateState?: (
    seq: number,
    states: ReadonlyMap<Seat, PrivateState>,
  ) => Result<void>;
}): Result<ReconstructedPrivateSeats> {
  const masters = new Map<Seat, Uint8Array>();
  const beacons = new Map<Seat, { length: number; provider: BeaconSecretProvider }>();
  let driver: VerifiedSessionDriver | undefined;
  let retained = false;
  const releaseSeat = (seat: Seat) => {
    driver?.relinquishSeats([seat]);
    const master = masters.get(seat);
    master?.fill(0);
    masters.delete(seat);
    const beacon = beacons.get(seat);
    beacon?.provider.dispose();
    beacons.delete(seat);
  };
  const dispose = () => {
    for (const seat of masters.keys()) releaseSeat(seat);
    driver?.dispose();
  };
  try {
    if (!Array.isArray(input.secrets) || input.secrets.length < 1 || input.secrets.length > 6)
      return failure('private-replay-seats', 'Supply one through six distinct owned seat secrets');
    for (const { seat, master } of input.secrets) {
      if (
        !Number.isSafeInteger(seat) ||
        seat < 0 ||
        seat > 5 ||
        masters.has(seat) ||
        !(master instanceof Uint8Array) ||
        master.length !== 32
      )
        return failure('private-replay-secrets', 'Seat secrets are malformed or duplicated');
      const copy = new Uint8Array(master);
      masters.set(seat, copy);
      scalarFromBytes(copy, { nonzero: true });
    }

    // Authenticate the whole supplied branch before reporting any secret mismatch.
    // A corrupt imported certificate must not be attributed to a departed owner.
    const publicReplay = replayCertifiedPrefix(
      input.genesisEntry,
      input.entries,
      input.engine,
      input.policy,
    );
    if (!publicReplay.ok)
      return failure('private-replay-history', 'Certified history could not be verified', {
        reason: publicReplay.error.code,
      });
    const { genesis, crypto } = publicReplay.value.context.log;
    if (genesis.security !== 'verified' || !crypto)
      return failure('private-replay-security', 'Private reconstruction requires verified history');
    for (const [seat, master] of masters) {
      const verified = verifyRevealedMaster(genesis, crypto.decks, seat, master);
      if (!verified.ok) return verified;
    }
    const initial = initialProposalContext(input.genesisEntry, input.engine, input.policy);
    if (!initial.ok) return initial;
    const initialBeacon = initial.value.log.crypto?.beacon;
    if (!initialBeacon)
      return failure('private-replay-beacon', 'Verified genesis has no beacon state');
    const ceremonyId = deckCeremonyId(genesis);
    for (const chain of initialBeacon.chains) {
      const master = masters.get(chain.seat);
      if (master)
        beacons.set(chain.seat, {
          length: chain.length,
          provider: createBeaconSecretSource(
            master,
            { ceremonyId, seat: chain.seat },
            chain.length,
          ),
        });
    }
    const getMaster = (seat: Seat): Uint8Array => {
      const master = masters.get(seat);
      if (!master) throw new Error('Seat is not owned by this private replay');
      return master;
    };
    driver = new VerifiedSessionDriver(
      input.engine,
      genesis,
      [...masters.keys()],
      (deckId, seat) => {
        const deck = crypto.decks.decks.find(
          (item) => item.commitment.definition.deckId === deckId,
        );
        if (!deck) throw new Error('Private replay deck is not in certified genesis');
        return createDeckSecretSource(getMaster(seat), deck.commitment.definition, seat);
      },
      (seat) => createHandSecretSource(getMaster(seat), genesisDigest(genesis), seat),
      (seat) => {
        const owner = genesis.seats.find((item) => item.seat === seat);
        if (!owner) throw new Error('Private replay seat is not in certified genesis');
        return createStealSecretSource(
          getMaster(seat),
          genesis.ceremonyNonce,
          seat,
          owner.publicKey,
        );
      },
    );
    const activeDriver = driver;
    const verifyPrivateState = (seq: number): Result<void> => {
      if (!input.verifyPrivateState) return success(undefined);
      const states = new Map<Seat, PrivateState>();
      for (const seat of masters.keys()) {
        const state = activeDriver.privateState(seat);
        if (!state)
          return failure('verified-private-missing', 'Owned private state is missing', { seq });
        states.set(seat, state);
      }
      return input.verifyPrivateState(seq, states);
    };
    const initialPrivateCheck = verifyPrivateState(initial.value.log.head.seq);
    if (!initialPrivateCheck.ok) return initialPrivateCheck;
    let prior = initial.value;
    const rebuilt = replayCertifiedPrefix(
      input.genesisEntry,
      publicReplay.value.entries,
      input.engine,
      input.policy,
      (entry, next) => {
        const beacon = next.log.crypto?.beacon;
        if (!beacon) return failure('private-replay-beacon', 'Certified beacon state is missing');
        for (const chain of beacon.chains) {
          let source = beacons.get(chain.seat);
          if (!source) continue;
          if (source.length !== chain.length) {
            source.provider.dispose();
            source = {
              length: chain.length,
              provider: createBeaconSecretSource(
                getMaster(chain.seat),
                { ceremonyId, seat: chain.seat },
                chain.length,
              ),
            };
            beacons.set(chain.seat, source);
          }
          const expected =
            chain.index > 0
              ? source.provider.source.link(chain.chainEpoch, chain.index)
              : chain.chainEpoch === 0
                ? source.provider.initialCommitment.tip
                : source.provider.source.extension(chain.chainEpoch).tip;
          try {
            if (toBase64Url(expected) !== chain.tip)
              return failure(
                'master-beacon-history',
                'Master does not reproduce a certified beacon link',
                {
                  seat: chain.seat,
                  seq: entry.entry.seq,
                },
              );
          } finally {
            expected.fill(0);
          }
        }
        const applied = activeDriver.committedEntry(entry, prior.log, next.log);
        if (!applied.ok) return applied;
        const checked = verifyPrivateState(entry.entry.seq);
        if (!checked.ok) return checked;
        prior = next;
        return success(undefined);
      },
    );
    if (!rebuilt.ok) return rebuilt;
    // Chain sources are needed only for historical checks, not subsequent hand proofs.
    for (const source of beacons.values()) source.provider.dispose();
    beacons.clear();
    retained = true;
    return success({ context: rebuilt.value.context, driver: activeDriver, releaseSeat, dispose });
  } catch {
    return failure('private-replay-failed', 'Could not reconstruct the requested private seats');
  } finally {
    if (!retained) dispose();
  }
}


FILE packages/protocol/src/replay.ts
import { canonicalDecode, canonicalEncode, hashValue, toHex } from '@cp2p/codec';
import { failure, success } from '@cp2p/engine';
import type { Engine, GameEvent, Input, Result } from '@cp2p/engine';
import { entryHash, genesisDigest, validateGenesisEntry } from './genesis.js';
import { ownImmutableGenesis } from './genesis-identity.js';
import { objectiveEvidenceSeq, validateObjectiveAccusation } from './control.js';
import { initializeCryptoContext } from './crypto-context.js';
import type { GenesisPolicy } from './genesis.js';
import type { ValidatedEntry } from './log.js';
import { advanceContext, proposerFor, validateCertifiedEntry } from './proposal.js';
import type { CertifiedEntry, ProposalContext } from './proposal.js';
import { authenticatedCheatSigner, verifyCheatProof } from './cheat-proof.js';
import type { CheatFinding } from './cheat-proof.js';
import { initialSeatAuthorities } from './authority.js';
import { initialTransferState } from './transfer-readiness.js';
import { advanceTimerAnchors } from './turn-timeout.js';

const MAX_HISTORICAL_CONTEXTS = 16;

export interface ReplayPolicy {
  genesis: GenesisPolicy;
  entry: ProposalContext['policy'];
}

export interface ReplayedPrefix {
  context: ProposalContext;
  entries: CertifiedEntry[];
  inputs: Input[];
  events: GameEvent[];
}

/** Genesis signatures establish the first voter set; transport peers have no say. */
export function initialProposalContext(
  genesisEntry: unknown,
  engine: Engine,
  policy: ReplayPolicy,
): Result<ProposalContext> {
  const checked = validateGenesisEntry(genesisEntry, engine, policy.genesis);
  if (!checked.ok) return checked;
  const { state, entry } = checked.value;
  const genesis = ownImmutableGenesis(checked.value.genesis);
  const authority = initialSeatAuthorities(genesis);
  if (!authority.ok) return authority;
  const transfer =
    genesis.security === 'verified' ? initialTransferState(genesis, entry) : success(undefined);
  if (!transfer.ok) return transfer;
  const crypto = initializeCryptoContext(
    genesis,
    engine,
    state,
    entry,
    policy.entry.randomDerivations,
    authority.value,
  );
  if (!crypto.ok) return crypto;
  const timers = advanceTimerAnchors(engine, state, entry);
  if (!timers.ok) return timers;
  return success({
    log: {
      genesis,
      engine,
      state,
      head: entry,
      lastNonces: new Map(),
      crypto: crypto.value,
      timers: timers.value,
      authority: authority.value,
      recovery: { authorizations: [], pending: null, offline: [], completed: [], void: null },
      ...(transfer.value ? { transfer: transfer.value } : {}),
    },
    membership: {
      genesisDigest: genesisDigest(genesis),
      epoch: 0,
      voters: genesis.seats
        .filter((seat) => seat.kind === 'human')
        .map(({ seat, publicKey }) => ({ seat, publicKey })),
    },
    excludedProposers: [],
    policy: policy.entry,
  });
}

/** Replay certificates in order. A claimed snapshot never supplies voter or nonce state. */
export function replayCertifiedPrefix(
  genesisEntry: unknown,
  entries: readonly unknown[],
  engine: Engine,
  policy: ReplayPolicy,
  onEntry?: (entry: ValidatedEntry & CertifiedEntry, next: ProposalContext) => Result<void>,
): Result<ReplayedPrefix> {
  return replayCertifiedPrefixWithCache(genesisEntry, entries, engine, policy, new Map(), onEntry);
}

/** Successful findings are shared only within this certified ancestry. */
function replayCertifiedPrefixWithCache(
  genesisEntry: unknown,
  entries: readonly unknown[],
  engine: Engine,
  policy: ReplayPolicy,
  verifiedFindings: Map<string, CheatFinding>,
  onEntry?: (entry: ValidatedEntry & CertifiedEntry, next: ProposalContext) => Result<void>,
): Result<ReplayedPrefix> {
  const initial = initialProposalContext(genesisEntry, engine, policy);
  if (!initial.ok) return initial;
  const certified: CertifiedEntry[] = [];
  const historical = new Map<number, ProposalContext>();
  const cheatHistorical = new Map<number, ProposalContext>();
  const controllerTimeline = [
    {
      atSeq: 0,
      authority: initial.value.log.authority,
      epoch: initial.value.log.crypto?.epoch ?? initial.value.log.authority?.epoch ?? 0,
    },
  ];
  let context: ProposalContext = {
    ...initial.value,
    verifyHistoricalCheat: (claim) => {
      const atSeq = claim.evidence.at.seq;
      if (atSeq > certified.length)
        return failure('cheat-history', 'Certified evidence parent is unavailable');
      const parentEntry = atSeq === 0 ? initial.value.log.head : certified[atSeq - 1]?.entry;
      if (!parentEntry || claim.evidence.at.hash !== entryHash(parentEntry))
        return failure('cheat-history', 'Certified evidence parent hash does not match');
      const parentAuthority = controllerTimeline.findLast((item) => item.atSeq <= atSeq);
      if (
        !parentAuthority ||
        !authenticatedCheatSigner(
          claim,
          initial.value.log.genesis,
          parentAuthority.authority,
          parentAuthority.epoch,
        )
      )
        return failure('cheat-signature', 'Cheat evidence has no authenticated controller');
      const key = toHex(hashValue({ domain: 'cp2p/v1/cheat-claim-cache', claim }));
      const previous = verifiedFindings.get(key);
      if (previous) return success(previous);
      let parent = cheatHistorical.get(atSeq);
      if (!parent) {
        const replayed = replayCertifiedPrefixWithCache(
          genesisEntry,
          certified.slice(0, atSeq),
          engine,
          policy,
          verifiedFindings,
        );
        if (!replayed.ok) return replayed;
        parent = replayed.value.context;
      }
      cheatHistorical.delete(atSeq);
      cheatHistorical.set(atSeq, parent);
      if (cheatHistorical.size > MAX_HISTORICAL_CONTEXTS) {
        const oldest = cheatHistorical.keys().next().value;
        if (oldest !== undefined) cheatHistorical.delete(oldest);
      }
      return verifyCheatProof(claim, parent.log);
    },
    verifyHistoricalAccusation: (control) => {
      const atSeq = objectiveEvidenceSeq(control);
      if (atSeq < 1 || atSeq - 1 > certified.length)
        return failure('control-history', 'Certified evidence parent is unavailable');
      let parent = historical.get(atSeq);
      if (!parent) {
        const replayed = replayCertifiedPrefixWithCache(
          genesisEntry,
          certified.slice(0, atSeq - 1),
          engine,
          policy,
          verifiedFindings,
        );
        if (!replayed.ok) return replayed;
        parent = replayed.value.context;
      }
      // Pending proofs and round hints can reference different certified parents.
      // Keep recent parents together without retaining the whole game state history.
      historical.delete(atSeq);
      historical.set(atSeq, parent);
      if (historical.size > MAX_HISTORICAL_CONTEXTS) {
        const oldest = historical.keys().next().value;
        if (oldest !== undefined) historical.delete(oldest);
      }
      const checked = validateObjectiveAccusation(control, {
        log: parent.log,
        commandPolicy: parent.policy,
        membership: parent.membership,
        excludedProposers: parent.excludedProposers,
        proposerFor: (seq, term) =>
          proposerFor(seq, term, parent.membership, parent.excludedProposers),
      });
      return checked.ok ? success(entryHash(parent.log.head)) : checked;
    },
  };
  const inputs: Input[] = [];
  const events: GameEvent[] = [];
  for (const entry of entries) {
    const checked = validateCertifiedEntry(entry, context);
    if (!checked.ok) return checked;
    const next = checked.value;
    if (next.entry.payload.kind === 'cheat-proof') {
      const claim = next.entry.payload.claim;
      const finding = next.crypto?.cheats.find(
        (item) => item.seat === claim.seat && item.kind === claim.evidence.kind,
      );
      if (!finding)
        return failure('cheat-replay', 'Certified cheat record has no replayed finding');
      verifiedFindings.set(
        toHex(hashValue({ domain: 'cp2p/v1/cheat-claim-cache', claim })),
        finding,
      );
    }
    certified.push({ entry: next.entry, certificate: next.certificate });
    if (next.input !== null) inputs.push(next.input);
    events.push(...next.events);
    const advanced = advanceContext(context, next);
    if (!advanced.ok) return advanced;
    if (advanced.value.log.authority !== context.log.authority) {
      controllerTimeline.push({
        atSeq: next.entry.seq,
        authority: advanced.value.log.authority,
        epoch: advanced.value.log.crypto?.epoch ?? advanced.value.log.authority?.epoch ?? 0,
      });
    }
    const visited = onEntry?.(next, advanced.value);
    if (visited && !visited.ok) return visited;
    context = advanced.value;
  }
  return success({ context, entries: certified, inputs, events });
}

/** A cache for display/load speed, always checked against the certified replay before voting. */
export function snapshotFromContext(context: ProposalContext) {
  return canonicalDecode(
    canonicalEncode({
      genesisDigest: context.membership.genesisDigest,
      seq: context.log.head.seq,
      hash: entryHash(context.log.head),
      state: context.log.state,
      crypto: context.log.crypto,
      authority: context.log.authority ?? null,
      recovery: context.log.recovery ?? null,
      transfer: context.log.transfer ?? null,
      timers: context.log.timers ?? [],
      lastNonces: [...context.log.lastNonces].toSorted(([a], [b]) => a - b),
      membership: context.membership,
      excludedProposers: context.excludedProposers,
    }),
  );
}

export function verifyReplaySnapshot(value: unknown, context: ProposalContext): Result<void> {
  try {
    return toHex(hashValue(value)) === toHex(hashValue(snapshotFromContext(context)))
      ? success(undefined)
      : failure('snapshot-mismatch', 'Snapshot differs from the certified replay');
  } catch {
    return failure('snapshot-malformed', 'Snapshot is not canonical data');
  }
}


FILE packages/protocol/src/testing/verified-network-audit.ts
import { hashValue, toHex } from '@cp2p/codec';
import { createBaseEngine, failure, success } from '@cp2p/engine';
import type { Seat } from '@cp2p/engine';
import { auditCertifiedGame } from '../audit.js';
import type { AuditReport } from '../audit-types.js';
import { validateDeckCeremony } from '../deck-genesis.js';
import { reconstructPrivateSeats } from '../private-replay.js';
import type { SessionAuditInput } from '../session-audit-types.js';
import type { DeckTranscript } from './deck-fixture.js';

declare const performance: { now(): number };

export interface VerifiedNetworkPrivateSnapshot {
  readonly seq: number;
  readonly seats: readonly (readonly [Seat, string])[];
}
export interface VerifiedNetworkAuditRequest extends SessionAuditInput {
  readonly deckTranscripts: readonly DeckTranscript[];
  readonly privateStates?: {
    readonly snapshots: readonly VerifiedNetworkPrivateSnapshot[];
    readonly digest: string;
  };
}
export interface VerifiedNetworkAuditResult {
  readonly report: AuditReport;
  readonly checkedPrivateSequences: number;
  readonly privateStateDigest: string | null;
  readonly privateComparisonMilliseconds: number;
}
export interface VerifiedNetworkAuditJob {
  readonly result: Promise<VerifiedNetworkAuditResult>;
  cancel(): void;
}

/** Uses only terminal-authorized masters supplied by the caller. */
export function performVerifiedNetworkAudit(
  input: VerifiedNetworkAuditRequest,
): VerifiedNetworkAuditResult {
  const engine = createBaseEngine();
  const policy = {
    genesis: {
      verifyCommitments: (candidate: Parameters<typeof validateDeckCeremony>[0]) =>
        validateDeckCeremony(candidate, input.deckTranscripts),
    },
    entry: {},
  };
  let checkedPrivateSequences = 0;
  let privateComparisonMilliseconds = 0;
  const expected = input.privateStates;
  if (expected) {
    const started = performance.now();
    if (
      expected.snapshots.length !== input.entries.length + 1 ||
      toHex(hashValue(expected.snapshots)) !== expected.digest ||
      expected.snapshots.some(
        (snapshot, seq) =>
          snapshot.seq !== seq ||
          snapshot.seats.length !== 4 ||
          snapshot.seats.some(
            ([seat, hash], index) => seat !== index || !/^[0-9a-f]{64}$/.test(hash),
          ),
      )
    )
      throw new Error('fixture-live-private-state: Invalid owned snapshot evidence');
    const rebuilt = reconstructPrivateSeats({
      ...input,
      engine,
      policy,
      secrets: input.masters,
      verifyPrivateState(seq, states) {
        const snapshot = expected.snapshots[seq];
        if (
          seq !== checkedPrivateSequences ||
          !snapshot ||
          states.size !== 4 ||
          snapshot.seats.some(([seat, hash]) => {
            const state = states.get(seat);
            return !state || toHex(hashValue(state)) !== hash;
          })
        )
          return failure(
            'fixture-live-private-state',
            'Live owned state differs from terminal reconstruction',
            { seq },
          );
        checkedPrivateSequences++;
        return success(undefined);
      },
    });
    if (!rebuilt.ok) throw new Error(`${rebuilt.error.code}: ${rebuilt.error.message}`);
    rebuilt.value.dispose();
    if (checkedPrivateSequences !== expected.snapshots.length)
      throw new Error('fixture-live-private-state: Reconstruction omitted a certified sequence');
    privateComparisonMilliseconds = performance.now() - started;
  }
  return {
    report: auditCertifiedGame({ ...input, engine, policy }),
    checkedPrivateSequences,
    privateStateDigest: expected?.digest ?? null,
    privateComparisonMilliseconds,
  };
}


FILE docs/verification/stage07/scenario6-owned-genesis-profile-2026-09-28/comparison.json
{
  "handMemo": {
    "cost": {
      "validateHandCommitments": 257.955,
      "decodePoint": 2112.503,
      "canonicalEncode": 23501.514,
      "genesisDigest": 9809.962,
      "contextStamp": 5137.928,
      "sameContextStamp": 2819.839,
      "validateNextEntry": 12516.168,
      "validateCertifiedEntry": 10260.282,
      "persistCommit": 12289.548
    },
    "callers": {
      "genesisDigest": {
        "resolveArtifactSigner authority.js:106": 3826.24,
        "validateCryptoTransition crypto-context.js:68": 1388.442,
        "validateControllerContext proposal.js:111": 1024.465,
        "validateSignedCommand command-validation.js:14": 904.373,
        "validateEntry proposal.js:129": 603.382,
        "validateCommandForEntry command-validation.js:104": 574.551,
        "authenticateCertifiedEntry proposal.js:244": 461.51,
        "committedEntry verified-session-driver.js:569": 314.955,
        "bound consensus.js:148": 253.503,
        "createConsensusState consensus.js:499": 122.592,
        "validateNextEntry log.js:91": 102.555,
        "entryHash genesis.js:185": 80.831
      },
      "canonicalEncode": {
        "hashValue hash.js:9": 8412.281,
        "contextStamp consensus.js:109": 5039.027,
        "canonicalDecode canonical.js:160": 4569.086,
        "parseCanonical validation.js:6": 1586.885,
        "copyConsensusStateData consensus.js:145": 1237.87,
        "copyCanonical replicated-log.js:3877": 684.616,
        "copyCanonical p2p-session.js:1619": 418.114,
        "snapshot consensus-controller.js:97": 290.727,
        "objectMessage identity.js:44": 253.716,
        "detachedContext replicated-log.js:3881": 243.849,
        " consensus-controller.js:141": 201.552,
        "transition consensus.js:474": 200.509
      },
      "decodePoint": {
        "checkedPoints deck-setup.js:100": 1161.273,
        "validateStealOperation steal-delivery.js:104": 237.384,
        "parseAndCheckEnvelope escrow-distribution.js:118": 127.5,
        "applyPublicResourceEffect hand-commitments.js:106": 91.264,
        "schnorrStatement sigma.js:3": 59.692,
        "dleqStatement sigma.js:14": 49.489,
        "verifySchnorr sigma.js:55": 44.427,
        "verifySealedEphemeralProof seal.js:93": 37.177,
        "parsePoints shuffle.js:11": 33.66,
        "validPoint online-bindings.js:36": 33.425,
        "validateGenesisMasters genesis-masters.js:10": 32.421,
        "inspectBitProof range.js:44": 26.633
      },
      "validateHandCommitments": {
        "planHandTransition hand-transition.js:62": 82.24,
        "validateCryptoTransition crypto-context.js:68": 76.066,
        "verifyHandOpening hand-commitments.js:140": 56.005,
        "applyPublicResourceEffect hand-commitments.js:106": 42.184,
        "completeStealResult steal-state.js:190": 1.46
      }
    },
    "revision": 116,
    "turn": 22,
    "elapsed": 60044.988916,
    "operationTimings": {
      "sessionFlush": {
        "calls": 4373,
        "totalMilliseconds": 45802.64018599994,
        "maximumMilliseconds": 1422.1577499999985
      },
      "networkDelivery": {
        "calls": 4307,
        "totalMilliseconds": 908.3438070001321,
        "maximumMilliseconds": 7.534166999997979
      },
      "botDecide": {
        "calls": 65,
        "totalMilliseconds": 24.460544000014124,
        "maximumMilliseconds": 1.7255829999994603
      },
      "actorExport": {
        "calls": 96,
        "totalMilliseconds": 784.5516999999963,
        "maximumMilliseconds": 15.717917000001762
      },
      "actorAdvance": {
        "calls": 96,
        "totalMilliseconds": 3350.5725370000146,
        "maximumMilliseconds": 335.80208400000265
      },
      "actorDecide": {
        "calls": 18,
        "totalMilliseconds": 7.746793000023899,
        "maximumMilliseconds": 0.8909590000039316
      }
    },
    "sourceUnchanged": true
  },
  "ownedGenesis": {
    "cost": {
      "validateHandCommitments": 323.85,
      "decodePoint": 2285.221,
      "canonicalEncode": 21566.235,
      "genesisDigest": 521.456,
      "contextStamp": 6837.143,
      "sameContextStamp": 3990.099,
      "validateNextEntry": 9902.912,
      "validateCertifiedEntry": 6766.723,
      "persistCommit": 13427.25
    },
    "callers": {
      "genesisDigest": {
        "committedEntry verified-session-driver.js:569": 366.969,
        "entryHash genesis.js:185": 76.144,
        "prepareCommand verified-session-driver.js:431": 33.173,
        "genesisId genesis-identity.js:40": 15.036,
        "ownImmutableGenesis genesis-identity.js:4": 8.764,
        "resolveArtifactSigner authority.js:106": 7.545,
        "validateGenesis genesis.js:72": 5.021,
        "initializeBeaconState beacon-state.js:125": 5.015,
        "signGenesis genesis.js:25": 1.281,
        "invalidCommandProposal net-adversary.js:4": 1.255,
        "createVerifiedNetworkFixture verified-network-fixture.js:57": 1.253
      },
      "canonicalEncode": {
        "contextStamp consensus.js:109": 6763.769,
        "canonicalDecode canonical.js:160": 5243.272,
        "hashValue hash.js:9": 3360.921,
        "parseCanonical validation.js:6": 1956.108,
        "copyConsensusStateData consensus.js:145": 1497.896,
        "copyCanonical p2p-session.js:1619": 591.284,
        "copyCanonical replicated-log.js:3958": 442.407,
        "snapshot consensus-controller.js:97": 331.878,
        "detachedContext replicated-log.js:3962": 301.109,
        "transition consensus.js:474": 228.94,
        "objectMessage identity.js:44": 221.151,
        " consensus-controller.js:141": 212.62
      },
      "decodePoint": {
        "checkedPoints deck-setup.js:100": 1129.836,
        "validateStealOperation steal-delivery.js:104": 427.228,
        "parseAndCheckEnvelope escrow-distribution.js:118": 114.058,
        "applyPublicResourceEffect hand-commitments.js:106": 89.916,
        "schnorrStatement sigma.js:3": 66.34,
        "verifySealedEphemeralProof seal.js:93": 46.459,
        "dleqStatement sigma.js:14": 42.67,
        "validateGenesisMasters genesis-masters.js:10": 42.3,
        " steal-state.js:213": 35.97,
        "readPayload seal.js:20": 32.31,
        "validPoint online-bindings.js:36": 32.013,
        "inspectBitProof range.js:44": 31.244
      },
      "validateHandCommitments": {
        "validateCryptoTransition crypto-context.js:68": 107.943,
        "planHandTransition hand-transition.js:62": 86.435,
        "verifyHandOpening hand-commitments.js:140": 63.286,
        "applyPublicResourceEffect hand-commitments.js:106": 57.413,
        "completeStealResult steal-state.js:190": 8.773
      }
    },
    "revision": 174,
    "turn": 34,
    "elapsed": 60003.779834,
    "operationTimings": {
      "sessionFlush": {
        "calls": 6444,
        "totalMilliseconds": 46854.46187900022,
        "maximumMilliseconds": 809.2985000000008
      },
      "networkDelivery": {
        "calls": 6345,
        "totalMilliseconds": 607.6345450003719,
        "maximumMilliseconds": 8.15008300000045
      },
      "botDecide": {
        "calls": 98,
        "totalMilliseconds": 28.980125999960364,
        "maximumMilliseconds": 1.4810840000009193
      },
      "actorExport": {
        "calls": 154,
        "totalMilliseconds": 343.1253819999947,
        "maximumMilliseconds": 3.294500000003609
      },
      "actorAdvance": {
        "calls": 154,
        "totalMilliseconds": 3270.0308359999763,
        "maximumMilliseconds": 261.81162499999846
      },
      "actorDecide": {
        "calls": 28,
        "totalMilliseconds": 8.693372999998246,
        "maximumMilliseconds": 0.7771250000005239
      }
    },
    "sourceUnchanged": true
  },
  "changedCompiledSinceBaseline": [
    "packages/p2p/dist/manual-bootstrap.js",
    "packages/p2p/dist/peer-link.js",
    "packages/p2p/dist/signaling-envelope.js",
    "packages/p2p/dist/web-rtc-transport.js",
    "packages/protocol/dist/genesis-identity.js",
    "packages/protocol/dist/master-reveal.js",
    "packages/protocol/dist/online-ceremony.js",
    "packages/protocol/dist/replay.js",
    "packages/protocol/dist/replicated-log.js",
    "packages/protocol/dist/testing/recovery-fixture.js",
    "packages/storage/dist/indexed-db-protocol-journal.js"
  ],
  "postCompiledExactMatch": true
}

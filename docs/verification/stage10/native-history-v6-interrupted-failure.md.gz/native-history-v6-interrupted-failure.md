# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: online-history.e2e.ts >> inactive history stays readable and deletion prevents revival of its signed save
- Location: tests/online-history.e2e.ts:22:1

# Error details

```
Error: expect(received).toMatchObject(expected)

Matcher error: received value must be a non-null object

Received has value: null
```

# Page snapshot

```yaml
- generic [ref=f3e2]:
  - main [ref=f3e3]:
    - generic [ref=f3e4]:
      - generic [ref=f3e6]: Hexfield
      - link "Settings" [ref=f3e7] [cursor=pointer]:
        - /url: /#/settings
    - generic [ref=f3e8]:
      - region [ref=f3e9]:
        - heading "A table ready when you are" [level=1] [ref=f3e10]
        - paragraph [ref=f3e11]: Play with friends in your browsers, or share a screen for a local game.
        - generic [ref=f3e12]:
          - link "Play with friends" [ref=f3e13] [cursor=pointer]:
            - /url: /#/online/create
          - link "Join a game" [ref=f3e14] [cursor=pointer]:
            - /url: /#/join
        - generic [ref=f3e15]: Multiplayer beta · invite friends to your table
        - link "New local game" [ref=f3e16] [cursor=pointer]:
          - /url: /#/local/new
      - generic [ref=f3e17]:
        - region [ref=f3e18]:
          - heading "Online games" [level=2] [ref=f3e19]
          - article [ref=f3e20]:
            - 'link "Resume online game: Avery, Blake, Casey, Drew" [ref=f3e21] [cursor=pointer]':
              - /url: /#/game/OkBMgYtlo7vY_qJpary94k
              - generic [ref=f3e22]:
                - generic [ref=f3e23]: Avery · Blake · Casey · Drew
                - generic [ref=f3e24]: Started 11/14/2023
                - generic [ref=f3e25]: Last active 8/28/2026
                - generic [ref=f3e26]: Inactive for 30 days
              - generic [aria-hidden] [ref=f3e27]: →
            - generic [ref=f3e28]:
              - button "View replay" [ref=f3e29] [cursor=pointer]
              - button "Export replay" [ref=f3e30] [cursor=pointer]
              - button "Export full save" [ref=f3e31] [cursor=pointer]
              - button "Remove" [ref=f3e32] [cursor=pointer]
        - region [ref=f3e33]:
          - heading "Public game replays" [level=2] [ref=f3e34]
          - paragraph [ref=f3e35]: Open an exported game to view its public board and event history.
          - button "Import replay" [ref=f3e36] [cursor=pointer]
          - 'link "Open public replay: Avery, Blake, Casey, Drew" [ref=f3e37] [cursor=pointer]':
            - /url: /#/replay/673a5f49b3d7b90cf4821d4d616c40092b969e3f611c352df98ed84ca4f75c7a
            - generic [ref=f3e38]:
              - generic [ref=f3e39]: Avery · Blake · Casey · Drew
              - generic [ref=f3e40]: 11/14/2023 · entry 8
            - generic [aria-hidden] [ref=f3e41]: →
        - region [ref=f3e42]:
          - heading "Imported full saves" [level=2] [ref=f3e43]
          - paragraph [ref=f3e44]: Imported files open as paused, read-only snapshots. Importing a save never restores control of a live game.
          - generic [ref=f3e45]:
            - text: File passphrase, if needed
            - textbox "File passphrase, if needed" [ref=f3e46]
          - button "Import full save" [ref=f3e47] [cursor=pointer]
          - status [ref=f3e48]: Loading imported saves…
        - region [ref=f3e49]:
          - heading "Saved games" [level=2] [ref=f3e51]
          - paragraph [ref=f3e52]: No saved games yet.
  - generic:
    - contentinfo:
      - button "Open TanStack Router Devtools" [ref=f3e53] [cursor=pointer]:
        - generic [ref=f3e125]: "-"
        - generic [ref=f3e126]: TanStack Router
  - button "Open Tanstack query devtools" [ref=f3e177] [cursor=pointer]
```

# Test source

```ts
  89  |             entry.certified,
  90  |             new Uint8Array(entry.safety),
  91  |           );
  92  |           if (!committed) throw new Error('Fixture journal failed to commit');
  93  |         }
  94  |         await saveOnlineGameActivity(store, activity);
  95  |       } finally {
  96  |         await journal.close();
  97  |         await store.close();
  98  |       }
  99  |     },
  100 |     {
  101 |       start,
  102 |       initialSafety,
  103 |       entries,
  104 |       storagePath,
  105 |       activity: {
  106 |         gameId: fixture.genesis.gameId,
  107 |         genesisDigest: genesisDigest(fixture.genesis),
  108 |         head: { seq: context.log.head.seq, hash: entryHash(context.log.head) },
  109 |         lastActivityAt: Date.now() - 31 * 24 * 60 * 60 * 1_000,
  110 |       },
  111 |     },
  112 |   );
  113 |   await page.reload();
  114 |   const saved = page.locator('.online-history-item');
  115 |   await expect(saved).toHaveCount(1);
  116 |   await expect(saved.locator('.online-history-inactive')).toBeVisible();
  117 |   const [download] = await Promise.all([
  118 |     page.waitForEvent('download'),
  119 |     saved.getByRole('button', { name: 'Export replay', exact: true }).click(),
  120 |   ]);
  121 |   expect(download.suggestedFilename()).toMatch(/\.hxar$/);
  122 |   const downloadPath = await download.path();
  123 |   if (!downloadPath) throw new Error('Replay download was not saved');
  124 |   expect((await readFile(downloadPath)).subarray(0, 5).toString()).toBe('HXAR1');
  125 |   await saved.getByRole('button', { name: 'View replay', exact: true }).click();
  126 |   await expect(page).toHaveURL(/#\/replay\/[a-f0-9]{64}$/);
  127 |   await expect(page.getByRole('heading', { name: 'Public game replay' })).toBeVisible();
  128 |   const canvas = page.locator('.public-replay-board canvas');
  129 |   await expect(canvas).toBeVisible();
  130 |   const bounds = await canvas.boundingBox();
  131 |   expect(bounds?.height).toBeGreaterThan(300);
  132 |   expect(bounds?.width).toBeGreaterThan(300);
  133 |   await expect(page.getByRole('button', { name: 'Roll dice' })).toHaveCount(0);
  134 |   await page.screenshot({ path: testInfo.outputPath('public-replay-desktop.png') });
  135 |   await page.reload();
  136 |   await expect(page.getByRole('heading', { name: 'Public game replay' })).toBeVisible();
  137 |   await page.setViewportSize({ width: 390, height: 844 });
  138 |   await expect(canvas).toBeVisible();
  139 |   const mobileCanvas = await canvas.boundingBox();
  140 |   expect(mobileCanvas?.width).toBeLessThanOrEqual(390);
  141 |   expect(mobileCanvas?.height).toBeGreaterThan(300);
  142 |   expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390);
  143 |   await page.screenshot({ path: testInfo.outputPath('public-replay-mobile.png') });
  144 |   await page.getByRole('link', { name: 'Back to home' }).click();
  145 |   await saved.getByRole('button', { name: 'Remove', exact: true }).click();
  146 |   const dialog = page.getByRole('dialog');
  147 |   await expect(dialog).toBeVisible();
  148 |   await page.screenshot({ path: testInfo.outputPath('remove-save-mobile.png') });
  149 |   await dialog.getByRole('button', { name: 'Keep game' }).click();
  150 |   await expect(saved).toHaveCount(1);
  151 |   await saved.getByRole('button', { name: 'Remove', exact: true }).click();
  152 |   await dialog.getByRole('button', { name: 'Remove', exact: true }).click();
  153 |   await expect(saved).toHaveCount(0);
  154 |   await page.reload();
  155 |   await expect(saved).toHaveCount(0);
  156 |   const deletion = await page.evaluate(
  157 |     async ({ start: savedStart, initialSafety: safety, storagePath: storageModulePath }) => {
  158 |       // oxlint-disable typescript/no-unsafe-type-assertion -- Known local Vite modules in an isolated browser test context.
  159 |       const { IndexedDbByteStore, IndexedDbProtocolJournal, readOnlineGameTombstone } =
  160 |         (await import(/* @vite-ignore */ storageModulePath)) as typeof import('@cp2p/storage');
  161 |       const recordsPath = '/src/session/online-game-records.ts';
  162 |       const { saveOnlineGameRecord } = (await import(
  163 |         /* @vite-ignore */ recordsPath
  164 |       )) as typeof import('../src/session/online-game-records.js');
  165 |       // oxlint-enable typescript/no-unsafe-type-assertion
  166 |       const gameId = savedStart.result.genesis.gameId;
  167 |       const store = new IndexedDbByteStore();
  168 |       const journal = new IndexedDbProtocolJournal(gameId);
  169 |       try {
  170 |         const tombstone = await readOnlineGameTombstone(gameId);
  171 |         const savedAgain = await saveOnlineGameRecord(store, savedStart).then(
  172 |           () => 'accepted',
  173 |           (error: unknown) => (error instanceof Error ? error.message : 'unknown'),
  174 |         );
  175 |         const initializedAgain = await journal
  176 |           .initialize(savedStart.result.entry, new Uint8Array(safety))
  177 |           .then(
  178 |             () => 'accepted',
  179 |             (error: unknown) => (error instanceof Error ? error.message : 'unknown'),
  180 |           );
  181 |         return { tombstone, savedAgain, initializedAgain };
  182 |       } finally {
  183 |         await journal.close();
  184 |         await store.close();
  185 |       }
  186 |     },
  187 |     { start, initialSafety, storagePath },
  188 |   );
> 189 |   expect(deletion.tombstone).toMatchObject({
      |                              ^ Error: expect(received).toMatchObject(expected)
  190 |     gameId: fixture.genesis.gameId,
  191 |     genesisDigest: genesisDigest(fixture.genesis),
  192 |   });
  193 |   expect(deletion.savedAgain).toContain('deleted locally');
  194 |   expect(deletion.initializedAgain).toContain('deleted locally');
  195 |   await testInfo.attach('history-deletion-evidence', {
  196 |     body: JSON.stringify({
  197 |       protocolVersion: fixture.genesis.protocolVersion,
  198 |       gameId: fixture.genesis.gameId,
  199 |       lastCertifiedSequence: context.log.head.seq,
  200 |       inactivityDays: 31,
  201 |       deletion,
  202 |     }),
  203 |     contentType: 'application/json',
  204 |   });
  205 |   await page.getByRole('link', { name: /^Open public replay:/ }).click();
  206 |   await expect(page.getByRole('heading', { name: 'Public game replay' })).toBeVisible();
  207 |   await page.getByRole('link', { name: 'Back to home' }).click();
  208 |   await page.getByLabel('Choose public replay archive').setInputFiles(downloadPath);
  209 |   await expect(page.getByRole('heading', { name: 'Public game replay' })).toBeVisible();
  210 |   expect(errors).toEqual([]);
  211 | });
  212 | 
```
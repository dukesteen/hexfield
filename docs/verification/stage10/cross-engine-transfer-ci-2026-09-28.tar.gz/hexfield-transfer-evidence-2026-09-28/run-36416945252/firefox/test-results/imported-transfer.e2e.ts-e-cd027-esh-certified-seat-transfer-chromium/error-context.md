# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: imported-transfer.e2e.ts >> encrypted imported history stays read-only until a fresh certified seat transfer
- Location: tests/imported-transfer.e2e.ts:89:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Imported game snapshot' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: 'Imported game snapshot' }) with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Imported game snapshot' })

```

```yaml
- status: Checking imported save…
- contentinfo:
  - button "Open TanStack Router Devtools":
    - img
    - img
    - text: "- TanStack Router"
- button "Open Tanstack query devtools":
  - img
```

# Test source

```ts
  72  |       )) as typeof import('../src/features/online/room-registry.js');
  73  |       // oxlint-enable typescript/no-unsafe-type-assertion
  74  |       const session = getOnlineGameRoom(id)?.getGame()?.session;
  75  |       if (!session) return false;
  76  |       for (const seat of session.controllableSeats()) {
  77  |         const command = session.getLegalCommands(seat).commands[0];
  78  |         if (!command) continue;
  79  |         const submitted = await session.submit(seat, command);
  80  |         if (!submitted.ok) throw new Error(`Legal command refused: ${submitted.error.code}`);
  81  |         return true;
  82  |       }
  83  |       return false;
  84  |     },
  85  |     { id: gameId, modulePath: path },
  86  |   );
  87  | }
  88  | 
  89  | test('encrypted imported history stays read-only until a fresh certified seat transfer', async ({
  90  |   browser,
  91  |   playwright,
  92  |   baseURL,
  93  | }, testInfo) => {
  94  |   test.setTimeout(240_000);
  95  |   if (!baseURL) throw new Error('Transfer acceptance requires the configured app URL');
  96  |   const destinationBrowser =
  97  |     destinationEngine === 'firefox' || destinationEngine === 'webkit'
  98  |       ? await playwright[destinationEngine].launch({ headless: true })
  99  |       : null;
  100 |   const contexts: BrowserContext[] = [];
  101 |   const pages: Page[] = [];
  102 |   const errors: string[] = [];
  103 |   try {
  104 |     for (const engine of [browser, browser, destinationBrowser ?? browser]) {
  105 |       const context = await engine.newContext({ baseURL });
  106 |       contexts.push(context);
  107 |       await context.addInitScript(() => performance.setResourceTimingBufferSize(5_000));
  108 |       const page = await context.newPage();
  109 |       page.on('pageerror', (error) => errors.push(error.message));
  110 |       pages.push(page);
  111 |     }
  112 |     const [source, survivor, destination] = pages;
  113 |     if (!source || !survivor || !destination) throw new Error('Missing transfer page');
  114 |     await source.goto('/#/online/create');
  115 |     await source.getByLabel('Room name').fill('Imported checkpoint transfer');
  116 |     await source.getByLabel('Your player name').fill('Original device');
  117 |     await source.getByText('Advanced connection options', { exact: true }).click();
  118 |     await source.getByLabel('Invite friends with').selectOption('server');
  119 |     await source.getByLabel('Custom room server').fill(signalingUrl);
  120 |     await source.getByLabel('Player count').selectOption('2');
  121 |     await source.getByRole('button', { name: 'Create room' }).click();
  122 |     const lobbyTitle = source.getByRole('heading', { name: 'Imported checkpoint transfer' });
  123 |     await expect(lobbyTitle).toBeVisible();
  124 | 
  125 |     const lobbyInvite = await source
  126 |       .getByRole('textbox', { name: /^Invitation link/ })
  127 |       .inputValue();
  128 |     await survivor.goto(lobbyInvite);
  129 |     await expect(
  130 |       survivor.getByRole('heading', { name: 'Imported checkpoint transfer' }),
  131 |     ).toBeVisible();
  132 |     await survivor.getByRole('button', { name: 'Take seat' }).click();
  133 |     await source.getByRole('button', { name: 'Ready up' }).click();
  134 |     await survivor.getByRole('button', { name: 'Ready up' }).click();
  135 |     await expect(source.getByRole('button', { name: 'Start game' })).toBeEnabled();
  136 |     await source.getByRole('button', { name: 'Start game' }).click();
  137 |     await expect(source).toHaveURL(/\/game\/[^/]+$/, { timeout: 90_000 });
  138 |     await expect(survivor).toHaveURL(/\/game\/[^/]+$/, { timeout: 90_000 });
  139 |     const gameId = new URL(source.url()).hash.match(/\/game\/([^/?]+)/)?.[1];
  140 |     if (!gameId) throw new Error('Game route has no identifier');
  141 |     const requiredDeckPasses = (await gameView(source, gameId))?.requiredDeckPasses;
  142 |     if (!requiredDeckPasses) throw new Error('Verified game has no deck-pass commitments');
  143 |     await expect
  144 |       .poll(async () => (await gameView(source, gameId))?.head?.seq ?? 0, { timeout: 60_000 })
  145 |       .toBeGreaterThanOrEqual(requiredDeckPasses);
  146 | 
  147 |     // Export the certified live head with its private package encrypted; importing it must not
  148 |     // open a writer or restore control on the destination device.
  149 |     await source.locator('summary[aria-label="Open game menu"]').click();
  150 |     await source.getByRole('button', { name: 'Export full save', exact: true }).click();
  151 |     const exportDialog = source.getByRole('dialog');
  152 |     await exportDialog.getByRole('checkbox').check();
  153 |     await exportDialog.getByLabel('File passphrase', { exact: true }).fill(filePassphrase);
  154 |     const [download] = await Promise.all([
  155 |       source.waitForEvent('download'),
  156 |       exportDialog.getByRole('button', { name: 'Export full save', exact: true }).click(),
  157 |     ]);
  158 |     expect(download.suggestedFilename()).toMatch(/\.hxfs$/);
  159 |     const downloadPath = await download.path();
  160 |     if (!downloadPath) throw new Error('Encrypted full-save download was not retained');
  161 | 
  162 |     await destination.goto('/#/');
  163 |     await expect(destination.getByLabel('File passphrase, if needed')).toBeVisible({
  164 |       timeout: 15_000,
  165 |     });
  166 |     await destination.getByLabel('File passphrase, if needed').fill(filePassphrase);
  167 |     await destination.getByLabel('Choose full-save file').setInputFiles(downloadPath);
  168 |     // Import authenticates the saved history before exposing the read-only snapshot.
  169 |     await expect(destination).toHaveURL(/#\/full-save\/([a-f0-9]{64})$/, { timeout: 30_000 });
  170 |     await expect(
  171 |       destination.getByRole('heading', { name: 'Imported game snapshot' }),
> 172 |     ).toBeVisible();
      |       ^ Error: expect(locator).toBeVisible() failed
  173 |     await expect(destination.getByText('Paused, read-only snapshot')).toBeVisible();
  174 |     await expect(
  175 |       destination.getByText(
  176 |         'This file contains an encrypted private package. This view does not unlock or install it.',
  177 |       ),
  178 |     ).toBeVisible();
  179 |     await expect(destination.getByRole('button', { name: 'Roll dice', exact: true })).toHaveCount(
  180 |       0,
  181 |     );
  182 |     await expect(destination.getByRole('button', { name: 'Build', exact: true })).toHaveCount(0);
  183 |     const archiveId = new URL(destination.url()).hash.match(/\/full-save\/([a-f0-9]{64})$/)?.[1];
  184 |     if (!archiveId) throw new Error('Imported archive has no immutable identifier');
  185 | 
  186 |     const gameMenu = source.locator('details.game-menu');
  187 |     if ((await gameMenu.getAttribute('open')) === null)
  188 |       await source.locator('summary[aria-label="Open game menu"]').click();
  189 |     await source.getByRole('button', { name: 'Move this seat to another device' }).click();
  190 |     const transferDialog = source.getByRole('dialog', { name: 'Move this seat to another device' });
  191 |     const sourceDevice = await transferDialog
  192 |       .locator('.online-transfer-self code')
  193 |       .first()
  194 |       .innerText();
  195 |     const transferInvite = await transferDialog
  196 |       .getByRole('textbox', { name: /^Seat transfer invitation/ })
  197 |       .inputValue();
  198 | 
  199 |     await destination
  200 |       .getByLabel("Current player's signed transfer invitation URL")
  201 |       .fill(transferInvite);
  202 |     await destination.getByRole('button', { name: 'Continue with this invitation' }).click();
  203 |     await expect(destination).toHaveURL(new RegExp(`/transfer/[^?]+\\?archiveId=${archiveId}$`));
  204 |     await expect(destination.getByRole('button', { name: 'Start seat transfer' })).toBeVisible();
  205 |     await destination.getByRole('button', { name: 'Start seat transfer' }).click();
  206 |     await expect
  207 |       .poll(
  208 |         () =>
  209 |           destination
  210 |             .locator('.online-transfer-panel .online-transfer-self strong')
  211 |             .first()
  212 |             .innerText()
  213 |             .catch(() => ''),
  214 |         { timeout: 30_000 },
  215 |       )
  216 |       .toBe('This device');
  217 |     const destinationDevice = await destination
  218 |       .locator('.online-transfer-self code')
  219 |       .first()
  220 |       .innerText();
  221 |     expect(destinationDevice).not.toBe(sourceDevice);
  222 | 
  223 |     await expect(transferDialog.getByRole('radio')).toHaveCount(1, { timeout: 30_000 });
  224 |     await transferDialog.getByRole('radio').click();
  225 |     await expect(transferDialog.getByRole('button', { name: 'Confirm move' })).toBeEnabled({
  226 |       timeout: 35_000,
  227 |     });
  228 |     await transferDialog.getByRole('button', { name: 'Confirm move' }).click();
  229 |     await expect(destination.getByRole('button', { name: 'Open game on this device' })).toBeVisible(
  230 |       { timeout: 90_000 },
  231 |     );
  232 |     await destination.getByRole('button', { name: 'Open game on this device' }).click();
  233 |     await expect(destination).toHaveURL(new RegExp(`/game/${gameId}$`), { timeout: 30_000 });
  234 | 
  235 |     await expect
  236 |       .poll(async () => (await gameView(destination, gameId))?.head ?? null, { timeout: 30_000 })
  237 |       .toEqual(await gameView(survivor, gameId).then((view) => view?.head ?? null));
  238 |     await expect
  239 |       .poll(async () => (await gameView(source, gameId))?.seats.length ?? 0, { timeout: 20_000 })
  240 |       .toBe(0);
  241 | 
  242 |     let acceptedMove = false;
  243 |     for (let attempt = 0; attempt < 8 && !acceptedMove; attempt += 1) {
  244 |       const current = await gameView(destination, gameId);
  245 |       const peer = await gameView(survivor, gameId);
  246 |       if (!current?.head || !peer?.head) throw new Error('Transferred game has no certified head');
  247 |       if (current.legal.some((item) => item.count > 0)) {
  248 |         const before = current.head.seq;
  249 |         acceptedMove = await submitFirstLegal(destination, gameId);
  250 |         if (acceptedMove) {
  251 |           await expect
  252 |             .poll(async () => (await gameView(survivor, gameId))?.head?.seq ?? 0, {
  253 |               timeout: 30_000,
  254 |             })
  255 |             .toBeGreaterThan(before);
  256 |         }
  257 |       } else if (peer.legal.some((item) => item.count > 0)) {
  258 |         const before = peer.head.seq;
  259 |         await submitFirstLegal(survivor, gameId);
  260 |         await expect
  261 |           .poll(async () => (await gameView(destination, gameId))?.head?.seq ?? 0, {
  262 |             timeout: 30_000,
  263 |           })
  264 |           .toBeGreaterThan(before);
  265 |       }
  266 |     }
  267 |     expect(acceptedMove).toBe(true);
  268 |     expect((await gameView(destination, gameId))?.head).toEqual(
  269 |       (await gameView(survivor, gameId))?.head,
  270 |     );
  271 | 
  272 |     await source.reload();
```
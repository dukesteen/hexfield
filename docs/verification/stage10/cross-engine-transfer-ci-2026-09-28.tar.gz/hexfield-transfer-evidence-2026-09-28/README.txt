Imported transfer cross-engine CI evidence, captured 2026-09-28.

Runs:
- 36416108153 at 8502469: Firefox and WebKit failed before transfer; raw job logs, Playwright reports, and public page diagnostics are under run-36416108153/.
- 36416945252 at 80133af: WebKit passed; Firefox remained in imported-view checking before transfer. Both raw job logs and public reports/diagnostics are under run-36416945252/.
- 36417729313 at 98d8846: Firefox and WebKit both passed, including stale pre-transfer archive import after activation, retired-source refusal, and a peer-accepted destination command. Raw logs and public results are under run-36417729313/.

source-80133af/ and source-98d8846/ pin the imported-transfer test, mixed-engine workflow, import worker, and route at each tested source revision. Each directory contains exact commit/tree pins and SHA-256 manifests. The public artifacts contain synthetic test data and no user credentials or private game material.

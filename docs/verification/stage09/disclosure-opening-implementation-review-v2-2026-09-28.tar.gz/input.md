Read-only implementation review for Claude Opus 5.5 at medium effort. Do not execute tools, edit files, or disclose fixture secret values. Review ONLY the opening fence, not a lifetime fence for an already-active independent coordinator. No new disposition certificate/quorum, no new protocol trust flag.

Confirmed fail-before: genuinely transferred resume with retained authenticated escrow disclosure on same device activated despite normal coordinator halt. New shared prepareOnlineDisclosureGuard uses signed genesis original frozen roster, strict stored device packet and full dispute proof/signature, exact pinned escrow envelope; openOnlineGame checks before opening and buffers device output across P2P create/restore, then final store check and synchronous release under the existing attempt lock. Typed error maps startup to halted.

Ask: verify exact store slot authentication and kind/context binding; original human vs bot/transferred controller identities; exact pinned envelope and master/dealer/holder bindings; forged/foreign/alternate evidence DoS; opening async persistence/create/flush order, races and lock reentrancy; cancellation/cleanup/bounded128message1MiB queue and transport forwarding signatures; error UI cold path. Evaluate claims against actual tests and evidence JSON.

Important escrow-invalid question: it IS reachable post-consent, but coordinator #acceptInvalidPacket consented branch deliberately preserves result, emits no halt and states that malformed dealer packet reveals no private share and cannot revoke signed/certified genesis. Is scanning only escrow-dispute correct under this existing semantic contract? Do NOT assume invalidkind unreachable.

Final cleanup correction: outputStopped is monotonic. stopOutput sets it and clears buffered output before projection transport disposal. cleanup calls stopOutput before session disposal/flush; send drops after stopped; checkCancelled checks stopped. The final release must never resume output after abort/cleanup. Independently assess this correction and closing callbacks. This is immutable v2; prior v1 is retained separately.

Checks from evidence: fail-before81339 disclosed entered playing. Final34012 five cases PASS24.282s tests/25.94srunner, including actual restored opening with late evidence and no actual device output. Normal91888 three checks PASS22.61srunner; shared test tsc77161/scopedstatic68581 PASS. Eight initial checks total. After the cleanup correction, selected genuine disputed-opening/deferred-close run39382 PASS2/2,7.613s/3.120s tests and12.22srunner; scoped formatting/type-aware lint8810 PASS. These selected cases verify the final stopped-output source, while unchanged cases retain their prior results. No lifetime independent-coordinator claim and no full RTC/network acceptance claim.

Return severity, exact function, concrete trigger, minimal fix/test for real bugs. State whether ready after narrow corrections.



### packages/protocol/src/online-disclosure.ts
import { hashValue, toHex } from '@cp2p/codec';
import { failure, success } from '@cp2p/engine';
import type { Result } from '@cp2p/engine';
import * as v from 'valibot';
import { escrowShareEnvelopeHash } from './escrow-distribution.js';
import { verifyEscrowShareDispute } from './escrow-dispute.js';
import { validateGenesisEscrow } from './genesis-escrow.js';
import { validateGenesisOnlineStart } from './genesis-online-start.js';
import {
  onlineCeremonyAttemptId,
  onlineCeremonySlot,
  verifyOnlineCeremonyPacket,
} from './online-ceremony-wire.js';
import { genesisSchema } from './schemas.js';
import type { Genesis } from './types.js';
import type { EscrowLifecycleStore } from './escrow-lifecycle.js';
import { MAX_MESSAGE_BYTES, parseCanonical } from './validation.js';

const disputeSchema = v.strictObject({ envelope: v.unknown(), dispute: v.unknown() });

/** Owns the original authenticated roster and pinned envelopes across storage awaits. */
export function prepareOnlineDisclosureGuard(genesis: Genesis): Result<{
  readonly attemptId: string;
  check(store: Pick<EscrowLifecycleStore, 'load'>): Promise<Result<boolean>>;
}> {
  const owned = parseCanonical(genesis, genesisSchema);
  if (!owned.ok) return owned;
  const start = validateGenesisOnlineStart(owned.value);
  if (!start.ok) return start;
  const escrow = validateGenesisEscrow(owned.value);
  if (!escrow.ok) return escrow;
  const state = start.value.bindings.agreement.state;
  const freezeHash = toHex(hashValue(state));
  const nonce = state.ceremonyNonce;
  if (!nonce) return failure('online-disclosure-genesis', 'Frozen ceremony nonce is missing');
  const attemptId = onlineCeremonyAttemptId(freezeHash, nonce);
  return success({
    attemptId,
    async check(store) {
      try {
        for (const dealer of escrow.value) {
          for (const { envelope } of dealer.shares) {
            const holder = state.seats.find((seat) => seat.seat === envelope.body.holder.seat);
            if (!holder || holder.kind !== 'human') continue;
            const slot = onlineCeremonySlot('escrow-dispute', holder.seat, dealer.dealerSeat);
            // oxlint-disable-next-line no-await-in-loop -- Check only the bounded pinned roster slots.
            const bytes = await store.load(`online-ceremony/${attemptId}/${slot}`);
            if (!bytes || bytes.byteLength > MAX_MESSAGE_BYTES) continue;
            const packet = verifyOnlineCeremonyPacket(bytes, holder.peer, freezeHash, nonce);
            if (
              !packet.ok ||
              packet.value.body.kind !== 'escrow-dispute' ||
              packet.value.body.seat !== holder.seat ||
              packet.value.body.step !== dealer.dealerSeat
            )
              continue;
            const payload = parseCanonical(packet.value.body.payload, disputeSchema);
            if (!payload.ok) continue;
            const verdict = verifyEscrowShareDispute(
              payload.value.dispute,
              payload.value.envelope,
              owned.value,
            );
            if (
              !verdict.ok ||
              verdict.value.dispute.body.holderSeat !== holder.seat ||
              verdict.value.dispute.body.dealerSeat !== dealer.dealerSeat ||
              verdict.value.dispute.body.envelopeHash !== escrowShareEnvelopeHash(envelope)
            )
              continue;
            return success(true);
          }
        }
        return success(false);
      } catch {
        return failure('online-disclosure-store', 'Could not inspect retained disclosure evidence');
      }
    },
  });
}


### packages/protocol/src/index.ts
export const PACKAGE_NAME = '@cp2p/protocol';

export { createBeaconSecretSource } from './beacon-source.js';
export type { BeaconSecretProvider, BeaconSecretSourceContext } from './beacon-source.js';

export { MemoryBeaconContributionStore } from './beacon-contributions.js';
export { MemoryCheatCandidateStore } from './cheat-candidates.js';
export type { CheatCandidateStore } from './cheat-candidates.js';
export type {
  BeaconContribution,
  BeaconContributionStore,
  BeaconSecretSource,
} from './beacon-contributions.js';
export type { CryptoContext } from './crypto-context.js';
export { MemoryCountContributionStore } from './count-contributions.js';
export type { CountContributionStore, CountProofProducer } from './count-contributions.js';
export type { CountOperation, CountState, SignedCountContribution } from './count-reveal.js';
export { createHandSecretSource } from './hand-source.js';
export type { HandSecretSource, HandSourceFactory } from './hand-source.js';
export { createRandomDerivations, randomDerivations } from './random-derivations.js';
export type { RandomDerivation, RandomPending, BeaconOutcome } from './random-derivations.js';

export {
  GENESIS_PREVIOUS_HASH,
  entryBody,
  entryHash,
  genesisBody,
  genesisDigest,
  genesisId,
  signEntry,
  validateGenesis,
  validateGenesisEntry,
} from './genesis.js';
export type { GenesisPolicy, ValidatedGenesis } from './genesis.js';
export { validateGenesisOnlineStart } from './genesis-online-start.js';
export type { VerifiedOnlineStart } from './genesis-online-start.js';
export type { GenesisSeedMode } from './genesis-seed.js';
export { prepareOnlineDisclosureGuard } from './online-disclosure.js';
export { OnlineCeremony } from './online-ceremony.js';
export type {
  OnlineCeremonyOptions,
  OnlineCeremonyProgress,
  OnlineCeremonyResult,
  OnlineCeremonyPhase,
} from './online-ceremony.js';
export { signCommand, stubEvidence, validateNextEntry, validateSignedCommand } from './log.js';
export type { EntryPolicy, LogContext, ValidatedEntry } from './log.js';
export { validateExcludeProposerControl, validateObjectiveAccusation } from './control.js';
export type { ControlEvidenceContext } from './control.js';
export {
  authenticateCertifiedEntry,
  proposerFor,
  signProposal,
  validateCertifiedEntry,
  validateProposal,
} from './proposal.js';
export type {
  CertifiedEntry,
  ProposalBody,
  ProposalContext,
  SignedProposal,
  ValidatedProposal,
} from './proposal.js';
export { advanceContext } from './proposal.js';
export { certifiedEntrySchema } from './proposal.js';
export { genesisSchema, logEntrySchema } from './schemas.js';
export { MemorySafetyStore } from './safety-store.js';
export { createConsensusState, restoreConsensusState } from './consensus.js';
export { verifyRevealedMaster } from './genesis-secrets.js';
export { validateGenesisEscrow } from './genesis-escrow.js';
export { restoreRetiredSafety } from './retired-safety.js';
export {
  transferAuthorizationStatementSchema,
  transferChangeSchema,
  transferCheckDigest,
  transferEntryRef,
  TRANSFER_DEVICE_DOMAIN,
  TRANSFER_GAME_KEY_DOMAIN,
  TRANSFER_BOT_KEY_DOMAIN,
  TRANSFER_DESTINATION_CHECK_DOMAIN,
  TRANSFER_BOT_CHECK_DOMAIN,
} from './transfer-readiness.js';
export type {
  SeatTransferAuthorization,
  SeatTransferAuthorizationStatement,
  TransferReplacement,
} from './transfer-types.js';
export { TRANSFER_RETURN_INTENT_DOMAIN } from './transfer-readiness.js';
export {
  prepareTransferPrivate,
  importTransferPrivate,
  verifyTransferPrivateEnvelope,
  transferPrivateEnvelopeSchema,
  TRANSFER_PRIVATE_DOMAIN,
} from './transfer-private.js';
export type {
  TransferPrivateEnvelope,
  TransferPrivateStore,
  ImportedTransferPrivate,
} from './transfer-private.js';
export { transferActivationStatementSchema } from './transfer-readiness.js';
export {
  validatePendingTransferMaterial,
  validateRetiredTransferBinding,
  validateTransferOwnedMaterial,
} from './transfer-material.js';
export type { TransferOwnedMaterial, TransferOwnedSeat } from './transfer-material.js';
export type { SafetyStore, StoredSafety } from './safety-store.js';
export { MemoryProtocolJournal, journalSafetyStore } from './journal.js';
export type { JournalRecord, ProtocolJournal } from './journal.js';
export { P2PSession } from './p2p-session.js';
export { VerifiedSessionDriver } from './verified-session-driver.js';
export type { CertifiedHistory, P2PSessionOptions, SessionDriver } from './p2p-session.js';
export { ReplicatedLog } from './replicated-log.js';
export type {
  ReplicatedLogOptions,
  ReplicatedLogStatus,
  RecoveredReplicaOwnership,
} from './replicated-log.js';
export { chooseBotPending } from './bot-pending.js';
export {
  initialProposalContext,
  replayCertifiedPrefix,
  snapshotFromContext,
  verifyReplaySnapshot,
} from './replay.js';
export type { ReplayPolicy, ReplayedPrefix } from './replay.js';
export { decodeProtocolMessage, encodeProtocolMessage, protocolMessageSchema } from './messages.js';
export type { ProtocolMessage } from './messages.js';
export type {
  GameSession,
  SessionScheduler,
  SessionStatus,
  SessionTimer,
  SessionUpdate,
  SessionFairness,
  SubmitOptions,
} from './session-types.js';
export { phaseIdentity, timerKey } from './session-timing.js';
export { TURN_TIMEOUT_PROTOCOL } from './turn-timeout.js';
export type { TimerAnchor } from './turn-timeout.js';
export type { PeerId, ProtocolClock, Transport, Unsubscribe } from './transport.js';
export { PROTOCOL_VERSION } from './types.js';
export { DEFAULT_TAKEOVER_POLICY, takeoverPolicySchema } from './takeover-policy.js';
export type { TakeoverPolicy } from './takeover-policy.js';
export { LobbyController, verifyLobbyFreezeAgreement } from './lobby.js';
export type { LobbyControllerOptions, HostLobbyOptions, JoinLobbyOptions } from './lobby.js';
export { LOBBY_COLOURS } from './lobby-types.js';
export type {
  LobbyBotLevel,
  LobbyColour,
  LobbyDiagnostic,
  LobbyFreezeAck,
  LobbyFreezeAgreement,
  LobbyRequest,
  LobbySeat,
  LobbyState,
} from './lobby-types.js';
export {
  ONLINE_SEAT_BINDING_DOMAIN,
  ONLINE_SEAT_BINDING_PROTOCOL,
  signGameSeatBinding,
  verifyGameSeatBindings,
} from './online-bindings.js';
export type {
  GameSeatBindingBody,
  SignedGameSeatBinding,
  SignGameSeatBindingInput,
  VerifiedGameSeatBindings,
} from './online-bindings.js';
export { EscrowCeremony } from './escrow-ceremony.js';
export type { CeremonySend, EscrowCeremonyStore } from './escrow-ceremony.js';
export type { EscrowManifestApproval } from './escrow-lifecycle.js';
export type { EscrowShareAck, AcceptedEscrowShare } from './escrow-distribution.js';
export type { EscrowShareEnvelope } from './escrow-types.js';
export type {
  BotSeat,
  CommandBody,
  CommandEvidence,
  EntryBody,
  EntryPayload,
  ExcludeProposerControl,
  ObjectiveEvidence,
  Genesis,
  GenesisBody,
  GenesisSeat,
  HumanSeat,
  LogEntry,
  SeatSignature,
  SignedCommand,
  SystemEvidence,
} from './types.js';
export { MAX_MESSAGE_BYTES } from './validation.js';
export { quorumSize, signVote, validateVote, verifyCertificate } from './votes.js';
export type { ExpectedVote, SignedVote, VoteBody, VoteContext, VotePhase } from './votes.js';
export { decodeMessage, encodeMessage } from './wire.js';
export {
  initDeckSetup,
  validateDeckSetupState,
  deckSetupId,
  deckPassOperationId,
  applyDeckPass,
  signDeckShuffle,
  signDeckLock,
  replayDeckSetup,
} from './deck-setup.js';
export type { DeckDefinition, DeckSetupState, SignedDeckPass } from './deck-setup.js';
export { createDeckSecretSource } from './deck-source.js';
export type { DeckSecretSource, DeckSourceFactory } from './deck-source.js';
export {
  freezeDeckDraw,
  validateDeckDrawOperation,
  deckDrawOperationId,
  verifyDeckUnlockPrefix,
  signDeckUnlock,
  verifyDeckUnlock,
  completeDeckDraw,
  decodeDeckCard,
  proveDeckReveal,
  verifyDeckReveal,
} from './deck-draw.js';
export type {
  DeckDrawRequest,
  DeckDrawOperation,
  SignedDeckUnlock,
  DealtDeckCard,
  DeckRevealContext,
  DeckCardReveal,
} from './deck-draw.js';
export { prepareDeckUnlock } from './deck-outbox.js';
export type { DeckContributionStore } from './deck-outbox.js';
export { prepareDeckPass } from './deck-setup-outbox.js';

export {
  deckCeremonyId,
  genesisDeckDefinitions,
  deckPassHash,
  createDeckGenesisCommitment,
  validateDeckGenesisCommitments,
  validateDeckCeremony,
} from './deck-genesis.js';
export type { DeckGenesisCommitment } from './deck-genesis.js';
export { DECK_DRAW_PROTOCOL, DECK_REVEAL_PROTOCOL, decksReady } from './deck-ledger.js';
export type { DeckLedger, LedgerDeck, LedgerSlot } from './deck-ledger.js';

export { prepareGenesisConsent, MemoryGenesisConsentStore } from './genesis-outbox.js';
export type { GenesisConsentStore } from './genesis-outbox.js';

export { createStealSecretSource } from './steal-source.js';
export type { StealSecretSource, StealSourceFactory } from './steal-source.js';
export type { StealState } from './steal-state.js';
export { MemoryStealDeliveryStore } from './steal-contributions.js';
export type {
  StealContributionProducer,
  StealDeliveryStore,
  StealResponse,
  StealResponseProducer,
} from './steal-contributions.js';
export type {
  IndexedHandProof,
  SignedTradeProofRequest,
  SignedTradeProofResponse,
  TradeProofBody,
} from './trade-proof-delivery.js';

export { artifactSigner, resolveArtifactSigner } from './authority.js';
export type { ArtifactSigner, ControllerRecord, SeatAuthorities } from './authority-types.js';
export type {
  AuthorizedRecovery,
  RecoveryActivation,
  RecoveryActivationStatement,
  RecoveryAuthorization,
  RecoveryChange,
  RecoveryReadiness,
  RecoveryState,
  RecoveryVoid,
  RecoveryVoidReason,
  RecoveryVoidStatement,
} from './recovery-types.js';
export { recoveryCheckDigest } from './recovery-membership.js';
export {
  prepareRecoveryReadiness,
  loadPreparedRecoveryReadiness,
  loadActivatedRecoveryKeys,
} from './recovery-readiness.js';
export type { RecoveryApprovalCandidate, RecoveryApprovalPreview } from './recovery-facade.js';
export type {
  ActivatedRecoveryKeySet,
  RecoveryReadinessReplacement,
  RecoveryReadinessStore,
} from './recovery-readiness.js';
export {
  prepareRecoveryRelease,
  verifyRecoveryRelease,
  openRecoveryRelease,
  recoverAuthorizedMaster,
} from './recovery-release.js';
export type { RecoveryRelease, RecoveryReleaseStore } from './recovery-release.js';
export { produceRecoveryCheck, produceRecoveryCheckFromShares } from './recovery-check.js';
export { produceRecoveryVoidCheckFromShares } from './recovery-void.js';
export type { SignedRecoveryVoidCheck, RecoveryVoidCheckInput } from './recovery-void.js';
export type {
  ProducedRecoveryCheck,
  RecoveryCheckInput,
  RecoveryCheckStore,
  SignedRecoveryCheck,
} from './recovery-check.js';
export { RecoveryInbox } from './recovery-inbox.js';
export { loadRecoveryPrivate } from './recovery-private.js';
export type { RecoveryPrivateStore } from './recovery-private.js';
export { loadRecoveredHost } from './recovered-host.js';
export type { RecoveredHost, RecoveredHostInput } from './recovered-host.js';
export { RecoveryParticipant } from './recovery-participant.js';
export type {
  RecoveryParticipantOptions,
  PreparedRecoveryPackets,
} from './recovery-participant.js';
export { auditCertifiedGame } from './audit.js';
export type { AuditCertifiedGameInput } from './audit.js';
export type { AuditReport, AuditViolation, AuditInputError, AuditEntryRef } from './audit-types.js';
export {
  MasterRevealCoordinator,
  signedMasterRevealSchema,
  verifyMasterReveal,
} from './master-reveal.js';
export type {
  MasterRevealOptions,
  MasterRevealStore,
  MasterRevealVerdict,
  SignedMasterReveal,
} from './master-reveal.js';
export type {
  SessionAuditInput,
  SessionAuditJob,
  SessionAuditRunner,
  SessionAuditState,
} from './session-audit-types.js';


### apps/web/src/session/online-game.ts
import { canonicalDecode, canonicalEncode, toBase64Url } from '@cp2p/codec';
import { G, encodePoint, identityFromSecret, scalarFromBytes, scalePoint } from '@cp2p/crypto';
import { RandomBot } from '@cp2p/bots';
import { success } from '@cp2p/engine';
import type { Engine, Seat } from '@cp2p/engine';
import {
  createBeaconSecretSource,
  createDeckSecretSource,
  createHandSecretSource,
  createStealSecretSource,
  deckCeremonyId,
  decksReady,
  genesisDigest,
  entryHash,
  initialProposalContext,
  replayCertifiedPrefix,
  transferChangeSchema,
  validateTransferOwnedMaterial,
  P2PSession,
  prepareOnlineDisclosureGuard,
  validateDeckCeremony,
  validateGenesisOnlineStart,
  VerifiedSessionDriver,
} from '@cp2p/protocol';
import type {
  BeaconSecretProvider,
  BeaconSecretSource,
  DeckSourceFactory,
  EscrowCeremonyStore,
  Genesis,
  LobbyFreezeAgreement,
  LogEntry,
  LogContext,
  CertifiedEntry,
  ProtocolClock,
  ProtocolJournal,
  ReplayPolicy,
  GameSession,
  SessionAuditRunner,
  SignedDeckPass,
  SignedGameSeatBinding,
  Transport,
} from '@cp2p/protocol';
import {
  acquireActiveGameWriterLease,
  IndexedDbProtocolJournal,
  IndexedDbPublicSnapshotStore,
} from '@cp2p/storage';
import type { GameWriterLease } from '@cp2p/storage';
import * as v from 'valibot';
import type { OwnedSeatMaterial } from './online-credentials.js';
import { createOnlineGameTransport } from './online-game-transport.js';
import type { OnlineDeviceRoutes, OnlineGameTransport } from './online-game-transport.js';
import { createOnlineGameCandidateStore } from './online-game-candidates.js';
import { createSessionAuditRunner } from './audit-worker-client.js';
import { createOnlineGameHistoryWriter } from './online-game-history-writer.js';
import { createOnlineGameActivityWriter } from './online-game-activity.js';
import { browserEntropy, randomIndex, randomSeed } from './random.js';

type OnlineJournal = ProtocolJournal & { close(): Promise<void> };

export interface OnlineGameRuntime {
  readonly acquireLease?: typeof acquireActiveGameWriterLease;
  readonly createJournal?: (
    gameId: string,
    keyBinding: { recordKey: string; bytes: Uint8Array },
  ) => OnlineJournal;
  readonly auditRunner?: SessionAuditRunner;
}

export interface OnlineGameInput {
  readonly entry: LogEntry;
  readonly transcripts: readonly { deckId: string; passes: readonly SignedDeckPass[] }[];
  readonly agreement: LobbyFreezeAgreement;
  readonly bindings: readonly SignedGameSeatBinding[];
  readonly material: readonly OwnedSeatMaterial[];
  readonly deviceTransport: Transport;
  readonly store: EscrowCeremonyStore;
  readonly clock: ProtocolClock;
  readonly engine: Engine;
  readonly botDelayMs?: number;
  readonly signal?: AbortSignal;
  /** Immediate fatal fence for an unexpectedly lost exclusive game writer. */
  readonly onFatal?: (error: Error) => void;
  /** Reports local history-metadata persistence failures without affecting gameplay. */
  readonly onHistoryMetadataError?: (error: Error) => void;
  readonly onDeviceRoutes?: (routes: OnlineDeviceRoutes) => void;
  /** Resume preserves history; the built-in journal may initialize only an atomically proven unused slot. */
  readonly journalMode?: 'fresh-or-restore' | 'restore-only';
}

export interface OnlineGame<T extends GameSession = P2PSession> {
  readonly gameId: string;
  readonly genesis: Genesis;
  readonly seat: Seat;
  readonly session: T;
  close(): Promise<void>;
}

export class OnlineGameDisclosureError extends Error {
  constructor() {
    super('online-ceremony-disputed');
    this.name = 'OnlineGameDisclosureError';
  }
}

/** Opens only an authenticated, fully verified ceremony result under an exclusive game writer. */
export async function openOnlineGame(
  supplied: OnlineGameInput,
  runtime: OnlineGameRuntime = {},
): Promise<OnlineGame> {
  // Retain detached public evidence across asynchronous lease and storage work.
  const input = {
    ...supplied,
    entry: copyEvidence(supplied.entry),
    transcripts: copyEvidence(supplied.transcripts),
    agreement: copyEvidence(supplied.agreement),
    bindings: copyEvidence(supplied.bindings),
  };
  const material = input.material.map((item) => ({
    ...item,
    signingKey: new Uint8Array(item.signingKey),
    master: new Uint8Array(item.master),
  }));
  // Opening cannot publish prepared game output until its final shared-store check.
  const openingOutput: { to: string; bytes: Uint8Array }[] = [];
  let openingBytes = 0;
  let opening = true;
  let outputStopped = false;
  const device = input.deviceTransport;
  const send = (to: string, bytes: Uint8Array) => {
    if (outputStopped) return;
    if (!opening) {
      device.send(to, bytes);
      return;
    }
    if (openingOutput.length >= 128 || openingBytes + bytes.byteLength > 1024 * 1024)
      throw new Error('Online opening output exceeds its bounded queue');
    openingOutput.push({ to, bytes: bytes.slice() });
    openingBytes += bytes.byteLength;
  };
  const openingTransport: Transport = {
    self: device.self,
    peers: () => device.peers(),
    send,
    broadcast: (bytes) => {
      for (const peer of device.peers()) send(peer, bytes);
    },
    onMessage: (listener) => device.onMessage(listener),
    onPeerChange: (listener) => device.onPeerChange(listener),
    disconnect: (peer) => device.disconnect(peer),
  };
  let journal: OnlineJournal | null = null;
  let snapshotStore: IndexedDbPublicSnapshotStore | null = null;
  let lease: GameWriterLease | null = null;
  let transport: OnlineGameTransport | null = null;
  let session: P2PSession | null = null;
  let historyWriter: ReturnType<typeof createOnlineGameHistoryWriter> | null = null;
  let activityWriter: ReturnType<typeof createOnlineGameActivityWriter> | null = null;
  let terminalHead: { seq: number; hash: string } | null = null;
  let leaseLost = false;
  const providers = new Map<Seat, BeaconSecretProvider>();
  const checkCancelled = () => {
    if (input.signal?.aborted || leaseLost || outputStopped)
      throw new DOMException('Online game opening was cancelled', 'AbortError');
  };
  const stopOutput = () => {
    outputStopped = true;
    openingOutput.length = 0;
    openingBytes = 0;
    transport?.dispose();
  };
  input.signal?.addEventListener('abort', stopOutput, { once: true });
  const cleanup = async () => {
    stopOutput();
    input.signal?.removeEventListener('abort', stopOutput);
    historyWriter?.stop();
    activityWriter?.stop();
    try {
      session?.dispose();
      await session?.flush();
    } finally {
      await historyWriter?.flush();
      await activityWriter?.flush();
      transport?.dispose();
      for (const provider of providers.values()) provider.dispose();
      for (const item of material) {
        item.signingKey.fill(0);
        item.master.fill(0);
      }
      try {
        try {
          await snapshotStore?.close();
        } finally {
          await journal?.close();
        }
      } finally {
        await lease?.close();
      }
    }
  };
  try {
    checkCancelled();
    const policy: ReplayPolicy = {
      genesis: {
        verifyCommitments(genesis) {
          const decks = validateDeckCeremony(genesis, input.transcripts);
          return decks.ok ? success(undefined) : decks;
        },
      },
      entry: {},
    };
    const checked = initialProposalContext(input.entry, input.engine, policy);
    if (!checked.ok) throw new Error(checked.error.message);
    const { genesis, state, crypto } = checked.value.log;
    const startup = validateGenesisOnlineStart(genesis);
    if (!startup.ok) throw new Error(startup.error.message);
    if (!crypto) throw new Error('Verified game commitments are missing');
    const disclosure = prepareOnlineDisclosureGuard(genesis);
    if (!disclosure.ok) throw new Error(disclosure.error.message);
    const checkDisclosure = async () => {
      const checkedDisclosure = await disclosure.value.check(input.store);
      if (!checkedDisclosure.ok) throw new Error(checkedDisclosure.error.message);
      if (checkedDisclosure.value) throw new OnlineGameDisclosureError();
      checkCancelled();
    };
    await checkDisclosure();
    const humans = material.filter((seat) => seat.kind === 'human');
    const local = humans[0];
    if (humans.length !== 1 || !local) throw new Error('Stored material needs one human seat');
    lease = await (runtime.acquireLease ?? acquireActiveGameWriterLease)(genesis.gameId, {
      onLost(error) {
        leaseLost = true;
        transport?.dispose();
        session?.dispose();
        try {
          input.onFatal?.(error);
        } catch {
          // Reporting failure cannot restore authority or resume output.
        }
      },
    });
    checkCancelled();
    if (!lease) throw new Error('This game is already active in another tab');
    const digest = genesisDigest(genesis);
    const keyBinding = {
      recordKey: `online-game/${digest}/keys`,
      bytes: canonicalEncode({
        protocol: 'online-game-keys-v1',
        genesisDigest: digest,
        devicePeer: input.deviceTransport.self,
        humanSeat: local.seat,
        seats: material,
      }),
    };
    try {
      journal = runtime.createJournal
        ? runtime.createJournal(genesis.gameId, keyBinding)
        : new IndexedDbProtocolJournal(genesis.gameId, { keyBinding });
    } finally {
      keyBinding.bytes.fill(0);
    }
    // Vault-bound journals use an injected factory but still have the same durable public cache.
    if (journal instanceof IndexedDbProtocolJournal)
      snapshotStore = new IndexedDbPublicSnapshotStore(genesis.gameId);
    const saved = await journal.load();
    checkCancelled();
    if (saved && entryHash(saved.genesis) !== entryHash(input.entry))
      throw new Error('Stored game history differs from the certified online start');
    let installed: LogContext | null =
      checked.value.log.authority?.controllers.find((seat) => seat.seat === local.seat)
        ?.publicKey === local.peerId
        ? checked.value.log
        : null;
    let priorKey = checked.value.log.authority?.controllers.find(
      (seat) => seat.seat === local.seat,
    )?.publicKey;
    const replayed = saved
      ? replayCertifiedPrefix(
          saved.genesis,
          saved.entries,
          input.engine,
          policy,
          (_entry, next) => {
            if (!terminalHead && next.log.state.result)
              terminalHead = { seq: next.log.head.seq, hash: entryHash(next.log.head) };
            const key = next.log.authority?.controllers.find(
              (seat) => seat.seat === local.seat,
            )?.publicKey;
            if (key !== priorKey && key === local.peerId) installed = next.log;
            priorKey = key;
            return success(undefined);
          },
        )
      : success({ context: checked.value });
    if (!replayed.ok) throw new Error(replayed.error.message);
    const current = replayed.value.context.log;
    if (!installed) throw new Error('Stored game key has no certified owning generation');
    // The durable binding contains exactly the seats installed with this human
    // key. Later recovery adds separately persisted bots; a return can retire one.
    if (current.crypto && decksReady(current.crypto.decks)) {
      const ownedMaterial = validateTransferOwnedMaterial(
        {
          protocol: 'online-game-keys-v1',
          genesisDigest: digest,
          devicePeer: input.deviceTransport.self,
          humanSeat: local.seat,
          seats: material,
        },
        { ...installed, crypto: current.crypto },
      );
      if (!ownedMaterial.ok) throw new Error(ownedMaterial.error.message);
      for (const seat of ownedMaterial.value.seats) {
        seat.signingKey.fill(0);
        seat.master.fill(0);
      }
    } else {
      // Before certified deck setup only the original frozen owners can open.
      // Driver/source checks below validate the available deck and beacon data.
      const owned = genesis.seats.filter(
        (seat) =>
          seat.seat === local.seat || (seat.kind === 'bot' && seat.botHost === local.peerId),
      );
      if (
        installed.head.seq !== 0 ||
        material.length !== owned.length ||
        material.some(
          (item, index) =>
            item.seat !== owned[index]?.seat ||
            item.kind !== owned[index]?.kind ||
            item.peerId !== owned[index]?.publicKey,
        )
      )
        throw new Error('Stored game keys differ from the frozen device-owned seats');
      for (const item of material) {
        const identity = identityFromSecret(item.signingKey);
        try {
          if (
            identity.peerId !== item.peerId ||
            encodePoint(scalePoint(G, scalarFromBytes(item.master, { nonzero: true }))) !==
              startup.value.bindings.masters.find((entry) => entry.seat === item.seat)?.masterPub
          )
            throw new Error('Stored game secrets do not match the certified identity');
        } finally {
          identity.secretKey.fill(0);
        }
      }
    }
    const projection = createOnlineGameTransport({
      deviceTransport: openingTransport,
      validatedGenesis: { genesis, state },
      agreement: input.agreement,
      bindings: input.bindings,
      certifiedHistory: {
        genesisEntry: input.entry,
        entries: saved?.entries ?? [],
        engine: input.engine,
        policy,
      },
    });
    if (!projection.ok) throw new Error(projection.error.message);
    transport = projection.value;
    const human = current.authority?.controllers.find(
      (seat) => seat.seat === local.seat && seat.kind === 'human' && seat.status === 'active',
    );
    if (!human || human.publicKey !== local.peerId || transport.self !== local.peerId)
      throw new Error('The stored human key no longer controls this seat');
    const activeMaterial = material.filter((item) =>
      current.authority?.controllers.some(
        (seat) =>
          seat.seat === item.seat &&
          seat.kind === item.kind &&
          seat.status === 'active' &&
          seat.hostSeat === human.seat &&
          seat.publicKey === item.peerId,
      ),
    );
    const ownedMaterial = new Map(activeMaterial.map((item) => [item.seat, item]));
    // The journal retains the exact installing-generation binding. Working
    // secrets belong only to the seats still controlled at the restored head.
    for (const item of material) {
      if (ownedMaterial.has(item.seat)) continue;
      item.signingKey.fill(0);
      item.master.fill(0);
    }
    const masterFor = (seat: Seat) => {
      const entry = ownedMaterial.get(seat);
      if (!entry) throw new Error('Cannot derive secrets for another device');
      return entry.master;
    };
    const deckSource: DeckSourceFactory = (deckId, seat) => {
      const definition = crypto.decks.decks.find(
        (deck) => deck.commitment.definition.deckId === deckId,
      )?.commitment.definition;
      if (!definition) throw new Error('Unknown verified deck');
      return createDeckSecretSource(masterFor(seat), definition, seat);
    };
    const stealSource = (seat: Seat) => {
      const owner = genesis.seats.find((item) => item.seat === seat);
      if (!owner) throw new Error("Cannot derive another device's encryption key");
      return createStealSecretSource(masterFor(seat), genesis.ceremonyNonce, seat, owner.publicKey);
    };
    const chain = crypto.beacon.chains.find((item) => item.seat === human.seat);
    if (!chain) throw new Error('Missing human beacon commitment');
    const beacon = createBeaconSecretSource(
      local.master,
      { ceremonyId: deckCeremonyId(genesis), seat: human.seat },
      chain.length,
    );
    providers.set(human.seat, beacon);
    if (toBase64Url(beacon.initialCommitment.tip) !== chain.tip)
      throw new Error('Stored master differs from the frozen beacon chain');
    const beaconSources = new Map<Seat, BeaconSecretSource>();
    for (const item of activeMaterial) {
      if (item.kind !== 'bot') continue;
      const originalChain = crypto.beacon.chains.find((candidate) => candidate.seat === item.seat);
      if (!originalChain) {
        if (genesis.seats.find((seat) => seat.seat === item.seat)?.kind === 'bot') continue;
        throw new Error('Missing hosted-seat beacon commitment');
      }
      const provider = createBeaconSecretSource(
        item.master,
        { ceremonyId: deckCeremonyId(genesis), seat: item.seat },
        originalChain.length,
      );
      providers.set(item.seat, provider);
      if (toBase64Url(provider.initialCommitment.tip) !== originalChain.tip)
        throw new Error('Hosted master differs from the frozen beacon chain');
      beaconSources.set(item.seat, provider.source);
    }
    const bot = new RandomBot();
    const botKeys = new Map(
      activeMaterial
        .filter((item) => item.kind === 'bot')
        .map((item) => [item.seat, item.signingKey]),
    );
    const publicSnapshots = snapshotStore;
    const options = {
      genesisEntry: input.entry,
      engine: input.engine,
      policy,
      seat: human.seat,
      secretKey: local.signingKey,
      transport,
      clock: input.clock,
      journal,
      ...(publicSnapshots
        ? { savePublicSnapshot: (snapshot: unknown) => publicSnapshots.saveCommitted(snapshot) }
        : {}),
      onCertifiedNonMembershipCommit(head: { readonly seq: number; readonly hash: string }) {
        const pruned = projection.value.pruneRetired(head);
        if (pruned.ok && pruned.value) {
          const routes = projection.value.deviceRoutes();
          if (routes) input.onDeviceRoutes?.(routes);
        }
        return pruned.ok ? success(undefined) : pruned;
      },
      onMembershipCommitted(entries: readonly CertifiedEntry[]) {
        const routed = projection.value.advanceCertifiedHistory(entries);
        const payload = entries.at(-1)?.entry.payload;
        const transfer =
          payload?.kind === 'membership' ? v.safeParse(transferChangeSchema, payload.change) : null;
        const replacements =
          transfer?.success && transfer.output.kind === 'transfer-activate'
            ? transfer.output.statement.replacements
            : [];
        const retired = !routed.ok && routed.error.code === 'online-transport-retired';
        if (routed.ok) {
          const routes = projection.value.deviceRoutes();
          if (routes) input.onDeviceRoutes?.(routes);
        }
        for (const item of material) {
          if (
            !retired &&
            !replacements.some(
              (replacement) =>
                replacement.seat === item.seat && replacement.oldPublicKey === item.peerId,
            )
          )
            continue;
          item.signingKey.fill(0);
          item.master.fill(0);
          ownedMaterial.delete(item.seat);
          providers.get(item.seat)?.dispose();
          providers.delete(item.seat);
        }
        // The final commit was sent with the old route. Retirement disposes this
        // immutable signer/transport; the destination opens a fresh instance.
        return retired ? success(undefined) : routed;
      },
      botKeys,
      botDelayMs: input.botDelayMs ?? 800,
      decideBot: (
        view: Parameters<RandomBot['decide']>[0],
        pending: Parameters<RandomBot['decide']>[1],
      ) => bot.decide(view, pending, { int: (max) => randomIndex(browserEntropy, max) }),
      beaconSource: beacon.source,
      beaconSources,
      beaconContributions: input.store,
      deckSetupPasses: input.transcripts.flatMap(({ deckId, passes }) =>
        passes.map((pass) => ({ deckId, pass })),
      ),
      createDeckSource: deckSource,
      deckContributions: input.store,
      countContributionStore: input.store,
      stealDeliveryStore: input.store,
      cheatCandidateStore: createOnlineGameCandidateStore(input.store, digest),
      recoveryStore: input.store,
      transferPrivateOutbox: input.store,
      transferPrivateImportStore: input.store,
      recoveryParticipant: {
        store: input.store,
        privateEntropy: () => randomSeed(browserEntropy),
        encryptionSecret: () => {
          const source = stealSource(human.seat);
          try {
            return source.encryptionSecret();
          } finally {
            source.dispose();
          }
        },
      },
      createDriver: (
        engine: Engine,
        approved: Genesis,
        _clock: ProtocolClock,
        seats: readonly Seat[],
      ) =>
        new VerifiedSessionDriver(
          engine,
          approved,
          seats,
          deckSource,
          (seat) => createHandSecretSource(masterFor(seat), digest, seat),
          stealSource,
        ),
      masterReveal: {
        store: input.store,
        async loadOwnedMaster(seat: Seat) {
          const item = ownedMaterial.get(seat);
          return item ? new Uint8Array(item.master) : null;
        },
      },
      auditRunner: runtime.auditRunner ?? createSessionAuditRunner(),
    };
    // The built-in journal returns null only when genesis, entries, safety and
    // its bound voting-key record are all absent in one IndexedDB transaction.
    // Injected journals have no equivalent proof and must remain restore-only.
    if (input.journalMode === 'restore-only' && !saved && runtime.createJournal)
      throw new Error('The certified online game journal is missing');
    await checkDisclosure();
    const opened = await lease.run(() => {
      checkCancelled();
      return saved ? P2PSession.restore(options) : P2PSession.create(options);
    });
    if (!opened.ok) throw new Error(opened.error.message);
    session = opened.value;
    checkCancelled();
    // Evidence insertion uses this attempt lock. This callback only loads and
    // sends synchronously; it does not acquire another ceremony or writer lock.
    await input.store.withCeremonyLock(disclosure.value.attemptId, async () => {
      await checkDisclosure();
      for (const output of openingOutput) {
        checkCancelled();
        device.send(output.to, output.bytes);
      }
      openingOutput.length = 0;
      openingBytes = 0;
      opening = false;
    });
    historyWriter = createOnlineGameHistoryWriter({
      store: input.store,
      gameId: genesis.gameId,
      genesisDigest: digest,
      session,
      localHumanSeat: human.seat,
      terminalHead,
      ...(input.onHistoryMetadataError ? { onError: input.onHistoryMetadataError } : {}),
    });
    activityWriter = createOnlineGameActivityWriter({
      store: input.store,
      gameId: genesis.gameId,
      genesisDigest: digest,
      session,
      ...(input.onHistoryMetadataError ? { onError: input.onHistoryMetadataError } : {}),
    });
    const routes = projection.value.deviceRoutes();
    if (routes) input.onDeviceRoutes?.(routes);
    let closing: Promise<void> | null = null;
    return {
      gameId: genesis.gameId,
      genesis,
      seat: human.seat,
      session,
      close() {
        closing ??= Promise.resolve().then(cleanup);
        return closing;
      },
    };
  } catch (error) {
    await cleanup();
    throw error;
  }
}

function copyEvidence<T>(value: T): T {
  // oxlint-disable-next-line typescript/no-unsafe-type-assertion -- The same canonical value is detached here and validated before use.
  return canonicalDecode(canonicalEncode(value)) as T;
}


### apps/web/src/session/online-startup.ts
import {
  canonicalDecode,
  canonicalEncode,
  fromBase64Url,
  hashValue,
  toBase64Url,
  toHex,
} from '@cp2p/codec';
import { failure, success } from '@cp2p/engine';
import type { Engine, Result } from '@cp2p/engine';
import { OnlineCeremony, genesisDigest, verifyLobbyFreezeAgreement } from '@cp2p/protocol';
import type {
  EscrowCeremonyStore,
  LobbyController,
  LobbyFreezeAgreement,
  OnlineCeremonyProgress,
  LobbyState,
  ProtocolClock,
  Transport,
  Unsubscribe,
} from '@cp2p/protocol';
import { loadCeremonyMaterial, prepareCeremonyMaterial } from './online-credentials.js';
import type { DisposableOnlineIdentity, OwnedCeremonyMaterial } from './online-credentials.js';
import { OnlineGameDisclosureError, openOnlineGame } from './online-game.js';
import type { OnlineGame, OnlineGameRuntime } from './online-game.js';
import type { OnlineDeviceRoutes } from './online-game-transport.js';
import type { OnlineInvite } from './online-invite.js';
import { assertSupportedOnlineGameVersion, saveOnlineGameRecord } from './online-game-records.js';
import type { SavedOnlineGameRecord } from './online-game-records.js';
import { loadActiveOnlineResume } from './online-resume-binding.js';

export interface OnlineStartupSnapshot {
  readonly phase: OnlineCeremonyProgress['phase'] | 'freezing' | 'opening' | 'playing' | 'halted';
  readonly awaitingSeats: readonly number[];
  readonly locallyConsented: boolean;
  readonly error: string | null;
  readonly gameId: string | null;
}

interface OnlineStartupBase {
  readonly invite: OnlineInvite;
  readonly identity: DisposableOnlineIdentity;
  readonly transport: Transport;
  readonly store: EscrowCeremonyStore;
  readonly clock: ProtocolClock;
  readonly engine: Engine;
  readonly gameRuntime?: OnlineGameRuntime;
  readonly onGameFatal?: (error: Error) => void;
  readonly onDeviceRoutes?: (routes: OnlineDeviceRoutes) => void;
}

export type OnlineStartupOptions = OnlineStartupBase &
  (
    | {
        readonly lobby: LobbyController;
        /** Removes unseated connections and freezes discovery before key disclosure. */
        readonly freezePeers: (peers: readonly string[]) => void;
        readonly resume?: never;
        readonly approved?: never;
      }
    | {
        readonly resume: SavedOnlineGameRecord;
        readonly lobby?: never;
        readonly freezePeers?: never;
        readonly approved?: never;
      }
    | {
        /** The worker receives this only after the main lobby formed every signed ACK. */
        readonly approved: LobbyFreezeAgreement;
        readonly lobby?: never;
        readonly freezePeers?: never;
        readonly resume?: never;
      }
  );

/** Owns the immutable transition from device-key lobby consent to a game-key session. */
export class OnlineStartup {
  private readonly listeners = new Set<() => void>();
  private readonly unsubscribers: Unsubscribe[] = [];
  private current: OnlineStartupSnapshot | null = null;
  private approved: LobbyFreezeAgreement | null = null;
  private material: Pick<OwnedCeremonyMaterial, 'keys' | 'dispose'> | null = null;
  private ceremony: OnlineCeremony | null = null;
  private activeGame: OnlineGame | null = null;
  private work: Promise<void> | null = null;
  private retry: unknown = null;
  private closed = false;
  private closing: Promise<void> | null = null;
  private activationAttempted = false;
  private revoked = false;
  private stoppingGame: Promise<void> | null = null;
  private readonly abort = new AbortController();
  private readonly resume: SavedOnlineGameRecord | null;
  private readonly invite: OnlineInvite;

  constructor(private readonly options: OnlineStartupOptions) {
    this.invite = copyEvidence(options.invite);
    if (options.resume) {
      assertSupportedOnlineGameVersion(options.resume.result.genesis);
      if (options.resume.result.entry.payload.kind === 'genesis')
        assertSupportedOnlineGameVersion(options.resume.result.entry.payload.genesis);
    }
    this.resume = options.resume ? copyEvidence(options.resume) : null;
    if (this.resume) {
      const checked = verifyLobbyFreezeAgreement(this.resume.agreement);
      if (
        !checked.ok ||
        genesisDigest(this.resume.result.genesis) !== this.resume.genesisDigest ||
        this.resume.result.genesis.gameId !== this.resume.gameId ||
        !sameBytes(canonicalEncode(this.resume.invite), canonicalEncode(this.invite))
      )
        throw new Error('Saved online game does not match its signed agreement');
      this.approved = checked.value;
      this.current = {
        phase: 'opening',
        awaitingSeats: [],
        locallyConsented: true,
        error: null,
        gameId: this.resume.gameId,
      };
    } else if (options.approved) {
      const checked = verifyLobbyFreezeAgreement(options.approved);
      if (!checked.ok || checked.value.state.lobbyId !== this.invite.roomId)
        throw new Error('Approved online start has an invalid signed agreement');
      this.approved = checked.value;
      this.current = {
        phase: 'frozen',
        awaitingSeats: [],
        locallyConsented: true,
        error: null,
        gameId: null,
      };
    }
    if (options.lobby) this.unsubscribers.push(options.lobby.onChange(() => this.observe()));
    this.unsubscribers.push(options.transport.onPeerChange(() => this.observe()));
    this.observe();
  }

  snapshot(): OnlineStartupSnapshot | null {
    return this.current
      ? { ...this.current, awaitingSeats: [...this.current.awaitingSeats] }
      : null;
  }

  agreement(): LobbyFreezeAgreement | null {
    // The verifier returns detached data; callers never receive the retained snapshot.
    if (!this.approved) return null;
    const checked = verifyLobbyFreezeAgreement(this.approved);
    return checked.ok ? checked.value : null;
  }

  game(): OnlineGame | null {
    return this.activeGame;
  }

  subscribe(listener: () => void): Unsubscribe {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  begin(): Result<void> {
    if (!this.options.lobby)
      return failure('online-start-resume', 'A saved game cannot start a new lobby ceremony');
    if (this.closed || this.approved || this.current)
      return failure('online-start-active', 'An online start is already active');
    const bytes = new Uint8Array(32);
    globalThis.crypto.getRandomValues(bytes);
    return this.options.lobby.start(toBase64Url(bytes));
  }

  /** Retry this exact attempt after storage or writer contention, never a new freeze. */
  async retryFailed(): Promise<Result<void>> {
    if (
      this.closed ||
      this.revoked ||
      this.activeGame ||
      this.work ||
      this.current?.phase !== 'error'
    )
      return failure('online-start-retry', 'There is no failed start ready to retry');
    if (this.ceremony && !this.ceremony.result()) {
      this.ceremony.dispose();
      await this.ceremony.flush();
      this.ceremony = null;
    }
    if (this.closed) return failure('online-start-closed', 'The room is closed');
    this.activationAttempted = false;
    this.update({
      phase: 'frozen',
      awaitingSeats: [],
      locallyConsented: this.current.locallyConsented,
      error: null,
      gameId: this.current.gameId,
    });
    this.observe();
    return success(undefined);
  }

  /** Closing stops output immediately, then drains writes before the room releases its lock. */
  close(): Promise<void> {
    if (this.closing) return this.closing;
    this.closed = true;
    this.abort.abort();
    if (this.retry !== null) this.options.clock.clearTimeout(this.retry);
    this.retry = null;
    for (const unsubscribe of this.unsubscribers) unsubscribe();
    this.ceremony?.dispose();
    this.listeners.clear();
    this.closing = Promise.resolve().then(() => this.releaseResources());
    return this.closing;
  }

  private async releaseResources(): Promise<void> {
    try {
      await this.work;
      await this.ceremony?.flush();
      await this.stoppingGame;
      await this.activeGame?.close();
    } finally {
      this.material?.dispose();
      this.material = null;
    }
  }

  private update(value: OnlineStartupSnapshot): void {
    if (this.closed) return;
    this.current = value;
    for (const listener of this.listeners) {
      try {
        listener();
      } catch {
        /* A view cannot interrupt the durable start. */
      }
    }
  }

  private fail(error: unknown): void {
    if (this.revoked) return;
    if (error instanceof OnlineGameDisclosureError) {
      this.haltDisputedGame();
      return;
    }
    this.update({
      phase: 'error',
      awaitingSeats: [],
      locallyConsented: this.ceremony?.snapshot().locallyConsented ?? Boolean(this.resume),
      error: error instanceof Error ? error.message : 'Online startup failed',
      gameId: this.resume?.gameId ?? this.current?.gameId ?? null,
    });
  }

  private observe(): void {
    if (
      this.closed ||
      this.revoked ||
      this.work ||
      this.activeGame ||
      this.current?.phase === 'error'
    )
      return;
    this.work = Promise.resolve()
      .then(() => this.advance())
      .catch((error: unknown) => this.fail(error))
      .finally(() => {
        this.work = null;
        if (this.closed || this.revoked || this.activeGame || this.current?.phase === 'error')
          return;
        if (this.retry === null) {
          this.retry = this.options.clock.setTimeout(() => {
            this.retry = null;
            this.observe();
          }, 1_000);
        }
      });
  }

  private async advance(): Promise<void> {
    if (this.closed || this.revoked) return;
    if (!this.approved) {
      const lobby = this.options.lobby;
      if (!lobby) throw new Error('Saved game has no verified freeze agreement');
      const state = lobby.state();
      if (!state || state.status !== 'starting') return;
      if (
        !state.seats.some(
          (seat) => seat.kind === 'human' && seat.peer === this.options.identity.peerId,
        )
      )
        return;
      this.update({
        phase: 'freezing',
        awaitingSeats: [],
        locallyConsented: false,
        error: null,
        gameId: null,
      });
      const freezeHash = toHex(hashValue(state));
      await this.pin(`online-freeze/${this.options.identity.peerId}/${state.ceremonyNonce}`, {
        protocol: 'online-freeze-pin-v1',
        freezeHash,
      });
      if (this.closed) return;
      const current = lobby.state();
      if (!current || toHex(hashValue(current)) !== freezeHash) return;
      // Exact ACK retries also let the host retransmit a dropped all-human agreement.
      const acknowledged = lobby.ackFreeze();
      if (!acknowledged.ok) return;
      const agreement = lobby.freezeAgreement();
      if (!agreement) return;
      const checked = verifyLobbyFreezeAgreement(agreement);
      if (!checked.ok) throw new Error(checked.error.message);
      const approved = checked.value;
      if (toHex(hashValue(approved.state)) !== freezeHash)
        throw new Error('Lobby changed after the locally pinned freeze');
      await this.pin(`online-start/${freezeHash}/agreement`, {
        protocol: 'online-browser-start-v1',
        invite: this.invite,
        agreement: approved,
      });
      if (this.closed) return;
      const freezePeers = this.options.freezePeers;
      if (!freezePeers) throw new Error('Fresh online start has no roster freeze');
      freezePeers(
        approved.state.seats.flatMap((seat) => (seat.kind === 'human' ? [seat.peer] : [])),
      );
      this.approved = approved;
    }
    if (this.resume && !this.ceremony) {
      const active = await loadActiveOnlineResume({
        store: this.options.store,
        record: this.resume,
        devicePeer: this.options.identity.peerId,
        engine: this.options.engine,
        includeMaterial: true,
        ...(this.options.gameRuntime?.createJournal
          ? { createJournal: this.options.gameRuntime.createJournal }
          : {}),
      });
      if (this.closed) {
        active.material?.dispose();
        return;
      }
      const original = this.resume.result.genesis.seats.some(
        (seat) =>
          seat.seat === active.humanSeat &&
          seat.kind === 'human' &&
          seat.publicKey === active.gamePeer &&
          this.approved?.state.seats.some(
            (frozen) =>
              frozen.seat === seat.seat &&
              frozen.kind === 'human' &&
              frozen.peer === this.options.identity.peerId,
          ),
      );
      if (!original) {
        if (!active.material) throw new Error('Transferred device has no active owned binding');
        this.material?.dispose();
        this.material = active.material;
        await this.openTransferredResume();
        return;
      }
      active.material?.dispose();
    }
    if (!this.ceremony) {
      const approved = this.approved;
      if (!this.resume && this.options.approved) {
        const freezeHash = toHex(hashValue(approved.state));
        await this.requirePin(
          `online-freeze/${this.options.identity.peerId}/${approved.state.ceremonyNonce}`,
          { protocol: 'online-freeze-pin-v1', freezeHash },
        );
        await this.pin(`online-start/${freezeHash}/agreement`, {
          protocol: 'online-browser-start-v1',
          invite: this.invite,
          agreement: approved,
        });
      }
      if (this.resume) {
        const freezeHash = toHex(hashValue(approved.state));
        await this.requirePin(
          `online-freeze/${this.options.identity.peerId}/${approved.state.ceremonyNonce}`,
          {
            protocol: 'online-freeze-pin-v1',
            freezeHash,
          },
        );
        await this.requirePin(`online-start/${freezeHash}/agreement`, {
          protocol: 'online-browser-start-v1',
          invite: this.invite,
          agreement: approved,
        });
        await this.requirePin(`online-game/${this.resume.genesisDigest}/start`, {
          protocol: 'online-browser-game-v1',
          invite: this.invite,
          agreement: approved,
          result: this.resume.result,
        });
      }
      const nonce = approved.state.ceremonyNonce;
      if (!nonce) throw new Error('Frozen lobby has no ceremony nonce');
      const layout = approved.state.seats.map((seat) => {
        if (seat.kind === 'open') throw new Error('Frozen lobby still contains an open seat');
        return seat.kind === 'human'
          ? { seat: seat.seat, kind: seat.kind, devicePeerId: seat.peer }
          : { seat: seat.seat, kind: seat.kind, botHost: seat.botHost };
      });
      this.material?.dispose();
      this.material = null;
      const materialInput = {
        store: this.options.store,
        identity: this.options.identity,
        ceremonyNonce: fromBase64Url(nonce),
        layout,
      };
      this.material = this.resume
        ? await loadCeremonyMaterial(materialInput)
        : await prepareCeremonyMaterial(materialInput);
      if (this.closed) return;
      const created = OnlineCeremony.create({
        agreement: approved,
        transport: this.options.transport,
        clock: this.options.clock,
        deviceSigningKey: this.options.identity.secretKey,
        ownedSeats: this.material.keys,
        store: this.options.store,
        engine: this.options.engine,
        ...(this.resume ? { restoreResult: this.resume.result } : {}),
        ...(!this.resume && approved.state.hostPeer === this.options.identity.peerId
          ? { hostCreatedAt: Math.floor(this.options.clock.now()) }
          : {}),
      });
      if (!created.ok) throw new Error(created.error.message);
      this.ceremony = created.value;
      this.unsubscribers.push(
        this.ceremony.onChange((progress) => {
          if (progress.locallyConsented && progress.error === 'online-ceremony-disputed') {
            this.haltDisputedGame();
            return;
          }
          if (this.revoked) return;
          if (this.activeGame || this.activationAttempted) return;
          this.update({
            ...progress,
            phase:
              progress.locallyConsented && progress.phase === 'consent'
                ? 'waiting'
                : progress.phase,
            gameId: this.resume?.gameId ?? null,
          });
          this.observe();
        }),
      );
      const started = await this.ceremony.start();
      if (!started.ok) {
        // The coordinator emits this only after reading or persisting retirement.
        // Preserve that durable disposition instead of offering a generic retry.
        const progress = this.ceremony.snapshot();
        if (progress.phase === 'retired') {
          this.update({ ...progress, gameId: this.resume?.gameId ?? null });
          return;
        }
        throw new Error(started.error.message);
      }
      await this.ceremony.flush();
    }
    const result = this.ceremony.result();
    if (this.closed || this.revoked || !result || this.activationAttempted) return;
    if (this.resume && !sameBytes(canonicalEncode(result), canonicalEncode(this.resume.result)))
      throw new Error('Restored ceremony differs from the saved certified game');
    if (!this.material) throw new Error('Owned game material is unavailable');
    this.activationAttempted = true;
    this.update({
      phase: 'opening',
      awaitingSeats: [],
      locallyConsented: true,
      error: null,
      gameId: result.genesis.gameId,
    });
    if (!this.resume)
      await saveOnlineGameRecord(this.options.store, {
        invite: this.invite,
        agreement: this.approved,
        result,
      });
    if (this.closed || this.revoked) return;
    const game = await openOnlineGame(
      {
        ...result,
        agreement: this.approved,
        material: this.material.keys,
        deviceTransport: this.options.transport,
        store: this.options.store,
        clock: this.options.clock,
        engine: this.options.engine,
        signal: this.abort.signal,
        ...(this.options.onGameFatal ? { onFatal: this.options.onGameFatal } : {}),
        ...(this.options.onDeviceRoutes ? { onDeviceRoutes: this.options.onDeviceRoutes } : {}),
        ...(this.resume ? { journalMode: 'restore-only' as const } : {}),
      },
      this.options.gameRuntime,
    );
    if (this.closed || this.revoked) {
      await game.close();
      return;
    }
    this.activeGame = game;
    this.material.dispose();
    this.material = null;
    this.update({
      phase: 'playing',
      awaitingSeats: [],
      locallyConsented: true,
      error: null,
      gameId: game.gameId,
    });
  }

  private async openTransferredResume(): Promise<void> {
    const resume = this.resume;
    const material = this.material;
    const agreement = this.approved;
    if (!resume || !material || !agreement || this.closed || this.revoked)
      throw new Error('Transferred resume is incomplete');
    this.activationAttempted = true;
    this.update({
      phase: 'opening',
      awaitingSeats: [],
      locallyConsented: true,
      error: null,
      gameId: resume.gameId,
    });
    const game = await openOnlineGame(
      {
        ...resume.result,
        agreement,
        material: material.keys,
        deviceTransport: this.options.transport,
        store: this.options.store,
        clock: this.options.clock,
        engine: this.options.engine,
        signal: this.abort.signal,
        journalMode: 'restore-only',
        ...(this.options.onGameFatal ? { onFatal: this.options.onGameFatal } : {}),
        ...(this.options.onDeviceRoutes ? { onDeviceRoutes: this.options.onDeviceRoutes } : {}),
      },
      this.options.gameRuntime,
    ).finally(() => {
      material.dispose();
      if (this.material === material) this.material = null;
    });
    if (this.closed || this.revoked) {
      await game.close();
      return;
    }
    this.activeGame = game;
    this.update({
      phase: 'playing',
      awaitingSeats: [],
      locallyConsented: true,
      error: null,
      gameId: resume.gameId,
    });
  }

  private haltDisputedGame(): void {
    if (this.closed || this.revoked) return;
    this.revoked = true;
    // The coordinator has authenticated a secret disclosure, including after genesis.
    // Stop game output synchronously; preserve its public board and durable evidence.
    this.abort.abort();
    this.activeGame?.session.dispose();
    this.stoppingGame = this.activeGame?.close() ?? null;
    // close() will surface cleanup errors to the room owner after draining its work.
    void this.stoppingGame?.catch(() => undefined);
    if (this.retry !== null) this.options.clock.clearTimeout(this.retry);
    this.retry = null;
    this.update({
      phase: 'halted',
      awaitingSeats: [],
      locallyConsented: true,
      error: 'online-ceremony-disputed',
      gameId: this.activeGame?.gameId ?? this.current?.gameId ?? null,
    });
  }

  private async pin(id: string, value: unknown): Promise<void> {
    const bytes = canonicalEncode(value);
    const stored = this.options.store;
    await stored.withCeremonyLock(id, async () => {
      if (await stored.putIfAbsent(id, bytes)) return;
      const existing = await stored.load(id);
      if (
        !existing ||
        existing.length !== bytes.length ||
        existing.some((byte, index) => byte !== bytes[index])
      )
        throw new Error('Stored online start differs from the approved game');
    });
  }

  private async requirePin(id: string, value: unknown): Promise<void> {
    const bytes = canonicalEncode(value);
    const existing = await this.options.store.load(id);
    if (!existing || !sameBytes(existing, bytes))
      throw new Error('Saved online consent or game record is missing or differs');
  }
}

/** The worker durably pins the exact lobby state before the device signs its freeze ACK. */
export async function pinOnlineFreeze(
  store: EscrowCeremonyStore,
  self: string,
  supplied: LobbyState,
): Promise<string> {
  const state = copyEvidence(supplied);
  if (
    state.status !== 'starting' ||
    !state.ceremonyNonce ||
    !state.seats.some((seat) => seat.kind === 'human' && seat.peer === self)
  )
    throw new Error('Only a seated human can pin a starting lobby');
  const freezeHash = toHex(hashValue(state));
  const id = `online-freeze/${self}/${state.ceremonyNonce}`;
  const bytes = canonicalEncode({ protocol: 'online-freeze-pin-v1', freezeHash });
  await store.withCeremonyLock(id, async () => {
    if (await store.putIfAbsent(id, bytes)) return;
    const existing = await store.load(id);
    if (!existing || !sameBytes(existing, bytes))
      throw new Error('Stored online freeze differs from this lobby state');
  });
  return freezeHash;
}

function sameBytes(left: Uint8Array, right: Uint8Array): boolean {
  return left.length === right.length && left.every((byte, index) => byte === right[index]);
}

function copyEvidence<T>(value: T): T {
  // oxlint-disable-next-line typescript/no-unsafe-type-assertion -- Canonical data is detached and checked before use.
  return canonicalDecode(canonicalEncode(value)) as T;
}


### apps/web/src/session/online-resume-binding.test.ts
import { canonicalEncode, hashValue, toHex } from '@cp2p/codec';
import {
  G,
  decodePoint,
  parsePeerId,
  proveDleq,
  verifyDleq,
  verifyObject,
  encodePoint,
  identityFromSecret,
  scalePoint,
  scalarToBytes,
  signObject,
} from '@cp2p/crypto';
import { createBaseEngine } from '@cp2p/engine';
import {
  createConsensusState,
  createStealSecretSource,
  validateGenesisEscrow,
  genesisDigest,
  MemoryProtocolJournal,
  P2PSession,
  validateGenesisOnlineStart,
} from '@cp2p/protocol';
import {
  TRANSFER_DESTINATION_CHECK_DOMAIN,
  TRANSFER_DEVICE_DOMAIN,
  TRANSFER_GAME_KEY_DOMAIN,
  TRANSFER_OWNER_GAME_DOMAIN,
  advanceRecoveryFixture,
  escrowShareEnvelopeHash,
  certifyRecoveryFixtureEntry,
  createMemnet,
  createRecoveryFixture,
  MemoryEscrowLifecycleStore,
  recoveryFixtureKey,
  signRecoveryFixtureEntry,
  transferCheckDigest,
  transferEntryRef,
} from '@cp2p/protocol/testing';
import { expect, test, vi } from 'vitest';
import type { SavedOnlineGameRecord } from './online-game-records.js';
import { loadActiveOnlineResume } from './online-resume-binding.js';
import { OnlineStartup } from './online-startup.js';

function required<T>(value: T | null | undefined): T {
  if (value === null || value === undefined) throw new Error('Missing certified resume fixture');
  return value;
}

test.each(['clean', 'disclosed', 'during-open', 'malformed', 'foreign'] as const)(
  'certified transferred resume with %s retained evidence',
  async (evidence) => {
    const fixture = createRecoveryFixture({ masterBackedBeacon: true });
    const start = validateGenesisOnlineStart(fixture.genesis);
    if (!start.ok) throw new Error(start.error.message);
    const old = required(fixture.ready.log.authority?.controllers.find(({ seat }) => seat === 0));
    const destination = identityFromSecret(new Uint8Array(32).fill(111));
    const game = identityFromSecret(new Uint8Array(32).fill(112));
    const statement = {
      protocol: 'seat-transfer-v1' as const,
      genesisDigest: genesisDigest(fixture.genesis),
      anchor: transferEntryRef(fixture.ready.log.head),
      validUntilSeq: fixture.ready.log.head.seq + 64,
      mode: 'live' as const,
      seat: 0 as const,
      currentController: {
        publicKey: old.publicKey,
        kind: old.kind,
        activatedAt: old.activatedAt,
        hostSeat: old.hostSeat,
      },
      recovery: null,
      nextEpoch: 1,
      destination: {
        devicePeer: destination.peerId,
        gamePeer: game.peerId,
        transferEncryptionKey: encodePoint(scalePoint(G, 147n)),
      },
      replacements: [
        {
          seat: 0 as const,
          oldPublicKey: old.publicKey,
          newPublicKey: game.peerId,
          newHostSeat: 0 as const,
        },
      ],
    };
    const authorization = {
      kind: 'transfer-authorize' as const,
      statement,
      destinationDeviceSig: signObject(TRANSFER_DEVICE_DOMAIN, statement, destination.secretKey),
      destinationGameSig: signObject(TRANSFER_GAME_KEY_DOMAIN, statement, game.secretKey),
      replacementKeySigs: [],
      ownerIntent: {
        signer: 'current-game' as const,
        sig: signObject(TRANSFER_OWNER_GAME_DOMAIN, statement, recoveryFixtureKey(fixture, 0)),
      },
    };
    const authorizedEntry = signRecoveryFixtureEntry(
      fixture,
      fixture.ready,
      { kind: 'membership', change: authorization },
      fixture.ready.log.head.stateHash,
    );
    const authorizedCertificate = certifyRecoveryFixtureEntry(
      fixture,
      fixture.ready,
      authorizedEntry,
      [0, 1, 2, 3],
    );
    const authorized = advanceRecoveryFixture(fixture.ready, authorizedCertificate);
    const activationStatement = {
      protocol: 'seat-transfer-activation-v1' as const,
      genesisDigest: statement.genesisDigest,
      authorization: transferEntryRef(authorizedEntry),
      parent: transferEntryRef(authorized.log.head),
      nextEpoch: 1,
      destinationDevice: destination.peerId,
      destinationGame: game.peerId,
      replacements: statement.replacements,
      checkDigest: transferCheckDigest(authorized.log, transferEntryRef(authorizedEntry)),
    };
    const activationEntry = signRecoveryFixtureEntry(
      fixture,
      authorized,
      {
        kind: 'membership',
        change: {
          kind: 'transfer-activate',
          statement: activationStatement,
          destinationCheck: signObject(
            TRANSFER_DESTINATION_CHECK_DOMAIN,
            activationStatement,
            game.secretKey,
          ),
          replacementChecks: [],
        },
      },
      authorized.log.head.stateHash,
    );
    const activation = certifyRecoveryFixtureEntry(
      fixture,
      authorized,
      activationEntry,
      [0, 1, 2, 3],
    );
    const activated = advanceRecoveryFixture(authorized, activation);
    const safety = createConsensusState(activated, 0);
    if (!safety.ok) throw new Error(safety.error.message);
    const journal = new MemoryProtocolJournal();
    expect(await journal.initialize(fixture.genesisEntry, Uint8Array.of(1))).toBe(true);
    for (const certified of [...fixture.deckEntries, authorizedCertificate, activation]) {
      // oxlint-disable-next-line no-await-in-loop -- Preserve the certified ancestry in this fixture.
      const committed = await journal.commit(
        certified.entry.seq,
        0,
        certified,
        certified === activation ? canonicalEncode(safety.value) : Uint8Array.of(1),
      );
      expect(committed).toBe(true);
    }
    const record: SavedOnlineGameRecord = {
      gameId: fixture.genesis.gameId,
      genesisDigest: statement.genesisDigest,
      invite: {
        roomId: start.value.bindings.agreement.state.lobbyId,
        hostPeer: start.value.bindings.agreement.state.hostPeer,
        serverUrl: '',
      },
      agreement: start.value.bindings.agreement,
      result: {
        entry: fixture.genesisEntry,
        genesis: fixture.genesis,
        transcripts: fixture.deck.transcripts,
        bindings: start.value.bindings.bindings,
      },
    };
    const binding = canonicalEncode({
      protocol: 'online-game-keys-v1',
      genesisDigest: statement.genesisDigest,
      devicePeer: destination.peerId,
      humanSeat: 0,
      seats: [
        {
          seat: 0,
          kind: 'human',
          peerId: game.peerId,
          signingKey: game.secretKey,
          master: scalarToBytes(17n),
        },
      ],
    });
    const store = {
      load: async (key: string) =>
        key === `online-game/${statement.genesisDigest}/keys` ? binding.slice() : null,
    };
    const createJournal = () => Object.assign(journal, { close: async () => undefined });
    const common = { store, record, engine: createBaseEngine(), createJournal };
    const publicView = await loadActiveOnlineResume({
      ...common,
      devicePeer: destination.peerId,
    });
    expect(publicView.gamePeer).toBe(game.peerId);
    expect(publicView.material).toBeNull();
    expect(publicView.peers).toContain(destination.peerId);
    const withMaterial = await loadActiveOnlineResume({
      ...common,
      devicePeer: destination.peerId,
      includeMaterial: true,
    });
    expect(withMaterial.material?.keys[0]?.peerId).toBe(game.peerId);
    withMaterial.material?.dispose();
    expect(withMaterial.material?.keys[0]?.master).toEqual(new Uint8Array(32));
    const oldDevice = required(
      start.value.bindings.agreement.state.seats.find(
        (seat) => seat.seat === 0 && seat.kind === 'human',
      ),
    );
    if (oldDevice.kind !== 'human') throw new Error('Missing original device');
    await expect(
      loadActiveOnlineResume({
        ...common,
        devicePeer: oldDevice.peer,
      }),
    ).rejects.toThrow(/binding differs/);
    const forged = new MemoryProtocolJournal();
    expect(await forged.initialize(fixture.genesisEntry, Uint8Array.of(1))).toBe(true);
    for (const certified of fixture.deckEntries) {
      // oxlint-disable-next-line no-await-in-loop -- Build the older certified parent only.
      expect(await forged.commit(certified.entry.seq, 0, certified, Uint8Array.of(1))).toBe(true);
    }
    await expect(
      loadActiveOnlineResume({
        ...common,
        devicePeer: destination.peerId,
        createJournal: () => Object.assign(forged, { close: async () => undefined }),
      }),
    ).rejects.toThrow(/certified active generation/);

    const durable = new MemoryEscrowLifecycleStore();
    expect(await durable.putIfAbsent(`online-game/${statement.genesisDigest}/keys`, binding)).toBe(
      true,
    );
    // oxlint-disable vitest/no-conditional-expect -- Only the disclosed parameter constructs and verifies this authenticated witness.
    let disclosureRecord: { key: string; bytes: Uint8Array } | null = null;
    if (evidence !== 'clean') {
      const escrow = validateGenesisEscrow(fixture.genesis);
      if (!escrow.ok) throw new Error(escrow.error.message);
      const envelope = required(required(escrow.value[0]).shares[0]).envelope;
      const holderSeat = envelope.body.holder.seat;
      const holderGame = required(fixture.source.identities.get(holderSeat));
      const holderDevice = identityFromSecret(
        hashValue({ domain: 'cp2p/test/online-device/v1', gamePeer: holderGame.peerId }),
      );
      const frozenHolder = required(
        record.agreement.state.seats.find((seat) => seat.seat === holderSeat),
      );
      if (frozenHolder.kind !== 'human') throw new Error('Expected frozen holder');
      expect(holderDevice.peerId).toBe(frozenHolder.peer);
      const source = createStealSecretSource(
        scalarToBytes(BigInt(17 + holderSeat)),
        fixture.genesis.ceremonyNonce,
        holderSeat,
        holderGame.peerId,
      );
      const secret = source.encryptionSecret();
      source.dispose();
      const context = {
        protocol: 'escrow-share-dispute-v1' as const,
        ceremonyId: envelope.body.ceremonyId,
        dealerSeat: envelope.body.dealer.seat,
        holderSeat,
        envelopeHash: escrowShareEnvelopeHash(envelope),
      };
      const sharedPoint = encodePoint(
        scalePoint(decodePoint(envelope.body.sealed.ephemeral), secret),
      );
      const dleqStatement = {
        base1: encodePoint(G),
        point1: envelope.body.holder.encryptionKey,
        base2: envelope.body.sealed.ephemeral,
        point2: sharedPoint,
      };
      const proof = proveDleq(dleqStatement, secret, new Uint8Array(32).fill(99), context);
      expect(verifyDleq(dleqStatement, proof, context)).toBe(true);
      const body = { ...context, sharedPoint, proof };
      const dispute = { body, sig: signObject('escrow-share-dispute', body, holderGame.secretKey) };
      expect(
        verifyObject('escrow-share-dispute', body, dispute.sig, parsePeerId(holderGame.peerId)),
      ).toBe(true);
      const freezeHash = toHex(hashValue(record.agreement.state));
      const ceremonyNonce = required(record.agreement.state.ceremonyNonce);
      const packetBody = {
        protocol: 'online-ceremony-v1' as const,
        freezeHash,
        ceremonyNonce,
        senderDevice: holderDevice.peerId,
        kind: 'escrow-dispute' as const,
        seat: holderSeat,
        step: envelope.body.dealer.seat,
        payload: { envelope, dispute },
      };
      const packet = {
        body: packetBody,
        sig: signObject('online-ceremony-message-v1', packetBody, holderDevice.secretKey),
      };
      expect(
        verifyObject(
          'online-ceremony-message-v1',
          packetBody,
          packet.sig,
          parsePeerId(frozenHolder.peer),
        ),
      ).toBe(true);
      const attempt = toHex(
        hashValue({ domain: 'cp2p/v1/online-attempt', freezeHash, nonce: ceremonyNonce }),
      );
      const foreignBody = {
        ...packetBody,
        ceremonyNonce: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
      };
      const retained =
        evidence === 'foreign'
          ? {
              body: foreignBody,
              sig: signObject('online-ceremony-message-v1', foreignBody, holderDevice.secretKey),
            }
          : packet;
      disclosureRecord = {
        key: `online-ceremony/${attempt}/escrow-dispute/${holderSeat}/${envelope.body.dealer.seat}`,
        bytes: evidence === 'malformed' ? Uint8Array.of(1) : canonicalEncode(retained),
      };
      if (evidence !== 'during-open')
        expect(await durable.putIfAbsent(disclosureRecord.key, disclosureRecord.bytes)).toBe(true);
      holderDevice.secretKey.fill(0);
    }
    // oxlint-enable vitest/no-conditional-expect
    const net = createMemnet({
      peers: [
        ...start.value.bindings.agreement.state.seats.flatMap((seat) =>
          seat.kind === 'human' ? [seat.peer] : [],
        ),
        destination.peerId,
      ],
    });
    let injected = false;
    const actualRestore = P2PSession.restore.bind(P2PSession);
    const restore = vi.spyOn(P2PSession, 'restore').mockImplementation(async (options) => {
      const opened = await actualRestore(options);
      if (evidence === 'during-open' && !injected) {
        injected = true;
        const retained = required(disclosureRecord);
        await durable.putIfAbsent(retained.key, retained.bytes);
      }
      return opened;
    });
    const actualTransport = net.transport(destination.peerId);
    const output = vi.fn<(to: string, bytes: Uint8Array) => void>((to, bytes) =>
      actualTransport.send(to, bytes),
    );
    const observedTransport = {
      self: actualTransport.self,
      peers: () => actualTransport.peers(),
      send: output,
      broadcast: (bytes: Uint8Array) => {
        for (const peer of actualTransport.peers()) output(peer, bytes);
      },
      onMessage: actualTransport.onMessage.bind(actualTransport),
      onPeerChange: actualTransport.onPeerChange.bind(actualTransport),
      disconnect: actualTransport.disconnect.bind(actualTransport),
    };
    const startup = new OnlineStartup({
      resume: record,
      invite: record.invite,
      identity: { ...destination, dispose: () => undefined },
      transport: observedTransport,
      store: durable,
      clock: net.clock,
      engine: fixture.source.engine,
      gameRuntime: {
        acquireLease: async () => ({
          lockName: 'transferred-resume-test',
          run: async <T>(task: () => T | PromiseLike<T>): Promise<T> => task(),
          close: async () => undefined,
        }),
        createJournal,
      },
    });
    try {
      for (let step = 0; step < 200 && startup.snapshot()?.phase !== 'playing'; step++) {
        // oxlint-disable-next-line no-await-in-loop -- Let the real certified restore yield.
        await new Promise((resolve) => setTimeout(resolve, 0));
      }
      expect(startup.snapshot()).toMatchObject({
        phase: evidence === 'disclosed' || evidence === 'during-open' ? 'halted' : 'playing',
        gameId: record.gameId,
      });
      if (evidence === 'disclosed' || evidence === 'during-open') {
        // oxlint-disable-next-line vitest/no-conditional-expect -- These parameters require discarded opening output.
        expect(output).not.toHaveBeenCalled();
      }
      expect(injected).toBe(evidence === 'during-open');
      expect(startup.game()?.seat).toBe(
        evidence === 'disclosed' || evidence === 'during-open' ? undefined : 0,
      );
    } finally {
      await startup.close();
      restore.mockRestore();
      net.dispose();
    }
  },
  30_000,
);


### packages/protocol/src/online-ceremony-wire.ts
import { canonicalDecode, canonicalEncode, hashValue, toHex } from '@cp2p/codec';
import { parsePeerId, signObject, verifyObject } from '@cp2p/crypto';
import { failure, success } from '@cp2p/engine';
import type { Result, Seat } from '@cp2p/engine';
import * as v from 'valibot';
import { hashSchema, key32Schema, seatSchema, signature64Schema } from './schema-values.js';
import type { PeerId } from './transport.js';
import { parseCanonical, MAX_MESSAGE_BYTES } from './validation.js';

export const ONLINE_CEREMONY_PROTOCOL = 'online-ceremony-v1';
export const ONLINE_CEREMONY_DOMAIN = 'online-ceremony-message-v1';

export const onlineCeremonyKindSchema = v.picklist([
  'created-at',
  'binding',
  'approval',
  'escrow-envelope',
  'escrow-accepted',
  'escrow-dispute',
  'escrow-invalid',
  'beacon-tip',
  'seed-commit',
  'seed-reveal',
  'deck-pass',
  'consent',
  'genesis-entry',
] as const);

export type OnlineCeremonyKind = v.InferOutput<typeof onlineCeremonyKindSchema>;

export const onlineCeremonyPacketSchema = v.strictObject({
  body: v.strictObject({
    protocol: v.literal(ONLINE_CEREMONY_PROTOCOL),
    freezeHash: hashSchema,
    ceremonyNonce: key32Schema,
    senderDevice: key32Schema,
    kind: onlineCeremonyKindSchema,
    seat: seatSchema,
    step: v.pipe(v.number(), v.integer(), v.minValue(0), v.maxValue(64)),
    payload: v.unknown(),
  }),
  sig: signature64Schema,
});

export type OnlineCeremonyPacket = v.InferOutput<typeof onlineCeremonyPacketSchema>;

export function onlineCeremonySlot(kind: OnlineCeremonyKind, seat: Seat, step: number): string {
  return `${kind}/${seat}/${step}`;
}

export function onlineCeremonyAttemptId(freezeHash: string, nonce: string): string {
  return toHex(hashValue({ domain: 'cp2p/v1/online-attempt', freezeHash, nonce }));
}

export function signOnlineCeremonyPacket(
  body: OnlineCeremonyPacket['body'],
  signingKey: Uint8Array,
): Result<{ packet: OnlineCeremonyPacket; bytes: Uint8Array }> {
  const parsed = parseCanonical(body, onlineCeremonyPacketSchema.entries.body);
  if (!parsed.ok) return parsed;
  try {
    const packet = {
      body: parsed.value,
      sig: signObject(ONLINE_CEREMONY_DOMAIN, parsed.value, signingKey),
    };
    const bytes = canonicalEncode(packet);
    return bytes.byteLength <= MAX_MESSAGE_BYTES
      ? success({ packet, bytes })
      : failure('online-ceremony-size', 'Ceremony packet exceeds the wire limit');
  } catch {
    return failure('online-ceremony-sign', 'Could not sign the ceremony packet');
  }
}

export function verifyOnlineCeremonyPacket(
  bytes: Uint8Array,
  from: PeerId,
  freezeHash: string,
  nonce: string,
): Result<OnlineCeremonyPacket> {
  if (!(bytes instanceof Uint8Array) || bytes.byteLength > MAX_MESSAGE_BYTES)
    return failure('online-ceremony-size', 'Ceremony packet exceeds the wire limit');
  try {
    const parsed = parseCanonical(canonicalDecode(bytes), onlineCeremonyPacketSchema);
    if (!parsed.ok) return parsed;
    const packet = parsed.value;
    if (
      packet.body.freezeHash !== freezeHash ||
      packet.body.ceremonyNonce !== nonce ||
      packet.body.senderDevice !== from ||
      !verifyObject(ONLINE_CEREMONY_DOMAIN, packet.body, packet.sig, parsePeerId(from))
    )
      return failure('online-ceremony-auth', 'Packet is outside the frozen authenticated attempt');
    const canonical = canonicalEncode(packet);
    if (canonical.length !== bytes.length || canonical.some((byte, index) => byte !== bytes[index]))
      return failure('online-ceremony-wire', 'Ceremony packet bytes are not canonical');
    return success(packet);
  } catch {
    return failure('online-ceremony-wire', 'Ceremony packet is malformed');
  }
}


### packages/protocol/src/escrow-dispute.ts
import {
  DERIVATION_LABELS,
  G,
  decodePoint,
  deriveBytes,
  encodePoint,
  identityFromSecret,
  openSealedWithSharedPoint,
  parsePeerId,
  proveDleq,
  scalarToBytes,
  scalePoint,
  signObject,
  verifyDleq,
  verifyObject,
} from '@cp2p/crypto';
import type { DleqProof } from '@cp2p/crypto';
import { failure, success } from '@cp2p/engine';
import type { Result, Seat } from '@cp2p/engine';
import * as v from 'valibot';
import { deckCeremonyId } from './deck-genesis.js';
import { escrowShareEnvelopeHash, verifyEscrowShareEphemeralProof } from './escrow-distribution.js';
import type { EscrowShareEnvelope } from './escrow-distribution.js';
import { escrowDeliveryContexts, readEscrowShareOpening } from './escrow-opening.js';
import { validateGenesisMasters } from './genesis-masters.js';
import { hashSchema, key32Schema, seatSchema, signature64Schema } from './schema-values.js';
import { genesisSchema } from './schemas.js';
import type { GenesisBody } from './types.js';
import { parseCanonical } from './validation.js';

const PROTOCOL = 'escrow-share-dispute-v1';

interface DisputeBinding {
  readonly protocol: typeof PROTOCOL;
  readonly ceremonyId: string;
  readonly dealerSeat: Seat;
  readonly holderSeat: Seat;
  readonly envelopeHash: string;
}

export interface EscrowShareDispute {
  readonly body: DisputeBinding & { readonly sharedPoint: string; readonly proof: DleqProof };
  readonly sig: string;
}

/** Both verdicts disclose a share, requiring ceremony abort and master retirement. */
export type EscrowDisputeVerdict =
  | { readonly kind: 'bad-share'; readonly dealerSeat: Seat; readonly dispute: EscrowShareDispute }
  | {
      readonly kind: 'false-complaint';
      readonly holderSeat: Seat;
      readonly dispute: EscrowShareDispute;
    };

const bodySchema = v.union([genesisSchema, v.omit(genesisSchema, ['gameId', 'signatures'])]);

const disputeSchema = v.strictObject({
  body: v.strictObject({
    protocol: v.literal(PROTOCOL),
    ceremonyId: key32Schema,
    dealerSeat: seatSchema,
    holderSeat: seatSchema,
    envelopeHash: hashSchema,
    sharedPoint: key32Schema,
    proof: v.strictObject({
      commitments: v.tuple([key32Schema, key32Schema]),
      response: key32Schema,
    }),
  }),
  sig: signature64Schema,
});

function checkedDelivery(
  envelope: unknown,
  genesis: GenesisBody,
  dealerSeat: Seat,
): Result<EscrowShareEnvelope> {
  const masters = validateGenesisMasters(genesis);
  if (!masters.ok) return masters;
  const master = masters.value.find((item) => item.seat === dealerSeat);
  if (!master) return failure('escrow-dispute-dealer', 'Dealer has no master commitment');
  return verifyEscrowShareEphemeralProof(envelope, genesis, dealerSeat, master.masterPub);
}

function binding(envelope: EscrowShareEnvelope): DisputeBinding {
  return {
    protocol: PROTOCOL,
    ceremonyId: envelope.body.ceremonyId,
    dealerSeat: envelope.body.dealer.seat,
    holderSeat: envelope.body.holder.seat,
    envelopeHash: escrowShareEnvelopeHash(envelope),
  };
}

function statement(envelope: EscrowShareEnvelope, sharedPoint: string) {
  return {
    base1: encodePoint(G),
    point1: envelope.body.holder.encryptionKey,
    base2: envelope.body.sealed.ephemeral,
    point2: sharedPoint,
  };
}

function openDisputed(envelope: EscrowShareEnvelope, sharedPoint: string) {
  return readEscrowShareOpening(
    openSealedWithSharedPoint(
      envelope.body.sealed,
      envelope.body.holder.encryptionKey,
      sharedPoint,
      escrowDeliveryContexts(envelope.body).seal,
    ),
    envelope.body,
  );
}

/**
 * Reveals decryption evidence only for an authenticated, demonstrably bad share.
 * Sender ephemeral-key knowledge must pass before computing a disclosed point.
 * Publication requires ceremony abort and retirement of all local dealing masters.
 */
export function createEscrowShareDispute(input: {
  readonly genesis: GenesisBody;
  readonly envelope: unknown;
  readonly dealerSeat: Seat;
  readonly holderSeat: Seat;
  readonly recipientEncryptionSecret: bigint;
  readonly holderSigningKey: Uint8Array;
}): Result<EscrowShareDispute> {
  let secretBytes: Uint8Array | undefined;
  let proofSeed: Uint8Array | undefined;
  try {
    const checked = checkedDelivery(input.envelope, input.genesis, input.dealerSeat);
    if (!checked.ok) return checked;
    const envelope = checked.value;
    const { holder } = envelope.body;
    if (
      holder.seat !== input.holderSeat ||
      encodePoint(scalePoint(G, input.recipientEncryptionSecret)) !== holder.encryptionKey
    )
      return failure('escrow-dispute-holder', 'Holder secret does not match this delivery');
    const identity = identityFromSecret(input.holderSigningKey);
    const matches = identity.peerId === holder.publicKey;
    identity.secretKey.fill(0);
    if (!matches) return failure('escrow-dispute-holder', 'Holder signing key does not match');
    const sharedPoint = encodePoint(
      scalePoint(decodePoint(envelope.body.sealed.ephemeral), input.recipientEncryptionSecret),
    );
    if (openDisputed(envelope, sharedPoint).ok)
      return failure('escrow-good-delivery', 'A valid share is not evidence against its dealer');
    const context = binding(envelope);
    secretBytes = scalarToBytes(input.recipientEncryptionSecret);
    proofSeed = deriveBytes(
      secretBytes,
      DERIVATION_LABELS.proofRandomness,
      { ...context, sharedPoint, role: 'escrow-dispute' },
      32,
    );
    const proof = proveDleq(
      statement(envelope, sharedPoint),
      input.recipientEncryptionSecret,
      proofSeed,
      context,
    );
    const body = { ...context, sharedPoint, proof };
    return success({ body, sig: signObject('escrow-share-dispute', body, input.holderSigningKey) });
  } catch {
    return failure('escrow-dispute-production', 'Could not prove an invalid escrow delivery');
  } finally {
    proofSeed?.fill(0);
    secretBytes?.fill(0);
  }
}

/** A successful verdict requires ceremony abort. Failure alone attributes no misconduct. */
export function verifyEscrowShareDispute(
  value: unknown,
  envelopeValue: unknown,
  genesis: GenesisBody,
): Result<EscrowDisputeVerdict> {
  try {
    const parsed = parseCanonical(value, disputeSchema);
    if (!parsed.ok) return parsed;
    const signed = parsed.value;
    const parsedGenesis = parseCanonical(genesis, bodySchema);
    if (!parsedGenesis.ok) return parsedGenesis;
    const frozenGenesis = parsedGenesis.value;
    const masters = validateGenesisMasters(frozenGenesis);
    if (!masters.ok) return masters;
    const holder = frozenGenesis.seats.find((seat) => seat.seat === signed.body.holderSeat);
    if (
      holder?.kind !== 'human' ||
      signed.body.ceremonyId !== deckCeremonyId(frozenGenesis) ||
      !verifyObject('escrow-share-dispute', signed.body, signed.sig, parsePeerId(holder.publicKey))
    )
      return failure('escrow-dispute-signature', 'Complaint is not signed by its ceremony holder');
    const checked = checkedDelivery(envelopeValue, frozenGenesis, signed.body.dealerSeat);
    if (!checked.ok) return checked;
    const envelope = checked.value;
    const context = binding(envelope);
    if (
      signed.body.holderSeat !== context.holderSeat ||
      signed.body.envelopeHash !== context.envelopeHash
    )
      return failure('escrow-dispute-binding', 'Complaint concerns another sealed share');
    decodePoint(signed.body.sharedPoint, { nonIdentity: true });
    if (!verifyDleq(statement(envelope, signed.body.sharedPoint), signed.body.proof, context))
      return failure('escrow-dispute-proof', 'Disclosed decryption point is not authenticated');
    if (openDisputed(envelope, signed.body.sharedPoint).ok)
      return success({ kind: 'false-complaint', holderSeat: holder.seat, dispute: signed });
    return success({ kind: 'bad-share', dealerSeat: signed.body.dealerSeat, dispute: signed });
  } catch {
    return failure('escrow-dispute', 'Escrow complaint could not be verified');
  }
}


### packages/protocol/src/genesis-escrow.ts
import { hashValue, toHex } from '@cp2p/codec';
import { failure, success } from '@cp2p/engine';
import type { Result, Seat } from '@cp2p/engine';
import * as v from 'valibot';
import { deckCeremonyId } from './deck-genesis.js';
import {
  escrowShareEnvelopeSchema,
  escrowShareEnvelopeHash,
  prepareEscrowVerifier,
} from './escrow-distribution.js';
import type { EscrowShareAck, EscrowShareEnvelope } from './escrow-distribution.js';
import { deriveEscrowRosters } from './escrow-roster.js';
import { validateGenesisMasters } from './genesis-masters.js';
import { seatSchema } from './schema-values.js';
import { genesisSchema } from './schemas.js';
import type { GenesisBody } from './types.js';
import { parseCanonical } from './validation.js';

export interface EscrowDealerCommitment {
  dealerSeat: Seat;
  shares: readonly { envelope: EscrowShareEnvelope; ack: EscrowShareAck }[];
}

const bodySchema = v.union([genesisSchema, v.omit(genesisSchema, ['gameId', 'signatures'])]);
const escrowSchema = v.pipe(
  v.array(
    v.strictObject({
      dealerSeat: seatSchema,
      shares: v.pipe(
        v.array(v.strictObject({ envelope: v.unknown(), ack: v.unknown() })),
        v.maxLength(5),
      ),
    }),
  ),
  v.maxLength(6),
);

/**
 * Verify every signed delivery and its exact holder ACK before genesis consent.
 * An ACK is evidence of holder acceptance, not a public proof of the plaintext.
 * Only authorized recovery or end-game reveal may publish the private shares.
 */
export function validateGenesisEscrow(
  value: GenesisBody,
): Result<readonly EscrowDealerCommitment[]> {
  const parsedBody = parseCanonical(value, bodySchema);
  if (!parsedBody.ok) return parsedBody;
  const genesis = parsedBody.value;
  if (genesis.security === 'stub')
    return genesis.commitments.escrow === undefined
      ? success([])
      : failure('stub-escrow', 'Stub games cannot claim escrow distribution');
  const masters = validateGenesisMasters(genesis);
  if (!masters.ok) return masters;
  const rosters = deriveEscrowRosters(genesis);
  if (!rosters.ok) return rosters;
  const parsed = parseCanonical(genesis.commitments.escrow, escrowSchema);
  if (!parsed.ok)
    return failure('genesis-escrow', 'Genesis needs an explicit bounded escrow transcript');
  const eligible = rosters.value.filter((roster) => roster.eligible);
  if (
    parsed.value.length !== eligible.length ||
    parsed.value.some((item, index) => item.dealerSeat !== eligible[index]?.dealer.seat)
  )
    return failure('genesis-escrow-roster', 'Escrow dealers differ from the original human roster');
  const ceremonyId = deckCeremonyId(genesis);
  // Reject missing holders and mixed polynomials before any signature/proof work.
  const ordered: {
    dealerSeat: Seat;
    masterPub: string;
    shares: { envelope: EscrowShareEnvelope; ack: unknown }[];
  }[] = [];
  for (const [index, roster] of eligible.entries()) {
    const item = parsed.value[index];
    const master = masters.value.find((entry) => entry.seat === roster.dealer.seat);
    if (!item || !master || item.shares.length !== roster.holders.length)
      return failure(
        'genesis-escrow-holders',
        'Every required holder must accept exactly one share',
      );
    const shares: { envelope: EscrowShareEnvelope; ack: unknown }[] = [];
    let commitmentsHash: string | null = null;
    for (const [holderIndex, holder] of roster.holders.entries()) {
      const delivery = item.shares[holderIndex];
      if (!delivery) return failure('genesis-escrow-holders', 'An escrow delivery is missing');
      const envelope = parseCanonical(delivery.envelope, escrowShareEnvelopeSchema);
      if (!envelope.ok) return envelope;
      const { body } = envelope.value;
      if (body.holder.seat !== holder.seat)
        return failure('genesis-escrow-order', 'Escrow shares must follow the exact holder order');
      if (
        body.dealer.seat !== roster.dealer.seat ||
        body.threshold !== roster.threshold ||
        body.commitments.length !== roster.threshold ||
        body.masterPub !== master.masterPub ||
        body.commitments[0] !== master.masterPub
      )
        return failure('escrow-binding', 'Escrow share differs from its frozen ceremony roster');
      const hash = toHex(hashValue(body.commitments));
      if (commitmentsHash !== null && commitmentsHash !== hash)
        return failure(
          'genesis-escrow-polynomial',
          'A dealer supplied different share polynomials',
        );
      commitmentsHash = hash;
      shares.push({ envelope: envelope.value, ack: delivery.ack });
    }
    ordered.push({ dealerSeat: roster.dealer.seat, masterPub: master.masterPub, shares });
  }
  const verifier = prepareEscrowVerifier(genesis);
  if (!verifier.ok) return verifier;
  const result: EscrowDealerCommitment[] = [];
  for (const item of ordered) {
    const shares: { envelope: EscrowShareEnvelope; ack: EscrowShareAck }[] = [];
    for (const delivery of item.shares) {
      const envelope = verifier.value.envelope(delivery.envelope, item.dealerSeat, item.masterPub);
      if (!envelope.ok) return envelope;
      const ack = verifier.value.ack(delivery.ack, {
        ceremonyId,
        dealerSeat: item.dealerSeat,
        holderSeat: envelope.value.body.holder.seat,
        expectedMasterPub: item.masterPub,
        shareHash: envelope.value.body.shareHash,
        envelopeHash: escrowShareEnvelopeHash(envelope.value),
      });
      if (!ack.ok) return ack;
      shares.push({ envelope: envelope.value, ack: ack.value });
    }
    result.push({ dealerSeat: item.dealerSeat, shares });
  }
  return success(result);
}


### packages/protocol/src/genesis-online-start.ts
import { hashValue, toHex } from '@cp2p/codec';
import { failure, success } from '@cp2p/engine';
import type { Result } from '@cp2p/engine';
import * as v from 'valibot';
import { deckCeremonyId } from './deck-genesis.js';
import { validateGenesisMasters } from './genesis-masters.js';
import { validateGenesisSeedTranscript } from './genesis-seed.js';
import type { GenesisSeedTranscript } from './genesis-seed.js';
import { verifyGameSeatBindings } from './online-bindings.js';
import type { VerifiedGameSeatBindings } from './online-bindings.js';
import type { GenesisBody } from './types.js';
import { parseCanonical } from './validation.js';

export const ONLINE_START_PROTOCOL = 'online-start-v1';

const onlineStartSchema = v.strictObject({
  protocol: v.literal(ONLINE_START_PROTOCOL),
  agreement: v.unknown(),
  bindings: v.unknown(),
  seed: v.unknown(),
});

export interface VerifiedOnlineStart {
  readonly bindings: VerifiedGameSeatBindings;
  readonly seed: GenesisSeedTranscript;
}

function sameValue(left: unknown, right: unknown): boolean {
  return toHex(hashValue(left)) === toHex(hashValue(right));
}

/** Mandatory verified-genesis evidence; callback policy cannot substitute for it. */
export function validateGenesisOnlineStart(body: GenesisBody): Result<VerifiedOnlineStart> {
  if (body.security !== 'verified')
    return failure('online-start-security', 'Only verified genesis carries online start');
  const parsed = parseCanonical(body.commitments.onlineStart, onlineStartSchema);
  if (!parsed.ok)
    return failure('online-start', 'Verified genesis needs a strict online-start transcript');
  const bindings = verifyGameSeatBindings(parsed.value.agreement, parsed.value.bindings);
  if (!bindings.ok) return bindings;
  const { agreement, genesisSeats } = bindings.value;
  if (
    !sameValue(agreement.state.config, body.config) ||
    !sameValue(agreement.state.takeover, body.takeover) ||
    !sameValue(genesisSeats, body.seats) ||
    agreement.state.ceremonyNonce !== body.ceremonyNonce
  )
    return failure('online-start-roster', 'Genesis differs from the device-approved freeze');
  const masters = validateGenesisMasters(body);
  if (!masters.ok) return masters;
  if (!sameValue(bindings.value.masters, masters.value))
    return failure('online-start-masters', 'Master commitments differ from seat bindings');
  const seed = validateGenesisSeedTranscript(
    {
      freezeHash: bindings.value.freezeHash,
      ceremonyNonce: body.ceremonyNonce,
      ceremonyId: deckCeremonyId(body),
      participants: body.seats.map(({ seat, publicKey }) => ({ seat, publicKey })),
      mode: agreement.state.seedMode,
    },
    parsed.value.seed,
  );
  if (!seed.ok) return seed;
  if (seed.value.genesisSeed !== body.genesisSeed)
    return failure('online-start-seed', 'Genesis board seed differs from the frozen transcript');
  return success({ bindings: bindings.value, seed: seed.value.transcript });
}


### packages/protocol/src/escrow-roster.ts
import { parsePeerId } from '@cp2p/crypto';
import { failure, success } from '@cp2p/engine';
import type { Result, Seat } from '@cp2p/engine';
import * as v from 'valibot';
import { genesisSchema } from './schemas.js';
import type { GenesisBody, GenesisSeat } from './types.js';
import { parseCanonical } from './validation.js';

export interface EscrowHolder {
  /** Original genesis seat; its one-based seat index is the Feldman x-coordinate. */
  readonly seat: Seat;
  readonly publicKey: string;
  readonly index: number;
}

export interface EscrowDealerRoster {
  readonly dealer: {
    readonly seat: Seat;
    readonly kind: GenesisSeat['kind'];
    readonly publicKey: string;
  };
  /** Two- and three-human games explicitly have no escrow holders. */
  readonly eligible: boolean;
  readonly threshold: number;
  readonly holders: readonly EscrowHolder[];
}

/** Derive holder sets only from the immutable original genesis roster. */
export function deriveEscrowRosters(value: unknown): Result<readonly EscrowDealerRoster[]> {
  const parsed = parseCanonical(
    value,
    v.union([genesisSchema, v.omit(genesisSchema, ['gameId', 'signatures'])]),
  );
  if (!parsed.ok) return failure('escrow-roster-genesis', 'Genesis roster is malformed');
  const genesis: GenesisBody = {
    protocolVersion: parsed.value.protocolVersion,
    engineVersion: parsed.value.engineVersion,
    config: parsed.value.config,
    seats: parsed.value.seats,
    genesisSeed: parsed.value.genesisSeed,
    ceremonyNonce: parsed.value.ceremonyNonce,
    security: parsed.value.security,
    takeover: parsed.value.takeover,
    commitments: parsed.value.commitments,
    createdAt: parsed.value.createdAt,
  };
  const humans = genesis.seats.filter((seat) => seat.kind === 'human');
  if (
    genesis.seats.length !== genesis.config.seats.length ||
    genesis.seats.some(
      (seat, index) => seat.seat !== index || genesis.config.seats[index] !== index,
    )
  )
    return failure('escrow-roster-seats', 'Genesis seats must exactly match configured seat order');
  if (new Set(genesis.seats.map((seat) => seat.publicKey)).size !== genesis.seats.length)
    return failure('escrow-roster-keys', 'Genesis seat public keys must be unique');

  const humanByKey = new Map<string, Seat>();
  try {
    for (const seat of genesis.seats) {
      parsePeerId(seat.publicKey);
      if (seat.kind === 'human') humanByKey.set(seat.publicKey, seat.seat);
    }
  } catch {
    return failure('escrow-roster-keys', 'Genesis seat identity is invalid');
  }
  for (const seat of genesis.seats) {
    if (seat.kind === 'bot' && !humanByKey.has(seat.botHost))
      return failure('escrow-roster-host', 'Every bot host must be an original human identity');
  }

  const eligible = humans.length >= 4;
  return success(
    genesis.seats.map((dealer) => {
      if (!eligible) {
        return {
          dealer: { seat: dealer.seat, kind: dealer.kind, publicKey: dealer.publicKey },
          eligible: false,
          threshold: 0,
          holders: [],
        };
      }
      const excluded = dealer.kind === 'human' ? dealer.seat : humanByKey.get(dealer.botHost);
      const holders = humans
        .filter((human) => human.seat !== excluded)
        .map((human) => ({ seat: human.seat, publicKey: human.publicKey, index: human.seat + 1 }));
      return {
        dealer: { seat: dealer.seat, kind: dealer.kind, publicKey: dealer.publicKey },
        eligible: true,
        threshold: holders.length,
        holders,
      };
    }),
  );
}


### packages/protocol/src/transport.ts
/** Ed25519 public key encoded as canonical, unpadded base64url. */
export type PeerId = string;

export type Unsubscribe = () => void;

/** Authenticated peer links. Packets may be lost while a link reconnects. */
export interface Transport {
  readonly self: PeerId;
  peers(): PeerId[];
  send(to: PeerId, message: Uint8Array): void;
  broadcast(message: Uint8Array): void;
  onMessage(listener: (from: PeerId, message: Uint8Array) => void): Unsubscribe;
  onPeerChange(listener: (peer: PeerId, online: boolean) => void): Unsubscribe;
  disconnect(peer: PeerId): void;
}

/** Injected monotonic clock; the protocol never depends on browser timers. */
export interface ProtocolClock {
  now(): number;
  setTimeout(callback: () => void, delayMs: number): unknown;
  clearTimeout(handle: unknown): void;
}


### packages/protocol/src/validation.ts
import { canonicalDecode, canonicalEncode } from '@cp2p/codec';
import { failure, success } from '@cp2p/engine';
import type { Result } from '@cp2p/engine';
import * as v from 'valibot';

export const MAX_MESSAGE_BYTES = 256 * 1024;

/** Copy and validate untrusted data before retaining any of its references. */
export function parseCanonical<T>(value: unknown, schema: v.GenericSchema<unknown, T>): Result<T> {
  try {
    const bytes = canonicalEncode(value);
    if (bytes.byteLength > MAX_MESSAGE_BYTES)
      return failure('message-too-large', 'Protocol value exceeds 256 KiB');
    const parsed = v.safeParse(schema, canonicalDecode(bytes));
    return parsed.success
      ? success(parsed.output)
      : failure('invalid-envelope', 'Protocol value does not match its schema');
  } catch {
    return failure('invalid-encoding', 'Protocol value is not canonical data');
  }
}


### packages/protocol/src/escrow-distribution.ts
import { canonicalEncode, fromBase64Url, hashValue, toBase64Url, toHex } from '@cp2p/codec';
import {
  createFeldmanShares,
  G,
  decodePoint,
  decodeScalar,
  encodePoint,
  encodeScalar,
  identityFromSecret,
  openSealed,
  parsePeerId,
  scalePoint,
  sealWithEphemeralProof,
  signObject,
  verifyObject,
  verifySealedEphemeralProof,
} from '@cp2p/crypto';
import { failure, success } from '@cp2p/engine';
import type { Result, Seat } from '@cp2p/engine';
import * as v from 'valibot';
import { deriveEscrowRosters } from './escrow-roster.js';
import { escrowDeliveryContexts, readEscrowShareOpening } from './escrow-opening.js';
import type { EscrowShareEnvelope } from './escrow-types.js';
import type { EscrowDealerRoster } from './escrow-roster.js';
import { deckCeremonyId } from './deck-genesis.js';
import { genesisSchema } from './schemas.js';
import { validateGenesisEncryption } from './genesis-encryption.js';
import { validateGenesisMasters } from './genesis-masters.js';
import type { MasterCommitment } from './genesis-masters.js';
import { hashSchema, key32Schema, seatSchema, signature64Schema } from './schema-values.js';
import type { GenesisBody } from './types.js';
import { parseCanonical } from './validation.js';

export const ESCROW_SHARE_PROTOCOL = 'escrow-share-v1';
export const ESCROW_ACK_PROTOCOL = 'escrow-share-ack-v1';

export type { EscrowShareEnvelope } from './escrow-types.js';

export interface EscrowShareAck {
  readonly body: {
    readonly protocol: typeof ESCROW_ACK_PROTOCOL;
    readonly ceremonyId: string;
    readonly dealerSeat: Seat;
    readonly holderSeat: Seat;
    readonly holderIndex: number;
    readonly masterPub: string;
    readonly shareHash: string;
    readonly envelopeHash: string;
  };
  readonly sig: string;
}

export interface AcceptedEscrowShare {
  readonly dealerSeat: Seat;
  readonly holderSeat: Seat;
  readonly index: number;
  readonly value: bigint;
  readonly shareHash: string;
  readonly ack: EscrowShareAck;
}

export const escrowShareEnvelopeSchema = v.strictObject({
  body: v.strictObject({
    protocol: v.literal(ESCROW_SHARE_PROTOCOL),
    ceremonyId: key32Schema,
    dealer: v.strictObject({ seat: seatSchema, publicKey: key32Schema }),
    holder: v.strictObject({
      seat: seatSchema,
      publicKey: key32Schema,
      index: v.pipe(v.number(), v.integer(), v.minValue(1), v.maxValue(6)),
      encryptionKey: key32Schema,
    }),
    threshold: v.pipe(v.number(), v.integer(), v.minValue(1), v.maxValue(6)),
    masterPub: key32Schema,
    commitments: v.pipe(v.array(key32Schema), v.minLength(1), v.maxLength(6)),
    shareHash: hashSchema,
    sealed: v.strictObject({
      ephemeral: key32Schema,
      ciphertext: v.pipe(v.string(), v.maxLength(512), v.regex(/^[A-Za-z0-9_-]+$/)),
    }),
    ephemeralProof: v.strictObject({ commitment: key32Schema, response: key32Schema }),
  }),
  sig: signature64Schema,
});

const ackSchema = v.strictObject({
  body: v.strictObject({
    protocol: v.literal(ESCROW_ACK_PROTOCOL),
    ceremonyId: key32Schema,
    dealerSeat: seatSchema,
    holderSeat: seatSchema,
    holderIndex: v.pipe(v.number(), v.integer(), v.minValue(1), v.maxValue(6)),
    masterPub: key32Schema,
    shareHash: hashSchema,
    envelopeHash: hashSchema,
  }),
  sig: signature64Schema,
});

function checkedVerifiedGenesis(value: unknown): Result<GenesisBody> {
  const parsed = parseCanonical(
    value,
    v.union([genesisSchema, v.omit(genesisSchema, ['gameId', 'signatures'])]),
  );
  if (!parsed.ok) return failure('escrow-genesis', 'Escrow requires a canonical genesis body');
  if (parsed.value.security !== 'verified')
    return failure('escrow-security', 'Escrow distribution is available only for verified genesis');
  const genesis: GenesisBody = {
    protocolVersion: parsed.value.protocolVersion,
    engineVersion: parsed.value.engineVersion,
    config: parsed.value.config,
    seats: parsed.value.seats,
    genesisSeed: parsed.value.genesisSeed,
    ceremonyNonce: parsed.value.ceremonyNonce,
    security: parsed.value.security,
    takeover: parsed.value.takeover,
    commitments: parsed.value.commitments,
    createdAt: parsed.value.createdAt,
  };
  const encryption = validateGenesisEncryption(genesis);
  if (!encryption.ok) return encryption;
  return success(genesis);
}

interface EscrowContext {
  readonly genesis: GenesisBody;
  readonly ceremonyId: string;
  readonly rosters: readonly EscrowDealerRoster[];
  readonly masters: readonly MasterCommitment[];
}

function checkedContext(value: unknown): Result<EscrowContext> {
  const genesis = checkedVerifiedGenesis(value);
  if (!genesis.ok) return genesis;
  const masters = validateGenesisMasters(genesis.value);
  if (!masters.ok) return masters;
  const rosters = deriveEscrowRosters(genesis.value);
  if (!rosters.ok) return rosters;
  return success({
    genesis: genesis.value,
    ceremonyId: deckCeremonyId(genesis.value),
    rosters: rosters.value,
    masters: masters.value,
  });
}

function matchesMaster(
  context: EscrowContext,
  dealerSeat: Seat,
  expectedMasterPub: string,
): boolean {
  return context.masters.some(
    (master) => master.seat === dealerSeat && master.masterPub === expectedMasterPub,
  );
}

function expectedPayloadLength(body: EscrowShareEnvelope['body']): number {
  return canonicalEncode({
    protocol: ESCROW_SHARE_PROTOCOL,
    ceremonyId: body.ceremonyId,
    dealerSeat: body.dealer.seat,
    holderSeat: body.holder.seat,
    holderIndex: body.holder.index,
    threshold: body.threshold,
    masterPub: body.masterPub,
    share: encodeScalar(0n),
  }).length;
}

function dealerRoster(rosters: readonly EscrowDealerRoster[], dealerSeat: Seat) {
  return rosters.find((roster) => roster.dealer.seat === dealerSeat);
}

/** Stable ACK binding for the exact signed, sealed delivery bytes. */
export function escrowShareEnvelopeHash(envelope: EscrowShareEnvelope): string {
  return toHex(hashValue({ domain: 'cp2p/v1/escrow-signed-envelope', envelope }));
}

function expectedHolder(roster: EscrowDealerRoster, holderSeat: Seat, genesis: GenesisBody) {
  const holder = roster.holders.find((item) => item.seat === holderSeat);
  const seat = genesis.seats.find((item) => item.seat === holderSeat);
  return holder && seat?.encryptionKey ? { holder, encryptionKey: seat.encryptionKey } : undefined;
}

function parseAndCheckEnvelope(
  value: unknown,
  context: EscrowContext,
  dealerSeat: Seat,
  expectedMasterPub: string,
): Result<{ envelope: EscrowShareEnvelope; roster: EscrowDealerRoster }> {
  const { genesis, ceremonyId } = context;
  if (!matchesMaster(context, dealerSeat, expectedMasterPub))
    return failure('escrow-master', 'Expected master differs from the genesis manifest');
  const parsed = parseCanonical(value, escrowShareEnvelopeSchema);
  if (!parsed.ok) return failure('escrow-envelope', 'Escrow share envelope is malformed');
  const envelope = parsed.value as EscrowShareEnvelope;
  const roster = dealerRoster(context.rosters, dealerSeat);
  if (!roster?.eligible)
    return failure('escrow-roster', 'Dealer or holder is not eligible in the original roster');
  const { body } = envelope;
  const recipient = expectedHolder(roster, body.holder.seat, genesis);
  if (!recipient)
    return failure('escrow-roster', 'Dealer or holder is not eligible in the original roster');
  if (
    body.ceremonyId !== ceremonyId ||
    body.dealer.seat !== dealerSeat ||
    body.dealer.publicKey !== roster.dealer.publicKey ||
    body.holder.publicKey !== recipient.holder.publicKey ||
    body.holder.index !== recipient.holder.index ||
    body.holder.encryptionKey !== recipient.encryptionKey ||
    body.threshold !== roster.threshold ||
    body.masterPub !== expectedMasterPub ||
    body.commitments.length !== roster.threshold ||
    body.commitments[0] !== expectedMasterPub
  )
    return failure('escrow-binding', 'Escrow share differs from its frozen ceremony roster');
  try {
    parsePeerId(body.dealer.publicKey);
    parsePeerId(body.holder.publicKey);
    if (!verifyObject('escrow-share', body, envelope.sig, parsePeerId(roster.dealer.publicKey)))
      return failure('escrow-signature', 'Escrow share dealer signature is invalid');
    const ciphertext = fromBase64Url(body.sealed.ciphertext);
    if (
      toBase64Url(ciphertext) !== body.sealed.ciphertext ||
      ciphertext.length !== expectedPayloadLength(body)
    )
      return failure(
        'escrow-ciphertext',
        'Escrow ciphertext is not canonical or has the wrong size',
      );
    decodePoint(expectedMasterPub, { nonIdentity: true });
    // Honest generation derives nonzero coefficients. Reject a lower-degree escrow.
    try {
      for (const commitment of body.commitments) decodePoint(commitment, { nonIdentity: true });
    } catch {
      return failure('escrow-coefficient', 'Escrow coefficients must be nonidentity group points');
    }
    decodePoint(body.holder.encryptionKey, { nonIdentity: true });
    const contexts = escrowDeliveryContexts(body);
    if (
      !verifySealedEphemeralProof(
        body.sealed,
        body.holder.encryptionKey,
        body.ephemeralProof,
        contexts.seal,
        contexts.proof,
      )
    )
      return failure(
        'escrow-ephemeral-proof',
        'Escrow sender did not prove ephemeral-key knowledge',
      );
    return success({ envelope, roster });
  } catch {
    return failure('escrow-envelope', 'Escrow share envelope cryptographic values are invalid');
  }
}

/** Create one individually signed, sealed share for every immutable roster holder. */
export function createEscrowShareEnvelopes(input: {
  readonly genesis: GenesisBody;
  readonly dealerSeat: Seat;
  readonly expectedMasterPub: string;
  readonly masterSecret: bigint;
  readonly entropy: Uint8Array;
  readonly dealerSigningKey: Uint8Array;
}): Result<readonly EscrowShareEnvelope[]> {
  let entropy: Uint8Array | undefined;
  try {
    const context = checkedContext(input.genesis);
    if (!context.ok) return context;
    const { dealerSeat, expectedMasterPub, masterSecret } = input;
    if (!matchesMaster(context.value, dealerSeat, expectedMasterPub))
      return failure('escrow-master', 'Expected master differs from the genesis manifest');
    const { genesis, ceremonyId } = context.value;
    const parsedId = parseCanonical(ceremonyId, key32Schema);
    if (!parsedId.ok) return failure('escrow-ceremony', 'Escrow ceremony identifier is invalid');
    decodePoint(expectedMasterPub, { nonIdentity: true });
    decodeScalar(encodeScalar(masterSecret));
    if (masterSecret === 0n) return failure('escrow-master', 'Master secret is invalid');
    if (encodePoint(scalePoint(G, masterSecret)) !== expectedMasterPub)
      return failure('escrow-master', 'Dealer secret differs from the checked manifest key');
    const roster = dealerRoster(context.value.rosters, dealerSeat);
    if (!roster?.eligible || roster.holders.length === 0)
      return failure('escrow-ineligible', 'This original roster has no escrow distribution');
    const dealerIdentity = identityFromSecret(input.dealerSigningKey);
    const dealerMatches = dealerIdentity.peerId === roster.dealer.publicKey;
    dealerIdentity.secretKey.fill(0);
    if (!dealerMatches)
      return failure('escrow-dealer-key', 'Dealer signing key does not match roster');
    if (
      !(input.entropy instanceof Uint8Array) ||
      input.entropy.length !== 32 ||
      input.entropy.every((byte) => byte === 0)
    )
      return failure('escrow-entropy', 'Escrow entropy must be a private nonzero 32-byte seed');
    // Retain this private entropy for retries of the same ceremony attempt. Never publish it.
    entropy = Uint8Array.from(input.entropy);
    const indices = roster.holders.map(({ index }) => index);
    const distribution = createFeldmanShares(masterSecret, indices, roster.threshold, entropy, {
      protocol: ESCROW_SHARE_PROTOCOL,
      ceremonyId,
      dealerSeat,
      dealerPublicKey: roster.dealer.publicKey,
      masterPub: expectedMasterPub,
      threshold: roster.threshold,
      holders: roster.holders,
    });
    if (distribution.commitments[0] !== expectedMasterPub)
      return failure('escrow-master', 'Master secret does not match the checked manifest key');
    const envelopes = [] as EscrowShareEnvelope[];
    for (const holder of roster.holders) {
      const recipient = expectedHolder(roster, holder.seat, genesis);
      if (!recipient) return failure('escrow-encryption-key', 'Holder encryption key is missing');
      decodePoint(recipient.encryptionKey, { nonIdentity: true });
      const share = distribution.shares.find((item) => item.index === holder.index);
      if (!share) return failure('escrow-share', 'Feldman share was not generated');
      const payload = canonicalEncode({
        protocol: ESCROW_SHARE_PROTOCOL,
        ceremonyId,
        dealerSeat,
        holderSeat: holder.seat,
        holderIndex: holder.index,
        threshold: roster.threshold,
        masterPub: expectedMasterPub,
        share: encodeScalar(share.value),
      });
      const shareHash = toHex(hashValue({ domain: 'cp2p/v1/escrow-share-payload', payload }));
      const contexts = escrowDeliveryContexts({
        protocol: ESCROW_SHARE_PROTOCOL,
        ceremonyId,
        dealer: { seat: dealerSeat, publicKey: roster.dealer.publicKey },
        holder: {
          seat: holder.seat,
          publicKey: holder.publicKey,
          index: holder.index,
          encryptionKey: recipient.encryptionKey,
        },
        threshold: roster.threshold,
        masterPub: expectedMasterPub,
        commitments: distribution.commitments,
        shareHash,
      });
      let sealed: ReturnType<typeof sealWithEphemeralProof>;
      try {
        sealed = sealWithEphemeralProof(
          payload,
          recipient.encryptionKey,
          entropy,
          contexts.seal,
          contexts.proof,
        );
      } finally {
        payload.fill(0);
      }
      const body = {
        protocol: ESCROW_SHARE_PROTOCOL,
        ceremonyId,
        dealer: { seat: dealerSeat, publicKey: roster.dealer.publicKey },
        holder: {
          seat: holder.seat,
          publicKey: holder.publicKey,
          index: holder.index,
          encryptionKey: recipient.encryptionKey,
        },
        threshold: roster.threshold,
        masterPub: expectedMasterPub,
        commitments: distribution.commitments,
        shareHash,
        sealed: sealed.sealed,
        ephemeralProof: sealed.ephemeralProof,
      } as const;
      envelopes.push({ body, sig: signObject('escrow-share', body, input.dealerSigningKey) });
    }
    return success(envelopes);
  } catch {
    return failure('escrow-create', 'Could not create the bounded escrow share distribution');
  } finally {
    entropy?.fill(0);
  }
}

/** Authenticate the envelope and ephemeral-scalar proof before opening any ciphertext. */
export function verifyEscrowShareEphemeralProof(
  value: unknown,
  genesis: GenesisBody,
  dealerSeat: Seat,
  expectedMasterPub: string,
): Result<EscrowShareEnvelope> {
  const context = checkedContext(genesis);
  if (!context.ok) return context;
  try {
    const checked = parseAndCheckEnvelope(value, context.value, dealerSeat, expectedMasterPub);
    return checked.ok ? success(checked.value.envelope) : checked;
  } catch {
    return failure('escrow-genesis', 'Escrow ceremony context is invalid');
  }
}

/** Decrypt, check the exact Feldman opening, and sign its holder acknowledgement. */
export function acceptEscrowShare(input: {
  readonly envelope: unknown;
  readonly genesis: GenesisBody;
  readonly dealerSeat: Seat;
  readonly expectedMasterPub: string;
  readonly holderSeat: Seat;
  readonly recipientEncryptionSecret: bigint;
  readonly holderSigningKey: Uint8Array;
}): Result<AcceptedEscrowShare> {
  let plaintext: Uint8Array | undefined;
  let signingSecret: Uint8Array | undefined;
  try {
    const context = checkedContext(input.genesis);
    if (!context.ok) return context;
    const { genesis } = context.value;
    const checked = parseAndCheckEnvelope(
      input.envelope,
      context.value,
      input.dealerSeat,
      input.expectedMasterPub,
    );
    if (!checked.ok) return checked;
    const { envelope, roster } = checked.value;
    const { body } = envelope;
    if (body.holder.seat !== input.holderSeat)
      return failure('escrow-holder', 'Escrow envelope is addressed to a different holder');
    const recipient = expectedHolder(roster, input.holderSeat, genesis);
    if (!recipient) return failure('escrow-holder', 'Holder is not in the immutable roster');
    const recipientPoint = encodePoint(scalePoint(G, input.recipientEncryptionSecret));
    if (recipientPoint !== body.holder.encryptionKey)
      return failure('escrow-encryption-key', 'Recipient secret does not match the roster key');
    const holderIdentity = identityFromSecret(input.holderSigningKey);
    const holderMatches = holderIdentity.peerId === body.holder.publicKey;
    holderIdentity.secretKey.fill(0);
    if (!holderMatches)
      return failure('escrow-holder-key', 'Holder signing key does not match roster');
    const contexts = escrowDeliveryContexts(body);
    plaintext = openSealed(body.sealed, input.recipientEncryptionSecret, contexts.seal);
    const share = readEscrowShareOpening(plaintext, body);
    if (!share.ok) return share;
    signingSecret = Uint8Array.from(input.holderSigningKey);
    const ackBody = {
      protocol: ESCROW_ACK_PROTOCOL,
      ceremonyId: deckCeremonyId(genesis),
      dealerSeat: input.dealerSeat,
      holderSeat: input.holderSeat,
      holderIndex: body.holder.index,
      masterPub: input.expectedMasterPub,
      shareHash: body.shareHash,
      envelopeHash: escrowShareEnvelopeHash(envelope),
    } as const;
    return success({
      dealerSeat: input.dealerSeat,
      holderSeat: input.holderSeat,
      index: body.holder.index,
      value: share.value.value,
      shareHash: body.shareHash,
      ack: { body: ackBody, sig: signObject('escrow-share-ack', ackBody, signingSecret) },
    });
  } catch {
    return failure('escrow-share-open', 'Could not open and verify the escrow share');
  } finally {
    plaintext?.fill(0);
    signingSecret?.fill(0);
  }
}

export interface ExpectedEscrowAck {
  ceremonyId: string;
  dealerSeat: Seat;
  holderSeat: Seat;
  expectedMasterPub: string;
  shareHash: string;
  envelopeHash: string;
}

function checkAck(
  value: unknown,
  context: EscrowContext,
  expected: ExpectedEscrowAck,
): Result<EscrowShareAck> {
  const parsed = parseCanonical(value, ackSchema);
  if (!parsed.ok) return failure('escrow-ack', 'Escrow acknowledgement is malformed');
  const roster = dealerRoster(context.rosters, expected.dealerSeat);
  const holder = roster?.holders.find((item) => item.seat === expected.holderSeat);
  const { body } = parsed.value;
  if (
    !roster?.eligible ||
    !holder ||
    !matchesMaster(context, expected.dealerSeat, expected.expectedMasterPub) ||
    body.protocol !== ESCROW_ACK_PROTOCOL ||
    body.ceremonyId !== expected.ceremonyId ||
    body.dealerSeat !== expected.dealerSeat ||
    body.holderSeat !== expected.holderSeat ||
    body.holderIndex !== holder.index ||
    body.masterPub !== expected.expectedMasterPub ||
    body.shareHash !== expected.shareHash ||
    body.envelopeHash !== expected.envelopeHash ||
    expected.ceremonyId !== context.ceremonyId
  )
    return failure('escrow-ack-binding', 'Escrow acknowledgement differs from expected share');
  try {
    if (!verifyObject('escrow-share-ack', body, parsed.value.sig, parsePeerId(holder.publicKey)))
      return failure('escrow-ack-signature', 'Escrow holder acknowledgement signature is invalid');
    return success(parsed.value as EscrowShareAck);
  } catch {
    return failure('escrow-ack-signature', 'Escrow holder acknowledgement signature is invalid');
  }
}

export function verifyEscrowShareAck(
  value: unknown,
  genesis: GenesisBody,
  expected: ExpectedEscrowAck,
): Result<EscrowShareAck> {
  const context = checkedContext(genesis);
  return context.ok ? checkAck(value, context.value, expected) : context;
}

/** Keep the detached checked genesis private while verifying a complete transcript. */
export function prepareEscrowVerifier(genesis: GenesisBody) {
  const context = checkedContext(genesis);
  if (!context.ok) return context;
  const checked = context.value;
  return success({
    envelope(
      value: unknown,
      dealerSeat: Seat,
      expectedMasterPub: string,
    ): Result<EscrowShareEnvelope> {
      const result = parseAndCheckEnvelope(value, checked, dealerSeat, expectedMasterPub);
      return result.ok ? success(result.value.envelope) : result;
    },
    ack(value: unknown, expected: ExpectedEscrowAck): Result<EscrowShareAck> {
      return checkAck(value, checked, expected);
    },
  });
}


### apps/web/src/session/online-game-transport.ts
import { fromBase64Url, hashValue, toHex } from '@cp2p/codec';
import { failure, success } from '@cp2p/engine';
import type { Engine, Result, Seat } from '@cp2p/engine';
import { MAX_MESSAGE_BYTES as MAX_WEBRTC_MESSAGE_BYTES } from '@cp2p/p2p';
import {
  genesisDigest,
  advanceContext,
  decodeProtocolMessage,
  encodeProtocolMessage,
  entryHash,
  MAX_MESSAGE_BYTES as MAX_PROTOCOL_MESSAGE_BYTES,
  replayCertifiedPrefix,
  validateCertifiedEntry,
  verifyGameSeatBindings,
  validateGenesisOnlineStart,
} from '@cp2p/protocol';
import type {
  LobbyFreezeAgreement,
  CertifiedEntry,
  PeerId,
  ProposalContext,
  ReplayPolicy,
  SignedGameSeatBinding,
  Transport,
  Unsubscribe,
  ValidatedGenesis,
} from '@cp2p/protocol';

const MAGIC = new Uint8Array([0x43, 0x50, 0x32, 0x47]); // CP2G
const FRAME_VERSION = 1;
const DIGEST_BYTES = 32;
const HEADER_BYTES = MAGIC.length + 1 + DIGEST_BYTES;
const RETIRED_GRACE_HEIGHTS = 128;
const MAX_RETIRED_ROUTES = 6;

interface RetiringRoute {
  readonly device: PeerId;
  readonly game: PeerId;
  readonly atSeq: number;
  readonly hint: Uint8Array;
  hinted: boolean;
}

function pruneRetiring(retired: Map<PeerId, RetiringRoute>, committedSeq: number): void {
  for (const [game, route] of retired)
    if (committedSeq - route.atSeq > RETIRED_GRACE_HEIGHTS) retired.delete(game);
}

function retireRemovedRoutes(
  prior: ReadonlyMap<PeerId, PeerId>,
  current: ReadonlyMap<PeerId, PeerId>,
  certified: CertifiedEntry,
  retired: Map<PeerId, RetiringRoute>,
): Result<void> {
  if (certified.entry.payload.kind === 'membership')
    for (const [device, game] of prior) {
      if (current.get(device) === game) continue;
      const hint = encodeProtocolMessage({
        t: 'COMMIT',
        certified: { entry: certified.entry, certificate: certified.certificate },
      });
      if (!hint.ok) return hint;
      retired.set(game, {
        device,
        game,
        atSeq: certified.entry.seq,
        hint: hint.value,
        hinted: false,
      });
    }
  pruneRetiring(retired, certified.entry.seq);
  while (retired.size > MAX_RETIRED_ROUTES) {
    const oldest = retired.keys().next().value;
    if (oldest === undefined) break;
    retired.delete(oldest);
  }
  return success(undefined);
}

export interface OnlineGameTransport extends Transport {
  /** Advances routing only from a verified extension of this transport's certified history. */
  advanceCertifiedHistory(entries: readonly CertifiedEntry[]): Result<void>;
  /** The caller supplies an already validated non-membership commit head. */
  pruneRetired(committedHead: OnlineDeviceRoutes['head']): Result<boolean>;
  /** Connection admission only; current game-key authorization remains in this transport. */
  deviceRoutes(): OnlineDeviceRoutes | null;
  /** Leaves the authenticated device links and their other subscribers alive. */
  dispose(): void;
}

export interface OnlineDeviceRoutes {
  readonly head: { readonly seq: number; readonly hash: string };
  /** Current certified game-seat owner; null identifies seats currently run as bots. */
  readonly seats: readonly { readonly seat: Seat; readonly devicePeer: PeerId | null }[];
  readonly activeDevices: readonly PeerId[];
  readonly catchupDevices: readonly PeerId[];
}

export interface OnlineGameTransportOptions {
  readonly deviceTransport: Transport;
  /** Output of certified genesis admission, never a caller-supplied draft. */
  readonly validatedGenesis: ValidatedGenesis;
  readonly agreement: LobbyFreezeAgreement;
  readonly bindings: readonly SignedGameSeatBinding[];
  /** Required on restore or when the device joined after genesis. */
  readonly certifiedHistory?: {
    readonly genesisEntry: unknown;
    readonly entries: readonly CertifiedEntry[];
    readonly engine: Engine;
    readonly policy: ReplayPolicy;
  };
}

function sameValue(left: unknown, right: unknown): boolean {
  return toHex(hashValue(left)) === toHex(hashValue(right));
}

/** Projects a certified genesis onto the device consent and fresh game-key roster. */
export function createOnlineGameTransport(
  options: OnlineGameTransportOptions,
): Result<OnlineGameTransport> {
  const checked = verifyGameSeatBindings(options.agreement, options.bindings);
  if (!checked.ok) return checked;
  const { genesis } = options.validatedGenesis;
  const { agreement, genesisSeats, masters } = checked.value;
  try {
    const certified = validateGenesisOnlineStart(genesis);
    if (
      !certified.ok ||
      !sameValue(agreement, certified.value.bindings.agreement) ||
      !sameValue(checked.value.bindings, certified.value.bindings.bindings)
    )
      return failure(
        'online-transport-genesis',
        'Device routing differs from the certified online start',
      );
    if (
      genesis.security !== 'verified' ||
      genesis.ceremonyNonce !== agreement.state.ceremonyNonce ||
      !sameValue(genesis.config, agreement.state.config) ||
      !sameValue(genesis.seats, genesisSeats) ||
      !sameValue(genesis.commitments.masters, masters)
    )
      return failure(
        'online-transport-genesis',
        'Game keys differ from the certified frozen roster',
      );
    const digest = fromBase64Url(genesisDigest(genesis));
    if (digest.byteLength !== DIGEST_BYTES)
      return failure('online-transport-genesis', 'Genesis digest is invalid');
    const deviceToGame = new Map<PeerId, PeerId>();
    const gameToDevice = new Map<PeerId, PeerId>();
    for (const frozen of agreement.state.seats) {
      if (frozen.kind !== 'human') continue;
      const game = genesisSeats.find((seat) => seat.seat === frozen.seat);
      if (!game || game.kind !== 'human')
        return failure('online-transport-genesis', 'Human game-key roster is incomplete');
      deviceToGame.set(frozen.peer, game.publicKey);
      gameToDevice.set(game.publicKey, frozen.peer);
    }
    let certifiedContext: ProposalContext | null = null;
    let certifiedHashes: string[] = [];
    const retiring = new Map<PeerId, RetiringRoute>();
    if (options.certifiedHistory) {
      const history = options.certifiedHistory;
      let priorRoutes = new Map(deviceToGame);
      const replayed = replayCertifiedPrefix(
        history.genesisEntry,
        history.entries,
        history.engine,
        history.policy,
        (entry, next) => {
          const routes = projectCertifiedRoutes(next);
          if (!routes.ok) return routes;
          const retained = retireRemovedRoutes(
            priorRoutes,
            routes.value.deviceToGame,
            entry,
            retiring,
          );
          if (retained.ok) priorRoutes = routes.value.deviceToGame;
          return retained;
        },
      );
      if (!replayed.ok) return replayed;
      if (!sameValue(replayed.value.context.log.genesis, genesis))
        return failure('online-transport-history', 'Certified history belongs to another genesis');
      const routes = projectCertifiedRoutes(replayed.value.context);
      if (!routes.ok) return routes;
      deviceToGame.clear();
      gameToDevice.clear();
      for (const [device, game] of routes.value.deviceToGame) deviceToGame.set(device, game);
      for (const [game, device] of routes.value.gameToDevice) gameToDevice.set(game, device);
      certifiedContext = replayed.value.context;
      certifiedHashes = replayed.value.entries.map(({ entry }) => entryHash(entry));
    }
    const self = deviceToGame.get(options.deviceTransport.self);
    if (!self) return failure('online-transport-self', 'Device has no frozen human game seat');
    return success(
      new GameKeyTransport(
        options.deviceTransport,
        self,
        digest,
        deviceToGame,
        gameToDevice,
        certifiedContext,
        certifiedHashes,
        retiring,
        options.certifiedHistory
          ? {
              genesisEntry: options.certifiedHistory.genesisEntry,
              engine: options.certifiedHistory.engine,
              policy: {
                genesis: { ...options.certifiedHistory.policy.genesis },
                entry: { ...options.certifiedHistory.policy.entry },
              },
            }
          : null,
      ),
    );
  } catch {
    return failure('online-transport-genesis', 'Certified genesis projection is invalid');
  }
}

function projectCertifiedRoutes(context: ProposalContext): Result<{
  deviceToGame: Map<PeerId, PeerId>;
  gameToDevice: Map<PeerId, PeerId>;
  seats: readonly { readonly seat: Seat; readonly devicePeer: PeerId | null }[];
}> {
  const authority = context.log.authority;
  const transfer = context.log.transfer;
  if (!authority || !transfer)
    return failure('online-transport-history', 'Certified authority or device routes are missing');
  const deviceToGame = new Map<PeerId, PeerId>();
  const gameToDevice = new Map<PeerId, PeerId>();
  for (const controller of authority.controllers) {
    if (controller.kind !== 'human' || controller.status !== 'active') continue;
    const device = transfer.routes.find(({ seat }) => seat === controller.seat)?.devicePeer;
    if (!device || deviceToGame.has(device) || gameToDevice.has(controller.publicKey))
      return failure('online-transport-history', 'Certified human device routes are incomplete');
    deviceToGame.set(device, controller.publicKey);
    gameToDevice.set(controller.publicKey, device);
  }
  const seats: { seat: Seat; devicePeer: PeerId | null }[] = [];
  for (const controller of authority.controllers) {
    if (controller.kind === 'bot') {
      seats.push({ seat: controller.seat, devicePeer: null });
      continue;
    }
    const devicePeer = transfer.routes.find(({ seat }) => seat === controller.seat)?.devicePeer;
    if (!devicePeer)
      return failure('online-transport-history', 'Certified human device routes are incomplete');
    seats.push({ seat: controller.seat, devicePeer });
  }
  return success({ deviceToGame, gameToDevice, seats });
}

class GameKeyTransport implements OnlineGameTransport {
  private readonly messageListeners = new Set<(from: PeerId, message: Uint8Array) => void>();
  private readonly peerListeners = new Set<(peer: PeerId, online: boolean) => void>();
  private readonly offMessage: Unsubscribe;
  private readonly offPeer: Unsubscribe;
  private routeHead: OnlineDeviceRoutes['head'] | null;
  private disposed = false;

  constructor(
    private readonly device: Transport,
    readonly self: PeerId,
    private readonly digest: Uint8Array,
    private deviceToGame: ReadonlyMap<PeerId, PeerId>,
    private gameToDevice: ReadonlyMap<PeerId, PeerId>,
    private context: ProposalContext | null,
    private certifiedHashes: string[],
    private retiring: Map<PeerId, RetiringRoute>,
    private readonly verifier: {
      readonly genesisEntry: unknown;
      readonly engine: Engine;
      readonly policy: ReplayPolicy;
    } | null,
  ) {
    this.routeHead = context
      ? { seq: context.log.head.seq, hash: entryHash(context.log.head) }
      : null;
    this.offMessage = device.onMessage((from, bytes) => this.receive(from, bytes));
    this.offPeer = device.onPeerChange((peer, online) => {
      for (const route of this.retiring.values())
        if (route.device === peer) {
          if (online) this.hintRetiring(route);
          else route.hinted = false;
        }
      const game = this.deviceToGame.get(peer);
      if (!this.disposed && game && game !== this.self)
        for (const listener of this.peerListeners) {
          try {
            listener(game, online);
          } catch {
            /* A view cannot interrupt other game or device subscribers. */
          }
        }
    });
    for (const route of this.retiring.values())
      if (device.peers().includes(route.device)) this.hintRetiring(route);
  }

  advanceCertifiedHistory(entries: readonly CertifiedEntry[]): Result<void> {
    if (this.disposed) return failure('online-transport-retired', 'Game transport is disposed');
    if (!this.context || !this.verifier)
      return failure('online-transport-history', 'Certified genesis history was not installed');
    let hashes: string[];
    try {
      hashes = entries.map(({ entry }) => entryHash(entry));
    } catch {
      return failure('online-transport-history', 'Certified history contains an invalid entry');
    }
    if (
      hashes.length < this.certifiedHashes.length ||
      this.certifiedHashes.some((hash, index) => hashes[index] !== hash)
    )
      return failure('online-transport-history', 'Certified history does not extend this prefix');
    if (hashes.length === this.certifiedHashes.length) return success(undefined);
    let next = this.context;
    const priorSeq = next.log.head.seq;
    let priorRoutes = new Map(this.deviceToGame);
    const retiring = new Map(this.retiring);
    const trackRoutes = (certified: CertifiedEntry, context: ProposalContext): Result<void> => {
      const nextRoutes = projectCertifiedRoutes(context);
      if (!nextRoutes.ok) return nextRoutes;
      const retained = retireRemovedRoutes(
        priorRoutes,
        nextRoutes.value.deviceToGame,
        certified,
        retiring,
      );
      if (!retained.ok) return retained;
      priorRoutes = nextRoutes.value.deviceToGame;
      return success(undefined);
    };
    const extension = entries.slice(this.certifiedHashes.length);
    if (
      extension.some(
        ({ entry }) => entry.payload.kind === 'control' || entry.payload.kind === 'cheat-proof',
      )
    ) {
      const replayed = replayCertifiedPrefix(
        this.verifier.genesisEntry,
        entries,
        this.verifier.engine,
        this.verifier.policy,
        (certified, context) =>
          certified.entry.seq > priorSeq ? trackRoutes(certified, context) : success(undefined),
      );
      if (!replayed.ok) return replayed;
      next = replayed.value.context;
    } else {
      for (const certified of extension) {
        if (!certified) return failure('online-transport-history', 'Certified entry is missing');
        const checked = validateCertifiedEntry(certified, next);
        if (!checked.ok) return checked;
        const advanced = advanceContext(next, checked.value);
        if (!advanced.ok) return advanced;
        next = advanced.value;
        const tracked = trackRoutes(certified, next);
        if (!tracked.ok) return tracked;
      }
    }
    const routes = projectCertifiedRoutes(next);
    if (!routes.ok) return routes;
    const nextHead = { seq: next.log.head.seq, hash: entryHash(next.log.head) };
    if (
      this.routeHead &&
      (nextHead.seq < this.routeHead.seq ||
        (nextHead.seq === this.routeHead.seq && nextHead.hash !== this.routeHead.hash))
    )
      return failure('online-transport-history', 'Certified routing head would move backwards');
    const newSelf = routes.value.deviceToGame.get(this.device.self);
    if (newSelf !== this.self) {
      this.dispose();
      return failure('online-transport-retired', 'Local game key was retired by certified history');
    }
    const online = new Set(this.device.peers());
    const previous = new Set(this.peers());
    const current = new Set(
      [...routes.value.gameToDevice]
        .filter(([, device]) => online.has(device))
        .map(([game]) => game),
    );
    this.context = next;
    this.certifiedHashes = hashes;
    this.routeHead = nextHead;
    this.deviceToGame = routes.value.deviceToGame;
    this.gameToDevice = routes.value.gameToDevice;
    this.retiring = retiring;
    for (const peer of previous) if (!current.has(peer)) this.notifyPeer(peer, false);
    for (const peer of current)
      if (!previous.has(peer) && peer !== this.self) this.notifyPeer(peer, true);
    for (const route of this.retiring.values())
      if (online.has(route.device)) this.hintRetiring(route);
    return success(undefined);
  }

  pruneRetired(committedHead: OnlineDeviceRoutes['head']): Result<boolean> {
    if (this.disposed || !this.context || !this.routeHead)
      return failure('online-transport-history', 'Certified routing context is unavailable');
    if (
      !committedHead ||
      !Number.isSafeInteger(committedHead.seq) ||
      typeof committedHead.hash !== 'string' ||
      !/^[0-9a-f]{64}$/.test(committedHead.hash) ||
      committedHead.seq < this.routeHead.seq ||
      (committedHead.seq === this.routeHead.seq && committedHead.hash !== this.routeHead.hash)
    )
      return failure('online-transport-history', 'Committed routing head is stale or malformed');
    const before = this.catchupDevices();
    pruneRetiring(this.retiring, committedHead.seq);
    this.routeHead = { seq: committedHead.seq, hash: committedHead.hash };
    const after = this.catchupDevices();
    return success(
      before.length !== after.length || before.some((device, index) => device !== after[index]),
    );
  }

  private catchupDevices(): PeerId[] {
    const activeDevices = this.deviceToGame;
    return [
      ...new Set(
        [...this.retiring.values()]
          .toSorted(
            (left, right) => right.atSeq - left.atSeq || left.device.localeCompare(right.device),
          )
          .map((route) => route.device),
      ),
    ]
      .filter((device) => !activeDevices.has(device))
      .slice(0, Math.max(0, 6 - activeDevices.size));
  }

  deviceRoutes(): OnlineDeviceRoutes | null {
    if (!this.context || this.disposed) return null;
    const current = projectCertifiedRoutes(this.context);
    if (!current.ok) return null;
    const activeDevices = [...this.deviceToGame.keys()].toSorted();
    const head = this.routeHead;
    if (!head) return null;
    return {
      head: { ...head },
      seats: current.value.seats.map((route) => ({ ...route })),
      activeDevices,
      catchupDevices: this.catchupDevices(),
    };
  }

  private hintRetiring(route: RetiringRoute): void {
    if (this.disposed || route.hinted) return;
    try {
      this.device.send(route.device, this.frame(route.hint));
      route.hinted = true;
    } catch {
      // Retry on the next authenticated link event or retired peer request.
    }
  }

  private notifyPeer(peer: PeerId, online: boolean): void {
    for (const listener of this.peerListeners) {
      try {
        listener(peer, online);
      } catch {
        /* A view cannot interrupt other game or device subscribers. */
      }
    }
  }

  peers(): PeerId[] {
    if (this.disposed) return [];
    return this.device
      .peers()
      .map((peer) => this.deviceToGame.get(peer))
      .filter((peer): peer is PeerId => peer !== undefined && peer !== this.self)
      .toSorted();
  }

  send(to: PeerId, message: Uint8Array): void {
    this.assertActive();
    const devicePeer = this.gameToDevice.get(to);
    if (devicePeer && to !== this.self) {
      this.device.send(devicePeer, this.frame(message));
      return;
    }
    const retired = this.retiring.get(to);
    if (!retired || !this.device.peers().includes(retired.device))
      throw new Error('Game peer is not a remote human');
    const decoded = decodeProtocolMessage(message);
    if (!decoded.ok || decoded.value.t !== 'SYNC_RES')
      throw new Error('Retired game peer accepts certified sync responses only');
    this.device.send(retired.device, this.frame(message));
  }

  broadcast(message: Uint8Array): void {
    this.assertActive();
    let firstError: unknown = null;
    for (const peer of this.peers()) {
      try {
        this.send(peer, message);
      } catch (error) {
        firstError ??= error;
      }
    }
    if (firstError) throw firstError;
  }

  onMessage(listener: (from: PeerId, message: Uint8Array) => void): Unsubscribe {
    if (this.disposed) return () => undefined;
    this.messageListeners.add(listener);
    return () => this.messageListeners.delete(listener);
  }

  onPeerChange(listener: (peer: PeerId, online: boolean) => void): Unsubscribe {
    if (this.disposed) return () => undefined;
    this.peerListeners.add(listener);
    return () => this.peerListeners.delete(listener);
  }

  disconnect(peer: PeerId): void {
    this.assertActive();
    const devicePeer = this.gameToDevice.get(peer);
    if (!devicePeer || peer === this.self) throw new Error('Game peer is not a remote human');
    this.device.disconnect(devicePeer);
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.offMessage();
    this.offPeer();
    this.messageListeners.clear();
    this.peerListeners.clear();
    this.retiring.clear();
  }

  private assertActive(): void {
    if (this.disposed) throw new Error('Game transport is disposed');
  }

  private frame(message: Uint8Array): Uint8Array {
    if (
      !(message instanceof Uint8Array) ||
      message.byteLength > MAX_PROTOCOL_MESSAGE_BYTES ||
      message.byteLength + HEADER_BYTES > MAX_WEBRTC_MESSAGE_BYTES
    )
      throw new RangeError('Gameplay packet exceeds the transport limit');
    const frame = new Uint8Array(HEADER_BYTES + message.byteLength);
    frame.set(MAGIC);
    frame[MAGIC.length] = FRAME_VERSION;
    frame.set(this.digest, MAGIC.length + 1);
    frame.set(message, HEADER_BYTES);
    return frame;
  }

  private receive(from: PeerId, bytes: Uint8Array): void {
    if (this.disposed) return;
    const gamePeer = this.deviceToGame.get(from);
    if (
      !(bytes instanceof Uint8Array) ||
      bytes.byteLength < HEADER_BYTES ||
      bytes.byteLength > HEADER_BYTES + MAX_PROTOCOL_MESSAGE_BYTES ||
      bytes.byteLength > MAX_WEBRTC_MESSAGE_BYTES ||
      MAGIC.some((byte, index) => bytes[index] !== byte) ||
      bytes[MAGIC.length] !== FRAME_VERSION ||
      this.digest.some((byte, index) => bytes[MAGIC.length + 1 + index] !== byte)
    )
      return;
    if (!gamePeer) {
      const retired = [...this.retiring.values()].find((route) => route.device === from);
      if (!retired) return;
      const decoded = decodeProtocolMessage(bytes.slice(HEADER_BYTES));
      if (!decoded.ok || decoded.value.t !== 'SYNC_REQ') return;
      this.hintRetiring(retired);
      for (const listener of this.messageListeners) {
        try {
          listener(retired.game, bytes.slice(HEADER_BYTES));
        } catch {
          /* A view cannot interrupt certified catch-up or other subscribers. */
        }
      }
      return;
    }
    if (gamePeer === this.self) return;
    for (const listener of this.messageListeners) {
      try {
        listener(gamePeer, bytes.slice(HEADER_BYTES));
      } catch {
        /* A view cannot interrupt other game or device subscribers. */
      }
    }
  }
}


### docs/verification/stage09/disclosure-opening-fence-2026-09-28.json
{
  "scope": "Opening-only, not already-active independent coordinator lifetime. Post-check hashes only.",
  "negativeRun": {
    "handle": 81339,
    "cleanMilliseconds": 9311,
    "disclosedMilliseconds": 3971,
    "result": "disclosed entered playing instead of halted"
  },
  "positiveRun": {
    "handle": 34012,
    "tests": 5,
    "testMilliseconds": 24282,
    "runnerSeconds": 25.94
  },
  "normalRegressionRun": {
    "handle": 91888,
    "tests": 3,
    "runnerSeconds": 22.61
  },
  "static": {
    "sharedTypecheck": 77161,
    "scopedChecks": 68581
  },
  "sourceSha256": {
    "packages/protocol/src/online-disclosure.ts": "bc89a89e547224e34070979d233744715ff4dd6da9b230df05b80dddf4cfef88",
    "packages/protocol/src/index.ts": "d799898f2d17d28844d0265dde5f96a576cc0affac6ecdb9c635873bf7c0258e",
    "apps/web/src/session/online-game.ts": "4d7c5c5cac593426bc5654b8aa48d0dd70ce6381e2b7641dcad6957448391cbc",
    "apps/web/src/session/online-startup.ts": "e2acad42fcbcb39323f5160fff8ccc4bb87a70f1eb7b5bb4ebaeb5df71e6ef19",
    "apps/web/src/session/online-resume-binding.test.ts": "954acafe4ffe82bb0b9e05e364ff15d6ab16193492694a706558c3cb9d599b2a"
  },
  "cleanupFollowup": {
    "handle": 39382,
    "tests": 2,
    "runnerSeconds": 12.22,
    "scope": "Monotonic output stop; selected disputed-opening and deferred-close regressions after initial five-case pass.",
    "formatAndLint": 8810
  }
}


### docs/verification/stage09/disclosure-opening-fence-2026-09-28.md
# Authenticated disclosure fence during browser activation

The current source fixes a demonstrated transferred-resume bypass of retained
post-consent escrow disclosure. It adds no disposition certificate, quorum rule
or recovery-share release.

## Failure and correction

The fail-before run `81339` retained a correctly signed original-holder disclosure
for the pinned genesis, including a verified DLEQ witness and original frozen
device signature. The clean transferred resume passed (9.311 seconds), but the
disclosed resume entered `playing` rather than `halted` (3.971 seconds). The
fixture uses a genuinely certified transfer journal and current key binding;
production `OnlineStartup` and `openOnlineGame` perform the restore. The witness
is constructed and authenticated directly in the test, not written by a second
ceremony coordinator.

The new protocol helper owns and validates the original genesis, frozen roster
and escrow transcript. It scans only bounded retained dispute slots, verifies
canonical device packets and holder proofs, and requires the exact envelope hash
from signed genesis. A foreign nonce, malformed packet or nonmatching witness
does not establish a halt. Storage failures stop opening rather than bypass the
check. Public invalid-envelope reports remain separate: they disclose no share
and do not revoke a completed genesis.

Shared browser activation checks this authenticated evidence before creating a
session. Opening device output is copied into a bounded FIFO (128 messages,
1 MiB). After genuine session create/restore, a final check and synchronous FIFO
release run under the same attempt lock used for disclosure insertion. This
callback only loads and sends; it acquires no nested ceremony/writer lock. Valid
disclosure discards buffered output and closes the prepared session. Startup
shows `halted` while preserving the signed promise and evidence. Clean opening
preserves send order. No internal signature prepared before the final check is
claimed to be recalled.

## Checks and scope

```sh
pnpm exec vitest run apps/web/src/session/online-resume-binding.test.ts --maxWorkers=1 --minWorkers=1
pnpm exec vitest run apps/web/src/session/online-startup.test.ts apps/web/src/session/online-startup-retry.test.ts -t 'freezes two humans|consented dispute during opening|closing during a deferred' --maxWorkers=1 --minWorkers=1
```

Final `34012`: **5/5 pass**, 24.282 seconds test time / 25.94-second runner.
Cases: clean, retained disclosure, disclosure inserted after the real
`P2PSession.restore` returns but before activation receives it, malformed bytes,
and a signed foreign nonce. The two halt cases emit no actual device messages.
The real restore implementation runs unchanged. `91888`: **3/3 pass**, fresh
startup/first certified move, disputed deferred lease, and close during opening
(22.61-second runner). Shared typecheck `77161`, scoped lint/format/diff `68581`
passed. Existing per-case bounds were retained. An earlier five-case pass inserted
evidence during the restore load; the final case strengthens that placement to
after the real restore returns.

This fixes retained-evidence and opening-race activation. It does **not** fence
an already-active independent coordinator for the rest of its lifetime. The
existing coordinator's live dispute event still halts its own session. Another
process that has already activated needs separate authenticated notification or
output fencing; no instant cross-process guarantee is claimed. A different
device cannot know a disclosure it has not received. This is focused correctness
evidence, not new browser timing, cross-engine or full-game acceptance.

The [design review](disclosure-halt-design-review-2026-09-28.md) rejected the
broader unanimous disposition proposal. The [source manifest](disclosure-opening-fence-2026-09-28.json)
records post-check source hashes; it is not a before/after runtime pin.

A subsequent read-only review identified that disposal callbacks could refill the
opening queue after it was cleared. The final source sets a monotonic output stop
before disposal, ignores subsequent sends, and refuses final release after stop.
The selected disputed-opening and deferred-close regressions passed 2/2 in
`39382` (12.22-second runner); scoped format/lint `8810` passed. The five-case
result above predates this narrow cleanup correction.


### packages/protocol/src/online-ceremony.ts lines 642–679
642:   async #attempt<T>(task: (record: AttemptRecord) => Promise<Result<T>>): Promise<Result<T>> {
643:     try {
644:       return await this.#options.store.withCeremonyLock(this.#attemptId, async () => {
645:         const id = `online-attempt/${this.#attemptId}`;
646:         let bytes = await this.#options.store.load(id);
647:         if (bytes === null) {
648:           if (this.#restoreExpected)
649:             return failure('online-ceremony-restore', 'Completed attempt record is missing');
650:           const initial = {
651:             protocol: ATTEMPT_PROTOCOL,
652:             freezeHash: this.#freezeHash,
653:             ceremonyNonce: this.#nonce,
654:             devicePeer: this.#self,
655:             phase: 'frozen',
656:             startedAt: Math.floor(this.#options.clock.now()),
657:             status: 'active',
658:           } as const;
659:           const proposed = canonicalEncode(initial);
660:           if (await this.#options.store.putIfAbsent(id, proposed)) bytes = proposed;
661:           else bytes = await this.#options.store.load(id);
662:         }
663:         if (bytes === null) return failure('online-ceremony-record', 'Attempt record is missing');
664:         const parsed = parseCanonical(canonicalDecode(bytes), attemptSchema);
665:         if (
666:           !parsed.ok ||
667:           !sameBytes(bytes, canonicalEncode(parsed.value)) ||
668:           parsed.value.freezeHash !== this.#freezeHash ||
669:           parsed.value.ceremonyNonce !== this.#nonce ||
670:           parsed.value.devicePeer !== this.#self
671:         )
672:           return failure(
673:             'online-ceremony-record',
674:             'Attempt record is corrupt or belongs to another device',
675:           );
676:         return task(parsed.value);
677:       });
678:     } catch {
679:       return failure('online-ceremony-store', 'Could not access durable ceremony state');

### packages/protocol/src/online-ceremony.ts lines 1319–1569
1319:   async #acceptInvalidPacket(
1320:     packet: OnlineCeremonyPacket,
1321:     bytes: Uint8Array,
1322:   ): Promise<Result<void>> {
1323:     const manifest = this.#escrowManifest;
1324:     const escrow = this.#escrow;
1325:     if (!manifest || !escrow) return success(undefined);
1326:     const { seat: holderSeat, step: dealerSeat } = packet.body;
1327:     const roster = this.#escrowRosters.find((item) => item.dealer.seat === dealerSeat);
1328:     const holder = roster?.holders.find((item) => item.seat === holderSeat);
1329:     if (!roster?.eligible || !holder || this.#ownerDevice(holder.seat) !== packet.body.senderDevice)
1330:       return failure('online-ceremony-escrow', 'Invalid-envelope reporter is not its holder');
1331:     const parsed = parseCanonical(packet.body.payload, invalidEscrowSchema);
1332:     if (!parsed.ok) return parsed;
1333:     let dealerBytes: Uint8Array;
1334:     try {
1335:       dealerBytes = fromBase64Url(parsed.value.dealerPacket);
1336:       if (toBase64Url(dealerBytes) !== parsed.value.dealerPacket)
1337:         return failure('online-ceremony-escrow', 'Invalid-envelope bytes are noncanonical');
1338:     } catch {
1339:       return failure('online-ceremony-escrow', 'Invalid-envelope bytes are malformed');
1340:     }
1341:     const dealerDevice = this.#ownerDevice(roster.dealer.seat);
1342:     if (!dealerDevice)
1343:       return failure('online-ceremony-escrow', 'Invalid-envelope dealer is missing');
1344:     const dealerPacket = verifyOnlineCeremonyPacket(
1345:       dealerBytes,
1346:       dealerDevice,
1347:       this.#freezeHash,
1348:       this.#nonce,
1349:     );
1350:     if (
1351:       !dealerPacket.ok ||
1352:       dealerPacket.value.body.kind !== 'escrow-envelope' ||
1353:       dealerPacket.value.body.seat !== roster.dealer.seat ||
1354:       dealerPacket.value.body.step !== holder.seat
1355:     )
1356:       return failure('online-ceremony-escrow', 'Evidence lacks an authenticated dealer delivery');
1357:     const envelopeSlot = this.#escrowEnvelopeSlot(manifest, [], roster, holder.seat);
1358:     if (envelopeSlot.validate(dealerPacket.value.body.payload).ok)
1359:       return failure('online-ceremony-escrow', 'A valid sealed share cannot be rejected');
1360:     const key = this.#packetKey('escrow-invalid', holder.seat, roster.dealer.seat);
1361:     const applied = await this.#attempt(async (record) => {
1362:       const prior = await this.#options.store.load(key);
1363:       if (prior !== null && !sameBytes(prior, bytes))
1364:         return failure(
1365:           'online-ceremony-conflict',
1366:           'Another invalid-envelope report owns this slot',
1367:         );
1368:       if (prior === null && record.status === 'retired')
1369:         return failure('online-ceremony-retired', 'New evidence cannot enter a retired attempt');
1370:       if (prior === null && !(await this.#options.store.putIfAbsent(key, bytes))) {
1371:         const winner = await this.#options.store.load(key);
1372:         if (!winner || !sameBytes(winner, bytes))
1373:           return failure(
1374:             'online-ceremony-conflict',
1375:             'Another invalid-envelope report owns this slot',
1376:           );
1377:       }
1378:       const retired = await escrow.abort();
1379:       if (
1380:         !retired.ok &&
1381:         retired.error.code !== 'escrow-ceremony-consenting' &&
1382:         retired.error.code !== 'escrow-ceremony-completed'
1383:       )
1384:         return retired;
1385:       if (!retired.ok) return success('consented' as const);
1386:       if (record.status !== 'retired') {
1387:         const before = canonicalEncode(record);
1388:         const after = canonicalEncode({ ...record, status: 'retired' });
1389:         if (
1390:           !(await this.#options.store.compareAndSwap(
1391:             `online-attempt/${this.#attemptId}`,
1392:             before,
1393:             after,
1394:           ))
1395:         )
1396:           return failure('online-ceremony-record', 'Evidence retirement lost its durable race');
1397:       }
1398:       return success('retired' as const);
1399:     });
1400:     if (!applied.ok) return applied;
1401:     this.#broadcast(key, bytes);
1402:     if (applied.value === 'consented') {
1403:       this.#locallyConsented = true;
1404:       // A malformed dealer packet proves misconduct but reveals no private share.
1405:       // It cannot revoke an already signed or certified genesis.
1406:     } else {
1407:       this.#result = null;
1408:       this.#disclosureBytes.set(key, bytes.slice());
1409:       this.#emit({
1410:         phase: 'retired',
1411:         awaitingSeats: [],
1412:         error: 'online-ceremony-escrow-invalid',
1413:         locallyConsented: false,
1414:       });
1415:     }
1416:     return success(undefined);
1417:   }
1418: 
1419:   async #acceptDisputePacket(
1420:     packet: OnlineCeremonyPacket,
1421:     bytes: Uint8Array,
1422:   ): Promise<Result<void>> {
1423:     const manifest = this.#escrowManifest;
1424:     const escrow = this.#escrow;
1425:     if (!manifest || !escrow) return success(undefined);
1426:     const { seat: holderSeat, step: dealerSeat } = packet.body;
1427:     const roster = this.#escrowRosters.find((item) => item.dealer.seat === dealerSeat);
1428:     const holder = roster?.holders.find((item) => item.seat === holderSeat);
1429:     if (!roster?.eligible || !holder || this.#ownerDevice(holder.seat) !== packet.body.senderDevice)
1430:       return failure('online-ceremony-escrow', 'Dispute actor differs from frozen escrow holder');
1431:     const parsed = parseCanonical(packet.body.payload, disputedEscrowSchema);
1432:     if (!parsed.ok) return parsed;
1433:     const verifier = prepareEscrowVerifier(manifest);
1434:     if (!verifier.ok) return verifier;
1435:     const masters = validateGenesisMasters(manifest);
1436:     if (!masters.ok) return masters;
1437:     const master = masters.value.find((item) => item.seat === roster.dealer.seat);
1438:     if (!master) return failure('online-ceremony-escrow', 'Disputed dealer has no master');
1439:     const envelope = verifier.value.envelope(
1440:       parsed.value.envelope,
1441:       roster.dealer.seat,
1442:       master.masterPub,
1443:     );
1444:     if (!envelope.ok || envelope.value.body.holder.seat !== holder.seat)
1445:       return failure('online-ceremony-escrow', 'Dispute references another sealed share');
1446:     const verdict = verifyEscrowShareDispute(parsed.value.dispute, envelope.value, manifest);
1447:     if (
1448:       !verdict.ok ||
1449:       verdict.value.dispute.body.holderSeat !== holder.seat ||
1450:       verdict.value.dispute.body.dealerSeat !== roster.dealer.seat
1451:     )
1452:       return failure('online-ceremony-escrow', 'Dispute proof does not bind this delivery');
1453:     const bound = await this.#checkConsentedDisputeEnvelope(
1454:       manifest,
1455:       roster.dealer.seat,
1456:       holder.seat,
1457:       envelope.value,
1458:     );
1459:     if (!bound.ok) return bound;
1460:     const key = this.#packetKey('escrow-dispute', holder.seat, roster.dealer.seat);
1461:     const applied = await this.#attempt(async (record) => {
1462:       const prior = await this.#options.store.load(key);
1463:       if (prior !== null && !sameBytes(prior, bytes))
1464:         return failure('online-ceremony-conflict', 'Another dispute owns this slot');
1465:       if (prior === null && record.status === 'retired')
1466:         return failure('online-ceremony-retired', 'New dispute cannot enter a retired attempt');
1467:       if (prior === null && !(await this.#options.store.putIfAbsent(key, bytes))) {
1468:         const winner = await this.#options.store.load(key);
1469:         if (!winner || !sameBytes(winner, bytes))
1470:           return failure('online-ceremony-conflict', 'Another dispute owns this slot');
1471:       }
1472:       const disclosed = await escrow.receiveDispute(envelope.value, verdict.value.dispute);
1473:       if (!disclosed.ok && disclosed.error.code !== 'escrow-ceremony-consenting-dispute')
1474:         return disclosed;
1475:       if (!disclosed.ok) return success('consented' as const);
1476:       if (record.status !== 'retired') {
1477:         const before = canonicalEncode(record);
1478:         const after = canonicalEncode({ ...record, status: 'retired' });
1479:         if (
1480:           !(await this.#options.store.compareAndSwap(
1481:             `online-attempt/${this.#attemptId}`,
1482:             before,
1483:             after,
1484:           ))
1485:         )
1486:           return failure('online-ceremony-record', 'Dispute retirement lost its durable race');
1487:       }
1488:       return success('retired' as const);
1489:     });
1490:     if (!applied.ok) return applied;
1491:     this.#result = null;
1492:     this.#disclosureBytes.set(key, bytes.slice());
1493:     this.#broadcast(key, bytes);
1494:     if (applied.value === 'consented') {
1495:       this.#locallyConsented = true;
1496:       this.#emit({
1497:         phase: 'waiting',
1498:         awaitingSeats: [],
1499:         error: 'online-ceremony-disputed',
1500:         locallyConsented: true,
1501:       });
1502:     } else {
1503:       this.#emit({
1504:         phase: 'retired',
1505:         awaitingSeats: [],
1506:         error: 'online-ceremony-disputed',
1507:         locallyConsented: false,
1508:       });
1509:     }
1510:     return success(undefined);
1511:   }
1512: 
1513:   async #checkConsentedDisputeEnvelope(
1514:     manifest: GenesisBody,
1515:     dealerSeat: Seat,
1516:     holderSeat: Seat,
1517:     envelope: EscrowShareEnvelope,
1518:   ): Promise<Result<void>> {
1519:     const status = await checkEscrowCeremonyActive(manifest, this.#options.store);
1520:     if (status.ok || status.error.code === 'escrow-ceremony-retired') return success(undefined);
1521:     if (
1522:       status.error.code !== 'escrow-ceremony-consenting' &&
1523:       status.error.code !== 'escrow-ceremony-completed'
1524:     )
1525:       return status;
1526: 
1527:     let finalBody: GenesisBody;
1528:     if (this.#result) finalBody = this.#result.genesis;
1529:     else if (this.#restoreExpected) finalBody = this.#restoreExpected.genesis;
1530:     else {
1531:       let bytes: Uint8Array | null;
1532:       try {
1533:         bytes = await this.#options.store.load(`online-draft/${this.#attemptId}`);
1534:       } catch {
1535:         return failure('online-ceremony-store', 'Could not read the pinned consent draft');
1536:       }
1537:       if (!bytes)
1538:         return failure('online-ceremony-escrow', 'Consented ceremony has no pinned final draft');
1539:       if (bytes.byteLength > MAX_MESSAGE_BYTES)
1540:         return failure('online-ceremony-size', 'Pinned consent draft exceeds its size limit');
1541:       let parsed: Result<GenesisBody>;
1542:       try {
1543:         parsed = parseCanonical(
1544:           canonicalDecode(bytes),
1545:           v.omit(genesisSchema, ['gameId', 'signatures']),
1546:         );
1547:       } catch {
1548:         return failure('online-ceremony-record', 'Pinned consent draft is malformed');
1549:       }
1550:       if (!parsed.ok) return parsed;
1551:       finalBody = parsed.value;
1552:     }
1553: 
1554:     const transcript = validateGenesisEscrow(finalBody);
1555:     if (!transcript.ok) return transcript;
1556:     const expected = transcript.value
1557:       .find((dealer) => dealer.dealerSeat === dealerSeat)
1558:       ?.shares.find((share) => share.envelope.body.holder.seat === holderSeat)?.envelope;
1559:     if (!expected || escrowShareEnvelopeHash(expected) !== escrowShareEnvelopeHash(envelope))
1560:       return failure(
1561:         'online-ceremony-escrow',
1562:         'Post-consent dispute does not reference the pinned escrow delivery',
1563:       );
1564:     return success(undefined);
1565:   }
1566: 
1567:   async #publishLocalDispute(
1568:     manifest: GenesisBody,
1569:     dealerSeat: Seat,

### packages/protocol/src/online-ceremony.ts lines 1617–1642
1617:   async #resumeEscrowDisclosures(): Promise<Result<boolean>> {
1618:     for (const roster of this.#escrowRosters.filter((item) => item.eligible)) {
1619:       for (const holder of roster.holders) {
1620:         for (const kind of ['escrow-dispute', 'escrow-invalid'] as const) {
1621:           const key = this.#packetKey(kind, holder.seat, roster.dealer.seat);
1622:           // oxlint-disable-next-line no-await-in-loop -- Bounded fixed evidence slots precede new output.
1623:           const bytes = await this.#options.store.load(key);
1624:           if (!bytes) continue;
1625:           const owner = this.#ownerDevice(holder.seat);
1626:           if (!owner) return failure('online-ceremony-escrow', 'Disclosure owner is missing');
1627:           const packet = verifyOnlineCeremonyPacket(bytes, owner, this.#freezeHash, this.#nonce);
1628:           if (!packet.ok) return packet;
1629:           // oxlint-disable no-await-in-loop -- A saved disclosure must retire/pause before returning.
1630:           const handled =
1631:             kind === 'escrow-dispute'
1632:               ? await this.#acceptDisputePacket(packet.value, bytes)
1633:               : await this.#acceptInvalidPacket(packet.value, bytes);
1634:           // oxlint-enable no-await-in-loop
1635:           if (!handled.ok) return handled;
1636:           if (this.#disclosureBytes.has(key)) return success(true);
1637:         }
1638:       }
1639:     }
1640:     return success(false);
1641:   }
1642: 

### packages/protocol/src/escrow-lifecycle.ts lines 88–126
88: }
89: 
90: /**
91:  * Device-global durable storage. A browser implementation must use a
92:  * transactionally persistent store shared by every tab for this identity.
93:  * This process-local memory implementation is only a test fixture.
94:  * The integration layer must preserve each permanent master reservation and
95:  * clear retained envelope bytes only after validating the certified genesis.
96:  */
97: export interface EscrowLifecycleStore {
98:   load(id: string): Promise<Uint8Array | null>;
99:   putIfAbsent(id: string, bytes: Uint8Array): Promise<boolean>;
100:   /** Atomic byte-exact compare-and-swap; true only after durable commit. */
101:   compareAndSwap(id: string, expected: Uint8Array, replacement: Uint8Array): Promise<boolean>;
102:   /** Shared device lock, required when this store is used for live delivery. */
103:   withCeremonyLock?<T>(ceremonyId: string, task: () => Promise<T>): Promise<T>;
104: }
105: 
106: export class MemoryEscrowLifecycleStore implements EscrowLifecycleStore {
107:   readonly #records = new Map<string, Uint8Array>();
108:   readonly #locks = new Map<string, Promise<void>>();
109: 
110:   async withCeremonyLock<T>(ceremonyId: string, task: () => Promise<T>): Promise<T> {
111:     const previous = this.#locks.get(ceremonyId) ?? Promise.resolve();
112:     let release!: () => void;
113:     const current = new Promise<void>((resolve) => {
114:       release = resolve;
115:     });
116:     this.#locks.set(ceremonyId, current);
117:     await previous;
118:     try {
119:       return await task();
120:     } finally {
121:       if (this.#locks.get(ceremonyId) === current) this.#locks.delete(ceremonyId);
122:       release();
123:     }
124:   }
125: 
126:   async load(id: string): Promise<Uint8Array | null> {

### packages/protocol/src/escrow-ceremony.ts lines 38–46
38: 
39: /** The adapter must use a device-wide lock shared by every local tab. */
40: export interface EscrowCeremonyStore extends EscrowLifecycleStore {
41:   withCeremonyLock<T>(ceremonyId: string, task: () => Promise<T>): Promise<T>;
42: }
43: 
44: /** Enqueue synchronously. A network completion is not awaited under the lock. */
45: export type CeremonySend<T> = (message: T) => undefined;
46: 

### packages/protocol/src/escrow-ceremony.ts lines 410–453
410:   async receiveDispute(
411:     envelopeValue: EscrowShareEnvelope,
412:     disputeValue: EscrowShareDispute,
413:   ): Promise<Result<void>> {
414:     const envelope = copy(envelopeValue);
415:     const dispute = copy(disputeValue);
416:     return this.#locked(() => this.#handleDispute(envelope, dispute, false));
417:   }
418: 
419:   async #handleDispute(
420:     envelope: EscrowShareEnvelope,
421:     dispute: EscrowShareDispute,
422:     local: boolean,
423:     publish?: CeremonySend<EscrowShareDispute>,
424:   ): Promise<Result<void>> {
425:     const verdict = verifyEscrowShareDispute(dispute, envelope, this.#manifest);
426:     if (!verdict.ok) return verdict;
427:     if (local && verdict.value.kind !== 'bad-share')
428:       return failure('escrow-dispute-local', 'A local holder cannot publish a false complaint');
429:     // Dispute intake must continue for later authenticated disclosures after
430:     // consent; the outgoing-action barrier belongs only on sign/send paths.
431:     const active = await checkEscrowCeremonyActive(this.#manifest, this.#store);
432:     if (
433:       !active.ok &&
434:       ![
435:         'escrow-ceremony-consenting',
436:         'escrow-ceremony-completed',
437:         'escrow-ceremony-retired',
438:       ].includes(active.error.code)
439:     )
440:       return active;
441:     const { dealerSeat, holderSeat } = dispute.body;
442:     const recordId = `escrow-dispute/${this.#ceremonyId}/${dealerSeat}/${holderSeat}`;
443:     const record = canonicalEncode({ envelope, dispute, verdict: verdict.value });
444:     const previous = await this.#store.load(recordId);
445:     if (!active.ok && active.error.code === 'escrow-ceremony-retired' && previous === null)
446:       return failure('escrow-ceremony-retired', 'Only an exact retained dispute can be retried');
447:     if (previous === null && !(await this.#store.putIfAbsent(recordId, record))) {
448:       const winner = await this.#store.load(recordId);
449:       if (!winner || !sameBytes(winner, record))
450:         return failure('escrow-dispute-record', 'Another disclosure is retained');
451:     } else if (previous !== null && !sameBytes(previous, record)) {
452:       return failure('escrow-dispute-record', 'Another disclosure is retained');
453:     }

### Prior committed apps/web/src/session/online-game.ts
import { canonicalDecode, canonicalEncode, toBase64Url } from '@cp2p/codec';
import { G, encodePoint, identityFromSecret, scalarFromBytes, scalePoint } from '@cp2p/crypto';
import { RandomBot } from '@cp2p/bots';
import { success } from '@cp2p/engine';
import type { Engine, Seat } from '@cp2p/engine';
import {
  createBeaconSecretSource,
  createDeckSecretSource,
  createHandSecretSource,
  createStealSecretSource,
  deckCeremonyId,
  decksReady,
  genesisDigest,
  entryHash,
  initialProposalContext,
  replayCertifiedPrefix,
  transferChangeSchema,
  validateTransferOwnedMaterial,
  P2PSession,
  validateDeckCeremony,
  validateGenesisOnlineStart,
  VerifiedSessionDriver,
} from '@cp2p/protocol';
import type {
  BeaconSecretProvider,
  BeaconSecretSource,
  DeckSourceFactory,
  EscrowCeremonyStore,
  Genesis,
  LobbyFreezeAgreement,
  LogEntry,
  LogContext,
  CertifiedEntry,
  ProtocolClock,
  ProtocolJournal,
  ReplayPolicy,
  GameSession,
  SessionAuditRunner,
  SignedDeckPass,
  SignedGameSeatBinding,
  Transport,
} from '@cp2p/protocol';
import {
  acquireActiveGameWriterLease,
  IndexedDbProtocolJournal,
  IndexedDbPublicSnapshotStore,
} from '@cp2p/storage';
import type { GameWriterLease } from '@cp2p/storage';
import * as v from 'valibot';
import type { OwnedSeatMaterial } from './online-credentials.js';
import { createOnlineGameTransport } from './online-game-transport.js';
import type { OnlineDeviceRoutes, OnlineGameTransport } from './online-game-transport.js';
import { createOnlineGameCandidateStore } from './online-game-candidates.js';
import { createSessionAuditRunner } from './audit-worker-client.js';
import { createOnlineGameHistoryWriter } from './online-game-history-writer.js';
import { createOnlineGameActivityWriter } from './online-game-activity.js';
import { browserEntropy, randomIndex, randomSeed } from './random.js';

type OnlineJournal = ProtocolJournal & { close(): Promise<void> };

export interface OnlineGameRuntime {
  readonly acquireLease?: typeof acquireActiveGameWriterLease;
  readonly createJournal?: (
    gameId: string,
    keyBinding: { recordKey: string; bytes: Uint8Array },
  ) => OnlineJournal;
  readonly auditRunner?: SessionAuditRunner;
}

export interface OnlineGameInput {
  readonly entry: LogEntry;
  readonly transcripts: readonly { deckId: string; passes: readonly SignedDeckPass[] }[];
  readonly agreement: LobbyFreezeAgreement;
  readonly bindings: readonly SignedGameSeatBinding[];
  readonly material: readonly OwnedSeatMaterial[];
  readonly deviceTransport: Transport;
  readonly store: EscrowCeremonyStore;
  readonly clock: ProtocolClock;
  readonly engine: Engine;
  readonly botDelayMs?: number;
  readonly signal?: AbortSignal;
  /** Immediate fatal fence for an unexpectedly lost exclusive game writer. */
  readonly onFatal?: (error: Error) => void;
  /** Reports local history-metadata persistence failures without affecting gameplay. */
  readonly onHistoryMetadataError?: (error: Error) => void;
  readonly onDeviceRoutes?: (routes: OnlineDeviceRoutes) => void;
  /** Resume preserves history; the built-in journal may initialize only an atomically proven unused slot. */
  readonly journalMode?: 'fresh-or-restore' | 'restore-only';
}

export interface OnlineGame<T extends GameSession = P2PSession> {
  readonly gameId: string;
  readonly genesis: Genesis;
  readonly seat: Seat;
  readonly session: T;
  close(): Promise<void>;
}

/** Opens only an authenticated, fully verified ceremony result under an exclusive game writer. */
export async function openOnlineGame(
  supplied: OnlineGameInput,
  runtime: OnlineGameRuntime = {},
): Promise<OnlineGame> {
  // Retain detached public evidence across asynchronous lease and storage work.
  const input = {
    ...supplied,
    entry: copyEvidence(supplied.entry),
    transcripts: copyEvidence(supplied.transcripts),
    agreement: copyEvidence(supplied.agreement),
    bindings: copyEvidence(supplied.bindings),
  };
  const material = input.material.map((item) => ({
    ...item,
    signingKey: new Uint8Array(item.signingKey),
    master: new Uint8Array(item.master),
  }));
  let journal: OnlineJournal | null = null;
  let snapshotStore: IndexedDbPublicSnapshotStore | null = null;
  let lease: GameWriterLease | null = null;
  let transport: OnlineGameTransport | null = null;
  let session: P2PSession | null = null;
  let historyWriter: ReturnType<typeof createOnlineGameHistoryWriter> | null = null;
  let activityWriter: ReturnType<typeof createOnlineGameActivityWriter> | null = null;
  let terminalHead: { seq: number; hash: string } | null = null;
  let leaseLost = false;
  const providers = new Map<Seat, BeaconSecretProvider>();
  const checkCancelled = () => {
    if (input.signal?.aborted || leaseLost)
      throw new DOMException('Online game opening was cancelled', 'AbortError');
  };
  const stopOutput = () => transport?.dispose();
  input.signal?.addEventListener('abort', stopOutput, { once: true });
  const cleanup = async () => {
    input.signal?.removeEventListener('abort', stopOutput);
    historyWriter?.stop();
    activityWriter?.stop();
    try {
      session?.dispose();
      await session?.flush();
    } finally {
      await historyWriter?.flush();
      await activityWriter?.flush();
      transport?.dispose();
      for (const provider of providers.values()) provider.dispose();
      for (const item of material) {
        item.signingKey.fill(0);
        item.master.fill(0);
      }
      try {
        try {
          await snapshotStore?.close();
        } finally {
          await journal?.close();
        }
      } finally {
        await lease?.close();
      }
    }
  };
  try {
    checkCancelled();
    const policy: ReplayPolicy = {
      genesis: {
        verifyCommitments(genesis) {
          const decks = validateDeckCeremony(genesis, input.transcripts);
          return decks.ok ? success(undefined) : decks;
        },
      },
      entry: {},
    };
    const checked = initialProposalContext(input.entry, input.engine, policy);
    if (!checked.ok) throw new Error(checked.error.message);
    const { genesis, state, crypto } = checked.value.log;
    const startup = validateGenesisOnlineStart(genesis);
    if (!startup.ok) throw new Error(startup.error.message);
    if (!crypto) throw new Error('Verified game commitments are missing');
    const humans = material.filter((seat) => seat.kind === 'human');
    const local = humans[0];
    if (humans.length !== 1 || !local) throw new Error('Stored material needs one human seat');
    lease = await (runtime.acquireLease ?? acquireActiveGameWriterLease)(genesis.gameId, {
      onLost(error) {
        leaseLost = true;
        transport?.dispose();
        session?.dispose();
        try {
          input.onFatal?.(error);
        } catch {
          // Reporting failure cannot restore authority or resume output.
        }
      },
    });
    checkCancelled();
    if (!lease) throw new Error('This game is already active in another tab');
    const digest = genesisDigest(genesis);
    const keyBinding = {
      recordKey: `online-game/${digest}/keys`,
      bytes: canonicalEncode({
        protocol: 'online-game-keys-v1',
        genesisDigest: digest,
        devicePeer: input.deviceTransport.self,
        humanSeat: local.seat,
        seats: material,
      }),
    };
    try {
      journal = runtime.createJournal
        ? runtime.createJournal(genesis.gameId, keyBinding)
        : new IndexedDbProtocolJournal(genesis.gameId, { keyBinding });
    } finally {
      keyBinding.bytes.fill(0);
    }
    // Vault-bound journals use an injected factory but still have the same durable public cache.
    if (journal instanceof IndexedDbProtocolJournal)
      snapshotStore = new IndexedDbPublicSnapshotStore(genesis.gameId);
    const saved = await journal.load();
    checkCancelled();
    if (saved && entryHash(saved.genesis) !== entryHash(input.entry))
      throw new Error('Stored game history differs from the certified online start');
    let installed: LogContext | null =
      checked.value.log.authority?.controllers.find((seat) => seat.seat === local.seat)
        ?.publicKey === local.peerId
        ? checked.value.log
        : null;
    let priorKey = checked.value.log.authority?.controllers.find(
      (seat) => seat.seat === local.seat,
    )?.publicKey;
    const replayed = saved
      ? replayCertifiedPrefix(
          saved.genesis,
          saved.entries,
          input.engine,
          policy,
          (_entry, next) => {
            if (!terminalHead && next.log.state.result)
              terminalHead = { seq: next.log.head.seq, hash: entryHash(next.log.head) };
            const key = next.log.authority?.controllers.find(
              (seat) => seat.seat === local.seat,
            )?.publicKey;
            if (key !== priorKey && key === local.peerId) installed = next.log;
            priorKey = key;
            return success(undefined);
          },
        )
      : success({ context: checked.value });
    if (!replayed.ok) throw new Error(replayed.error.message);
    const current = replayed.value.context.log;
    if (!installed) throw new Error('Stored game key has no certified owning generation');
    // The durable binding contains exactly the seats installed with this human
    // key. Later recovery adds separately persisted bots; a return can retire one.
    if (current.crypto && decksReady(current.crypto.decks)) {
      const ownedMaterial = validateTransferOwnedMaterial(
        {
          protocol: 'online-game-keys-v1',
          genesisDigest: digest,
          devicePeer: input.deviceTransport.self,
          humanSeat: local.seat,
          seats: material,
        },
        { ...installed, crypto: current.crypto },
      );
      if (!ownedMaterial.ok) throw new Error(ownedMaterial.error.message);
      for (const seat of ownedMaterial.value.seats) {
        seat.signingKey.fill(0);
        seat.master.fill(0);
      }
    } else {
      // Before certified deck setup only the original frozen owners can open.
      // Driver/source checks below validate the available deck and beacon data.
      const owned = genesis.seats.filter(
        (seat) =>
          seat.seat === local.seat || (seat.kind === 'bot' && seat.botHost === local.peerId),
      );
      if (
        installed.head.seq !== 0 ||
        material.length !== owned.length ||
        material.some(
          (item, index) =>
            item.seat !== owned[index]?.seat ||
            item.kind !== owned[index]?.kind ||
            item.peerId !== owned[index]?.publicKey,
        )
      )
        throw new Error('Stored game keys differ from the frozen device-owned seats');
      for (const item of material) {
        const identity = identityFromSecret(item.signingKey);
        try {
          if (
            identity.peerId !== item.peerId ||
            encodePoint(scalePoint(G, scalarFromBytes(item.master, { nonzero: true }))) !==
              startup.value.bindings.masters.find((entry) => entry.seat === item.seat)?.masterPub
          )
            throw new Error('Stored game secrets do not match the certified identity');
        } finally {
          identity.secretKey.fill(0);
        }
      }
    }
    const projection = createOnlineGameTransport({
      deviceTransport: input.deviceTransport,
      validatedGenesis: { genesis, state },
      agreement: input.agreement,
      bindings: input.bindings,
      certifiedHistory: {
        genesisEntry: input.entry,
        entries: saved?.entries ?? [],
        engine: input.engine,
        policy,
      },
    });
    if (!projection.ok) throw new Error(projection.error.message);
    transport = projection.value;
    const human = current.authority?.controllers.find(
      (seat) => seat.seat === local.seat && seat.kind === 'human' && seat.status === 'active',
    );
    if (!human || human.publicKey !== local.peerId || transport.self !== local.peerId)
      throw new Error('The stored human key no longer controls this seat');
    const activeMaterial = material.filter((item) =>
      current.authority?.controllers.some(
        (seat) =>
          seat.seat === item.seat &&
          seat.kind === item.kind &&
          seat.status === 'active' &&
          seat.hostSeat === human.seat &&
          seat.publicKey === item.peerId,
      ),
    );
    const ownedMaterial = new Map(activeMaterial.map((item) => [item.seat, item]));
    // The journal retains the exact installing-generation binding. Working
    // secrets belong only to the seats still controlled at the restored head.
    for (const item of material) {
      if (ownedMaterial.has(item.seat)) continue;
      item.signingKey.fill(0);
      item.master.fill(0);
    }
    const masterFor = (seat: Seat) => {
      const entry = ownedMaterial.get(seat);
      if (!entry) throw new Error('Cannot derive secrets for another device');
      return entry.master;
    };
    const deckSource: DeckSourceFactory = (deckId, seat) => {
      const definition = crypto.decks.decks.find(
        (deck) => deck.commitment.definition.deckId === deckId,
      )?.commitment.definition;
      if (!definition) throw new Error('Unknown verified deck');
      return createDeckSecretSource(masterFor(seat), definition, seat);
    };
    const stealSource = (seat: Seat) => {
      const owner = genesis.seats.find((item) => item.seat === seat);
      if (!owner) throw new Error("Cannot derive another device's encryption key");
      return createStealSecretSource(masterFor(seat), genesis.ceremonyNonce, seat, owner.publicKey);
    };
    const chain = crypto.beacon.chains.find((item) => item.seat === human.seat);
    if (!chain) throw new Error('Missing human beacon commitment');
    const beacon = createBeaconSecretSource(
      local.master,
      { ceremonyId: deckCeremonyId(genesis), seat: human.seat },
      chain.length,
    );
    providers.set(human.seat, beacon);
    if (toBase64Url(beacon.initialCommitment.tip) !== chain.tip)
      throw new Error('Stored master differs from the frozen beacon chain');
    const beaconSources = new Map<Seat, BeaconSecretSource>();
    for (const item of activeMaterial) {
      if (item.kind !== 'bot') continue;
      const originalChain = crypto.beacon.chains.find((candidate) => candidate.seat === item.seat);
      if (!originalChain) {
        if (genesis.seats.find((seat) => seat.seat === item.seat)?.kind === 'bot') continue;
        throw new Error('Missing hosted-seat beacon commitment');
      }
      const provider = createBeaconSecretSource(
        item.master,
        { ceremonyId: deckCeremonyId(genesis), seat: item.seat },
        originalChain.length,
      );
      providers.set(item.seat, provider);
      if (toBase64Url(provider.initialCommitment.tip) !== originalChain.tip)
        throw new Error('Hosted master differs from the frozen beacon chain');
      beaconSources.set(item.seat, provider.source);
    }
    const bot = new RandomBot();
    const botKeys = new Map(
      activeMaterial
        .filter((item) => item.kind === 'bot')
        .map((item) => [item.seat, item.signingKey]),
    );
    const publicSnapshots = snapshotStore;
    const options = {
      genesisEntry: input.entry,
      engine: input.engine,
      policy,
      seat: human.seat,
      secretKey: local.signingKey,
      transport,
      clock: input.clock,
      journal,
      ...(publicSnapshots
        ? { savePublicSnapshot: (snapshot: unknown) => publicSnapshots.saveCommitted(snapshot) }
        : {}),
      onCertifiedNonMembershipCommit(head: { readonly seq: number; readonly hash: string }) {
        const pruned = projection.value.pruneRetired(head);
        if (pruned.ok && pruned.value) {
          const routes = projection.value.deviceRoutes();
          if (routes) input.onDeviceRoutes?.(routes);
        }
        return pruned.ok ? success(undefined) : pruned;
      },
      onMembershipCommitted(entries: readonly CertifiedEntry[]) {
        const routed = projection.value.advanceCertifiedHistory(entries);
        const payload = entries.at(-1)?.entry.payload;
        const transfer =
          payload?.kind === 'membership' ? v.safeParse(transferChangeSchema, payload.change) : null;
        const replacements =
          transfer?.success && transfer.output.kind === 'transfer-activate'
            ? transfer.output.statement.replacements
            : [];
        const retired = !routed.ok && routed.error.code === 'online-transport-retired';
        if (routed.ok) {
          const routes = projection.value.deviceRoutes();
          if (routes) input.onDeviceRoutes?.(routes);
        }
        for (const item of material) {
          if (
            !retired &&
            !replacements.some(
              (replacement) =>
                replacement.seat === item.seat && replacement.oldPublicKey === item.peerId,
            )
          )
            continue;
          item.signingKey.fill(0);
          item.master.fill(0);
          ownedMaterial.delete(item.seat);
          providers.get(item.seat)?.dispose();
          providers.delete(item.seat);
        }
        // The final commit was sent with the old route. Retirement disposes this
        // immutable signer/transport; the destination opens a fresh instance.
        return retired ? success(undefined) : routed;
      },
      botKeys,
      botDelayMs: input.botDelayMs ?? 800,
      decideBot: (
        view: Parameters<RandomBot['decide']>[0],
        pending: Parameters<RandomBot['decide']>[1],
      ) => bot.decide(view, pending, { int: (max) => randomIndex(browserEntropy, max) }),
      beaconSource: beacon.source,
      beaconSources,
      beaconContributions: input.store,
      deckSetupPasses: input.transcripts.flatMap(({ deckId, passes }) =>
        passes.map((pass) => ({ deckId, pass })),
      ),
      createDeckSource: deckSource,
      deckContributions: input.store,
      countContributionStore: input.store,
      stealDeliveryStore: input.store,
      cheatCandidateStore: createOnlineGameCandidateStore(input.store, digest),
      recoveryStore: input.store,
      transferPrivateOutbox: input.store,
      transferPrivateImportStore: input.store,
      recoveryParticipant: {
        store: input.store,
        privateEntropy: () => randomSeed(browserEntropy),
        encryptionSecret: () => {
          const source = stealSource(human.seat);
          try {
            return source.encryptionSecret();
          } finally {
            source.dispose();
          }
        },
      },
      createDriver: (
        engine: Engine,
        approved: Genesis,
        _clock: ProtocolClock,
        seats: readonly Seat[],
      ) =>
        new VerifiedSessionDriver(
          engine,
          approved,
          seats,
          deckSource,
          (seat) => createHandSecretSource(masterFor(seat), digest, seat),
          stealSource,
        ),
      masterReveal: {
        store: input.store,
        async loadOwnedMaster(seat: Seat) {
          const item = ownedMaterial.get(seat);
          return item ? new Uint8Array(item.master) : null;
        },
      },
      auditRunner: runtime.auditRunner ?? createSessionAuditRunner(),
    };
    // The built-in journal returns null only when genesis, entries, safety and
    // its bound voting-key record are all absent in one IndexedDB transaction.
    // Injected journals have no equivalent proof and must remain restore-only.
    if (input.journalMode === 'restore-only' && !saved && runtime.createJournal)
      throw new Error('The certified online game journal is missing');
    const opened = await lease.run(() => {
      checkCancelled();
      return saved ? P2PSession.restore(options) : P2PSession.create(options);
    });
    if (!opened.ok) throw new Error(opened.error.message);
    session = opened.value;
    checkCancelled();
    historyWriter = createOnlineGameHistoryWriter({
      store: input.store,
      gameId: genesis.gameId,
      genesisDigest: digest,
      session,
      localHumanSeat: human.seat,
      terminalHead,
      ...(input.onHistoryMetadataError ? { onError: input.onHistoryMetadataError } : {}),
    });
    activityWriter = createOnlineGameActivityWriter({
      store: input.store,
      gameId: genesis.gameId,
      genesisDigest: digest,
      session,
      ...(input.onHistoryMetadataError ? { onError: input.onHistoryMetadataError } : {}),
    });
    const routes = projection.value.deviceRoutes();
    if (routes) input.onDeviceRoutes?.(routes);
    let closing: Promise<void> | null = null;
    return {
      gameId: genesis.gameId,
      genesis,
      seat: human.seat,
      session,
      close() {
        closing ??= Promise.resolve().then(cleanup);
        return closing;
      },
    };
  } catch (error) {
    await cleanup();
    throw error;
  }
}

function copyEvidence<T>(value: T): T {
  // oxlint-disable-next-line typescript/no-unsafe-type-assertion -- The same canonical value is detached here and validated before use.
  return canonicalDecode(canonicalEncode(value)) as T;
}


### Prior committed apps/web/src/session/online-startup.ts
import {
  canonicalDecode,
  canonicalEncode,
  fromBase64Url,
  hashValue,
  toBase64Url,
  toHex,
} from '@cp2p/codec';
import { failure, success } from '@cp2p/engine';
import type { Engine, Result } from '@cp2p/engine';
import { OnlineCeremony, genesisDigest, verifyLobbyFreezeAgreement } from '@cp2p/protocol';
import type {
  EscrowCeremonyStore,
  LobbyController,
  LobbyFreezeAgreement,
  OnlineCeremonyProgress,
  LobbyState,
  ProtocolClock,
  Transport,
  Unsubscribe,
} from '@cp2p/protocol';
import { loadCeremonyMaterial, prepareCeremonyMaterial } from './online-credentials.js';
import type { DisposableOnlineIdentity, OwnedCeremonyMaterial } from './online-credentials.js';
import { openOnlineGame } from './online-game.js';
import type { OnlineGame, OnlineGameRuntime } from './online-game.js';
import type { OnlineDeviceRoutes } from './online-game-transport.js';
import type { OnlineInvite } from './online-invite.js';
import { assertSupportedOnlineGameVersion, saveOnlineGameRecord } from './online-game-records.js';
import type { SavedOnlineGameRecord } from './online-game-records.js';
import { loadActiveOnlineResume } from './online-resume-binding.js';

export interface OnlineStartupSnapshot {
  readonly phase: OnlineCeremonyProgress['phase'] | 'freezing' | 'opening' | 'playing' | 'halted';
  readonly awaitingSeats: readonly number[];
  readonly locallyConsented: boolean;
  readonly error: string | null;
  readonly gameId: string | null;
}

interface OnlineStartupBase {
  readonly invite: OnlineInvite;
  readonly identity: DisposableOnlineIdentity;
  readonly transport: Transport;
  readonly store: EscrowCeremonyStore;
  readonly clock: ProtocolClock;
  readonly engine: Engine;
  readonly gameRuntime?: OnlineGameRuntime;
  readonly onGameFatal?: (error: Error) => void;
  readonly onDeviceRoutes?: (routes: OnlineDeviceRoutes) => void;
}

export type OnlineStartupOptions = OnlineStartupBase &
  (
    | {
        readonly lobby: LobbyController;
        /** Removes unseated connections and freezes discovery before key disclosure. */
        readonly freezePeers: (peers: readonly string[]) => void;
        readonly resume?: never;
        readonly approved?: never;
      }
    | {
        readonly resume: SavedOnlineGameRecord;
        readonly lobby?: never;
        readonly freezePeers?: never;
        readonly approved?: never;
      }
    | {
        /** The worker receives this only after the main lobby formed every signed ACK. */
        readonly approved: LobbyFreezeAgreement;
        readonly lobby?: never;
        readonly freezePeers?: never;
        readonly resume?: never;
      }
  );

/** Owns the immutable transition from device-key lobby consent to a game-key session. */
export class OnlineStartup {
  private readonly listeners = new Set<() => void>();
  private readonly unsubscribers: Unsubscribe[] = [];
  private current: OnlineStartupSnapshot | null = null;
  private approved: LobbyFreezeAgreement | null = null;
  private material: Pick<OwnedCeremonyMaterial, 'keys' | 'dispose'> | null = null;
  private ceremony: OnlineCeremony | null = null;
  private activeGame: OnlineGame | null = null;
  private work: Promise<void> | null = null;
  private retry: unknown = null;
  private closed = false;
  private closing: Promise<void> | null = null;
  private activationAttempted = false;
  private revoked = false;
  private stoppingGame: Promise<void> | null = null;
  private readonly abort = new AbortController();
  private readonly resume: SavedOnlineGameRecord | null;
  private readonly invite: OnlineInvite;

  constructor(private readonly options: OnlineStartupOptions) {
    this.invite = copyEvidence(options.invite);
    if (options.resume) {
      assertSupportedOnlineGameVersion(options.resume.result.genesis);
      if (options.resume.result.entry.payload.kind === 'genesis')
        assertSupportedOnlineGameVersion(options.resume.result.entry.payload.genesis);
    }
    this.resume = options.resume ? copyEvidence(options.resume) : null;
    if (this.resume) {
      const checked = verifyLobbyFreezeAgreement(this.resume.agreement);
      if (
        !checked.ok ||
        genesisDigest(this.resume.result.genesis) !== this.resume.genesisDigest ||
        this.resume.result.genesis.gameId !== this.resume.gameId ||
        !sameBytes(canonicalEncode(this.resume.invite), canonicalEncode(this.invite))
      )
        throw new Error('Saved online game does not match its signed agreement');
      this.approved = checked.value;
      this.current = {
        phase: 'opening',
        awaitingSeats: [],
        locallyConsented: true,
        error: null,
        gameId: this.resume.gameId,
      };
    } else if (options.approved) {
      const checked = verifyLobbyFreezeAgreement(options.approved);
      if (!checked.ok || checked.value.state.lobbyId !== this.invite.roomId)
        throw new Error('Approved online start has an invalid signed agreement');
      this.approved = checked.value;
      this.current = {
        phase: 'frozen',
        awaitingSeats: [],
        locallyConsented: true,
        error: null,
        gameId: null,
      };
    }
    if (options.lobby) this.unsubscribers.push(options.lobby.onChange(() => this.observe()));
    this.unsubscribers.push(options.transport.onPeerChange(() => this.observe()));
    this.observe();
  }

  snapshot(): OnlineStartupSnapshot | null {
    return this.current
      ? { ...this.current, awaitingSeats: [...this.current.awaitingSeats] }
      : null;
  }

  agreement(): LobbyFreezeAgreement | null {
    // The verifier returns detached data; callers never receive the retained snapshot.
    if (!this.approved) return null;
    const checked = verifyLobbyFreezeAgreement(this.approved);
    return checked.ok ? checked.value : null;
  }

  game(): OnlineGame | null {
    return this.activeGame;
  }

  subscribe(listener: () => void): Unsubscribe {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  begin(): Result<void> {
    if (!this.options.lobby)
      return failure('online-start-resume', 'A saved game cannot start a new lobby ceremony');
    if (this.closed || this.approved || this.current)
      return failure('online-start-active', 'An online start is already active');
    const bytes = new Uint8Array(32);
    globalThis.crypto.getRandomValues(bytes);
    return this.options.lobby.start(toBase64Url(bytes));
  }

  /** Retry this exact attempt after storage or writer contention, never a new freeze. */
  async retryFailed(): Promise<Result<void>> {
    if (
      this.closed ||
      this.revoked ||
      this.activeGame ||
      this.work ||
      this.current?.phase !== 'error'
    )
      return failure('online-start-retry', 'There is no failed start ready to retry');
    if (this.ceremony && !this.ceremony.result()) {
      this.ceremony.dispose();
      await this.ceremony.flush();
      this.ceremony = null;
    }
    if (this.closed) return failure('online-start-closed', 'The room is closed');
    this.activationAttempted = false;
    this.update({
      phase: 'frozen',
      awaitingSeats: [],
      locallyConsented: this.current.locallyConsented,
      error: null,
      gameId: this.current.gameId,
    });
    this.observe();
    return success(undefined);
  }

  /** Closing stops output immediately, then drains writes before the room releases its lock. */
  close(): Promise<void> {
    if (this.closing) return this.closing;
    this.closed = true;
    this.abort.abort();
    if (this.retry !== null) this.options.clock.clearTimeout(this.retry);
    this.retry = null;
    for (const unsubscribe of this.unsubscribers) unsubscribe();
    this.ceremony?.dispose();
    this.listeners.clear();
    this.closing = Promise.resolve().then(() => this.releaseResources());
    return this.closing;
  }

  private async releaseResources(): Promise<void> {
    try {
      await this.work;
      await this.ceremony?.flush();
      await this.stoppingGame;
      await this.activeGame?.close();
    } finally {
      this.material?.dispose();
      this.material = null;
    }
  }

  private update(value: OnlineStartupSnapshot): void {
    if (this.closed) return;
    this.current = value;
    for (const listener of this.listeners) {
      try {
        listener();
      } catch {
        /* A view cannot interrupt the durable start. */
      }
    }
  }

  private fail(error: unknown): void {
    if (this.revoked) return;
    this.update({
      phase: 'error',
      awaitingSeats: [],
      locallyConsented: this.ceremony?.snapshot().locallyConsented ?? Boolean(this.resume),
      error: error instanceof Error ? error.message : 'Online startup failed',
      gameId: this.resume?.gameId ?? this.current?.gameId ?? null,
    });
  }

  private observe(): void {
    if (
      this.closed ||
      this.revoked ||
      this.work ||
      this.activeGame ||
      this.current?.phase === 'error'
    )
      return;
    this.work = Promise.resolve()
      .then(() => this.advance())
      .catch((error: unknown) => this.fail(error))
      .finally(() => {
        this.work = null;
        if (this.closed || this.revoked || this.activeGame || this.current?.phase === 'error')
          return;
        if (this.retry === null) {
          this.retry = this.options.clock.setTimeout(() => {
            this.retry = null;
            this.observe();
          }, 1_000);
        }
      });
  }

  private async advance(): Promise<void> {
    if (this.closed || this.revoked) return;
    if (!this.approved) {
      const lobby = this.options.lobby;
      if (!lobby) throw new Error('Saved game has no verified freeze agreement');
      const state = lobby.state();
      if (!state || state.status !== 'starting') return;
      if (
        !state.seats.some(
          (seat) => seat.kind === 'human' && seat.peer === this.options.identity.peerId,
        )
      )
        return;
      this.update({
        phase: 'freezing',
        awaitingSeats: [],
        locallyConsented: false,
        error: null,
        gameId: null,
      });
      const freezeHash = toHex(hashValue(state));
      await this.pin(`online-freeze/${this.options.identity.peerId}/${state.ceremonyNonce}`, {
        protocol: 'online-freeze-pin-v1',
        freezeHash,
      });
      if (this.closed) return;
      const current = lobby.state();
      if (!current || toHex(hashValue(current)) !== freezeHash) return;
      // Exact ACK retries also let the host retransmit a dropped all-human agreement.
      const acknowledged = lobby.ackFreeze();
      if (!acknowledged.ok) return;
      const agreement = lobby.freezeAgreement();
      if (!agreement) return;
      const checked = verifyLobbyFreezeAgreement(agreement);
      if (!checked.ok) throw new Error(checked.error.message);
      const approved = checked.value;
      if (toHex(hashValue(approved.state)) !== freezeHash)
        throw new Error('Lobby changed after the locally pinned freeze');
      await this.pin(`online-start/${freezeHash}/agreement`, {
        protocol: 'online-browser-start-v1',
        invite: this.invite,
        agreement: approved,
      });
      if (this.closed) return;
      const freezePeers = this.options.freezePeers;
      if (!freezePeers) throw new Error('Fresh online start has no roster freeze');
      freezePeers(
        approved.state.seats.flatMap((seat) => (seat.kind === 'human' ? [seat.peer] : [])),
      );
      this.approved = approved;
    }
    if (this.resume && !this.ceremony) {
      const active = await loadActiveOnlineResume({
        store: this.options.store,
        record: this.resume,
        devicePeer: this.options.identity.peerId,
        engine: this.options.engine,
        includeMaterial: true,
        ...(this.options.gameRuntime?.createJournal
          ? { createJournal: this.options.gameRuntime.createJournal }
          : {}),
      });
      if (this.closed) {
        active.material?.dispose();
        return;
      }
      const original = this.resume.result.genesis.seats.some(
        (seat) =>
          seat.seat === active.humanSeat &&
          seat.kind === 'human' &&
          seat.publicKey === active.gamePeer &&
          this.approved?.state.seats.some(
            (frozen) =>
              frozen.seat === seat.seat &&
              frozen.kind === 'human' &&
              frozen.peer === this.options.identity.peerId,
          ),
      );
      if (!original) {
        if (!active.material) throw new Error('Transferred device has no active owned binding');
        this.material?.dispose();
        this.material = active.material;
        await this.openTransferredResume();
        return;
      }
      active.material?.dispose();
    }
    if (!this.ceremony) {
      const approved = this.approved;
      if (!this.resume && this.options.approved) {
        const freezeHash = toHex(hashValue(approved.state));
        await this.requirePin(
          `online-freeze/${this.options.identity.peerId}/${approved.state.ceremonyNonce}`,
          { protocol: 'online-freeze-pin-v1', freezeHash },
        );
        await this.pin(`online-start/${freezeHash}/agreement`, {
          protocol: 'online-browser-start-v1',
          invite: this.invite,
          agreement: approved,
        });
      }
      if (this.resume) {
        const freezeHash = toHex(hashValue(approved.state));
        await this.requirePin(
          `online-freeze/${this.options.identity.peerId}/${approved.state.ceremonyNonce}`,
          {
            protocol: 'online-freeze-pin-v1',
            freezeHash,
          },
        );
        await this.requirePin(`online-start/${freezeHash}/agreement`, {
          protocol: 'online-browser-start-v1',
          invite: this.invite,
          agreement: approved,
        });
        await this.requirePin(`online-game/${this.resume.genesisDigest}/start`, {
          protocol: 'online-browser-game-v1',
          invite: this.invite,
          agreement: approved,
          result: this.resume.result,
        });
      }
      const nonce = approved.state.ceremonyNonce;
      if (!nonce) throw new Error('Frozen lobby has no ceremony nonce');
      const layout = approved.state.seats.map((seat) => {
        if (seat.kind === 'open') throw new Error('Frozen lobby still contains an open seat');
        return seat.kind === 'human'
          ? { seat: seat.seat, kind: seat.kind, devicePeerId: seat.peer }
          : { seat: seat.seat, kind: seat.kind, botHost: seat.botHost };
      });
      this.material?.dispose();
      this.material = null;
      const materialInput = {
        store: this.options.store,
        identity: this.options.identity,
        ceremonyNonce: fromBase64Url(nonce),
        layout,
      };
      this.material = this.resume
        ? await loadCeremonyMaterial(materialInput)
        : await prepareCeremonyMaterial(materialInput);
      if (this.closed) return;
      const created = OnlineCeremony.create({
        agreement: approved,
        transport: this.options.transport,
        clock: this.options.clock,
        deviceSigningKey: this.options.identity.secretKey,
        ownedSeats: this.material.keys,
        store: this.options.store,
        engine: this.options.engine,
        ...(this.resume ? { restoreResult: this.resume.result } : {}),
        ...(!this.resume && approved.state.hostPeer === this.options.identity.peerId
          ? { hostCreatedAt: Math.floor(this.options.clock.now()) }
          : {}),
      });
      if (!created.ok) throw new Error(created.error.message);
      this.ceremony = created.value;
      this.unsubscribers.push(
        this.ceremony.onChange((progress) => {
          if (progress.locallyConsented && progress.error === 'online-ceremony-disputed') {
            this.haltDisputedGame();
            return;
          }
          if (this.revoked) return;
          if (this.activeGame || this.activationAttempted) return;
          this.update({
            ...progress,
            phase:
              progress.locallyConsented && progress.phase === 'consent'
                ? 'waiting'
                : progress.phase,
            gameId: this.resume?.gameId ?? null,
          });
          this.observe();
        }),
      );
      const started = await this.ceremony.start();
      if (!started.ok) {
        // The coordinator emits this only after reading or persisting retirement.
        // Preserve that durable disposition instead of offering a generic retry.
        const progress = this.ceremony.snapshot();
        if (progress.phase === 'retired') {
          this.update({ ...progress, gameId: this.resume?.gameId ?? null });
          return;
        }
        throw new Error(started.error.message);
      }
      await this.ceremony.flush();
    }
    const result = this.ceremony.result();
    if (this.closed || this.revoked || !result || this.activationAttempted) return;
    if (this.resume && !sameBytes(canonicalEncode(result), canonicalEncode(this.resume.result)))
      throw new Error('Restored ceremony differs from the saved certified game');
    if (!this.material) throw new Error('Owned game material is unavailable');
    this.activationAttempted = true;
    this.update({
      phase: 'opening',
      awaitingSeats: [],
      locallyConsented: true,
      error: null,
      gameId: result.genesis.gameId,
    });
    if (!this.resume)
      await saveOnlineGameRecord(this.options.store, {
        invite: this.invite,
        agreement: this.approved,
        result,
      });
    if (this.closed || this.revoked) return;
    const game = await openOnlineGame(
      {
        ...result,
        agreement: this.approved,
        material: this.material.keys,
        deviceTransport: this.options.transport,
        store: this.options.store,
        clock: this.options.clock,
        engine: this.options.engine,
        signal: this.abort.signal,
        ...(this.options.onGameFatal ? { onFatal: this.options.onGameFatal } : {}),
        ...(this.options.onDeviceRoutes ? { onDeviceRoutes: this.options.onDeviceRoutes } : {}),
        ...(this.resume ? { journalMode: 'restore-only' as const } : {}),
      },
      this.options.gameRuntime,
    );
    if (this.closed || this.revoked) {
      await game.close();
      return;
    }
    this.activeGame = game;
    this.material.dispose();
    this.material = null;
    this.update({
      phase: 'playing',
      awaitingSeats: [],
      locallyConsented: true,
      error: null,
      gameId: game.gameId,
    });
  }

  private async openTransferredResume(): Promise<void> {
    const resume = this.resume;
    const material = this.material;
    const agreement = this.approved;
    if (!resume || !material || !agreement || this.closed || this.revoked)
      throw new Error('Transferred resume is incomplete');
    this.activationAttempted = true;
    this.update({
      phase: 'opening',
      awaitingSeats: [],
      locallyConsented: true,
      error: null,
      gameId: resume.gameId,
    });
    const game = await openOnlineGame(
      {
        ...resume.result,
        agreement,
        material: material.keys,
        deviceTransport: this.options.transport,
        store: this.options.store,
        clock: this.options.clock,
        engine: this.options.engine,
        signal: this.abort.signal,
        journalMode: 'restore-only',
        ...(this.options.onGameFatal ? { onFatal: this.options.onGameFatal } : {}),
        ...(this.options.onDeviceRoutes ? { onDeviceRoutes: this.options.onDeviceRoutes } : {}),
      },
      this.options.gameRuntime,
    ).finally(() => {
      material.dispose();
      if (this.material === material) this.material = null;
    });
    if (this.closed || this.revoked) {
      await game.close();
      return;
    }
    this.activeGame = game;
    this.update({
      phase: 'playing',
      awaitingSeats: [],
      locallyConsented: true,
      error: null,
      gameId: resume.gameId,
    });
  }

  private haltDisputedGame(): void {
    if (this.closed || this.revoked) return;
    this.revoked = true;
    // The coordinator has authenticated a secret disclosure, including after genesis.
    // Stop game output synchronously; preserve its public board and durable evidence.
    this.abort.abort();
    this.activeGame?.session.dispose();
    this.stoppingGame = this.activeGame?.close() ?? null;
    // close() will surface cleanup errors to the room owner after draining its work.
    void this.stoppingGame?.catch(() => undefined);
    if (this.retry !== null) this.options.clock.clearTimeout(this.retry);
    this.retry = null;
    this.update({
      phase: 'halted',
      awaitingSeats: [],
      locallyConsented: true,
      error: 'online-ceremony-disputed',
      gameId: this.activeGame?.gameId ?? this.current?.gameId ?? null,
    });
  }

  private async pin(id: string, value: unknown): Promise<void> {
    const bytes = canonicalEncode(value);
    const stored = this.options.store;
    await stored.withCeremonyLock(id, async () => {
      if (await stored.putIfAbsent(id, bytes)) return;
      const existing = await stored.load(id);
      if (
        !existing ||
        existing.length !== bytes.length ||
        existing.some((byte, index) => byte !== bytes[index])
      )
        throw new Error('Stored online start differs from the approved game');
    });
  }

  private async requirePin(id: string, value: unknown): Promise<void> {
    const bytes = canonicalEncode(value);
    const existing = await this.options.store.load(id);
    if (!existing || !sameBytes(existing, bytes))
      throw new Error('Saved online consent or game record is missing or differs');
  }
}

/** The worker durably pins the exact lobby state before the device signs its freeze ACK. */
export async function pinOnlineFreeze(
  store: EscrowCeremonyStore,
  self: string,
  supplied: LobbyState,
): Promise<string> {
  const state = copyEvidence(supplied);
  if (
    state.status !== 'starting' ||
    !state.ceremonyNonce ||
    !state.seats.some((seat) => seat.kind === 'human' && seat.peer === self)
  )
    throw new Error('Only a seated human can pin a starting lobby');
  const freezeHash = toHex(hashValue(state));
  const id = `online-freeze/${self}/${state.ceremonyNonce}`;
  const bytes = canonicalEncode({ protocol: 'online-freeze-pin-v1', freezeHash });
  await store.withCeremonyLock(id, async () => {
    if (await store.putIfAbsent(id, bytes)) return;
    const existing = await store.load(id);
    if (!existing || !sameBytes(existing, bytes))
      throw new Error('Stored online freeze differs from this lobby state');
  });
  return freezeHash;
}

function sameBytes(left: Uint8Array, right: Uint8Array): boolean {
  return left.length === right.length && left.every((byte, index) => byte === right[index]);
}

function copyEvidence<T>(value: T): T {
  // oxlint-disable-next-line typescript/no-unsafe-type-assertion -- Canonical data is detached and checked before use.
  return canonicalDecode(canonicalEncode(value)) as T;
}

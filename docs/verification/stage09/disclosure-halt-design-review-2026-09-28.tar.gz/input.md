Read-only correctness/security DESIGN review. No product code has been written. Use only supplied source, no tools. Requested model Claude Opus 5.5, effort medium.

First answer REQUIREMENT QUESTION: Does current durable disclosed waiting/halted behavior already meet the literal intended Stage09 criteria? docs09 says recoverable waiting until exact genesis assembled OR agreed disposition; authenticated disclosure retained, no silent normal gameplay. It does NOT explicitly require normal gameplay resume. Distinguish safety, restart recoverability, bounded liveness conditional on all signers, and whether a new disposition feature is actually required versus a test/wording gap. Prefer no new feature if existing behavior meets the actual requirement; explain precise unmet condition if not.

Provisional narrow design ONLY IF needed:
* Keep all signed genesis consents irrevocable; never remove registry promises, anti-equivocation slots, genesis or disclosure bytes. No attempt to make exposed shares secret again (valid-share false complaint still compromises privacy). Never release any original recovery shares.
* Separate startup disposition certificate, not a new quorum/membership transition: domain-separated versioned statement binds protocol/game identity, exact pinned final genesis digest, ceremony nonce/freeze hash, canonical authenticated disclosure evidence digest, and terminal outcome=abandoned-disclosure. Every ORIGINAL human genesis public key signs exact same statement; hosted bots/current replacement voter sets do not count. Offline signer means indefinitely durable waiting. Verify complete ordered original signer set, no duplicates, all signatures/evidence before acceptance.
* Sign only from exact locally persisted final body matching this device's irreversible genesis-consent digest; validate full deck/escrow evidence even when global genesis signatures have not assembled. A disclosure may arrive before global certificate assembly. Do not trust caller body/digest. If local body/promise missing, wait; never redraft/retract. One immutable disposition promise per genesis; same retry exact bytes.
* Durable promise BEFORE returning/transmitting disposition signature, under device-global shared ceremony/attempt locks and atomic CAS registry. Across all coordinators, if disposition promise commits first then no further old-game start/genesis completion or command/vote signing is allowed locally. Existing genesis signatures remain retained and possibly assembled elsewhere; unilateral disposition promise is a LOCAL signing fence only, not global cancellation. If active output already occurred, record exact certified head/check active-controller ownership and stop/drain game writer before promise. Must not claim that outstanding pre-promise signatures can be recalled.
* Every start/resume/import/transfer activation path checks durable local disposition fence under same ownership/writer boundary before acquiring signer or emitting. Race with asynchronous openOnlineGame checked after awaits; close acquired session on fence. Imported snapshot never carries permission to bypass local fence. Active transfers cannot blindly accept original identity disposition authority over replacement controllers: safest narrow guard rejects disposition signing once certified authority/membership has changed or a transfer is pending; remain waiting until separately governed resolution. Likewise finalized/audited games should reject new startup disposition rather than overwrite results. Review whether these restrictions make proposed feature too broad/unimplementable or whether truly preplay-only disposition suffices.
* Once all signatures verified, persist certificate/evidence atomically before displaying terminal abandoned result/new-room affordance. Retain journal/safety and retirement/fence forever for old keys; deletion cannot erase anti-equivocation. Restart recovers partial promises/signatures and retransmits identical wire; no gameplay resume. A fresh ceremony uses genuinely fresh nonce/master/game keys. Forged/conflicting/foreign evidence cannot halt unrelated game.

Potential conflicts requiring explicit critique:
1. Current #outgoing holds attempt lock while consent holds escrow lock; abort takes attempt then escrow. A new design must specify same lock order and cannot nest/reacquire same nonreentrant locks.
2. Key ownership may already have transferred or recovery occurred; all original humans are not necessarily current signing controllers. A startup-only certificate must not override certified later authority.
3. Active session has durable signed outbox/prepared votes and encrypted worker owner lock. A local fence requires signer-layer checks, not just UI revoked=true. Rejecting postplay disposition may conflict with requirement that disclosure can arrive after ready.
4. Full genesis assembly and storage may win concurrently with local promise; assembly itself is safe if it never authorizes new output after promise. Current completion does not retract signatures.
5. A terminal certificate assembled after some signers have already played cannot safely erase shared history/outcome.

Return: A) current criterion verdict/no-feature possibility, B) exact safe minimal scope, C) blockers in draft, D) required deterministic fail-before regressions, E) whether APPROVE DESIGN / REVISE / DO NOT IMPLEMENT pending clarification. Identify source references supporting claims. No generic feature expansion.


SOURCE docs/09-lobby-and-game-setup.md

1: # 09 — Lobby & Game Setup (first end-to-end P2P game)
2: 
3: ## Goal
4: 
5: Users can create a game, invite friends (link, code or QR), configure rules, fill seats with humans or bots, and start. Starting runs a **genesis ceremony** that produces the signed genesis entry with all cryptographic commitments. After this stage, real people on different networks can play a full base game P2P.
6: 
7: ## Prerequisites
8: 
9: Stages 05, 07 and 08 are complete.
10: 
11: ## 1. Lobby model
12: 
13: The lobby is a small replicated document owned by the **lobby host** (the creator; after a host disconnect, the lowest remaining peer). Unlike the game log, lobby edits are host-authoritative and simple: the host broadcasts `LOBBY_STATE { version, ... }`, and other peers send requests.
14: 
15: ```ts
16: interface LobbyState {
17:   version: number;
18:   lobbyId: string; // = signaling room id or random id in manual mode
19:   hostPeer: PeerId;
20:   name: string;
21:   seats: Array<{
22:     seat: Seat;
23:     kind: 'open' | 'human' | 'bot';
24:     peer?: PeerId;
25:     name?: string;
26:     colour: ColourId;
27:     ready: boolean;
28:     botLevel?: BotLevel;
29:     botHost?: PeerId;
30:   }>;
31:   spectators: PeerId[];
32:   config: GameConfigDraft; // modules + options + map choice + timers
33:   status: 'open' | 'starting' | 'started';
34: }
35: ```
36: 
37: Messages: `LOBBY_STATE`, `LOBBY_REQ { kind: 'takeSeat' | 'leaveSeat' | 'setName' | 'setColour' | 'setReady' | 'spectate' }`, `LOBBY_CONFIG { patch }` (host only), `LOBBY_KICK` (host only), `LOBBY_START` (host only, needs all humans ready).
38: 
39: Rules:
40: 
41: - Any config change resets every `ready` flag.
42: - Colours must be unique.
43: - 2–4 seats for base; 5–6 once the `five-six` module exists.
44: - Bot seats are hosted by the lobby host by default. The host can reassign a bot's host to another peer.
45: 
46: ## 2. Screens
47: 
48: 1. **Home**: Play online (create / join), Play local (stage 05), Settings, How to play, Rules variants reference.
49: 2. **Create game**: name, then choose the connection method:
50:    - "Invite link" (signaling server): shows a link, a copy button and a QR code.
51:    - "Offline codes" (manual): shows the offer QR/code per joiner, with the answer-code input.
52: 3. **Join**: route `join/$roomId` (`#/join/<room>`) auto-joins via the server; or paste/scan a code at `#/join`. Routes added in this stage: `online/create`, `join/index`, `join/$roomId`, `lobby/$lobbyId`, `game/$gameId` (the P2P game screen; `useBlocker` guard on leave).
53: 4. **Lobby**:
54:    - seat list with status, colour picker, ready toggle;
55:    - config panel (editable only by the host, read-only for others): player count, map layout, modules, all options (from each module's `optionsSchema`, rendered generically), VP target, timers, seed ("random" or a fixed hex for replaying a board);
56:    - chat;
57:    - connection diagnostics;
58:    - "Add bot" / "Open seat" / "Kick".
59: 5. **Starting**: a progress view of the ceremony steps (§3) with per-peer check marks and timeouts.
60: 6. Then the game screen (stage 05 UI with a `P2PSession`).
61: 
62: ## 3. Genesis ceremony
63: 
64: Run when the host presses Start (all humans ready, all connected in a full mesh). Every step is signed. Before local genesis consent, a step timeout (20 s) aborts the ceremony and returns to the lobby with an error. Retire that ceremony and use fresh secrets on retry. Once a client durably promises and signs an exact genesis digest, timeout cannot revoke the signature. It stays in a recoverable waiting state until that genesis is assembled or an agreed disposition resolves it.
65: 
66: 1. **Freeze**: the host broadcasts `CEREMONY_BEGIN { lobbyVersion, protocolVersion, engineVersion, config, seats, ceremonyNonce }`. Every peer checks it equals its lobby view and replies with a signed `FREEZE_ACK`.
67: 2. **Secrets**: each human seat (and each bot host, for each of its bots) generates `masterSecret`s. For each one it computes and publishes a `SeatCommitments` package:
68:    - `masterPub` and the encryption key `E` (stage 07 §1),
69:    - `beaconTip` (hash-chain tip, stage 07 §2),
70:    - `seedCommit = H("seed" ‖ seedShare)`, where `seedShare = HKDF(master, "genesis-seed")`,
71:    - deck lock public keys for the decks the config needs (or a compact commitment from which they're derivable; see stage 07 §3),
72:    - Feldman coefficient commitments and `escrowShareHashes[]` (stage 07 §7).
73: 3. **Escrow**, only when the game starts with at least four humans: send sealed Shamir shares via `PRIVATE`. Each recipient verifies its share against the Feldman commitments, then replies with a signed `SHARE_ACK { dealerSeat, H(share) }`. A bad share aborts the ceremony (stage 07 §7).
74: 4. **Seed reveal**: after every `seedCommit` is collected, each seat reveals `seedShare`. Then `genesisSeed = SHA-256("cp2p/genesis" ‖ seedShares in seat order)`. (The config may specify a fixed seed; then the commit-reveal is skipped and the seed is used as-is. Mark such games "fixed board".)
75: 5. **Deck setup**: before genesis consent, collect every ordered shuffle and lock pass for every configured deck. The canonical catalogue and all seat keys, including bots, come from the frozen manifest. The deck `ceremonyId` binds the protocol/engine versions, config, ordered seats and fresh 32-byte ceremony nonce. It excludes the later seed and transcript commitments to avoid a hash cycle. Persist each local pass before sending it. Every human must obtain and verify the complete transcript and final locked deck; missing or invalid passes abort the ceremony.
76: 6. **Genesis draft**: every peer builds the identical `Genesis` body:
77:    `{ protocolVersion, engineVersion, config, seats(with game keys, identity bindings, names, colours, kinds, botHosts), genesisSeed, ceremonyNonce, security: 'verified', commitments(including deck definitions, ordered signed-pass hashes, final locked-deck hashes, share acknowledgements and sealed shares), createdAt(host clock, informational) }`.
78:    Hash the body and derive the routing `gameId` exactly as defined in stage 06. Each human uses `prepareGenesisConsent` to verify the complete deck transcript and durably reserve one final genesis digest for this ceremony and seat before returning its signature. A retry returns the same consent; a redraft that changes the digest must begin a fresh ceremony. The body excludes its derived identifier and consent signatures. A fixed board still needs a fresh agreed ceremony nonce. Retain the exact public transcript blobs for setup completion after a restart; a hash list alone cannot prove availability or valid setup.
79:    The ceremony coordinator first records an irreversible `consenting` phase for that digest in the same device-global registry that orders aborts. From then on, local abort is refused. Later authenticated share disclosures are retained across restart for agreed handling; they do not erase the consent or silently allow normal gameplay. A valid signed genesis can complete local storage while its disclosure disposition remains pending. This boundary avoids a client retiring keys whose genesis signature peers can still use.
80: 7. **Start and certify decks**: seq 0 is genesis with all human signatures. The term 1 sequencer certifies the already-fixed passes individually as state-preserving `crypto/deck-pass` entries, each within the 256 KiB message cap including its proposal/certificate envelope. Certified proposer-exclusion controls may intervene without resetting the deck cursor. The first engine pending, `startSeat`, stays frozen at its genesis anchor. No human reveals a beacon link and no gameplay entry is accepted until every committed deck pass has been verified and certified.
81: 
82: Version compatibility: in `HELLO` and in step 1, peers compare `protocolVersion` (must be equal) and `engineVersion` (must be equal). Otherwise the joining peer sees "Your app version differs from the host's. Please reload (the host is on vX)." The service worker update flow (stage 18) must make "reload to update" reliable.
83: 
84: ## 4. Seat keys & bots
85: 
86: - A human gets a fresh voting/command key for each game, bound to the authenticated device identity during the ceremony. Persist that key together with the game's consensus safety records before signing genesis. Keep it independent of escrowed game secrets.
87: - A bot seat gets its own Ed25519 key generated by the bot host. The bot host signs bot commands with the bot key. The genesis records `botHost` so peers know which peer relays them.
88: - Bot move timing: add a humanlike delay (configurable 0.5–2 s) so bots don't act instantly.
89: 
90: ## 5. Turn timers in P2P
91: 
92: - Timer config lives in genesis. The **sequencer** tracks deadlines using the entry times it observes. When a deadline passes, the sequencer appends a `system` `TIMEOUT` entry whose evidence is `{ pendingSince: seq, deadlineMs }`.
93: - That evidence is outside the engine input. The input itself contains only `kind`, `type`, `seat`, and `phase`.
94: - Peers accept it if their own local clock agrees (with ±3 s tolerance) that the deadline has passed since they applied `pendingSince`. If they disagree, they reject it, and the sequencer retries later. Don't use absolute timestamps across devices; use each peer's own monotonic time since it applied the referenced entry.
95: - The UI timer ring uses local time since the referenced entry.
96: - Timeout auto-actions that need the timed-out seat's private data (e.g. discard) are computed by that seat's client if it's online (it submits the command itself when its own local timer expires). If it's offline, the action waits until takeover (stage 10).
97: 
98: ## 6. Chat & emotes
99: 
100: - `CHAT` messages are broadcast, signed and rate-limited (5 per 10 s), max 300 chars. They're not in the game log (not hashed), but are stored locally.
101: - A small set of quick emotes/reactions.
102: - Mute per player.
103: 
104: ## Steps
105: 
106: 1. Lobby state machine + messages + host handover (unit tests on memnet).
107: 2. Screens: home, create, join, lobby (with generic option rendering from `optionsSchema`).
108: 3. Ceremony implementation + memnet tests (including every abort path).
109: 4. Wire the `P2PSession` start from genesis. Game screen in P2P mode (own seat only; other hands hidden; waiting indicators showing who the game waits for, from `getPending`).
110: 5. Timers in P2P.
111: 6. Chat.
112: 7. Playwright: 3 browser contexts + 1 bot; create via link, join, configure, start, and play to the end with bots controlling all human seats through the `__cp2p` hook. Assert all contexts see the same winner and the audit passes.
113: 8. Manual test on real devices across networks (home Wi-Fi + mobile hotspot). Record the results in STATUS.md.
114: 
115: ## Acceptance criteria
116: 
117: - [ ] Create → invite → join → start → finish → audit ✓ works over the signaling server and over manual codes.
118: - [x] Mixed humans and bots work, and a guest peer can host a bot. The [hosted-bot terminal trace](verification/stage09/hosted-bot-v6-acceptance.md) verifies the full two-human/two-bot game and both audits; the [guest-hosted command trace](verification/stage09/guest-bot-consent-races-2026-09-28.md) certifies a bot command signed by a bot hosted on the other human peer and strictly replays it on both peers.
119: - [x] A version mismatch is detected with a clear message. The [signed-version UI check](verification/stage09/lobby-ceremony-ui-bridge.md) rejects incompatible protocol and engine versions and displays the host version without a start action.
120: - [x] Pre-consent ceremony abort and timeout paths retire the attempt and return a retired state to the lobby. The [timeout/disclosure integration checks](verification/stage09/ceremony-timeout-disclosure-check-2026-09-28.md) cover missing phases and UI restoration; the [cross-coordinator consent races](verification/stage09/guest-bot-consent-races-2026-09-28.md) prove durable retirement-first and consent-first outcomes.
121: - [x] A post-consent timeout preserves the signed promise and restores to a recoverable waiting state. The timeout/disclosure integration check retains the exact consent across restore and completes only when the missing signed packet arrives.
122: - [ ] An authenticated post-consent disclosure preserves the promise and returns to a recoverable waiting state. The current check proves durable preservation and a safely halted UI; it does not prove a post-disclosure recovery/resume path.
123: - [x] Turn timers work, and a disagreeing peer cannot be forced into an early timeout. The [signed timer traces](verification/stage10/timer-acceptance.md) cover early `preRoll` and trade timeout refusal at verified replicas; the [owner-private discard trace](verification/stage09/private-discard-timer-2026-09-28.md) proves no pre-expiry command and the owner's signed discard at local expiry.


SOURCE packages/protocol/src/online-ceremony.ts

754:   async #abortUnsafe(
755:     reason: RetirementReason = 'online-ceremony-retired',
756:     expected?: { phase: CeremonyStep; startedAt: number },
757:   ): Promise<Result<void>> {
758:     if (this.#disposed) return failure('online-ceremony-disposed', 'Ceremony is disposed');
759:     if (this.#locallyConsented || this.#result)
760:       return failure('online-ceremony-consented', 'An exact genesis consent cannot be revoked');
761:     let recordedReason = reason;
762:     let recordedPhase: OnlineCeremonyPhase = this.#progress.phase;
763:     let stale = false;
764:     const retired = await this.#attempt(async (record) => {
765:       if (
766:         expected &&
767:         (record.phase !== expected.phase || record.startedAt !== expected.startedAt)
768:       ) {
769:         stale = true;
770:         return success(undefined);
771:       }
772:       if (record.status === 'retired') {
773:         recordedReason = record.retiredReason ?? 'online-ceremony-retired';
774:         recordedPhase = record.retiredPhase ?? 'retired';
775:         return success(undefined);
776:       }
777:       recordedPhase = record.phase;
778:       const pinned = await this.#options.store.load(`online-manifest/${this.#attemptId}`);
779:       if (pinned) {
780:         const manifest = parseCanonical(
781:           canonicalDecode(pinned),
782:           v.omit(genesisSchema, ['gameId', 'signatures']),
783:         );
784:         if (
785:           !manifest.ok ||
786:           manifest.value.ceremonyNonce !== this.#nonce ||
787:           toHex(hashValue(manifest.value.config)) !== toHex(hashValue(this.#agreement.state.config))
788:         )
789:           return failure('online-ceremony-record', 'Pinned retirement manifest is invalid');
790:         const escrow = await new EscrowCeremony(manifest.value, this.#options.store).abort();
791:         if (!escrow.ok) return escrow;
792:       }
793:       const before = canonicalEncode(record);
794:       const after = canonicalEncode({
795:         ...record,
796:         status: 'retired',
797:         retiredReason: recordedReason,
798:         retiredPhase: recordedPhase,
799:       });
800:       const updated = await this.#options.store.compareAndSwap(
801:         `online-attempt/${this.#attemptId}`,
802:         before,
803:         after,
804:       );
805:       return updated
806:         ? success(undefined)
807:         : failure('online-ceremony-record', 'Attempt retirement lost its durable race');
808:     });
809:     if (retired.ok && !stale)
810:       this.#emit({
811:         phase: 'retired',
812:         awaitingSeats: [],
813:         error:
814:           recordedReason === 'online-ceremony-retired'
815:             ? recordedReason
816:             : `${recordedReason}:${recordedPhase}`,
817:         locallyConsented: false,
818:       });
819:     else if (
820:       !retired.ok &&
821:       (retired.error.code === 'escrow-ceremony-consenting' ||
822:         retired.error.code === 'escrow-ceremony-completed')
823:     ) {
824:       this.#locallyConsented = true;
825:       this.#emit({ phase: 'waiting', awaitingSeats: [], error: null, locallyConsented: true });
826:     }
827:     return retired;

943:   ): Promise<Result<void>> {
944:     if (record.status === 'retired')
945:       return failure('online-ceremony-retired', 'Ceremony attempt was durably retired');
946:     if (this.#restoreExpected && !this.#restoreValidated) return success(undefined);
947:     const manifest = slot.escrowManifest;
948:     if (!manifest) {
949:       if (!this.#locallyConsented && this.#phaseExpired(record.startedAt))
950:         return failure('online-ceremony-timeout', 'Ceremony phase expired before send');
951:       this.#broadcast(key, bytes, slot.escrowRecipients);
952:       return success(undefined);
953:     }
954:     try {
955:       return await this.#options.store.withCeremonyLock(deckCeremonyId(manifest), async () => {
956:         if (this.#disposed) return failure('online-ceremony-disposed', 'Ceremony is disposed');
957:         const active = await checkEscrowCeremonyActive(manifest, this.#options.store);
958:         if (!active.ok) {
959:           // Once this device has consented, signed genesis contains the complete
960:           // public escrow transcript. Earlier share traffic has no further role.
961:           if (
962:             active.error.code === 'escrow-ceremony-consenting' ||
963:             active.error.code === 'escrow-ceremony-completed'
964:           )
965:             return success(undefined);
966:           return active;
967:         }
968:         if (!this.#locallyConsented && this.#phaseExpired(record.startedAt))
969:           return failure('online-ceremony-timeout', 'Ceremony phase expired before send');
970:         this.#broadcast(key, bytes, slot.escrowRecipients);
971:         return success(undefined);
972:       });
973:     } catch {
974:       return failure('online-ceremony-store', 'Could not check escrow retirement before send');
975:     }
976:   }
977: 
978:   #checkedPayload<T>(packet: OnlineCeremonyPacket, slot: Slot<T>): Result<T> {
979:     if (
980:       packet.body.kind !== slot.kind ||
981:       packet.body.seat !== slot.seat ||
982:       packet.body.step !== slot.step ||
983:       packet.body.senderDevice !== slot.ownerDevice
984:     )
985:       return failure('online-ceremony-slot', 'Packet actor or phase differs from the frozen slot');
986:     return slot.validate(packet.body.payload);
987:   }
988: 
989:   async #outgoing<T>(slot: Slot<T>, key: string): Promise<Result<T>> {
990:     return this.#attempt(async (record) => {
991:       if (this.#disposed) return failure('online-ceremony-disposed', 'Ceremony is disposed');
992:       if (record.status === 'retired')
993:         return failure('online-ceremony-retired', 'Ceremony attempt was durably retired');
994:       const prior = await this.#options.store.load(key);
995:       if (prior !== null) {
996:         const packet = verifyOnlineCeremonyPacket(prior, this.#self, this.#freezeHash, this.#nonce);
997:         if (!packet.ok) return packet;
998:         const checked = this.#checkedPayload(packet.value, slot);
999:         if (!checked.ok) return checked;
1000:         if (slot.kind === 'consent') this.#locallyConsented = true;
1001:         if (!this.#locallyConsented && this.#phaseExpired(record.startedAt))
1002:           return failure('online-ceremony-timeout', 'Ceremony phase expired before output');
1003:         const sent = await this.#sendSlotWithinAttempt(slot, key, prior, record);
1004:         return sent.ok ? checked : sent;
1005:       }
1006:       if (!this.#locallyConsented && this.#phaseExpired(record.startedAt))
1007:         return failure('online-ceremony-timeout', 'Ceremony phase expired before output');
1008:       if (this.#restoreExpected)
1009:         return failure('online-ceremony-restore', 'Completed phase packet is missing');
1010:       if (!slot.produce)
1011:         return failure('online-ceremony-owner', 'Only the local owner may produce this slot');
1012:       const produced = await slot.produce();
1013:       if (!produced.ok) return produced;
1014:       if (!this.#locallyConsented && this.#phaseExpired(record.startedAt))
1015:         return failure('online-ceremony-timeout', 'Ceremony phase expired before signing');
1016:       const body: OnlineCeremonyPacket['body'] = {
1017:         protocol: 'online-ceremony-v1',
1018:         freezeHash: this.#freezeHash,
1019:         ceremonyNonce: this.#nonce,
1020:         senderDevice: this.#self,
1021:         kind: slot.kind,
1022:         seat: slot.seat,
1023:         step: slot.step,
1024:         payload: produced.value,
1025:       };
1026:       const signed = signOnlineCeremonyPacket(body, this.#deviceKey);
1027:       if (!signed.ok) return signed;
1028:       const checked = this.#checkedPayload(signed.value.packet, slot);
1029:       if (!checked.ok) return checked;
1030:       if (!this.#locallyConsented && this.#phaseExpired(record.startedAt))
1031:         return failure('online-ceremony-timeout', 'Ceremony phase expired before persistence');
1032:       if (this.#disposed) return failure('online-ceremony-disposed', 'Ceremony is disposed');
1033:       if (!(await this.#options.store.putIfAbsent(key, signed.value.bytes))) {
1034:         const winner = await this.#options.store.load(key);
1035:         if (!winner || !sameBytes(winner, signed.value.bytes))
1036:           return failure('online-ceremony-conflict', 'Another packet already owns this phase slot');
1037:       }
1038:       if (slot.kind === 'consent') this.#locallyConsented = true;
1039:       if (this.#disposed) return failure('online-ceremony-disposed', 'Ceremony is disposed');
1040:       const sent = await this.#sendSlotWithinAttempt(slot, key, signed.value.bytes, record);
1041:       return sent.ok ? checked : sent;
1042:     });
1043:   }
1044: 
1045:   async #exchange<T>(
1046:     phase: CeremonyStep,
1047:     slots: readonly Slot<T>[],
1048:   ): Promise<Result<readonly T[] | null>> {
1049:     const entered = await this.#enterPhase(phase);
1050:     if (!entered.ok) return entered;

1418: 
1419:   async #acceptDisputePacket(
1420:     packet: OnlineCeremonyPacket,
1421:     bytes: Uint8Array,
1422:   ): Promise<Result<void>> {
1423:     const manifest = this.#escrowManifest;
1424:     const escrow = this.#escrow;
1425:     if (!manifest || !escrow) return success(undefined);
1426:     const { seat: holderSeat, step: dealerSeat } = packet.body;
1427:     const roster = this.#escrowRosters.find((item) => item.dealer.seat === dealerSeat);
1428:     const holder = roster?.holders.find((item) => item.seat === holderSeat);
1429:     if (!roster?.eligible || !holder || this.#ownerDevice(holder.seat) !== packet.body.senderDevice)
1430:       return failure('online-ceremony-escrow', 'Dispute actor differs from frozen escrow holder');
1431:     const parsed = parseCanonical(packet.body.payload, disputedEscrowSchema);
1432:     if (!parsed.ok) return parsed;
1433:     const verifier = prepareEscrowVerifier(manifest);
1434:     if (!verifier.ok) return verifier;
1435:     const masters = validateGenesisMasters(manifest);
1436:     if (!masters.ok) return masters;
1437:     const master = masters.value.find((item) => item.seat === roster.dealer.seat);
1438:     if (!master) return failure('online-ceremony-escrow', 'Disputed dealer has no master');
1439:     const envelope = verifier.value.envelope(
1440:       parsed.value.envelope,
1441:       roster.dealer.seat,
1442:       master.masterPub,
1443:     );
1444:     if (!envelope.ok || envelope.value.body.holder.seat !== holder.seat)
1445:       return failure('online-ceremony-escrow', 'Dispute references another sealed share');
1446:     const verdict = verifyEscrowShareDispute(parsed.value.dispute, envelope.value, manifest);
1447:     if (
1448:       !verdict.ok ||
1449:       verdict.value.dispute.body.holderSeat !== holder.seat ||
1450:       verdict.value.dispute.body.dealerSeat !== roster.dealer.seat
1451:     )
1452:       return failure('online-ceremony-escrow', 'Dispute proof does not bind this delivery');
1453:     const bound = await this.#checkConsentedDisputeEnvelope(
1454:       manifest,
1455:       roster.dealer.seat,
1456:       holder.seat,
1457:       envelope.value,
1458:     );
1459:     if (!bound.ok) return bound;
1460:     const key = this.#packetKey('escrow-dispute', holder.seat, roster.dealer.seat);
1461:     const applied = await this.#attempt(async (record) => {
1462:       const prior = await this.#options.store.load(key);
1463:       if (prior !== null && !sameBytes(prior, bytes))
1464:         return failure('online-ceremony-conflict', 'Another dispute owns this slot');
1465:       if (prior === null && record.status === 'retired')
1466:         return failure('online-ceremony-retired', 'New dispute cannot enter a retired attempt');
1467:       if (prior === null && !(await this.#options.store.putIfAbsent(key, bytes))) {
1468:         const winner = await this.#options.store.load(key);
1469:         if (!winner || !sameBytes(winner, bytes))
1470:           return failure('online-ceremony-conflict', 'Another dispute owns this slot');
1471:       }
1472:       const disclosed = await escrow.receiveDispute(envelope.value, verdict.value.dispute);
1473:       if (!disclosed.ok && disclosed.error.code !== 'escrow-ceremony-consenting-dispute')
1474:         return disclosed;
1475:       if (!disclosed.ok) return success('consented' as const);
1476:       if (record.status !== 'retired') {
1477:         const before = canonicalEncode(record);
1478:         const after = canonicalEncode({ ...record, status: 'retired' });
1479:         if (
1480:           !(await this.#options.store.compareAndSwap(
1481:             `online-attempt/${this.#attemptId}`,
1482:             before,
1483:             after,
1484:           ))
1485:         )
1486:           return failure('online-ceremony-record', 'Dispute retirement lost its durable race');
1487:       }
1488:       return success('retired' as const);
1489:     });
1490:     if (!applied.ok) return applied;
1491:     this.#result = null;
1492:     this.#disclosureBytes.set(key, bytes.slice());
1493:     this.#broadcast(key, bytes);
1494:     if (applied.value === 'consented') {
1495:       this.#locallyConsented = true;
1496:       this.#emit({
1497:         phase: 'waiting',
1498:         awaitingSeats: [],
1499:         error: 'online-ceremony-disputed',
1500:         locallyConsented: true,
1501:       });
1502:     } else {
1503:       this.#emit({
1504:         phase: 'retired',
1505:         awaitingSeats: [],
1506:         error: 'online-ceremony-disputed',
1507:         locallyConsented: false,
1508:       });
1509:     }
1510:     return success(undefined);
1511:   }
1512: 
1513:   async #checkConsentedDisputeEnvelope(
1514:     manifest: GenesisBody,
1515:     dealerSeat: Seat,
1516:     holderSeat: Seat,
1517:     envelope: EscrowShareEnvelope,
1518:   ): Promise<Result<void>> {
1519:     const status = await checkEscrowCeremonyActive(manifest, this.#options.store);
1520:     if (status.ok || status.error.code === 'escrow-ceremony-retired') return success(undefined);
1521:     if (
1522:       status.error.code !== 'escrow-ceremony-consenting' &&
1523:       status.error.code !== 'escrow-ceremony-completed'
1524:     )
1525:       return status;
1526: 
1527:     let finalBody: GenesisBody;
1528:     if (this.#result) finalBody = this.#result.genesis;
1529:     else if (this.#restoreExpected) finalBody = this.#restoreExpected.genesis;
1530:     else {
1531:       let bytes: Uint8Array | null;
1532:       try {
1533:         bytes = await this.#options.store.load(`online-draft/${this.#attemptId}`);
1534:       } catch {
1535:         return failure('online-ceremony-store', 'Could not read the pinned consent draft');
1536:       }
1537:       if (!bytes)
1538:         return failure('online-ceremony-escrow', 'Consented ceremony has no pinned final draft');
1539:       if (bytes.byteLength > MAX_MESSAGE_BYTES)
1540:         return failure('online-ceremony-size', 'Pinned consent draft exceeds its size limit');
1541:       let parsed: Result<GenesisBody>;
1542:       try {
1543:         parsed = parseCanonical(
1544:           canonicalDecode(bytes),
1545:           v.omit(genesisSchema, ['gameId', 'signatures']),
1546:         );
1547:       } catch {
1548:         return failure('online-ceremony-record', 'Pinned consent draft is malformed');
1549:       }
1550:       if (!parsed.ok) return parsed;
1551:       finalBody = parsed.value;
1552:     }
1553: 
1554:     const transcript = validateGenesisEscrow(finalBody);
1555:     if (!transcript.ok) return transcript;
1556:     const expected = transcript.value
1557:       .find((dealer) => dealer.dealerSeat === dealerSeat)
1558:       ?.shares.find((share) => share.envelope.body.holder.seat === holderSeat)?.envelope;
1559:     if (!expected || escrowShareEnvelopeHash(expected) !== escrowShareEnvelopeHash(envelope))
1560:       return failure(
1561:         'online-ceremony-escrow',
1562:         'Post-consent dispute does not reference the pinned escrow delivery',
1563:       );
1564:     return success(undefined);
1565:   }
1566: 
1567:   async #publishLocalDispute(
1568:     manifest: GenesisBody,

1618:     for (const roster of this.#escrowRosters.filter((item) => item.eligible)) {
1619:       for (const holder of roster.holders) {
1620:         for (const kind of ['escrow-dispute', 'escrow-invalid'] as const) {
1621:           const key = this.#packetKey(kind, holder.seat, roster.dealer.seat);
1622:           // oxlint-disable-next-line no-await-in-loop -- Bounded fixed evidence slots precede new output.
1623:           const bytes = await this.#options.store.load(key);
1624:           if (!bytes) continue;
1625:           const owner = this.#ownerDevice(holder.seat);
1626:           if (!owner) return failure('online-ceremony-escrow', 'Disclosure owner is missing');
1627:           const packet = verifyOnlineCeremonyPacket(bytes, owner, this.#freezeHash, this.#nonce);
1628:           if (!packet.ok) return packet;
1629:           // oxlint-disable no-await-in-loop -- A saved disclosure must retire/pause before returning.
1630:           const handled =
1631:             kind === 'escrow-dispute'
1632:               ? await this.#acceptDisputePacket(packet.value, bytes)
1633:               : await this.#acceptInvalidPacket(packet.value, bytes);
1634:           // oxlint-enable no-await-in-loop
1635:           if (!handled.ok) return handled;
1636:           if (this.#disclosureBytes.has(key)) return success(true);
1637:         }
1638:       }
1639:     }
1640:     return success(false);
1641:   }

2507:   async #advance(): Promise<Result<void>> {
2508:     if (this.#disposed) return failure('online-ceremony-disposed', 'Ceremony is disposed');
2509:     if (this.#disclosureBytes.size > 0) {
2510:       for (const [key, bytes] of this.#disclosureBytes) this.#broadcast(key, bytes);
2511:       return success(undefined);
2512:     }
2513:     if (this.#progress.phase === 'retired')
2514:       return failure('online-ceremony-retired', 'Ceremony attempt was durably retired');
2515:     if (this.#result) {
2516:       const first = this.#result.genesis.seats.find((seat) => seat.kind === 'human');
2517:       if (first && this.#ownerDevice(first.seat) === this.#self) {
2518:         const key = this.#packetKey('genesis-entry', first.seat, 0);
2519:         const bytes = await this.#options.store.load(key);
2520:         if (bytes) this.#broadcast(key, bytes);
2521:       }
2522:       return success(undefined);
2523:     }
2524:     try {
2525:       const advanced = await this.#advancePhases();
2526:       if (!advanced.ok && advanced.error.code === 'online-ceremony-timeout') {
2527:         const retired = await this.#abortUnsafe('online-ceremony-timeout');
2528:         return retired.ok || (this.#locallyConsented && this.#progress.phase === 'waiting')
2529:           ? success(undefined)
2530:           : retired;
2531:       }
2532:       if (!advanced.ok && this.#locallyConsented && this.#progress.phase === 'waiting')
2533:         return success(undefined);
2534:       if (
2535:         !advanced.ok &&
2536:         this.snapshot().phase !== 'retired' &&
2537:         this.#progress.error !== 'online-ceremony-disputed' &&
2538:         this.#progress.error !== 'online-ceremony-escrow-invalid'
2539:       )
2540:         this.#emit({
2541:           phase: 'error',
2542:           awaitingSeats: [],
2543:           error: advanced.error.code,
2544:           locallyConsented: this.#locallyConsented,
2545:         });
2546:       return advanced;
2547:     } catch {
2548:       this.#emit({
2549:         phase: 'error',
2550:         awaitingSeats: [],
2551:         error: 'online-ceremony-internal',
2552:         locallyConsented: this.#locallyConsented,
2553:       });
2554:       return failure('online-ceremony-internal', 'Could not advance the frozen ceremony');
2555:     }
2556:   }
2557: 
2558:   async #advancePhases(): Promise<Result<void>> {
2559:     const created = await this.#exchange('frozen', [this.#createdAtSlot()]);
2560:     if (!created.ok) return created;
2561:     if (created.value === null) return success(undefined);
2562:     const createdAt = created.value[0]?.createdAt;
2563:     if (createdAt === undefined)
2564:       return failure('online-ceremony-time', 'Host creation timestamp is missing');
2565: 
2566:     const exchangedBindings = await this.#exchange('bindings', this.#bindingSlots());
2567:     if (!exchangedBindings.ok) return exchangedBindings;
2568:     if (exchangedBindings.value === null) return success(undefined);
2569:     const verified = verifyGameSeatBindings(this.#agreement, exchangedBindings.value);
2570:     if (!verified.ok) return verified;
2571:     const manifest = this.#buildManifest(verified.value, createdAt);
2572:     const pinned = await this.#persistObject(`online-manifest/${this.#attemptId}`, manifest);
2573:     if (!pinned.ok) return pinned;
2574:     this.#escrow ??= new EscrowCeremony(manifest, this.#options.store);
2575:     this.#escrowManifest = manifest;
2576:     if (!this.#restoreExpected) {
2577:       const status = await checkEscrowCeremonyActive(manifest, this.#options.store);
2578:       if (!status.ok && status.error.code === 'escrow-ceremony-retired')
2579:         return this.#abortUnsafe('online-ceremony-escrow-retired');
2580:     }
2581:     if (this.#restoreExpected) {
2582:       const completed = await checkEscrowCeremonyActive(manifest, this.#options.store);
2583:       if (completed.ok || completed.error.code !== 'escrow-ceremony-completed')
2584:         return failure('online-ceremony-restore', 'Certified escrow completion is missing');
2585:     }
2586:     const rosters = deriveEscrowRosters(manifest);
2587:     if (!rosters.ok) return rosters;
2588:     this.#escrowRosters = rosters.value;
2589:     const disclosure = await this.#resumeEscrowDisclosures();
2590:     if (!disclosure.ok) return disclosure;
2591:     if (disclosure.value) return success(undefined);
2592: 
2593:     const approvals = await this.#exchange('approvals', this.#approvalSlots(manifest));
2594:     if (!approvals.ok) return approvals;
2595:     if (approvals.value === null) return success(undefined);
2596:     const approved = verifyEscrowManifestApprovals(manifest, approvals.value);
2597:     if (!approved.ok) return approved;
2598: 
2599:     const escrow = rosters.value.some((roster) => roster.eligible)
2600:       ? await this.#escrowTranscript(manifest, approvals.value)
2601:       : success([] as readonly EscrowDealerCommitment[]);
2602:     if (!escrow.ok) return escrow;
2603:     if (escrow.value === null) return success(undefined);
2604: 
2605:     const beacons = await this.#exchange('beacon-tips', this.#beaconSlots(manifest));
2606:     if (!beacons.ok) return beacons;
2607:     if (beacons.value === null) return success(undefined);
2608: 
2609:     const seed = await this.#seedTranscript(manifest);
2610:     if (!seed.ok) return seed;
2611:     if (seed.value === null) return success(undefined);
2612: 
2613:     const transcripts = await this.#deckTranscripts(manifest);
2614:     if (!transcripts.ok) return transcripts;
2615:     if (transcripts.value === null) return success(undefined);
2616:     const retained = await this.#persistObject(
2617:       `online-transcripts/${this.#attemptId}`,
2618:       transcripts.value,
2619:     );
2620:     if (!retained.ok) return retained;
2621:     const finalBody = this.#finalBody(
2622:       manifest,
2623:       verified.value,
2624:       escrow.value,
2625:       beacons.value,
2626:       seed.value,
2627:       transcripts.value,
2628:     );
2629:     if (!finalBody.ok) return finalBody;
2630:     const pinnedDraft = await this.#persistObject(
2631:       `online-draft/${this.#attemptId}`,
2632:       finalBody.value,
2633:     );
2634:     if (!pinnedDraft.ok) return pinnedDraft;
2635: 
2636:     const consents = await this.#exchange(
2637:       'consent',
2638:       this.#consentSlots(finalBody.value, transcripts.value),
2639:     );
2640:     if (!consents.ok) return consents;
2641:     if (consents.value === null) return success(undefined);
2642:     const genesis: Genesis = {
2643:       ...finalBody.value,
2644:       gameId: genesisId(finalBody.value),
2645:       signatures: [...consents.value],
2646:     };
2647:     const entry = await this.#exchange('waiting', [this.#entrySlot(genesis, transcripts.value)]);
2648:     if (!entry.ok) return entry;
2649:     if (entry.value === null) return success(undefined);
2650:     const signedEntry = entry.value[0];
2651:     if (!signedEntry || !this.#escrow)
2652:       return failure('online-ceremony-genesis', 'Signed genesis entry is missing');
2653:     const complete = await this.#escrow.complete({
2654:       signedGenesisEntry: signedEntry,
2655:       transcripts: transcripts.value,
2656:       engine: this.#options.engine,
2657:     });
2658:     if (!complete.ok) return complete;
2659:     const retainedEntry = await this.#persistObject(`online-entry/${this.#attemptId}`, signedEntry);
2660:     if (!retainedEntry.ok) return retainedEntry;
2661:     const result: OnlineCeremonyResult = {
2662:       entry: signedEntry,
2663:       genesis,
2664:       transcripts: transcripts.value,
2665:       bindings: verified.value.bindings,
2666:     };
2667:     if (
2668:       this.#restoreExpected &&
2669:       !sameBytes(canonicalEncode(result), canonicalEncode(this.#restoreExpected))
2670:     )
2671:       return failure('online-ceremony-restore', 'Restored result differs from completed result');
2672:     this.#result = copy(result);
2673:     if (!this.#restoreExpected)
2674:       this.#emit({
2675:         phase: 'ready',
2676:         awaitingSeats: [],
2677:         error: null,
2678:         locallyConsented: this.#locallyConsented,
2679:       });
2680:     return success(undefined);
2681:   }
2682: }


SOURCE packages/protocol/src/escrow-ceremony.ts

307:   async consentAndSend(input: {
308:     body: GenesisBody;
309:     transcripts: readonly { deckId: string; passes: readonly SignedDeckPass[] }[];
310:     seat: Seat;
311:     signingKey: Uint8Array;
312:     send: CeremonySend<SeatSignature>;
313:   }): Promise<Result<SeatSignature>> {
314:     const body = copy(input.body);
315:     const transcripts = copy(input.transcripts);
316:     const key = input.signingKey.slice();
317:     const { seat, send } = input;
318:     try {
319:       return await this.#locked(async () => {
320:         const active = await this.#active();
321:         if (!active.ok && active.error.code !== 'escrow-ceremony-consenting') return active;
322:         if (deckCeremonyId(body) !== this.#ceremonyId)
323:           return failure('escrow-manifest-conflict', 'Consent differs from the frozen ceremony');
324:         const checked = signVerifiedGenesis(body, transcripts, seat, key);
325:         if (!checked.ok) return checked;
326:         const localDistribution = await checkEscrowLocalDistribution(
327:           this.#manifest,
328:           body,
329:           this.#store,
330:         );
331:         if (!localDistribution.ok) return localDistribution;
332:         const localAcks = await this.#checkAcceptedAcks(body);
333:         if (!localAcks.ok) return localAcks;
334:         const digest = genesisDigest(body);
335:         const reserved = await reserveEscrowGenesisConsent(this.#manifest, digest, this.#store);
336:         if (!reserved.ok) return reserved;
337:         const consent = await prepareGenesisConsent(body, transcripts, seat, key, this.#store);
338:         if (!consent.ok) return consent;
339:         const beforeSend = await reserveEscrowGenesisConsent(this.#manifest, digest, this.#store);
340:         if (!beforeSend.ok) return beforeSend;
341:         send(copy(consent.value));
342:         return consent;
343:       });
344:     } finally {
345:       key.fill(0);
346:     }
347:   }
348: 
349:   async #checkAcceptedAcks(body: GenesisBody): Promise<Result<void>> {
350:     const transcript = validateGenesisEscrow(body);
351:     if (!transcript.ok) return transcript;
352:     for (const dealer of transcript.value) {
353:       for (const { envelope, ack } of dealer.shares) {
354:         const id = `escrow-accepted/${this.#ceremonyId}/${dealer.dealerSeat}/${envelope.body.holder.seat}`;
355:         // oxlint-disable-next-line no-await-in-loop -- Each bounded local record is checked against the final draft before consent.
356:         const bytes = await this.#store.load(id);
357:         if (bytes === null) continue;
358:         const parsed = parseCanonical(canonicalDecode(bytes), acceptedSchema);
359:         if (
360:           !parsed.ok ||
361:           !sameBytes(canonicalEncode(parsed.value), bytes) ||
362:           parsed.value.envelopeHash !== escrowShareEnvelopeHash(envelope) ||


SOURCE packages/protocol/src/escrow-lifecycle.ts

517: export async function reserveEscrowGenesisConsent(
518:   localFrozenManifest: GenesisBody,
519:   digest: string,
520:   store: EscrowLifecycleStore,
521: ): Promise<Result<void>> {
522:   const checked = checkedManifest(localFrozenManifest);
523:   if (!checked.ok) return checked;
524:   const ceremonyId = deckCeremonyId(checked.value);
525:   // oxlint-disable no-await-in-loop -- Each durable CAS retry reads the preceding winner.
526:   for (let attempt = 0; attempt < 64; attempt += 1) {
527:     const loaded = await loadRegistry(store);
528:     if (!loaded.ok) return loaded;
529:     const { bytes, value } = loaded.value;
530:     if (value.retiredCeremonies.includes(ceremonyId))
531:       return failure('escrow-ceremony-retired', 'Retired ceremony cannot consent');
532:     if (value.completedCeremonies.some((item) => item.ceremonyId === ceremonyId))
533:       return failure('escrow-ceremony-completed', 'Completed ceremony cannot consent');
534:     const previous = value.consentingCeremonies.find((item) => item.ceremonyId === ceremonyId);
535:     if (previous)
536:       return previous.genesisDigest === digest
537:         ? success(undefined)
538:         : failure(
539:             'escrow-ceremony-consent-conflict',
540:             'Ceremony already consented to another genesis',
541:           );
542:     const encoded = encodeRegistry(
543:       {
544:         ...value,
545:         consentingCeremonies: [
546:           ...value.consentingCeremonies,
547:           { ceremonyId, genesisDigest: digest },
548:         ],
549:       },
550:       false,
551:     );
552:     if (!encoded.ok) return encoded;
553:     try {
554:       const won =
555:         bytes === null
556:           ? await store.putIfAbsent(REGISTRY_ID, encoded.value)
557:           : await store.compareAndSwap(REGISTRY_ID, bytes, encoded.value);
558:       if (won) return success(undefined);
559:     } catch {
560:       return failure('escrow-registry-write', 'Could not durably reserve genesis consent');
561:     }
562:   }
563:   // oxlint-enable no-await-in-loop
564:   return failure('escrow-registry-contention', 'Could not reserve genesis consent');
565: }
566: 
567: /**
568:  * Called only after the coordinator validates the signed genesis entry and all
569:  * deck transcripts. Retained envelopes must appear byte-exactly in genesis.
570:  */
571: export async function completeEscrowCeremony(
572:   localFrozenManifest: GenesisBody,
573:   certifiedGenesis: GenesisBody,
574:   digest: string,
575:   store: EscrowLifecycleStore,
576: ): Promise<Result<void>> {
577:   const local = checkedManifest(localFrozenManifest);
578:   if (!local.ok) return local;
579:   const certified = checkedManifest(certifiedGenesis);
580:   if (!certified.ok) return certified;
581:   const ceremonyId = deckCeremonyId(local.value);
582:   if (deckCeremonyId(certified.value) !== ceremonyId)
583:     return failure(
584:       'escrow-manifest-conflict',
585:       'Certified genesis differs from the frozen ceremony',
586:     );
587:   const transcript = validateGenesisEscrow(certified.value);
588:   if (!transcript.ok) return transcript;
589:   // oxlint-disable no-await-in-loop -- Each durable CAS retry reads the preceding winner.
590:   for (let attempt = 0; attempt < 64; attempt += 1) {
591:     const loaded = await loadRegistry(store);
592:     if (!loaded.ok) return loaded;
593:     const { bytes, value } = loaded.value;
594:     if (value.retiredCeremonies.includes(ceremonyId))
595:       return failure('escrow-ceremony-retired', 'Retired ceremony cannot complete');
596:     const completed = value.completedCeremonies.find((item) => item.ceremonyId === ceremonyId);
597:     if (completed)
598:       return completed.genesisDigest === digest
599:         ? success(undefined)
600:         : failure('escrow-ceremony-conflict', 'Ceremony already completed with another genesis');
601:     const consented = value.consentingCeremonies.find((item) => item.ceremonyId === ceremonyId);
602:     if (!consented || consented.genesisDigest !== digest)
603:       return failure('escrow-ceremony-consent', 'Certified genesis lacks matching local consent');
604:     const reservations = [...value.reservations];
605:     for (const [index, reservation] of reservations.entries()) {
606:       if (reservation.ceremonyId !== ceremonyId) continue;
607:       if (reservation.status !== 'active')
608:         return failure('escrow-ceremony-retired', 'A local master has been retired');
609:       const dealer = transcript.value.find((item) => item.dealerSeat === reservation.dealerSeat);
610:       if (!dealer || dealer.shares.length !== reservation.envelopes.length)
611:         return failure('escrow-ceremony-transcript', 'Local retained shares differ from genesis');
612:       for (let shareIndex = 0; shareIndex < dealer.shares.length; shareIndex += 1) {
613:         const retained = reservation.envelopes[shareIndex];
614:         const signed = dealer.shares[shareIndex];
615:         if (!retained || !signed || retained !== toBase64Url(canonicalEncode(signed.envelope)))
616:           return failure('escrow-ceremony-transcript', 'Local retained share differs from genesis');
617:       }
618:       reservations[index] = { ...reservation, status: 'completed', envelopes: [] };
619:     }
620:     const updated: EscrowRegistry = {
621:       ...value,
622:       reservations,
623:       completedCeremonies: [...value.completedCeremonies, { ceremonyId, genesisDigest: digest }],
624:     };
625:     const encoded = encodeRegistry(updated, false);
626:     if (!encoded.ok) return encoded;
627:     try {
628:       const won =
629:         bytes === null
630:           ? await store.putIfAbsent(REGISTRY_ID, encoded.value)
631:           : await store.compareAndSwap(REGISTRY_ID, bytes, encoded.value);
632:       if (won) return success(undefined);
633:     } catch {
634:       return failure('escrow-registry-write', 'Could not durably complete the ceremony');
635:     }
636:   }
637:   // oxlint-enable no-await-in-loop
638:   return failure(
639:     'escrow-registry-contention',
640:     'Could not complete the ceremony after concurrent updates',
641:   );
642: }
643: 

876: /** Verify authenticated disclosure evidence and durably abort before returning its verdict. */
877: export async function verifyAndRetireEscrowShareDispute(input: {
878:   readonly dispute: unknown;
879:   readonly envelope: unknown;
880:   readonly genesis: GenesisBody;
881:   readonly localFrozenManifest: GenesisBody;
882:   readonly store: EscrowLifecycleStore;
883: }): Promise<Result<EscrowDisputeVerdict>> {
884:   const checkedLocal = checkedManifest(input.localFrozenManifest);
885:   if (!checkedLocal.ok) return checkedLocal;
886:   const checkedCandidate = checkedManifest(input.genesis);
887:   if (!checkedCandidate.ok) return checkedCandidate;
888:   if (deckCeremonyId(checkedCandidate.value) !== deckCeremonyId(checkedLocal.value))
889:     return failure(
890:       'escrow-manifest-conflict',
891:       'Dispute genesis differs from the local frozen manifest',
892:     );
893:   const verdict = verifyEscrowShareDispute(input.dispute, input.envelope, checkedCandidate.value);
894:   if (!verdict.ok) return verdict;
895:   const retired = await retireEscrowCeremony(checkedLocal.value, input.store);
896:   if (!retired.ok) return retired;
897:   return verdict;
898: }
899: 
900: async function retireCeremonyAttempt(
901:   ceremonyId: string,
902:   masters: readonly { readonly seat: Seat; readonly masterPub: string }[],
903:   store: EscrowLifecycleStore,
904:   attempts: number,
905: ): Promise<Result<void>> {
906:   if (attempts >= 64)
907:     return failure(
908:       'escrow-registry-contention',
909:       'Could not retire the ceremony after concurrent updates',
910:     );
911:   const loaded = await loadRegistry(store);
912:   if (!loaded.ok) return loaded;
913:   const { bytes, value } = loaded.value;
914:   if (value.completedCeremonies.some((entry) => entry.ceremonyId === ceremonyId))
915:     return failure('escrow-ceremony-completed', 'Certified escrow ceremony cannot be retired');
916:   if (value.consentingCeremonies.some((entry) => entry.ceremonyId === ceremonyId))
917:     return failure(
918:       'escrow-ceremony-consenting',
919:       'A signed genesis cannot be revoked by retirement',
920:     );
921:   const alreadyRetired = value.retiredCeremonies.includes(ceremonyId);
922:   const reservations = [...value.reservations];
923:   for (const master of masters) {
924:     const index = reservations.findIndex(
925:       (reservation) => reservation.masterPub === master.masterPub,
926:     );
927:     const current = index < 0 ? undefined : reservations[index];
928:     if (current && current.ceremonyId !== ceremonyId) continue;
929:     const retired: Reservation = {
930:       protocol: RESERVATION_PROTOCOL,
931:       ceremonyId,
932:       masterPub: master.masterPub,
933:       dealerSeat: master.seat,
934:       status: 'retired',
935:       envelopes: [],
936:     };
937:     if (index < 0) reservations.push(retired);
938:     else if (current?.status === 'active' || current?.envelopes.length)
939:       reservations[index] = retired;


SOURCE apps/web/src/session/online-startup.ts

424:         engine: this.options.engine,
425:         ...(this.resume ? { restoreResult: this.resume.result } : {}),
426:         ...(!this.resume && approved.state.hostPeer === this.options.identity.peerId
427:           ? { hostCreatedAt: Math.floor(this.options.clock.now()) }
428:           : {}),
429:       });
430:       if (!created.ok) throw new Error(created.error.message);
431:       this.ceremony = created.value;
432:       this.unsubscribers.push(
433:         this.ceremony.onChange((progress) => {
434:           if (progress.locallyConsented && progress.error === 'online-ceremony-disputed') {
435:             this.haltDisputedGame();
436:             return;
437:           }
438:           if (this.revoked) return;
439:           if (this.activeGame || this.activationAttempted) return;
440:           this.update({
441:             ...progress,
442:             phase:
443:               progress.locallyConsented && progress.phase === 'consent'
444:                 ? 'waiting'
445:                 : progress.phase,
446:             gameId: this.resume?.gameId ?? null,
447:           });
448:           this.observe();
449:         }),
450:       );
451:       const started = await this.ceremony.start();
452:       if (!started.ok) {
453:         // The coordinator emits this only after reading or persisting retirement.
454:         // Preserve that durable disposition instead of offering a generic retry.
455:         const progress = this.ceremony.snapshot();
456:         if (progress.phase === 'retired') {
457:           this.update({ ...progress, gameId: this.resume?.gameId ?? null });
458:           return;
459:         }
460:         throw new Error(started.error.message);
461:       }
462:       await this.ceremony.flush();
463:     }
464:     const result = this.ceremony.result();
465:     if (this.closed || this.revoked || !result || this.activationAttempted) return;
466:     if (this.resume && !sameBytes(canonicalEncode(result), canonicalEncode(this.resume.result)))
467:       throw new Error('Restored ceremony differs from the saved certified game');
468:     if (!this.material) throw new Error('Owned game material is unavailable');
469:     this.activationAttempted = true;
470:     this.update({
471:       phase: 'opening',
472:       awaitingSeats: [],
473:       locallyConsented: true,
474:       error: null,
475:       gameId: result.genesis.gameId,
476:     });
477:     if (!this.resume)
478:       await saveOnlineGameRecord(this.options.store, {
479:         invite: this.invite,
480:         agreement: this.approved,
481:         result,
482:       });
483:     if (this.closed || this.revoked) return;
484:     const game = await openOnlineGame(
485:       {
486:         ...result,
487:         agreement: this.approved,
488:         material: this.material.keys,
489:         deviceTransport: this.options.transport,
490:         store: this.options.store,
491:         clock: this.options.clock,
492:         engine: this.options.engine,
493:         signal: this.abort.signal,
494:         ...(this.options.onGameFatal ? { onFatal: this.options.onGameFatal } : {}),
495:         ...(this.options.onDeviceRoutes ? { onDeviceRoutes: this.options.onDeviceRoutes } : {}),
496:         ...(this.resume ? { journalMode: 'restore-only' as const } : {}),
497:       },
498:       this.options.gameRuntime,
499:     );
500:     if (this.closed || this.revoked) {
501:       await game.close();
502:       return;
503:     }
504:     this.activeGame = game;
505:     this.material.dispose();
506:     this.material = null;
507:     this.update({
508:       phase: 'playing',
509:       awaitingSeats: [],
510:       locallyConsented: true,
511:       error: null,
512:       gameId: game.gameId,
513:     });
514:   }
515: 
516:   private async openTransferredResume(): Promise<void> {
517:     const resume = this.resume;
518:     const material = this.material;
519:     const agreement = this.approved;
520:     if (!resume || !material || !agreement || this.closed || this.revoked)
521:       throw new Error('Transferred resume is incomplete');
522:     this.activationAttempted = true;
523:     this.update({
524:       phase: 'opening',
525:       awaitingSeats: [],
526:       locallyConsented: true,
527:       error: null,
528:       gameId: resume.gameId,
529:     });
530:     const game = await openOnlineGame(
531:       {
532:         ...resume.result,
533:         agreement,
534:         material: material.keys,
535:         deviceTransport: this.options.transport,
536:         store: this.options.store,
537:         clock: this.options.clock,
538:         engine: this.options.engine,
539:         signal: this.abort.signal,
540:         journalMode: 'restore-only',
541:         ...(this.options.onGameFatal ? { onFatal: this.options.onGameFatal } : {}),
542:         ...(this.options.onDeviceRoutes ? { onDeviceRoutes: this.options.onDeviceRoutes } : {}),
543:       },
544:       this.options.gameRuntime,
545:     ).finally(() => {
546:       material.dispose();
547:       if (this.material === material) this.material = null;
548:     });
549:     if (this.closed || this.revoked) {
550:       await game.close();
551:       return;
552:     }
553:     this.activeGame = game;
554:     this.update({
555:       phase: 'playing',
556:       awaitingSeats: [],
557:       locallyConsented: true,
558:       error: null,
559:       gameId: resume.gameId,
560:     });
561:   }
562: 
563:   private haltDisputedGame(): void {
564:     if (this.closed || this.revoked) return;
565:     this.revoked = true;
566:     // The coordinator has authenticated a secret disclosure, including after genesis.
567:     // Stop game output synchronously; preserve its public board and durable evidence.
568:     this.abort.abort();
569:     this.activeGame?.session.dispose();
570:     this.stoppingGame = this.activeGame?.close() ?? null;
571:     // close() will surface cleanup errors to the room owner after draining its work.
572:     void this.stoppingGame?.catch(() => undefined);
573:     if (this.retry !== null) this.options.clock.clearTimeout(this.retry);
574:     this.retry = null;
575:     this.update({
576:       phase: 'halted',
577:       awaitingSeats: [],
578:       locallyConsented: true,
579:       error: 'online-ceremony-disputed',
580:       gameId: this.activeGame?.gameId ?? this.current?.gameId ?? null,
581:     });
582:   }
583: 
584:   private async pin(id: string, value: unknown): Promise<void> {
585:     const bytes = canonicalEncode(value);


SOURCE packages/protocol/src/recovery-membership.ts

280:     : activate(parsed.value, entry, prepared, current, history, pending, carried.value);
281: }
282: 
283: function certifyVoid(
284:   change: RecoveryVoid,
285:   entry: LogEntry,
286:   context: LogContext & { crypto: CryptoContext },
287:   current: SeatAuthorities,
288:   history: RecoveryState,
289:   pending: AuthorizedRecovery | undefined,
290: ): Result<RecoveryTransition> {
291:   const statement = change.statement;
292:   if (
293:     !pending ||
294:     !same(statement.authorization, pending.entry) ||
295:     !pending.statement.replacements.some(({ seat }) => seat === statement.dealerSeat)
296:   )
297:     return failure('recovery-void-authorization', 'Void must name a pending affected dealer');
298:   const recoverers = current.controllers
299:     .filter((item) => item.kind === 'human' && item.status === 'active')
300:     .map(({ seat, publicKey }) => ({ seat, publicKey }));
301:   if (
302:     !same(recoverers, pending.statement.recoverers) ||
303:     !signedByAll(RECOVERY_VOID_DOMAIN, statement, change.checks, recoverers)
304:   )
305:     return failure('recovery-void-check', 'Every named current recoverer must attest to the void');
306:   if (
307:     entry.stateHash !== context.head.stateHash ||
308:     toHex(hashValue(context.state)) !== context.head.stateHash
309:   )
310:     return failure('recovery-void-state', 'Void must preserve the certified engine state');
311:   return success({
312:     authority: current,
313:     recovery: {
314:       ...history,
315:       pending: null,
316:       void: {
317:         entry: ref(entry),
318:         authorization: pending.entry,
319:         dealerSeat: statement.dealerSeat,
320:         reason: statement.reason,
321:       },
322:     },
323:     crypto: context.crypto,
324:     state: context.state,
325:     input: null,
326:   });
327: }
328: 
329: function authorize(
330:   change: Extract<RecoveryChange, { kind: 'recovery-authorize' }>,
331:   entry: LogEntry,
332:   context: LogContext & { crypto: CryptoContext },


SOURCE packages/protocol/src/recovery-void.ts

79:       return failure('recovery-void-shares', 'Void needs a bounded set of authorized shares');
80:     const releases = input.releases.map((release) =>
81:       v.parse(recoveryReleaseSchema, canonicalDecode(canonicalEncode(release))),
82:     );
83:     signingKey = new Uint8Array(input.signingKey);
84:     const record = await journal.load();
85:     const parent = record && journalHead(record);
86:     if (!record || !parent)
87:       return failure('recovery-void-journal', 'Certified journal or safety height is missing');
88:     const replayed = replayCertifiedPrefix(record.genesis, record.entries, engine, policy);
89:     if (!replayed.ok) return replayed;
90:     const context = replayed.value.context.log;
91:     const pending = context.recovery?.pending;
92:     const authorization = context.recovery?.authorizations.at(-1);
93:     if (
94:       !pending ||
95:       !authorization ||
96:       !sameRef(pending, authorization.entry) ||
97:       !context.authority ||
98:       !context.crypto ||
99:       context.recovery?.void
100:     )
101:       return failure('recovery-void-pending', 'Latest certified authorization is unavailable');
102:     const recoverers = context.authority.controllers
103:       .filter((item) => item.kind === 'human' && item.status === 'active')
104:       .map(({ seat, publicKey }) => ({ seat, publicKey }));
105:     const local = recoverers.find(({ seat }) => seat === localSeat);
106:     if (
107:       !local ||
108:       recoverers.length !== authorization.statement.recoverers.length ||
109:       recoverers.some((item, index) => {
110:         const expected = authorization.statement.recoverers[index];
111:         return item.seat !== expected?.seat || item.publicKey !== expected.publicKey;
112:       }) ||
113:       context.authority.epoch !== context.crypto.epoch
114:     )
115:       return failure('recovery-void-recoverer', 'Local controller is not an exact recoverer');
116:     const identity = identityFromSecret(signingKey);
117:     try {
118:       if (identity.peerId !== local.publicKey)
119:         return failure('recovery-void-key', 'Signing key is not the current recoverer');
120:     } finally {
121:       identity.secretKey.fill(0);
122:     }
123:     const affected = authorization.statement.replacements.map(({ seat }) => seat);
124:     if (releases.some(({ body }) => !affected.includes(body.dealerSeat)))
125:       return failure('recovery-void-shares', 'Release belongs to an unaffected dealer');
126:     for (const seat of affected) {
127:       const recovered = recoverAuthorizedMaster(
128:         releases.filter(({ body }) => body.dealerSeat === seat),
129:         context,
130:         seat,
131:         localSeat,
132:         recipientEncryptionSecret,
133:       );
134:       if (!recovered.ok) return recovered;
135:       secrets.push({ seat, master: recovered.value });
136:     }
137:     const rebuilt = reconstructPrivateSeats({
138:       genesisEntry: record.genesis,
139:       entries: record.entries,
140:       engine,
141:       policy,
142:       secrets,
143:     });
144:     if (rebuilt.ok) {
145:       rebuilt.value.dispose();
146:       return failure('recovery-void-unproven', 'Private reconstruction did not find a mismatch');
147:     }
148:     if (!isVoidReason(rebuilt.error.code))
149:       return failure('recovery-void-unproven', 'Private reconstruction failed for another reason');
150:     let dealerSeat: Seat | null = null;
151:     for (const { seat, master } of secrets) {
152:       const checked = verifyRevealedMaster(context.genesis, context.crypto.decks, seat, master);
153:       if (!checked.ok) {
154:         if (!isVoidReason(checked.error.code))
155:           return failure('recovery-void-unproven', 'Master verification failed for another reason');
156:         if (dealerSeat === null && checked.error.code === rebuilt.error.code) dealerSeat = seat;
157:       }
158:     }
159:     if (dealerSeat === null)
160:       return failure('recovery-void-unproven', 'No affected dealer has a derived-key mismatch');
161:     const statement: RecoveryVoidStatement = {
162:       genesisDigest: genesisDigest(context.genesis),
163:       parent,
164:       authorization: pending,
165:       dealerSeat,
166:       reason: rebuilt.error.code,
167:     };
168:     const signed: SignedRecoveryVoidCheck = {
169:       statement,
170:       check: { seat: localSeat, sig: signObject(RECOVERY_VOID_DOMAIN, statement, signingKey) },
171:     };
172:     const bytes = canonicalEncode(signed);
173:     // Activation and void share one immutable slot: concurrent callers cannot
174:     // sign contradictory outcomes for the same certified parent.
175:     const slot = `recovery-check/${context.genesis.gameId}/${pending.seq}-${pending.hash}/${parent.seq}-${parent.hash}/${localSeat}`;
176:     if (!(await store.putIfAbsent(slot, bytes))) {
177:       const previous = await store.load(slot);
178:       if (
179:         !previous ||
180:         previous.byteLength > MAX_MESSAGE_BYTES ||
181:         previous.byteLength !== bytes.byteLength ||
182:         !bytes.every((byte, index) => byte === previous[index])
183:       )
184:         return failure('recovery-void-conflict', 'A different check occupies this immutable slot');
185:     }
186:     const latest = await journal.load();
187:     const latestParent = latest && journalHead(latest);
188:     if (
189:       !latest ||
190:       !latestParent ||
191:       !sameRef(parent, latestParent) ||
192:       latest.height !== record.height ||
193:       entryHash(latest.genesis) !== entryHash(record.genesis)
194:     )
195:       return failure('recovery-void-stale', 'Certified head advanced during void verification');
196:     return success(signed);
197:   } catch {
198:     return failure('recovery-void-unavailable', 'Could not verify or persist the void check');
199:   } finally {
